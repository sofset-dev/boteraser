<?php
/**
 * Boteraser extended protection — pre-WordPress enforcement entry.
 *
 * Loaded via auto_prepend_file (through the boteraser-waf.php loader written to
 * the site root by includes/prepend-installer.php), so it runs before WordPress
 * on every PHP request — the same mechanism as Wordfence "extended" mode.
 *
 * Scope is deliberately the DB-free hard paths only:
 *   - the blocked-ips cache (repeat offenders 403 before WP even loads)
 *   - the compiled blacklists (whitelist bypass respected)
 * Grey/rate-limit counting needs the DB / object cache and therefore stays in
 * the plugin phase (bot_eraser_immediate_check), which still runs unchanged.
 *
 * Availability first: any failure here must stay silent and let the request
 * continue into WordPress.
 */
if (defined('ABSPATH') || defined('BOT_ERASER_PREPEND') || PHP_SAPI === 'cli') {
    return;
}
define('BOT_ERASER_PREPEND', true);

function bot_eraser_prepend_run(): void {
    require_once __DIR__ . '/includes/helpers.php';
    require_once __DIR__ . '/includes/list-match.php';

    // Parity with bot_eraser_immediate_check(): skip admin/login and logged-in users.
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    if (strpos($uri, '/wp-admin') !== false || strpos($uri, '/wp-login.php') !== false) {
        return;
    }
    foreach ($_COOKIE as $name => $value) {
        if (strpos($name, 'wordpress_logged_in_') === 0) {
            return;
        }
    }

    $ip = bot_eraser_get_visitor_ip();
    if ($ip === '' || $ip === '0.0.0.0' || bot_eraser_is_self_ip($ip)) {
        return;
    }

    // Already-blocked cache. The FIRST re-entry of a blocked IP is deferred to
    // the plugin phase so the JA4 capture (needs the WP HTTP API for signal
    // pairing) still happens exactly once; every later hit 403s here, pre-WP.
    $file = bot_eraser_list_blocked_path();
    if (is_file($file)) {
        $blocked = include $file;
        if (is_array($blocked) && isset($blocked[$ip]) && time() < $blocked[$ip]) {
            if (bot_eraser_ja4_done($ip)) {
                bot_eraser_hit_incr($ip);
                bot_eraser_list_deny();
            }
            return; // let WordPress run the capture path once
        }
    }

    // Threat lists: whitelist bypass -> blacklists (403 now). The grey/rate
    // loops are skipped automatically because bot_eraser_rate_hit (DB-backed)
    // is not loaded in the prepend phase.
    bot_eraser_enforce_lists($ip, $_SERVER['HTTP_USER_AGENT'] ?? '');
}

try {
    bot_eraser_prepend_run();
} catch (\Throwable $e) {
    // Never break the site from the prepend phase.
}
