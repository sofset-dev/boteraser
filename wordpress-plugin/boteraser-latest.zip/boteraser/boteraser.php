<?php
/*
Plugin Name: Boteraser
Plugin URI: https://boteraser.com
Description: Powerful WordPress security plugin by Sofset that blocks harmful bots, brute-force attacks, and DDoS threats using continuously updated threat intelligence.
Version: 1.0.0
Author: Sofset
Author URI: https://sofset.com
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/
if (!defined('ABSPATH')) {
    exit;
}

// Immediate IP block check - runs before anything else
function bot_eraser_immediate_check() {
    // Skip for wp-admin and wp-login
    if (strpos($_SERVER['REQUEST_URI'], '/wp-admin') !== false || 
        strpos($_SERVER['REQUEST_URI'], '/wp-login.php') !== false) {
        return;
    }

    // Get real visitor IP
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? // Cloudflare
          $_SERVER['HTTP_TRUE_CLIENT_IP'] ?? // Akamai and others
          $_SERVER['HTTP_X_REAL_IP'] ?? // Nginx proxy
          $_SERVER['HTTP_X_FORWARDED_FOR'] ?? // Standard proxy header
          $_SERVER['HTTP_X_FORWARDED'] ?? // Some proxy variants
          $_SERVER['HTTP_FORWARDED_FOR'] ?? // RFC 7239
          $_SERVER['HTTP_FORWARDED'] ?? // RFC 7239
          $_SERVER['HTTP_VIA'] ?? // Via proxy
          $_SERVER['HTTP_CLIENT_IP'] ?? // Client IP
          $_SERVER['HTTP_X_CLIENT_IP'] ?? // Some CDNs
          $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'] ?? // Load balancers
          $_SERVER['REMOTE_ADDR'] ?? // Direct IP
          '0.0.0.0';
    
    $ip = explode(',', $ip)[0];
    $ip = filter_var(trim($ip), FILTER_VALIDATE_IP) ?: '0.0.0.0';

    // Check file cache only (no WordPress functions needed)
    $cache_file = __DIR__ . '/includes/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
        if (isset($blocked_ips[$ip]) && time() < $blocked_ips[$ip]) {
            http_response_code(403);
            header('HTTP/1.1 403 Forbidden');
            header('Status: 403 Forbidden');
            header('Retry-After: 3600');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            die('403 Forbidden - Access Denied');
        }
    }
}

// Run immediate check
bot_eraser_immediate_check();

// Continue with rest of plugin code

// Define plugin constants
define('BOT_ERASER_VERSION', '1.0');
define('BOT_ERASER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BOT_ERASER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BOT_ERASER_SERVER_URL', 'https://user.boteraser.com/srv/be-server.php');
define('BOT_ERASER_LOG_PATH', BOT_ERASER_PLUGIN_DIR . 'logs/access.log');

// Include necessary files
// Helpers.php removed - unused functions, hash function moved to admin-settings.php
require_once BOT_ERASER_PLUGIN_DIR . 'includes/log-handler.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/server-communication.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/ip-blocker.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/logs.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/admin-settings.php';

// Register activation/deactivation hooks
register_activation_hook(__FILE__, 'bot_eraser_activate');
register_deactivation_hook(__FILE__, 'bot_eraser_deactivate');

// Register uninstall hook - WordPress will call this when plugin is deleted
register_uninstall_hook(__FILE__, 'bot_eraser_uninstall');

/**
 * Plugin activation handler
 */
function bot_eraser_activate() {
    // Create log file if missing
    if (!file_exists(BOT_ERASER_LOG_PATH)) {
        bot_eraser_create_log_file();
    }
    
    // Schedule cron job
    if (!wp_next_scheduled('bot_eraser_cron_hook')) {
        wp_schedule_event(time(), '5min', 'bot_eraser_cron_hook');
    }
}

/**
 * Plugin deactivation handler
 */
function bot_eraser_deactivate() {
    // Clear cron schedule
    wp_clear_scheduled_hook('bot_eraser_cron_hook');
    
    // Clean up temporary transients (but keep settings for reactivation)
    delete_transient('bot_eraser_process_data');
    
    // Log deactivation
    error_log('Boteraser: Plugin deactivated - cron jobs cleared, temporary data removed');
}

/**
 * Plugin uninstall handler
 * 
 * This function is called when the plugin is being uninstalled (deleted).
 * It removes ALL plugin data including settings, ensuring a clean uninstall.
 * Users will need to reconfigure the plugin if they reinstall it.
 */
function bot_eraser_uninstall() {
    // Only run if this is an actual uninstall request
    if (!defined('WP_UNINSTALL_PLUGIN')) {
        return;
    }
    
    // Clean up all plugin data
    bot_eraser_cleanup_all_data();
}

/**
 * Clean up all plugin data (options, transients, cron jobs, files)
 * 
 * This function removes all traces of the plugin from WordPress:
 * - WordPress options (API key, host IP, domain, validation state)
 * - Transients (blocked IPs cache, temporary data)
 * - Cron jobs (scheduled tasks)
 * - Plugin files (logs, cached data)
 * - Object cache entries
 * 
 * After this runs, it's as if the plugin was never installed.
 */
function bot_eraser_cleanup_all_data() {
    // Clean up WordPress options
    $options_to_delete = [
        'bot_eraser_api_key',
        'bot_eraser_host_ip',
        'bot_eraser_domain',
        'bot_eraser_api_validation_state'
    ];
    
    foreach ($options_to_delete as $option) {
        delete_option($option);
        delete_site_option($option); // Also remove from multisite if applicable
    }
    
    // Clear from object cache as well
    if (function_exists('wp_cache_delete')) {
        foreach ($options_to_delete as $option) {
            wp_cache_delete($option, 'options');
            wp_cache_delete($option, 'default');
        }
    }
    
    // Clean up WordPress transients
    $transients_to_delete = [
        'bot_eraser_blocked_ips',
        'bot_eraser_api_key',
        'bot_eraser_process_data'
    ];
    
    foreach ($transients_to_delete as $transient) {
        delete_transient($transient);
        delete_site_transient($transient); // Also remove from multisite if applicable
    }
    
    // Clean up WordPress cron jobs
    wp_clear_scheduled_hook('bot_eraser_cron_hook');
    
    // Remove any remaining cron entries (in case of multiple schedules)
    $cron_array = get_option('cron');
    if (is_array($cron_array)) {
        foreach ($cron_array as $timestamp => $cron) {
            if (isset($cron['bot_eraser_cron_hook'])) {
                unset($cron_array[$timestamp]['bot_eraser_cron_hook']);
                if (empty($cron_array[$timestamp])) {
                    unset($cron_array[$timestamp]);
                }
            }
        }
        update_option('cron', $cron_array);
    }
    
    // Clean up plugin files
    $log_path = BOT_ERASER_LOG_PATH;
    if (file_exists($log_path)) {
        unlink($log_path);
    }
    
    $blocked_ips_path = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    if (file_exists($blocked_ips_path)) {
        unlink($blocked_ips_path);
    }
    
    // Remove logs directory if empty
    $logs_dir = BOT_ERASER_PLUGIN_DIR . 'logs/';
    if (is_dir($logs_dir)) {
        $files = scandir($logs_dir);
        // Check if directory is empty (only contains . and ..)
        if (count($files) == 2) {
            rmdir($logs_dir);
        }
    }
    
    // Clear any remaining object cache
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
    
    // Log the cleanup (this will go to WordPress debug log if enabled)
    error_log('Boteraser: Plugin uninstalled and all data cleaned up successfully');
}

/**
 * Debug function to show what data would be removed during uninstall
 * This is useful for administrators to understand the cleanup scope
 */
function bot_eraser_get_cleanup_preview() {
    $cleanup_data = [
        'options' => [],
        'transients' => [],
        'cron_jobs' => [],
        'files' => []
    ];
    
    // Check which options exist
    $options_to_check = [
        'bot_eraser_api_key',
        'bot_eraser_host_ip',
        'bot_eraser_domain',
        'bot_eraser_api_validation_state'
    ];
    
    foreach ($options_to_check as $option) {
        if (get_option($option) !== false) {
            $cleanup_data['options'][] = $option;
        }
    }
    
    // Check which transients exist
    $transients_to_check = [
        'bot_eraser_blocked_ips',
        'bot_eraser_api_key',
        'bot_eraser_process_data'
    ];
    
    foreach ($transients_to_check as $transient) {
        if (get_transient($transient) !== false) {
            $cleanup_data['transients'][] = $transient;
        }
    }
    
    // Check which cron jobs exist
    if (wp_next_scheduled('bot_eraser_cron_hook')) {
        $cleanup_data['cron_jobs'][] = 'bot_eraser_cron_hook';
    }
    
    // Check which files exist
    $files_to_check = [
        BOT_ERASER_LOG_PATH,
        BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php'
    ];
    
    foreach ($files_to_check as $file) {
        if (file_exists($file)) {
            $cleanup_data['files'][] = basename($file);
        }
    }
    
    return $cleanup_data;
}

/**
 * Add custom cron interval
 */
add_filter('cron_schedules', 'bot_eraser_add_cron_interval');
function bot_eraser_add_cron_interval($schedules) {
    $schedules['5min'] = [
        'interval' => 300, // 300 seconds = 5 minutes
        'display'  => esc_html__('Every 5 Minutes', 'bot-eraser')
    ];
    return $schedules;
}

/**
 * Hook cron job to data sender
 */
add_action('bot_eraser_cron_hook', 'bot_eraser_send_data_to_server');

/**
 * Log visitor access on every page load
 */
add_action('init', 'bot_eraser_log_visitor');

/**
 * Check if IP is blocked on each request (including index.php)
 */

/**
 * Admin interface styling
 */
add_action('admin_head', function() {
    if (isset($_GET['page']) && (
        $_GET['page'] === 'bot-eraser' || 
        $_GET['page'] === 'bot-eraser-blocked-ips' ||
        $_GET['page'] === 'bot-eraser-logs'
    )) {
        ?>
        <style>
            /* General Layout & Spacing */
            .wrap {
                margin-top: 20px;
            }
            .boteraser-content-wrapper {
                display: grid;
                grid-template-columns: minmax(0, 2fr) minmax(0, 1fr); /* Allow shrinking */
                gap: 30px;
                margin-top: 30px;
                align-items: start;
            }
            @media screen and (max-width: 960px) {
                .boteraser-content-wrapper {
                    grid-template-columns: 1fr; /* Stack columns on smaller screens */
                }
                .boteraser-info-panel {
                    position: static; /* Remove sticky positioning */
                }
            }

            /* Header Styles */
            .boteraser-header {
                display: flex;
                align-items: center;
                gap: 15px;
                padding-bottom: 20px;
                border-bottom: 1px solid #ddd;
                margin-bottom: 30px;
            }
            .boteraser-logo {
                height: 48px; /* Slightly smaller logo */
                width: auto;
            }
            /* Removed .boteraser-header-text as it wasn't used */

            /* Card Styles (Settings, Info, Results) */
            .boteraser-settings-card,
            .boteraser-info-card,
            .boteraser-results {
                background: #fff;
                border: 1px solid #ddd;
                border-radius: 4px; /* Standard WP radius */
                padding: 25px;
                margin-bottom: 25px;
                box-shadow: 0 1px 1px rgba(0,0,0,0.04); /* Softer WP shadow */
            }
            .boteraser-execution-section {
                 margin-top: 30px; /* Space above manual execution */
            }
            .boteraser-execution-section h2 {
                 margin-bottom: 15px; /* Space below heading */
                 font-size: 20px;
            }

            /* Info Panel Specific */
            .boteraser-info-panel {
                position: sticky;
                top: 50px; /* Adjust for WP admin bar */
            }
            .boteraser-info-card h3 {
                margin: 0 0 15px;
                display: flex;
                align-items: center;
                gap: 8px; /* Slightly smaller gap */
                font-size: 16px; /* Slightly smaller heading */
                color: #2c3338;
            }
            .boteraser-info-card ul,
            .boteraser-info-card ol {
                margin: 15px 0 0; /* Remove bottom margin */
                padding-left: 25px;
                color: #50575e;
            }
            .boteraser-info-card li {
                margin-bottom: 10px;
                /* display: flex; align-items: center; gap: 8px; */ /* Removed flex for standard list look */
            }
            .boteraser-info-card li .dashicons {
                 margin-right: 5px;
                 color: #00a32a; /* Green check */
            }
            .boteraser-info-card ol li {
                 list-style: decimal;
                 margin-left: 0;
            }

            /* Data Flow Diagram */
            .data-flow-diagram {
                display: flex;
                justify-content: space-around; /* Better spacing */
                align-items: center;
                margin-top: 25px;
                gap: 10px;
            }
            .flow-step {
                text-align: center;
                padding: 15px 10px; /* Adjust padding */
                background: #f0f0f1; /* WP subtle background */
                border-radius: 4px;
                flex: 1; /* Allow steps to grow/shrink */
                min-width: 90px;
                font-size: 13px;
                color: #3c434a;
            }
            .flow-step .dashicons {
                font-size: 28px; /* Slightly smaller */
                width: 28px;
                height: 28px;
                margin-bottom: 8px;
                color: #50575e;
            }
            .flow-arrow {
                font-size: 20px;
                color: #787c82;
                flex: 0 0 auto; /* Don't grow/shrink */
            }

            /* Form Styles */
            .form-table th {
                padding: 15px 10px 15px 0; /* Adjust padding */
                width: 150px; /* Fixed width for labels */
            }
            .form-table td {
                padding: 10px 0; /* Adjust padding */
            }
            .form-table input[type="text"].regular-text {
                 width: 100%;
                 max-width: 400px; /* Limit width */
            }
            .description {
                display: flex;
                align-items: center;
                gap: 5px;
                margin: 5px 0 0; /* Adjust margin */
                color: #787c82; /* WP secondary text color */
                font-size: 13px;
            }
            .description .dashicons {
                 font-size: 16px;
                 width: 16px;
                 height: 16px;
            }

            /* Execution Controls */
            .execution-controls {
                display: flex;
                align-items: center;
                flex-wrap: wrap; /* Allow wrapping */
                gap: 15px;
                /* Removed margin-bottom from here */
                /* margin-bottom: 45px; */ 
            }
            .execution-controls form {
                flex: 0 0 auto;
                margin: 0;
            }

            /* Results Section */
            .boteraser-results {
                border-left: 4px solid #787c82; /* Default border color */
                padding: 20px; /* Slightly less padding */
                /* Added margin-top here to create space above */
                margin-top: 38px; 
            }
            .boteraser-results.success {
                border-left-color: #00a32a; /* Green */
            }
            .boteraser-results.error {
                border-left-color: #d63638; /* Red */
            }

            /* Status Indicators (Inline and Footer) */
            .inline-status-indicator,
            .status-indicator {
                padding: 6px 12px; /* Adjust padding */
                border-radius: 4px;
                font-weight: 600;
                display: inline-flex;
                align-items: center;
                gap: 6px; /* Adjust gap */
                font-size: 13px;
                text-transform: uppercase;
                letter-spacing: 0.4px; /* Adjust spacing */
                border: 1px solid transparent; /* Base border */
            }
            .inline-status-indicator .dashicons,
            .status-indicator .dashicons {
                width: 16px; /* Adjust icon size */
                height: 16px;
                font-size: 16px;
                line-height: 1;
            }

            /* Specific Status Colors */
            .inline-status-indicator.success,
            .status-indicator.success {
                background-color: #f0f8ff; /* Lighter green background */
                color: #00650c;
                border-color: #aee9b3;
            }
            .inline-status-indicator.success .dashicons,
            .status-indicator.success .dashicons {
                 color: #008a20;
            }

            .inline-status-indicator.error,
            .status-indicator.error {
                background-color: #fef0f1; /* Lighter red background */
                color: #991628;
                border-color: #f5b7b8;
            }
            .inline-status-indicator.error .dashicons,
            .status-indicator.error .dashicons {
                 color: #cc292b;
            }

            /* Footer within Results Box */
            .results-footer {
                margin-top: 20px;
                padding-top: 15px; /* Adjust padding */
                border-top: 1px solid #eee;
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            .execution-message {
                color: #50575e;
                font-size: 13px;
                margin: 0;
            }

            /* Media Query for Execution Controls */
             @media screen and (max-width: 782px) {
                .execution-controls {
                    flex-direction: column; /* Stack button and status */
                    align-items: flex-start;
                }
                .inline-status-indicator {
                    max-width: none;
                    width: 100%; /* Full width when stacked */
                    justify-content: center; /* Center text/icon */
                }
            }

            .results-grid {
                display: grid;
                gap: 25px; /* Slightly larger gap for columns */
                /* Changed to explicitly define 3 equal columns */
                grid-template-columns: repeat(3, 1fr); 
            }
            .results-section h4 {
                 font-size: 14px;
                 margin: 0 0 10px;
                 display: flex;
                 align-items: center;
                 gap: 6px;
                 color: #3c434a;
            }
             .results-section h4 .dashicons {
                 font-size: 18px;
                 width: 18px;
                 height: 18px;
                 color: #787c82;
            }

            /* ... other styles ... */

            /* Media Query for Results Grid */
            @media screen and (max-width: 960px) { /* Adjust breakpoint as needed */
                .results-grid {
                    grid-template-columns: 1fr; /* Stack to single column on smaller screens */
                }
            }

            /* Button icon alignment */
            .button .dashicons {
                vertical-align: -4px;
                line-height: 1;
                margin-right: 2px;
            }

            /* Media Query for Execution Controls (Keep this one too) */
             @media screen and (max-width: 782px) {
                .execution-controls {
                    flex-direction: column; /* Stack button and status */
                    align-items: flex-start;
                }
                .inline-status-indicator {
                    max-width: none;
                    width: 100%; /* Full width when stacked */
                    justify-content: center; /* Center text/icon */
                }
            }

        </style>
        <?php
    }
});

// Block a single IP for 24 hours
//bot_eraser_manual_block_ip('192.168.10.227');
