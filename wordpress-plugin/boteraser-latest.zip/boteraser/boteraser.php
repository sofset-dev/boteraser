<?php
/*
Plugin Name: Boteraser
Plugin URI: https://boteraser.com
Description: Powerful WordPress security plugin by Sofset that blocks harmful bots, brute-force attacks, and DDoS threats using continuously updated threat intelligence.
Version: 1.0.0
Author: Sofset
Author URI: https://sofset.com
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/
if (!defined('ABSPATH')) {
    exit;
}

// Immediate IP block check - runs before anything else
function bot_eraser_immediate_check() {
    // Skip for wp-admin and wp-login
    if (strpos($_SERVER['REQUEST_URI'], '/wp-admin') !== false || 
        strpos($_SERVER['REQUEST_URI'], '/wp-login.php') !== false) {
        return;
    }

    // Get real visitor IP
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? // Cloudflare
          $_SERVER['HTTP_TRUE_CLIENT_IP'] ?? // Akamai and others
          $_SERVER['HTTP_X_REAL_IP'] ?? // Nginx proxy
          $_SERVER['HTTP_X_FORWARDED_FOR'] ?? // Standard proxy header
          $_SERVER['HTTP_X_FORWARDED'] ?? // Some proxy variants
          $_SERVER['HTTP_FORWARDED_FOR'] ?? // RFC 7239
          $_SERVER['HTTP_FORWARDED'] ?? // RFC 7239
          $_SERVER['HTTP_VIA'] ?? // Via proxy
          $_SERVER['HTTP_CLIENT_IP'] ?? // Client IP
          $_SERVER['HTTP_X_CLIENT_IP'] ?? // Some CDNs
          $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'] ?? // Load balancers
          $_SERVER['REMOTE_ADDR'] ?? // Direct IP
          '0.0.0.0';
    
    $ip = explode(',', $ip)[0];
    $ip = filter_var(trim($ip), FILTER_VALIDATE_IP) ?: '0.0.0.0';

    // Check file cache only (no WordPress functions needed)
    $cache_file = __DIR__ . '/includes/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
        if (isset($blocked_ips[$ip]) && time() < $blocked_ips[$ip]) {
            http_response_code(403);
            header('HTTP/1.1 403 Forbidden');
            header('Status: 403 Forbidden');
            header('Retry-After: 3600');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            die('403 Forbidden - Access Denied');
        }
    }
}

// Run immediate check
bot_eraser_immediate_check();

// Continue with rest of plugin code

// Define plugin constants
define('BOT_ERASER_VERSION', '1.0');
define('BOT_ERASER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BOT_ERASER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BOT_ERASER_SERVER_URL', 'https://user.boteraser.com/srv/be-server.php');
define('BOT_ERASER_LOG_PATH', BOT_ERASER_PLUGIN_DIR . 'logs/access.log');

// Include necessary files
// Helpers.php removed - unused functions, hash function moved to admin-settings.php
require_once BOT_ERASER_PLUGIN_DIR . 'includes/log-handler.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/server-communication.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/ip-blocker.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/logs.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/admin-settings.php';

// Register activation/deactivation hooks
register_activation_hook(__FILE__, 'bot_eraser_activate');
register_deactivation_hook(__FILE__, 'bot_eraser_deactivate');

// Register uninstall hook - WordPress will call this when plugin is deleted
register_uninstall_hook(__FILE__, 'bot_eraser_uninstall');

/**
 * Plugin activation handler
 */
function bot_eraser_activate() {
    // Create log file if missing
    if (!file_exists(BOT_ERASER_LOG_PATH)) {
        bot_eraser_create_log_file();
    }
    
    // Schedule cron job
    if (!wp_next_scheduled('bot_eraser_cron_hook')) {
        wp_schedule_event(time(), '5min', 'bot_eraser_cron_hook');
    }
}

/**
 * Plugin deactivation handler
 */
function bot_eraser_deactivate() {
    // Clear cron schedule
    wp_clear_scheduled_hook('bot_eraser_cron_hook');
    
    // Clean up temporary transients (but keep settings for reactivation)
    delete_transient('bot_eraser_process_data');
    
    // Log deactivation
    error_log('Boteraser: Plugin deactivated - cron jobs cleared, temporary data removed');
}

/**
 * Plugin uninstall handler
 * 
 * This function is called when the plugin is being uninstalled (deleted).
 * It removes ALL plugin data including settings, ensuring a clean uninstall.
 * Users will need to reconfigure the plugin if they reinstall it.
 */
function bot_eraser_uninstall() {
    // Only run if this is an actual uninstall request
    if (!defined('WP_UNINSTALL_PLUGIN')) {
        return;
    }
    
    // Clean up all plugin data
    bot_eraser_cleanup_all_data();
}

/**
 * Clean up all plugin data (options, transients, cron jobs, files)
 * 
 * This function removes all traces of the plugin from WordPress:
 * - WordPress options (API key, host IP, domain, validation state)
 * - Transients (blocked IPs cache, temporary data)
 * - Cron jobs (scheduled tasks)
 * - Plugin files (logs, cached data)
 * - Object cache entries
 * 
 * After this runs, it's as if the plugin was never installed.
 */
function bot_eraser_cleanup_all_data() {
    // Clean up WordPress options
    $options_to_delete = [
        'bot_eraser_api_key',
        'bot_eraser_host_ip',
        'bot_eraser_domain',
        'bot_eraser_api_validation_state'
    ];
    
    foreach ($options_to_delete as $option) {
        delete_option($option);
        delete_site_option($option); // Also remove from multisite if applicable
    }
    
    // Clear from object cache as well
    if (function_exists('wp_cache_delete')) {
        foreach ($options_to_delete as $option) {
            wp_cache_delete($option, 'options');
            wp_cache_delete($option, 'default');
        }
    }
    
    // Clean up WordPress transients
    $transients_to_delete = [
        'bot_eraser_blocked_ips',
        'bot_eraser_api_key',
        'bot_eraser_process_data'
    ];
    
    foreach ($transients_to_delete as $transient) {
        delete_transient($transient);
        delete_site_transient($transient); // Also remove from multisite if applicable
    }
    
    // Clean up WordPress cron jobs
    wp_clear_scheduled_hook('bot_eraser_cron_hook');
    
    // Remove any remaining cron entries (in case of multiple schedules)
    $cron_array = get_option('cron');
    if (is_array($cron_array)) {
        foreach ($cron_array as $timestamp => $cron) {
            if (isset($cron['bot_eraser_cron_hook'])) {
                unset($cron_array[$timestamp]['bot_eraser_cron_hook']);
                if (empty($cron_array[$timestamp])) {
                    unset($cron_array[$timestamp]);
                }
            }
        }
        update_option('cron', $cron_array);
    }
    
    // Clean up plugin files
    $log_path = BOT_ERASER_LOG_PATH;
    if (file_exists($log_path)) {
        unlink($log_path);
    }
    
    $blocked_ips_path = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    if (file_exists($blocked_ips_path)) {
        unlink($blocked_ips_path);
    }
    
    // Remove logs directory if empty
    $logs_dir = BOT_ERASER_PLUGIN_DIR . 'logs/';
    if (is_dir($logs_dir)) {
        $files = scandir($logs_dir);
        // Check if directory is empty (only contains . and ..)
        if (count($files) == 2) {
            rmdir($logs_dir);
        }
    }
    
    // Clear any remaining object cache
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
    
    // Log the cleanup (this will go to WordPress debug log if enabled)
    error_log('Boteraser: Plugin uninstalled and all data cleaned up successfully');
}

/**
 * Debug function to show what data would be removed during uninstall
 * This is useful for administrators to understand the cleanup scope
 */
function bot_eraser_get_cleanup_preview() {
    $cleanup_data = [
        'options' => [],
        'transients' => [],
        'cron_jobs' => [],
        'files' => []
    ];
    
    // Check which options exist
    $options_to_check = [
        'bot_eraser_api_key',
        'bot_eraser_host_ip',
        'bot_eraser_domain',
        'bot_eraser_api_validation_state'
    ];
    
    foreach ($options_to_check as $option) {
        if (get_option($option) !== false) {
            $cleanup_data['options'][] = $option;
        }
    }
    
    // Check which transients exist
    $transients_to_check = [
        'bot_eraser_blocked_ips',
        'bot_eraser_api_key',
        'bot_eraser_process_data'
    ];
    
    foreach ($transients_to_check as $transient) {
        if (get_transient($transient) !== false) {
            $cleanup_data['transients'][] = $transient;
        }
    }
    
    // Check which cron jobs exist
    if (wp_next_scheduled('bot_eraser_cron_hook')) {
        $cleanup_data['cron_jobs'][] = 'bot_eraser_cron_hook';
    }
    
    // Check which files exist
    $files_to_check = [
        BOT_ERASER_LOG_PATH,
        BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php'
    ];
    
    foreach ($files_to_check as $file) {
        if (file_exists($file)) {
            $cleanup_data['files'][] = basename($file);
        }
    }
    
    return $cleanup_data;
}

/**
 * Add custom cron interval
 */
add_filter('cron_schedules', 'bot_eraser_add_cron_interval');
function bot_eraser_add_cron_interval($schedules) {
    $schedules['5min'] = [
        'interval' => 300, // 300 seconds = 5 minutes
        'display'  => esc_html__('Every 5 Minutes', 'bot-eraser')
    ];
    return $schedules;
}

/**
 * Hook cron job to data sender
 */
add_action('bot_eraser_cron_hook', 'bot_eraser_send_data_to_server');

/**
 * Log visitor access on every page load
 */
add_action('init', 'bot_eraser_log_visitor');

/**
 * Check if IP is blocked on each request (including index.php)
 */

// Note: Admin styles are now loaded via assets/css/admin.css through wp_enqueue_scripts
