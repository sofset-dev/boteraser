<?php
/*
Plugin Name: Boteraser
Plugin URI: https://boteraser.com
Description: Powerful WordPress security plugin by Sofset that blocks harmful bots, brute-force attacks, and DDoS threats using continuously updated threat intelligence.
Version: 1.0.0
Author: Sofset
Author URI: https://profiles.wordpress.org/sofset/
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
*/
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/includes/helpers.php';

// Threat-list enforcement + rate counter (loaded early for cache)
require_once __DIR__ . '/includes/rate-counter.php';
require_once __DIR__ . '/includes/list-match.php';

// Signal builder
require_once __DIR__ . '/includes/signal-builder.php';
// Verdict client (server with fallback)
require_once __DIR__ . '/includes/verdict-client.php';
// Detection module
require_once __DIR__ . '/detection.php';

// Immediate IP block check
function bot_eraser_immediate_check() {
    // Skip CLI (no HTTP request)
    if (php_sapi_name() === 'cli') {
        return;
    }

    // Skip wp-admin and login
    if (strpos($_SERVER['REQUEST_URI'], '/wp-admin') !== false ||
        strpos($_SERVER['REQUEST_URI'], '/wp-login.php') !== false) {
        return;
    }

    // Skip logged-in users
    foreach ($_COOKIE as $name => $value) {
        if (strpos($name, 'wordpress_logged_in_') === 0) {
            return;
        }
    }

    $ip = bot_eraser_get_visitor_ip();

    // Skip self-IP to avoid loopback self-blockade
    if (bot_eraser_is_self_ip($ip)) {
        return;
    }

    // Enforce vetted block list. Server decides blocking (whitelist -> feed).
    $cache_file = __DIR__ . '/includes/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
        if (isset($blocked_ips[$ip]) && time() < $blocked_ips[$ip]) {
            // Count hit before JA4 capture exits
            bot_eraser_hit_incr($ip);

            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0', true);
            header('Pragma: no-cache', true);

            // First visit: JA4 capture then 403. Subsequent: hard 403.
            // Marker file readable by pre-WP prepend phase.
            if (!bot_eraser_ja4_done($ip)) {
                bot_eraser_ja4_mark_done($ip, (int) $blocked_ips[$ip]);
                $tok = bot_eraser_gen_token();
                bot_eraser_send_min_signal($ip, $tok); // paired JA4 signal (no orphan)
                bot_eraser_emit_analyze_capture($tok);
            }

            header('HTTP/1.1 403 Forbidden', true, 403);
            exit;
        }
    }

    // Whitelist -> blacklists -> rate/greylist (after exact-block)
    if (function_exists('bot_eraser_enforce_lists')) {
        bot_eraser_enforce_lists($ip, $_SERVER['HTTP_USER_AGENT'] ?? '');
    }
}

// Run check
bot_eraser_immediate_check();

// Rest of plugin

// Constants
define('BOT_ERASER_VERSION', '1.0');
define('BOT_ERASER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BOT_ERASER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BOT_ERASER_SERVER_URL', 'https://user.boteraser.com/srv/manual.php');
define('BOT_ERASER_HASH_SERVER_URL', 'https://user.boteraser.com/srv/hash-lookup.php');
define('BOT_ERASER_VULN_SERVER_URL', 'https://user.boteraser.com/srv/vuln-lookup.php');
define('BOT_ERASER_WAF_URL', 'https://user.boteraser.com/srv/waf-rules.php');
define('BOT_ERASER_LIST_URL', 'https://user.boteraser.com/srv/lists.php');
define('BOT_ERASER_COUNTRY_URL', 'https://user.boteraser.com/srv/country-block.php');
define('BOT_ERASER_BLOCKLIST_URL', 'https://user.boteraser.com/srv/report.php');
define('BOT_ERASER_LOG_PATH', WP_CONTENT_DIR . '/uploads/boteraser/logs/access.log');

/**
 * Migrate old storage to new structure.
 * Runs once if old dirs exist.
 */
function boteraser_migrate_storage_locations() {
    $old_quarantine = WP_CONTENT_DIR . '/boteraser-quarantine';
    $old_logs       = WP_CONTENT_DIR . '/boteraser-logs';
    $new_base       = WP_CONTENT_DIR . '/uploads/boteraser';

    if (!is_dir($old_quarantine) && !is_dir($old_logs)) {
        return;
    }

    if (!is_dir($new_base)) {
        wp_mkdir_p($new_base);
    }

    if (is_dir($old_quarantine)) {
        $new_quarantine = $new_base . '/quarantine';
        if (!is_dir($new_quarantine)) {
            wp_mkdir_p($new_quarantine);
        }
        $files = scandir($old_quarantine);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $old_path = $old_quarantine . '/' . $file;
            $new_path = $new_quarantine . '/' . $file;
            if (is_file($old_path) && !file_exists($new_path)) {
                @rename($old_path, $new_path);
            }
        }
        $remaining = scandir($old_quarantine);
        if (count($remaining) <= 2) {
            @rmdir($old_quarantine);
        }
    }

    if (is_dir($old_logs)) {
        $new_logs = $new_base . '/logs';
        if (!is_dir($new_logs)) {
            wp_mkdir_p($new_logs);
        }
        $files = scandir($old_logs);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $old_path = $old_logs . '/' . $file;
            $new_path = $new_logs . '/' . $file;
            if (is_file($old_path) && !file_exists($new_path)) {
                @rename($old_path, $new_path);
            }
        }
        $remaining = scandir($old_logs);
        if (count($remaining) <= 2) {
            @rmdir($old_logs);
        }
    }
    update_option('boteraser_storage_migrated', true, true);
}
if (!get_option('boteraser_storage_migrated')) {
    boteraser_migrate_storage_locations();
}

require_once BOT_ERASER_PLUGIN_DIR . 'includes/log-handler.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/server-communication.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/blocklist-sync.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/ip-blocker.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/bot-detector.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/web-bot-auth.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/threat-score.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/logs.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/admin-settings.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/scanner/scanner-ajax.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/quarantine.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/upload-scanner.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/vulnerability-scanner.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/brute-force.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/waf-sync.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/list-sync.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/country-block.php';
require_once BOT_ERASER_PLUGIN_DIR . 'includes/prepend-installer.php';
// Trap rewrite rules
function boteraser_register_rewrite_rules() {
    $slug = get_option('boteraser_trap_slug');
    if ($slug) {
        add_rewrite_rule('^' . preg_quote($slug, '/') . '/?$', 'index.php?boteraser_trap=1', 'top');
    }

    $old_slug   = get_option('boteraser_trap_slug_old');
    $old_expiry = get_option('boteraser_trap_slug_old_expiry');
    if ($old_slug && $old_expiry && time() < $old_expiry) {
        add_rewrite_rule('^' . preg_quote($old_slug, '/') . '/?$', 'index.php?boteraser_trap=1&boteraser_old=1', 'top');
    }

    add_filter('query_vars', function($vars) {
        $vars[] = 'boteraser_trap';
        $vars[] = 'boteraser_old';
        return $vars;
    });
}
add_action('init', 'boteraser_register_rewrite_rules');

// Auto-flush rewrite rules if missing
function boteraser_maybe_flush_rewrite_rules() {
    $slug = get_option('boteraser_trap_slug');
    if (!$slug) return;

    $rules = get_option('rewrite_rules', []);
    $pattern = '^' . preg_quote($slug, '/') . '/?$';
    if (!isset($rules[$pattern])) {
        flush_rewrite_rules(false);
    }
}
add_action('init', 'boteraser_maybe_flush_rewrite_rules', 20);

// Inject footer trap link
// Honeypot: invisible to screen-readers/keyboard
function boteraser_inject_footer_link() {
    // Use .screen-reader-text clip (bots ignore display:none). Keep aria-hidden/tabindex for a11y.
    $hidden = 'position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;';
    echo '<div style="' . $hidden . '" aria-hidden="true" tabindex="-1">';

    // Link to bare host. Uses capture token if detected bot, else random (no signal).
    $tok = !empty($GLOBALS['bot_eraser_capture_token']) ? $GLOBALS['bot_eraser_capture_token'] : bot_eraser_gen_token();
    $ja4_url = 'https://data.boteraser.com/' . chr(random_int(97, 122)) . '/' . $tok;
    echo '<a href="' . esc_url($ja4_url) . '" rel="nofollow" tabindex="-1" aria-hidden="true">.</a>';

    // WP honeypot trap
    $slug = get_option('boteraser_trap_slug');
    if ($slug) {
        $url = home_url('/' . $slug . '/');
        echo '<a href="' . esc_url($url) . '" rel="nofollow noindex" tabindex="-1" aria-hidden="true">.</a>';
    }

    echo '</div>';
}
add_action('wp_footer', 'boteraser_inject_footer_link');

// Rotate slug daily; old slug 24h grace for cached bots
function boteraser_rotate_slug() {
    $current_slug = get_option('boteraser_trap_slug');
    if ($current_slug) {
        update_option('boteraser_trap_slug_old', $current_slug);
        update_option('boteraser_trap_slug_old_expiry', time() + DAY_IN_SECONDS);
    }
    update_option('boteraser_trap_slug', bin2hex(random_bytes(16)));
    flush_rewrite_rules(false);
}

// Trap URL not blocked instantly. Honeypot alone never triggers block — needs accumulated signals.

// Activation/deactivation hooks
register_activation_hook(__FILE__, 'bot_eraser_activate');
register_deactivation_hook(__FILE__, 'bot_eraser_deactivate');


/**
 * Plugin activation handler
 */
function bot_eraser_activate() {
    // Create log file
    if (!file_exists(BOT_ERASER_LOG_PATH)) {
        bot_eraser_create_log_file();
    }

    // Schedule cron
    if (!wp_next_scheduled('bot_eraser_cron_hook')) {
        wp_schedule_event(time(), '5min', 'bot_eraser_cron_hook');
    }

    // Generate trap slug
    if (!get_option('boteraser_trap_slug')) {
        update_option('boteraser_trap_slug', bin2hex(random_bytes(16)));
    }

    // Schedule slug rotation
    if (!wp_next_scheduled('boteraser_rotate_slug_hook')) {
        wp_schedule_event(time() + DAY_IN_SECONDS, 'boteraser_daily', 'boteraser_rotate_slug_hook');
    }

    // Re-arm auto scan cron
    bot_eraser_reschedule_auto_scan();

    // WAF sync + bootstrap
    bot_eraser_waf_schedule();
    bot_eraser_waf_sync();

    // Threat-list sync: table + schedule + first pull
    bot_eraser_rate_create_table();
    bot_eraser_list_schedule();
    bot_eraser_list_sync();

    flush_rewrite_rules();
}

/**
 * Plugin deactivation handler
 */
function bot_eraser_deactivate() {
    wp_clear_scheduled_hook('bot_eraser_cron_hook');
    wp_clear_scheduled_hook('boteraser_rotate_slug_hook');
    wp_clear_scheduled_hook('boteraser_auto_scan_hook');
    wp_clear_scheduled_hook('bot_eraser_waf_sync');
    wp_clear_scheduled_hook('bot_eraser_waf_sync_once');
    wp_clear_scheduled_hook('bot_eraser_list_sync');
    wp_clear_scheduled_hook('bot_eraser_list_sync_once');
    wp_clear_scheduled_hook('bot_eraser_proxy_sync');

    // Remove prepend when plugin disabled (lists would stale)
    bot_eraser_prepend_remove();

    delete_transient('bot_eraser_process_data');

    flush_rewrite_rules();

    // Log deactivation
    error_log('Boteraser: Plugin deactivated - cron jobs cleared, temporary data removed');
}

/**
 * Plugin uninstall handler
 * 
 * Removes all plugin data. Reconfigure needed on reinstall.
 */
function bot_eraser_uninstall() {
    // Only run on actual uninstall
    if (!defined('WP_UNINSTALL_PLUGIN')) {
        return;
    }
    
    // Clean up all data
    bot_eraser_cleanup_all_data();
}

/**
 * Recursively delete a directory and all its contents.
 */
function boteraser_recursive_delete($dir) {
    if (!is_dir($dir)) return;
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . '/' . $item;
        if (is_dir($path)) {
            boteraser_recursive_delete($path);
        } else {
            @unlink($path);
        }
    }
    @rmdir($dir);
}

/**
 * Clean up all plugin data.
 * 
 * Removes options, transients, cron jobs, files, and object cache.
 * Plugin appears as never installed.
 */
function bot_eraser_cleanup_all_data() {
    // Clean up options
    $options_to_delete = [
        'bot_eraser_api_key',
        'bot_eraser_host_ip',
        'bot_eraser_domain',
        'bot_eraser_api_validation_state',
        'bot_eraser_privacy_notice_dismissed',
        'boteraser_trap_slug',
        'boteraser_trap_slug_old',
        'boteraser_trap_slug_old_expiry',
        'boteraser_upload_alerts',
        'boteraser_vuln_data',
        'boteraser_bf_failures',
        'boteraser_bf_enabled',
        'boteraser_bf_max_attempts',
        'boteraser_bf_window_minutes',
        'boteraser_bf_block_minutes',
        'boteraser_sys_nginx',
        'boteraser_sys_php',
        'boteraser_sys_openssh',
        'boteraser_sys_linux',
        'boteraser_sys_webserver',
        'boteraser_sys_os',
        'boteraser_auto_scan_last_run',
        'bot_eraser_stats_day',
        'bot_eraser_last_manual_run',
        'boteraser_scanner_module_settings',
        'boteraser_auto_scan_enabled',
        'boteraser_auto_scan_interval',
        'boteraser_notify_enabled',
        'boteraser_notify_email',
        'boteraser_auto_scan_files_themes_plugins',
        'boteraser_auto_quarantine',
        'bot_eraser_block_reasons',
        'bot_eraser_fp_blacklist_queue',
        'bot_eraser_execution_history',
        'boteraser_scan_state_backup',
        'boteraser_last_scan_results',
        'boteraser_last_scan_time',
        'boteraser_scan_history',
        'boteraser_file_baseline',
        'boteraser_baseline_time',
        'boteraser_scan_whitelist',
        'boteraser_storage_migrated',
        'bot_eraser_waf_etag',
        'bot_eraser_waf_synced',
        'bot_eraser_waf_count',
        'boteraser_waf_enabled',
        'bot_eraser_prepend_mode',
        'bot_eraser_ip_source',
        'bot_eraser_trusted_ranges',
        'bot_eraser_trusted_ranges_synced',
        'bot_eraser_wba_allowed_signers',
        'boteraser_ts_enabled',
        'boteraser_auto_deactivate_plugins',
        'boteraser_auto_quarantine_uploads',
        'boteraser_block_dangerous_ext',
        'boteraser_block_php_uploads',
        'boteraser_realtime_cloud_scan',
        'boteraser_rollback_on_update',
        'boteraser_scan_before_activation',
        'boteraser_whitelist_safe_plugins',
        'boteraser_upload_popup_dismissed',
    ];

    // Remove prepend directive; loader file stays (no-op) to avoid fatal during user_ini cache
    if (function_exists('bot_eraser_prepend_remove')) {
        bot_eraser_prepend_remove();
    }

    // Per-list sync bookkeeping
    if (function_exists('bot_eraser_list_names')) {
        foreach (bot_eraser_list_names() as $list_name) {
            $options_to_delete[] = 'bot_eraser_list_etag_' . $list_name;
            $options_to_delete[] = 'bot_eraser_list_synced_' . $list_name;
            $options_to_delete[] = 'bot_eraser_list_count_' . $list_name;
        }
    }

    foreach ($options_to_delete as $option) {
        delete_option($option);
        delete_site_option($option); // Also from multisite
    }

    // Drop rate-counter failover table
    if (isset($GLOBALS['wpdb']) && function_exists('bot_eraser_rate_table')) {
        $GLOBALS['wpdb']->query('DROP TABLE IF EXISTS ' . bot_eraser_rate_table());
    }
    
    // Clear object cache
    if (function_exists('wp_cache_delete')) {
        foreach ($options_to_delete as $option) {
            wp_cache_delete($option, 'options');
            wp_cache_delete($option, 'default');
        }
    }
    
    // Clean up transients
    $transients_to_delete = [
        'bot_eraser_blocked_ips',
        'bot_eraser_api_key',
        'bot_eraser_process_data',
        'bot_eraser_self_ips',
        'bot_eraser_admin_bar_metrics',
        'bot_eraser_yesterday_stats',
    ];

    foreach ($transients_to_delete as $transient) {
        delete_transient($transient);
        delete_site_transient($transient); // Also from multisite
    }

    // Dynamic per-IP transients from older versions. Delete on uninstall.
    if (isset($GLOBALS['wpdb'])) {
        $GLOBALS['wpdb']->query(
            "DELETE FROM {$GLOBALS['wpdb']->options}
             WHERE option_name LIKE '\_transient\_%bot\_eraser\_unblocked\_%'
                OR option_name LIKE '\_transient\_%bot\_eraser\_ja4\_done\_%'"
        );
    }
    
    // Clean up cron jobs
    wp_clear_scheduled_hook('bot_eraser_cron_hook');
    wp_clear_scheduled_hook('boteraser_auto_scan_hook');
    wp_clear_scheduled_hook('boteraser_rotate_slug_hook');
    wp_clear_scheduled_hook('bot_eraser_waf_sync');
    wp_clear_scheduled_hook('bot_eraser_waf_sync_once');
    wp_clear_scheduled_hook('bot_eraser_list_sync');
    wp_clear_scheduled_hook('bot_eraser_list_sync_once');
    wp_clear_scheduled_hook('bot_eraser_proxy_sync');

    // Remove remaining cron entries
    $cron_array = get_option('cron');
    if (is_array($cron_array)) {
        foreach ($cron_array as $timestamp => $cron) {
            if (isset($cron['bot_eraser_cron_hook'])) {
                unset($cron_array[$timestamp]['bot_eraser_cron_hook']);
                if (empty($cron_array[$timestamp])) {
                    unset($cron_array[$timestamp]);
                }
            }
        }
        update_option('cron', $cron_array);
    }
    
    // Clean up files
    $log_path = BOT_ERASER_LOG_PATH;
    if (file_exists($log_path)) {
        unlink($log_path);
    }
    
    $blocked_ips_path = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    if (file_exists($blocked_ips_path)) {
        unlink($blocked_ips_path);
    }

    $ja4_done_path = BOT_ERASER_PLUGIN_DIR . 'includes/sig-snap.php';
    if (file_exists($ja4_done_path)) {
        unlink($ja4_done_path);
    }

    $hits_log_path = BOT_ERASER_PLUGIN_DIR . 'includes/hits.log';
    if (file_exists($hits_log_path)) {
        unlink($hits_log_path);
    }
    
    // Remove logs dir if empty
    $logs_dir = BOT_ERASER_PLUGIN_DIR . 'logs/';
    if (is_dir($logs_dir)) {
        $files = scandir($logs_dir);
        if (count($files) == 2) {
            rmdir($logs_dir);
        }
    }
    
    // Remove uploads/boteraser/ dir
    $uploads_dir = WP_CONTENT_DIR . '/uploads/boteraser/';
    if (is_dir($uploads_dir)) {
        boteraser_recursive_delete($uploads_dir);
    }
    
    // Clear remaining object cache
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
    
    // Log cleanup
    error_log('Boteraser: Plugin uninstalled and all data cleaned up successfully');
}

/**
 * Preview data removed during uninstall.
 */
function bot_eraser_get_cleanup_preview() {
    $cleanup_data = [
        'options' => [],
        'transients' => [],
        'cron_jobs' => [],
        'files' => []
    ];
    
    // Check options
    $options_to_check = [
        'bot_eraser_api_key',
        'bot_eraser_host_ip',
        'bot_eraser_domain',
        'bot_eraser_api_validation_state',
        'bot_eraser_privacy_notice_dismissed'
    ];
    
    foreach ($options_to_check as $option) {
        if (get_option($option) !== false) {
            $cleanup_data['options'][] = $option;
        }
    }
    
    // Check transients
    $transients_to_check = [
        'bot_eraser_blocked_ips',
        'bot_eraser_api_key',
        'bot_eraser_process_data'
    ];
    
    foreach ($transients_to_check as $transient) {
        if (get_transient($transient) !== false) {
            $cleanup_data['transients'][] = $transient;
        }
    }
    
    // Check cron jobs
    if (wp_next_scheduled('bot_eraser_cron_hook')) {
        $cleanup_data['cron_jobs'][] = 'bot_eraser_cron_hook';
    }
    
    // Check files
    $files_to_check = [
        BOT_ERASER_LOG_PATH,
        BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php'
    ];
    
    foreach ($files_to_check as $file) {
        if (file_exists($file)) {
            $cleanup_data['files'][] = basename($file);
        }
    }
    
    return $cleanup_data;
}

/**
 * Add custom cron interval
 */
add_filter('cron_schedules', 'bot_eraser_add_cron_interval');
function bot_eraser_add_cron_interval($schedules) {
    $schedules['5min'] = [
        'interval' => 300,
        'display'  => esc_html__('Every 5 Minutes', 'bot-eraser'),
    ];
    $schedules['boteraser_daily'] = [
        'interval' => DAY_IN_SECONDS,
        'display'  => esc_html__('Once Daily (Boteraser)', 'bot-eraser'),
    ];
    $schedules['boteraser_6h'] = [
        'interval' => 6 * HOUR_IN_SECONDS,
        'display'  => esc_html__('Every 6 Hours (Boteraser)', 'bot-eraser'),
    ];
    $schedules['boteraser_1h'] = [
        'interval' => HOUR_IN_SECONDS,
        'display'  => esc_html__('Every Hour (Boteraser)', 'bot-eraser'),
    ];
    $schedules['boteraser_15min'] = [
        'interval' => 900,
        'display'  => esc_html__('Every 15 Minutes (Boteraser)', 'bot-eraser'),
    ];
    return $schedules;
}

add_action('boteraser_rotate_slug_hook', 'boteraser_rotate_slug');

/**
 * Cleanup expired IPs (runs every 5 min).
 */
function bot_eraser_scheduled_cleanup() {
    $result = bot_eraser_cleanup_expired_ips();

    if ($result['removed'] > 0) {
        error_log(sprintf(
            'Boteraser: Cleaned up %d expired IP(s). %d active block(s) remaining.',
            $result['removed'],
            $result['remaining']
        ));
    }
}

/**
 * Cron cleanup hook. Auto-send retired; uses local threat lists.
 * 5-min cron for expired blocks, log rotation, rate pruning.
 */
add_action('bot_eraser_cron_hook', 'bot_eraser_scheduled_cleanup');
add_action('bot_eraser_cron_hook', 'bot_eraser_hit_flush');
add_action('bot_eraser_cron_hook', 'bot_eraser_cleanup_log_file');
add_action('bot_eraser_cron_hook', 'bot_eraser_rate_cleanup');
add_action('bot_eraser_cron_hook', 'bot_eraser_send_blocklist_to_server');

/**
 * Map interval slug to cron schedule. Falls back to daily.
 */
function bot_eraser_auto_scan_interval_slug($interval) {
    $allowed = array('boteraser_6h', 'twicedaily', 'boteraser_daily');
    return in_array($interval, $allowed, true) ? $interval : 'boteraser_daily';
}

/**
 * Reschedule auto scan cron.
 */
function bot_eraser_reschedule_auto_scan() {
    $enabled  = (bool) get_option('boteraser_auto_scan_enabled', false);
    $interval = bot_eraser_auto_scan_interval_slug(get_option('boteraser_auto_scan_interval', 'boteraser_daily'));

    $existing = wp_next_scheduled('boteraser_auto_scan_hook');
    if ($existing) {
        wp_clear_scheduled_hook('boteraser_auto_scan_hook');
    }

    if ($enabled) {
        wp_schedule_event(time() + 5 * MINUTE_IN_SECONDS, $interval, 'boteraser_auto_scan_hook');
    }
}

/**
 * Run auto scan in one cron request (chunked with time budget).
 */
function bot_eraser_run_auto_scan() {
    $validation_state = get_option('bot_eraser_api_validation_state', array());
    if (empty($validation_state['is_valid'])) {
        wp_clear_scheduled_hook('boteraser_auto_scan_hook');
        return;
    }

    update_option('boteraser_auto_scan_last_run', time(), false);

    $engine = BOT_ERASER_PLUGIN_DIR . 'includes/scanner/scan-engine.php';
    if (!file_exists($engine)) return;
    require_once $engine;

    if (function_exists('set_time_limit')) {
        @set_time_limit(200);
    }

    $saved = get_option('boteraser_scanner_module_settings', array());
    $modules = array(
        'core'        => isset($saved['mod_core'])        ? (bool) $saved['mod_core']        : true,
        'plugins'     => isset($saved['mod_plugins'])     ? (bool) $saved['mod_plugins']     : true,
        'themes'      => isset($saved['mod_themes'])      ? (bool) $saved['mod_themes']      : true,
        'filenames'   => isset($saved['mod_filenames'])   ? (bool) $saved['mod_filenames']   : true,
        'uploads'     => isset($saved['mod_uploads'])     ? (bool) $saved['mod_uploads']     : true,
        'htaccess'    => isset($saved['mod_htaccess'])    ? (bool) $saved['mod_htaccess']    : true,
        'database'    => isset($saved['mod_database'])    ? (bool) $saved['mod_database']    : true,
        'cron'        => isset($saved['mod_cron'])        ? (bool) $saved['mod_cron']        : true,
        'patterns'    => !empty($saved['mod_patterns']),
        'files'       => !empty($saved['mod_files']) || !empty($saved['mod_patterns']),
        'permissions' => isset($saved['mod_permissions']) ? (bool) $saved['mod_permissions'] : false,
        'malware_api' => !empty($saved['mod_malware_api']),
    );
    boteraser_scan_init($modules);

    $deadline = time() + BOT_ERASER_SCAN_TIMEOUT;
    while (time() < $deadline) {
        $result = boteraser_scan_chunk();
        if (!is_array($result)) break;
        $status = isset($result['status']) ? $result['status'] : '';
        if ($status === 'complete' || $status === 'error') break;
    }

    update_option('boteraser_auto_scan_last_run', time(), false);

    bot_eraser_vuln_fetch();

    if (get_option('boteraser_notify_enabled', false)) {
        bot_eraser_send_scan_notification();
    }
}
add_action('boteraser_auto_scan_hook', 'bot_eraser_run_auto_scan');

/**
 * Send scan summary email with findings and blocked IPs.
 * Runs via one-off cron after a manual scan completes (see scanner-ajax.php)
 * so a slow/hanging SMTP send never blocks the scan's final AJAX response.
 */
add_action('boteraser_scan_notify_event', 'bot_eraser_send_scan_notification');
function bot_eraser_send_scan_notification() {
    $to      = get_option('boteraser_notify_email', get_option('admin_email'));
    $site    = get_bloginfo('name') ?: get_bloginfo('url');
    $results = get_option('boteraser_last_scan_results', null);

    // Email subject window label
    $interval = get_option('boteraser_auto_scan_interval', 'boteraser_daily');
    $interval_labels = array(
        'boteraser_6h'    => '6 hours',
        'twicedaily'      => '12 hours',
        'boteraser_daily' => '24 hours',
    );
    $window = $interval_labels[$interval] ?? '24 hours';

    // Seconds per window for blocked-IP count
    $window_seconds = array(
        'boteraser_6h'    => 6  * HOUR_IN_SECONDS,
        'twicedaily'      => 12 * HOUR_IN_SECONDS,
        'boteraser_daily' => 24 * HOUR_IN_SECONDS,
    );
    $since = time() - ($window_seconds[$interval] ?? DAY_IN_SECONDS);

    // Findings
    $summary = $results['summary'] ?? array('high' => 0, 'medium' => 0, 'low' => 0, 'score' => 100, 'grade' => 'EXCELLENT');
    $high   = (int) ($summary['high']   ?? 0);
    $medium = (int) ($summary['medium'] ?? 0);
    $low    = (int) ($summary['low']    ?? 0);
    $score  = (int) ($summary['score']  ?? 100);
    $grade  = $summary['grade'] ?? 'EXCELLENT';
    $scanner_url = admin_url('admin.php?page=bot-eraser-scanner');
    $logo_url    = 'https://boteraser.com/wp-content/plugins/boteraser/assets/images/logo-email.png';

    // Blocked IPs from file store
    $blocked_ips_file  = plugin_dir_path(__FILE__) . 'includes/blocked-ips.php';
    $blocked_ips_all   = file_exists($blocked_ips_file) ? (array) include($blocked_ips_file) : array();
    $now               = time();
    $blocked_count     = 0;
    $blocked_in_window = 0;
    foreach ($blocked_ips_all as $expiry) {
        if ($expiry > $now) {
            $blocked_count++;
            $block_time = $expiry - BOT_ERASER_BLOCK_DURATION;
            if ($block_time >= $since) {
                $blocked_in_window++;
            }
        }
    }

    $subject = sprintf('[%s] Boteraser scan report — last %s', $site, $window);
    if ($high > 0) {
        $status_label = __('Action required', 'bot-eraser');
        $status_copy  = sprintf(__('%d high-severity finding(s) detected. Review the scan results immediately.', 'bot-eraser'), $high);
        $status_color = '#b91c1c';
        $status_bg    = '#fef2f2';
        $cta_label    = __('Review findings', 'bot-eraser');
    } elseif ($medium > 0) {
        $status_label = __('Review recommended', 'bot-eraser');
        $status_copy  = __('The scan finished with medium or low severity findings. Confirm them before taking action.', 'bot-eraser');
        $status_color = '#b45309';
        $status_bg    = '#fffbeb';
        $cta_label    = __('Open scanner', 'bot-eraser');
    } else {
        $status_label = __('Site looks clean', 'bot-eraser');
        $status_copy  = __('No threats were detected in the latest scan window.', 'bot-eraser');
        $status_color = '#166534';
        $status_bg    = '#f0fdf4';
        $cta_label    = __('View scanner', 'bot-eraser');
    }

    $score_color = $score >= 75 ? '#16a34a' : ($score >= 50 ? '#d97706' : '#dc2626');
    $score_bg    = $score >= 75 ? '#f0fdf4' : ($score >= 50 ? '#fffbeb' : '#fff5f5');
    $score_border= $score >= 75 ? '#bbf7d0' : ($score >= 50 ? '#fde68a' : '#fecaca');
    $scan_time   = date_i18n('d.m.Y H:i', time());

    $status_icon = $high > 0 ? '&#9888;' : ($medium > 0 ? '&#9432;' : '&#10003;');

    $body = '<!doctype html>'
        . '<html lang="en"><head>'
        . '<meta charset="' . esc_attr(get_bloginfo('charset')) . '">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>Boteraser Scan Report</title>'
        . '</head>'
        . '<body style="margin:0;padding:0;background:#f5f7fa;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,\'Helvetica Neue\',Arial,sans-serif;color:#1e293b;">'

        // Outer wrapper (grey bg)
        . '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f5f7fa;padding:36px 16px;">'
        . '<tr><td align="center">'
        . '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:620px;margin:0 auto;background:#ffffff;border-radius:16px;border:1px solid #e8edf2;overflow:hidden;">'

        // Header (white + accent top line)
        . '<tr><td style="border-top:4px solid #6366f1;padding:32px 36px 24px;text-align:left;">'
        . '<img src="' . esc_url($logo_url) . '" alt="Boteraser" style="display:block;width:130px;height:auto;margin-bottom:20px;">'
        . '<p style="margin:0 0 4px 0;font-size:11px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#94a3b8;">Security Scan Report</p>'
        . '<h1 style="margin:0 0 6px 0;font-size:22px;font-weight:700;color:#0f172a;">' . esc_html($site) . '</h1>'
        . '<p style="margin:0;font-size:13px;color:#94a3b8;">'
        . sprintf('Last %s &nbsp;&middot;&nbsp; %s', esc_html($window), esc_html($scan_time))
        . '</p>'
        . '</td></tr>'

        // Status banner
        . '<tr><td style="padding:0 36px 24px;">'
        . '<div style="padding:14px 18px;border-radius:10px;background:' . esc_attr($status_bg) . ';border:1px solid ' . esc_attr($status_color) . '33;">'
        . '<span style="font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:' . esc_attr($status_color) . ';">' . $status_icon . '&nbsp;&nbsp;' . esc_html($status_label) . '</span>'
        . '<p style="margin:4px 0 0 0;font-size:13px;line-height:1.6;color:#475569;">' . esc_html($status_copy) . '</p>'
        . '</div>'
        . '</td></tr>'

        // Metric cards
        . '<tr><td style="padding:0 36px 24px;">'
        . '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'

        // Score
        . '<td width="32%" style="padding-right:8px;vertical-align:top;">'
        . '<div style="border:1px solid ' . esc_attr($score_border) . ';border-radius:12px;padding:16px;background:' . esc_attr($score_bg) . ';text-align:center;">'
        . '<p style="margin:0 0 4px;font-size:11px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:#94a3b8;">Score</p>'
        . '<p style="margin:0;font-size:32px;font-weight:800;color:' . esc_attr($score_color) . ';line-height:1;">' . esc_html($score) . '<span style="font-size:14px;font-weight:500;color:#94a3b8;">/100</span></p>'
        . '<p style="margin:4px 0 0;font-size:11px;font-weight:600;color:' . esc_attr($score_color) . ';">' . esc_html($grade) . '</p>'
        . '</div></td>'

        // Findings
        . '<td width="36%" style="padding:0 4px;vertical-align:top;">'
        . '<div style="border:1px solid #e2e8f0;border-radius:12px;padding:16px;background:#fafbfc;text-align:center;">'
        . '<p style="margin:0 0 4px;font-size:11px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:#94a3b8;">Findings</p>'
        . '<p style="margin:0;font-size:32px;font-weight:800;color:#1e293b;line-height:1;">' . esc_html($high + $medium + $low) . '</p>'
        . '<p style="margin:6px 0 0;font-size:11px;line-height:1.8;">'
        . '<span style="padding:1px 7px;border-radius:5px;background:#fee2e2;color:#dc2626;font-weight:700;">H&nbsp;' . esc_html($high) . '</span>&nbsp;'
        . '<span style="padding:1px 7px;border-radius:5px;background:#fef3c7;color:#d97706;font-weight:700;">M&nbsp;' . esc_html($medium) . '</span>&nbsp;'
        . '<span style="padding:1px 7px;border-radius:5px;background:#dcfce7;color:#16a34a;font-weight:700;">L&nbsp;' . esc_html($low) . '</span>'
        . '</p></div></td>'

        // Blocked IPs
        . '<td width="32%" style="padding-left:8px;vertical-align:top;">'
        . '<div style="border:1px solid #e2e8f0;border-radius:12px;padding:16px;background:#fafbfc;text-align:center;">'
        . '<p style="margin:0 0 4px;font-size:11px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:#94a3b8;">Blocked IPs</p>'
        . '<p style="margin:0;font-size:32px;font-weight:800;color:#1e293b;line-height:1;">' . esc_html($blocked_count) . '</p>'
        . '<p style="margin:4px 0 0;font-size:11px;color:#94a3b8;">total &nbsp;&bull;&nbsp; +' . esc_html($blocked_in_window) . ' last ' . esc_html($window) . '</p>'
        . '</div></td>'

        . '</tr></table>'
        . '</td></tr>'

        // Summary table
        . '<tr><td style="padding:0 36px 28px;">'
        . '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #e8edf2;border-radius:10px;overflow:hidden;">'
        . '<tr style="background:#f8fafc;"><td colspan="2" style="padding:10px 16px;font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#64748b;border-bottom:1px solid #e8edf2;">Scan Summary</td></tr>'
        . '<tr><td style="padding:10px 16px;font-size:13px;color:#64748b;border-bottom:1px solid #f1f5f9;">High severity</td><td style="padding:10px 16px;font-size:13px;font-weight:700;color:#dc2626;text-align:right;border-bottom:1px solid #f1f5f9;">' . esc_html($high) . '</td></tr>'
        . '<tr style="background:#fafbfc;"><td style="padding:10px 16px;font-size:13px;color:#64748b;border-bottom:1px solid #f1f5f9;">Medium severity</td><td style="padding:10px 16px;font-size:13px;font-weight:700;color:#d97706;text-align:right;border-bottom:1px solid #f1f5f9;">' . esc_html($medium) . '</td></tr>'
        . '<tr><td style="padding:10px 16px;font-size:13px;color:#64748b;border-bottom:1px solid #f1f5f9;">Low severity</td><td style="padding:10px 16px;font-size:13px;font-weight:700;color:#16a34a;text-align:right;border-bottom:1px solid #f1f5f9;">' . esc_html($low) . '</td></tr>'
        . '<tr style="background:#fafbfc;"><td style="padding:10px 16px;font-size:13px;color:#64748b;border-bottom:1px solid #f1f5f9;">Blocked IPs (total)</td><td style="padding:10px 16px;font-size:13px;font-weight:700;color:#1e293b;text-align:right;border-bottom:1px solid #f1f5f9;">' . esc_html($blocked_count) . '</td></tr>'
        . '<tr><td style="padding:10px 16px;font-size:13px;color:#64748b;border-bottom:1px solid #f1f5f9;">Blocked IPs (last ' . esc_html($window) . ')</td><td style="padding:10px 16px;font-size:13px;font-weight:700;color:#1e293b;text-align:right;border-bottom:1px solid #f1f5f9;">' . esc_html($blocked_in_window) . '</td></tr>'
        . '<tr style="background:#fafbfc;"><td style="padding:10px 16px;font-size:13px;color:#64748b;">Site</td><td style="padding:10px 16px;font-size:13px;font-weight:600;color:#1e293b;text-align:right;">' . esc_html($site) . '</td></tr>'
        . '</table>'
        . '</td></tr>'

        // CTA button
        . '<tr><td style="padding:0 36px 32px;">'
        . '<a href="' . esc_url($scanner_url) . '" style="display:inline-block;padding:12px 28px;border-radius:8px;background:#6366f1;color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;">'
        . esc_html($cta_label)
        . '</a>'
        . '</td></tr>'

        // Footer
        . '<tr><td style="padding:20px 36px;border-top:1px solid #f1f5f9;background:#fafbfc;text-align:center;">'
        . '<p style="margin:0 0 12px;font-size:12px;color:#94a3b8;">Powered by <strong style="color:#64748b;">Boteraser</strong> &nbsp;&middot;&nbsp; <a href="' . esc_url(home_url()) . '" style="color:#94a3b8;text-decoration:none;">' . esc_html(home_url()) . '</a></p>'
        . '<p style="margin:0;line-height:1;">'
        . '<a href="https://www.facebook.com/profile.php?id=61582414976501" style="display:inline-block;margin:0 4px;text-decoration:none;" title="Facebook"><img src="https://cdn-icons-png.flaticon.com/24/733/733547.png" width="20" height="20" alt="Facebook" style="display:block;opacity:.5;"></a>'
        . '<a href="https://www.instagram.com/boteraser.official" style="display:inline-block;margin:0 4px;text-decoration:none;" title="Instagram"><img src="https://cdn-icons-png.flaticon.com/24/2111/2111463.png" width="20" height="20" alt="Instagram" style="display:block;opacity:.5;"></a>'
        . '<a href="https://www.linkedin.com/company/boteraser" style="display:inline-block;margin:0 4px;text-decoration:none;" title="LinkedIn"><img src="https://cdn-icons-png.flaticon.com/24/733/733561.png" width="20" height="20" alt="LinkedIn" style="display:block;opacity:.5;"></a>'
        . '<a href="https://x.com/boteraser" style="display:inline-block;margin:0 4px;text-decoration:none;" title="X / Twitter"><img src="https://cdn-icons-png.flaticon.com/24/5968/5968958.png" width="20" height="20" alt="X" style="display:block;opacity:.5;"></a>'
        . '<a href="https://www.youtube.com/@Boteraser" style="display:inline-block;margin:0 4px;text-decoration:none;" title="YouTube"><img src="https://cdn-icons-png.flaticon.com/24/1384/1384060.png" width="20" height="20" alt="YouTube" style="display:block;opacity:.5;"></a>'
        . '<a href="https://t.me/boteraser_official" style="display:inline-block;margin:0 4px;text-decoration:none;" title="Telegram"><img src="https://cdn-icons-png.flaticon.com/24/2111/2111646.png" width="20" height="20" alt="Telegram" style="display:block;opacity:.5;"></a>'
        . '</p>'
        . '</td></tr>'

        . '</table>'
        . '</td></tr>'
        . '</table>'
        . '</body></html>';

    $headers = array('Content-Type: text/html; charset=' . get_bloginfo('charset'));

    wp_mail($to, $subject, $body, $headers);
}


/**
 * Log visitor access on page load.
 */
add_action('template_redirect', 'bot_eraser_log_visitor', 1);

/**
 * Check if IP is blocked per request.
 */

// Admin styles via wp_enqueue_scripts
