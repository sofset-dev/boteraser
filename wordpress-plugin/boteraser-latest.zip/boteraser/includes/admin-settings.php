<?php
if (!defined('ABSPATH')) {
    exit;
}

function bot_eraser_admin_styles() {
    // We do not need to enqueue a script since we are using inline JavaScript
    // Just define the AJAX variables directly in the script
    
    echo '<style>
        #adminmenu .toplevel_page_bot-eraser img {
            margin-top: -4px;
            padding-top: 5px;
        }
        #adminmenu li.wp-has-submenu ul.wp-submenu li a[href*="user.boteraser.com"] {
            background-color: #28a745 !important;
            color: white !important;
            font-weight: 600 !important;
        }
        #adminmenu li.wp-has-submenu ul.wp-submenu li a[href*="user.boteraser.com"]:hover {
            background-color: #28a745 !important;
            color: white !important;
        }
        .form-table .description {
            font-size: 16px !important;
        }
        .form-table input[type="text"].regular-text {
            width: 700px !important;
            max-width: 100% !important;
        }
        input#api_key.regular-text {
            width: 700px !important;
            max-width: 100% !important;
        }
        .boteraser-settings-card input[name="api_key"] {
            width: 700px !important;
            max-width: 100% !important;
        }
        .boteraser-settings-card .submit {
            position: absolute; /* Position absolutely within the white box */
            left: 110px; /* Align with the input field left edge */
            bottom: 5px; /* Move button closer to the bottom edge */
            margin: 0 !important; /* Remove all margins */
            z-index: 5; /* Ensure button stays visible */
        }
        .boteraser-settings-card .button-primary {
            margin-left: 0 !important;
        }
        .api-key-wrapper {
            position: relative;
            display: inline-block;
            width: 550px;
            max-width: 100%;
        }
        .api-key-wrapper .dashicons-dashboard {
            position: absolute;
            left: 10px;
            top: 50%;
            transform:  translateY(-60%);
            color: #666;
            font-size: 16px;
            line-height: 1;
        }
        .api-key-wrapper input[type="text"] {
            padding-left: 35px !important;
            padding-right: 35px !important;
            width: 100% !important;
        }
        .api-key-wrapper .dashicons-yes-alt {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-60%);
            color: #46b450;
            font-size: 16px;
            line-height: 1;
            display: none;
        }
        .api-key-wrapper .dashicons-dismiss {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-60%);
            color: #dc3232;
            font-size: 16px;
            line-height: 1;
            display: none;
        }
        .api-key-wrapper .dashicons-update {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-60%);
            color: #666;
            font-size: 14px;
            line-height: 1;
            display: none;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: translateY(-60%) rotate(0deg); }
            100% { transform: translateY(-60%) rotate(360deg); }
        }
        .api-key-wrapper.valid .dashicons-yes-alt {
            display: block;
        }
        .api-key-wrapper.invalid .dashicons-dismiss {
            display: block;
        }
        .api-key-wrapper.validating .dashicons-update {
            display: block;
        }
        
        /* Large status indicator on the right */
        .api-key-status-indicator {
            position: absolute;
            right: 30px; /* Moved further left from edge */
            top: -10px; /* Moved up significantly */
            display: inline-block;
            vertical-align: top;
            text-align: center;
            width: 120px; /* Increased width to match icon size */
            z-index: 10;
        }
        .api-key-status-indicator .status-icon {
            width: 120px;
            height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            transition: all 0.3s ease;
        }
        .api-key-status-indicator .status-icon .dashicons {
            font-size: 120px;
            width: 120px;
            height: 120px;
            color: #666;
        }
        .api-key-status-indicator .status-text {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #666;
        }
        
        /* Status states */
        .api-key-status-indicator.validating .status-icon .dashicons {
            color: #856404;
            animation: spin 1s linear infinite;
        }
        .api-key-status-indicator.validating .status-text {
            color: #856404;
        }
        
        .api-key-status-indicator.valid .status-icon .dashicons {
            color: #46b450;
        }
        .api-key-status-indicator.valid .status-text {
            color: #46b450;
        }
        
        .api-key-status-indicator.invalid .status-icon .dashicons {
            color: #dc3232;
        }
        .api-key-status-indicator.invalid .status-text {
            color: #dc3232;
        }
        
        .api-key-status-indicator.hidden {
            opacity: 0;
            pointer-events: none;
        }
        
        /* Default/Not verified state */
        .api-key-status-indicator .status-icon .dashicons {
            color: #666;
        }
        .api-key-status-indicator .status-text {
            color: #666;
        }
        
        /* Ensure the form table row has proper layout */
        .form-table th,
        .form-table td {
            vertical-align: top;
        }
        
        /* Make sure the API key row has enough space */
        .api-key-table-row {
            position: relative;
        }
        
        .api-key-table-row th {
            padding-right: 4px !important; /* Reduced space between label and input */
            vertical-align: top !important;
            width: 80px !important; /* Reduced width to bring elements closer */
        }
        
        .api-key-table-row td {
            padding-right: 140px; /* Increased space for larger status indicator */
            padding-left: 0px !important; /* No left padding for tighter alignment */
            position: relative;
            min-height: 100px; /* Increased height for larger white box */
            overflow: visible; /* Allow button to extend beyond cell */
        }
        
        /* Add proper spacing between description and input */
        .api-key-table-row td .description {
            margin-bottom: 60px !important; /* Increased spacing below description */
            margin-top: 1px !important; /* Decreased spacing above description */
            margin-left: 0px !important; /* Align with input field - moved closer to left */         
        }
        
        /* Add space below the API key input */
        table.form-table .api-key-table-row td #api_key {
            margin-bottom: 6px !important; /* Optimal spacing between input and description */
            display: block !important; /* Ensure block display for margin to work */
        }
        
        /* Make the settings card more compact */
        .boteraser-settings-card {
            padding: 25px 25px 10px 25px !important; /* Reduce bottom padding to allow button to sit lower */
            position: relative; /* Enable absolute positioning for button */
            min-height: 140px !important; /* Set minimum height for larger appearance */
        }
        
        .boteraser-settings-card .form-table {
            margin-bottom: 15px !important; /* Increased bottom margin for more space */
        }
        
        .boteraser-settings-card .form-table tr {
            margin-bottom: 0 !important; /* Remove extra row spacing */
        }
        
        .boteraser-settings-card .form-table th,
        .boteraser-settings-card .form-table td {
            padding-top: 12px !important; /* Increased top padding */
            padding-bottom: 12px !important; /* Increased bottom padding */
        }
        
        .api-key-table-row th label {
            font-size: 16px !important;
            font-weight: 600 !important;
        }
    </style>';
    // Note: JavaScript moved to render function where $form_api_key is available
}
add_action('admin_head', 'bot_eraser_admin_styles');

function bot_eraser_add_settings_page() {
    add_menu_page(
        'Boteraser',
        'Boteraser',
        'manage_options',
        'bot-eraser',
        'bot_eraser_render_settings_page',
        BOT_ERASER_PLUGIN_URL . 'logo-menu.svg',
        100
    );

    // Add Dashboard submenu (points to main settings page)
    add_submenu_page(
        'bot-eraser',
        __('Dashboard', 'bot-eraser'),
        __('Dashboard', 'bot-eraser'),
        'manage_options',
        'bot-eraser',
        'bot_eraser_render_settings_page'
    );

    // Add Blocked IPs submenu
    add_submenu_page(
        'bot-eraser',
        __('Blocked IPs', 'bot-eraser'),
        __('Blocked IPs', 'bot-eraser'),
        'manage_options',
        'bot-eraser-blocked-ips',
        'bot_eraser_render_blocked_ips'
    );

    // Add Logs submenu
    add_submenu_page(
        'bot-eraser',
        __('Logs', 'bot-eraser'),
        __('Logs', 'bot-eraser'),
        'manage_options',
        'bot-eraser-logs',
        'bot_eraser_render_logs_page'
    );

    // Add Sign Up submenu as external link
    add_submenu_page(
        'bot-eraser',
        __('Sign Up', 'bot-eraser'),
        __('Sign Up', 'bot-eraser'),
        'manage_options',
        'https://user.boteraser.com/sign-up.php',
        ''
    );
}
add_action('admin_menu', 'bot_eraser_add_settings_page');

function bot_eraser_render_settings_page() {
    if (!current_user_can('manage_options')) return;

    // Clean up any duplicate API key entries before proceeding
    bot_eraser_cleanup_api_key_entries();

    // Handle form submissions
    $settings_saved = false;
    $api_validation_result = null;
    if (isset($_POST['bot_eraser_settings_nonce'])) {
        check_admin_referer('bot_eraser_settings', 'bot_eraser_settings_nonce');
        
        $api_key = sanitize_text_field($_POST['api_key']);
        
        // Validate the API key when form is submitted
        $api_validation_result = bot_eraser_validate_api_key_with_server($api_key);
        
        // Save validation state to database
        $validation_state = array(
            'api_key_hash' => bot_eraser_simple_hash($api_key),
            'is_valid' => $api_validation_result['valid'] ?? false,
            'message' => $api_validation_result['message'] ?? '',
            'timestamp' => time()
        );
        update_option('bot_eraser_api_validation_state', $validation_state);
        
        // Always save the API key regardless of validation result
        // COMPLETE CLEANUP: Remove ALL existing API key entries before saving new one
        global $wpdb;
        
        // 1. Delete from options table (handles all WordPress option variations)
        $wpdb->delete($wpdb->options, array('option_name' => 'bot_eraser_api_key'));
        
        // 2. Clear all WordPress caches that might contain the old value
        wp_cache_delete('bot_eraser_api_key', 'options');
        wp_cache_delete('alloptions', 'options');
        wp_cache_flush();
        
        // 3. Clear any object cache if available
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete('bot_eraser_api_key', 'options');
            wp_cache_delete('bot_eraser_api_key', 'default');
        }
        
        // 4. Clear any persistent object cache
        if (function_exists('wp_cache_flush_group')) {
            wp_cache_flush_group('options');
        }
        
        // 5. Clear any transients that might contain the API key
        delete_transient('bot_eraser_api_key');
        delete_site_transient('bot_eraser_api_key');
        
        // 6. Now insert the NEW API key as a fresh entry
        $insert_result = $wpdb->insert(
            $wpdb->options,
            array(
                'option_name' => 'bot_eraser_api_key',
                'option_value' => $api_key,
                'autoload' => 'yes'
            ),
            array('%s', '%s', '%s')
        );
        
        $settings_saved = true;
        
        // Debug output to verify the cleanup and save process
        error_log('Boteraser: OLD API key entries deleted from database');
        error_log('Boteraser: NEW API key saved to database: ' . substr($api_key, 0, 10) . '...');
        error_log('Boteraser: Insert result: ' . ($insert_result ? 'SUCCESS' : 'FAILED'));
        error_log('Boteraser: API key hash: ' . bot_eraser_simple_hash($api_key));
        
        // Verify immediately after saving with fresh database query
        $verification_api_key = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", 'bot_eraser_api_key'));
        error_log('Boteraser: Fresh DB verification: ' . substr($verification_api_key, 0, 10) . '...');
        
        // Count total entries (should be exactly 1)
        $total_entries = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name = %s", 'bot_eraser_api_key'));
        error_log('Boteraser: Total API key entries in database: ' . $total_entries);
        
        // FORCE verification immediately after insert - try multiple methods
        $fresh_verification = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s ORDER BY option_id DESC LIMIT 1", 'bot_eraser_api_key'));
        $get_option_verification = get_option('bot_eraser_api_key', 'NOT_FOUND');
        
        error_log('Boteraser: Fresh DB query result: ' . substr($fresh_verification, 0, 10) . '... (length: ' . strlen($fresh_verification) . ')');
        error_log('Boteraser: get_option result: ' . substr($get_option_verification, 0, 10) . '... (length: ' . strlen($get_option_verification) . ')');
        
        // If get_option doesn't match, force update it
        if ($get_option_verification !== $api_key) {
            error_log('Boteraser: get_option mismatch detected - forcing update');
            delete_option('bot_eraser_api_key');
            add_option('bot_eraser_api_key', $api_key, '', 'yes');
            
            // Verify the forced update
            $forced_verification = get_option('bot_eraser_api_key', 'STILL_NOT_FOUND');
            error_log('Boteraser: After forced update: ' . substr($forced_verification, 0, 10) . '... (length: ' . strlen($forced_verification) . ')');
        }
        
        // Show different messages based on validation result
        if ($api_validation_result['valid']) {
            echo '<div class="notice notice-success"><p>Settings saved successfully. API Key validated and saved.</p></div>';
        } else {
            echo '<div class="notice notice-warning"><p>Settings saved. API Key saved but validation failed:</p></div>';
        }
    }

    // Handle manual execution form submission
    $manual_execution_data = null;
    $manual_api_validation_result = null;
    if (isset($_POST['bot_eraser_manual_run']) && check_admin_referer('bot_eraser_manual_action', '_wpnonce')) {
        // Get current API key for validation
        global $wpdb;
        $current_api_key = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s ORDER BY option_id DESC LIMIT 1", 'bot_eraser_api_key'));
        
        // Validate the API key first
        if (!empty($current_api_key)) {
            $manual_api_validation_result = bot_eraser_validate_api_key_with_server($current_api_key);
            
            // Save validation state to database
            $validation_state = array(
                'api_key_hash' => bot_eraser_simple_hash($current_api_key),
                'is_valid' => $manual_api_validation_result['valid'] ?? false,
                'message' => $manual_api_validation_result['message'] ?? '',
                'timestamp' => time()
            );
            update_option('bot_eraser_api_validation_state', $validation_state);
        }
        
        // Run the manual execution and store results directly
        $manual_execution_data = bot_eraser_send_data_to_server();
        
        // Check if manual execution failed - any error status indicates API/server issues
        if (isset($manual_execution_data['status']) && $manual_execution_data['status'] === 'error') {
            $error_message = $manual_execution_data['message'] ?? '';
            
            // Any error from the server communication indicates API key or server issues
            // Update validation state to reflect the error
            if (!empty($current_api_key)) {
                $validation_state = array(
                    'api_key_hash' => bot_eraser_simple_hash($current_api_key),
                    'is_valid' => false,
                    'message' => $error_message,
                    'timestamp' => time()
                );
                update_option('bot_eraser_api_validation_state', $validation_state);
                $manual_api_validation_result = array('valid' => false, 'message' => $error_message);
            }
        }
        
        // Show success message
        echo '<div class="notice notice-success"><p><strong>Manual execution completed!</strong> Results are displayed below.</p></div>';
    }

    // Always get the latest saved API key from the database for display
    // Try both methods to see which one works
    global $wpdb;
    $form_api_key_db = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s ORDER BY option_id DESC LIMIT 1", 'bot_eraser_api_key'));
    $form_api_key_wp = get_option('bot_eraser_api_key', '');
    
    // Use whichever is not empty, prefer the database query
    $form_api_key = !empty($form_api_key_db) ? $form_api_key_db : $form_api_key_wp;
    
    // Handle null result (no API key saved yet)
    if ($form_api_key === null || $form_api_key === false) {
        $form_api_key = '';
    }
    
    // Additional debug output to verify what we're displaying
    error_log('Boteraser: Form display - DB query result: ' . substr($form_api_key_db, 0, 10) . '... (length: ' . strlen($form_api_key_db) . ')');
    error_log('Boteraser: Form display - WP get_option result: ' . substr($form_api_key_wp, 0, 10) . '... (length: ' . strlen($form_api_key_wp) . ')');
    error_log('Boteraser: Form display - Final used value: ' . substr($form_api_key, 0, 10) . '... (length: ' . strlen($form_api_key) . ')');
    
    // Debug: Check if there are multiple entries in database
    $debug_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name = %s", 'bot_eraser_api_key'));
    error_log('Boteraser: DEBUG - Total API key entries in database: ' . $debug_count);
    
    // Debug: Show all entries if more than 1
    if ($debug_count > 1) {
        $all_entries = $wpdb->get_results($wpdb->prepare("SELECT option_id, option_value FROM {$wpdb->options} WHERE option_name = %s", 'bot_eraser_api_key'));
        error_log('Boteraser: DEBUG - Multiple entries found: ' . print_r($all_entries, true));
    }
    
    // Debug: Also try get_option to compare
    $get_option_result = get_option('bot_eraser_api_key', 'NOT_FOUND');
    error_log('Boteraser: DEBUG - get_option result: ' . substr($get_option_result, 0, 10) . '... (length: ' . strlen($get_option_result) . ')');

    ?>
    <div class="wrap">
        <div class="boteraser-header">
            <img src="<?php echo esc_url(BOT_ERASER_PLUGIN_URL . '../boteraser/logo.svg'); ?>" 
                 alt="Boteraser Logo" 
                 class="boteraser-logo">
        </div>

        <div class="boteraser-content-wrapper">
            <!-- Left Column -->
            <div class="boteraser-left-column">
                <div class="boteraser-settings-card">
                    <form method="post">
                        <?php wp_nonce_field('bot_eraser_settings', 'bot_eraser_settings_nonce'); ?>
                        <table class="form-table">
                            <tr class="api-key-table-row">
                                <th scope="row"><label for="api_key">API Key</label></th>
                                <td>
                                    <div class="api-key-wrapper">
                                        <span class="dashicons dashicons-dashboard"></span>
                                        <input type="text" name="api_key" id="api_key" 
                                               value="<?php echo esc_attr($form_api_key); ?>" 
                                               class="regular-text"
                                               autocomplete="new-password">
                                        <span class="dashicons dashicons-yes-alt"></span>
                                        <span class="dashicons dashicons-dismiss"></span>
                                        <span class="dashicons dashicons-update"></span>
                                    </div>
                                    <div class="api-key-status-indicator hidden">
                                        <div class="status-icon">
                                            <span class="dashicons dashicons-editor-help"></span>
                                        </div>
                                        <div class="status-text">Not Verified</div>
                                    </div>
                                    <p class="description">
                                        <span class="dashicons dashicons-info"></span>
                                        Get your API key from the 
                                        <a href="https://user.boteraser.com/api.php" target="_blank">Boteraser Dashboard</a>
                                    </p>
                                </td>
                            </tr>
                        </table>
                        <?php submit_button('Save Settings', 'primary'); ?>
                    </form>
                </div>

                <div class="boteraser-execution-section">
                    <h2>Manual Execution</h2>
                    <form method="post">
                        <?php wp_nonce_field('bot_eraser_manual_action', '_wpnonce', false); ?>
                        <input type="hidden" name="bot_eraser_manual_run" value="1">
                        <button type="submit" class="button button-primary button-large">
                            <span class="dashicons dashicons-update"></span>
                            Run Boteraser Now
                        </button>
                    </form>
                    

                    <?php 
                    // Use manual execution data if available, otherwise check transient for historical data
                    $data = $manual_execution_data ?: get_transient('bot_eraser_process_data');
                    
                    if ($data) : 
                        // Simplified status determination: Success or Error only
                        $status_text = 'ERROR'; // Default text
                        $status_class = 'error'; // Default visual style to error
                        $status_icon = 'dashicons-warning'; // Default icon to warning

                        if (isset($data['status']) && $data['status'] === 'success') {
                            $status_text = 'SUCCESS';
                            $status_class = 'success'; // Use success style
                            $status_icon = 'dashicons-yes-alt'; // Use success icon
                        }
                        // Any other status value (including 'warning') will use error styling

                    ?>
                    <div class="boteraser-results <?php echo esc_attr($status_class); // Will be 'success' or 'error' ?>">
                        <div class="results-header">
                            <h3>
                                <span class="dashicons <?php echo esc_attr($status_icon); // Will be 'yes-alt' or 'warning' ?>"></span>
                                Last Execution Results
                                <small><?php echo date('M j, Y H:i:s'); ?></small>
                            </h3>
                        </div>

                        <div class="results-grid">
                            <div class="results-section">
                                <h4><span class="dashicons dashicons-dashboard"></span> Server Metrics</h4>
                                <div class="metrics-box">
                                    <div class="metric">
                                        <label>Server Load</label>
                                        <div class="value"><?php echo esc_html($data['sent_data']['srv_load'] ?? 'N/A'); ?></div>
                                    </div>
                                    <div class="metric">
                                        <label>Uptime</label>
                                        <div class="value"><?php 
                                            $seconds = $data['sent_data']['uptime'] ?? 0;
                                            $days = floor($seconds / 86400);
                                            $hours = floor(($seconds % 86400) / 3600);
                                            $minutes = floor(($seconds % 3600) / 60);
                                            $seconds_remaining = $seconds % 60;
                                            $parts = [];
                                            if ($days > 0) $parts[] = $days . 'd';
                                            if ($hours > 0) $parts[] = $hours . 'h';
                                            if ($minutes > 0) $parts[] = $minutes . 'm';
                                            
                                            echo esc_html(empty($parts) ? 'N/A' : implode(' ', $parts));
                                        ?></div>
                                    </div>
                                </div>
                            </div>

                            <div class="results-section">
                                <h4><span class="dashicons dashicons-database"></span> Data Payload</h4>
                                <div class="data-box">
                                    <?php
                                    // Check if the data exists and is not empty
                                    if (!empty($data['sent_data']['data'])) {
                                        // Display the pre-formatted and pre-sorted data directly
                                        echo '<pre>' . esc_html(trim($data['sent_data']['data'])) . '</pre>';
                                    } else {
                                        // Handle cases where data is missing or empty
                                        echo '<pre>No data generated or payload key missing.</pre>';
                                    }
                                    ?>
                                </div>
                            </div>

                            <div class="results-section">
                                <h4><span class="dashicons dashicons-email-alt"></span> Server Response</h4>
                                <div class="response-box">
                                    <pre><?php echo esc_html($data['response'] ?? 'No response received'); ?></pre>
                                </div>
                            </div>
                        </div>

                        <div class="results-footer">
                            <div class="status-indicator <?php echo esc_attr($status_class); // Will be 'success' or 'error' ?>">
                                <span class="dashicons <?php echo esc_attr($status_icon); // Will be 'yes-alt' or 'warning' ?>"></span>
                                Status: <?php echo esc_html($status_text); // Displays SUCCESS, WARNING, ERROR, or UNKNOWN ?>
                            </div>
                            <div class="execution-message">
                                <?php echo esc_html($data['message'] ?? 'No execution log'); ?>
                            </div>
                        </div>
                    </div>
                    <?php 
                    // Only delete transient if we're not using manual execution data
                    if (!$manual_execution_data && get_transient('bot_eraser_process_data')) {
                        delete_transient('bot_eraser_process_data'); 
                    }
                    endif; ?>
                </div>
            </div>

            <!-- Right Column -->
            <div class="boteraser-info-panel">
                <div class="boteraser-info-card">
                    <h3><span class="dashicons dashicons-shield-alt"></span> About Boteraser</h3>
                    <p>Boteraser is a comprehensive security solution that:</p>
                    <ul>
                        <li><span class="dashicons dashicons-yes"></span> Detects malicious bots in real-time</li>
                        <li><span class="dashicons dashicons-yes"></span> Blocks suspicious IP addresses</li>
                        <li><span class="dashicons dashicons-yes"></span> Protects against DDoS attacks</li>
                        <li><span class="dashicons dashicons-yes"></span> Maintains detailed access logs</li>
                    </ul>
                </div>

                <div class="boteraser-info-card">
                    <h3><span class="dashicons dashicons-dashboard"></span> How It Works</h3>
                    <ol>
                        <li>Logs all visitor access attempts</li>
                        <li>Analyzes user-agent strings for bot patterns</li>
                        <li>Sends threat data to our security network</li>
                        <li>Updates blocking rules every 5 minutes</li>
                    </ol>
                </div>
                
                <div class="boteraser-info-card">
                    <h3><span class="dashicons dashicons-performance"></span> Data Flow</h3>
                    <div class="data-flow-diagram">
                        <div class="flow-step">
                            <span class="dashicons dashicons-admin-site"></span>
                            <div>Your Website</div>
                        </div>
                        <div class="flow-arrow">→</div>
                        <div class="flow-step">
                            <span class="dashicons dashicons-database"></span>
                            <div>Local Logs</div>
                        </div>
                        <div class="flow-arrow">→</div>
                        <div class="flow-step">
                            <span class="dashicons dashicons-cloud"></span>
                            <div>Boteraser Cloud</div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        console.log('Boteraser: Settings page loaded');
        
        // Store the validation state for comparison
        var savedValidationState = null;
        var serverApiKey = <?php echo json_encode($form_api_key); ?>;
        
        // Load validation state from server
        <?php 
        $validation_state = get_option('bot_eraser_api_validation_state', array());
        if (!empty($validation_state)) {
            echo 'savedValidationState = ' . json_encode($validation_state) . ';';
        }
        ?>
        
        // Display validation result if form was just submitted
        <?php if ($api_validation_result !== null): ?>
        updateValidationUI(<?php echo $api_validation_result['valid'] ? 'true' : 'false'; ?>, <?php echo json_encode($api_validation_result['message'] ?? ''); ?>);
        <?php elseif ($manual_api_validation_result !== null): ?>
        // Handle manual execution API validation result
        updateValidationUI(<?php echo $manual_api_validation_result['valid'] ? 'true' : 'false'; ?>, <?php echo json_encode($manual_api_validation_result['message'] ?? ''); ?>);
        <?php else: ?>
        // Check initial state based on current API key
        checkApiKeyState();
        <?php endif; ?>
        
        function simpleHash(str) {
            var hash = 0;
            if (str.length === 0) return hash.toString(16);
            for (var i = 0; i < str.length; i++) {
                var char = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & 0xffffffff;
            }
            return Math.abs(hash).toString(16);
        }
        
        function checkApiKeyState() {
            var currentApiKey = $('#api_key').val().trim();
            var $indicator = $('.api-key-status-indicator');
            
            console.log('Boteraser: Checking API key state for:', currentApiKey.substring(0, 10) + '...');
            
            // If text box is empty, show not verified
            if (currentApiKey === '') {
                showNotVerifiedState();
                return;
            }
            
            // If we have saved validation state, check if current key matches
            if (savedValidationState && savedValidationState.api_key_hash) {
                var currentKeyHash = simpleHash(currentApiKey);
                
                console.log('Boteraser: Current key hash:', currentKeyHash);
                console.log('Boteraser: Saved key hash:', savedValidationState.api_key_hash);
                
                if (currentKeyHash === savedValidationState.api_key_hash) {
                    // Current key matches previously validated key - show validation status
                    updateValidationUI(savedValidationState.is_valid, savedValidationState.message);
                } else {
                    // Current key is different from previously validated key - show not verified
                    showNotVerifiedState();
                }
            } else {
                // No validation state saved - show not verified
                showNotVerifiedState();
            }
        }
        
        function showNotVerifiedState() {
            var $wrapper = $('.api-key-wrapper');
            var $indicator = $('.api-key-status-indicator');
            var $statusIcon = $indicator.find('.status-icon .dashicons');
            var $statusText = $indicator.find('.status-text');
            
            console.log('Boteraser: Showing not verified state');
            
            // Remove all status classes
            $wrapper.removeClass('validating valid invalid');
            $indicator.removeClass('validating valid invalid hidden');
            
            // Show not verified state
            $indicator.removeClass('hidden');
            $statusIcon.removeClass('dashicons-update dashicons-yes-alt dashicons-dismiss').addClass('dashicons-editor-help');
            $statusText.text('Not Verified');
        }
        
        function updateValidationUI(isValid, message) {
            var $wrapper = $('.api-key-wrapper');
            var $indicator = $('.api-key-status-indicator');
            var $statusIcon = $indicator.find('.status-icon .dashicons');
            var $statusText = $indicator.find('.status-text');
            
            console.log('Boteraser: Updating validation UI:', isValid, message);
            
            // Remove all status classes from wrapper and indicator
            $wrapper.removeClass('validating valid invalid not-validated');
            $indicator.removeClass('validating valid invalid not-validated hidden');
            
            // Show the status indicator
            $indicator.removeClass('hidden');
            
            if (isValid === true) {
                $wrapper.addClass('valid');
                $indicator.addClass('valid');
                $statusIcon.removeClass('dashicons-update dashicons-dismiss dashicons-editor-help').addClass('dashicons-yes-alt');
                $statusText.text(message || 'API Key Valid');
            } else if (isValid === false) {
                $wrapper.addClass('invalid');
                $indicator.addClass('invalid');
                $statusIcon.removeClass('dashicons-update dashicons-yes-alt dashicons-editor-help').addClass('dashicons-dismiss');
                $statusText.text(message || 'Invalid API key');
            } else {
                // Validating state
                $wrapper.addClass('validating');
                $indicator.addClass('validating');
                $statusIcon.removeClass('dashicons-yes-alt dashicons-dismiss dashicons-editor-help').addClass('dashicons-update');
                $statusText.text(message || 'Validating...');
            }
            
            console.log('Boteraser: Validation UI updated:', isValid, message);
        }
        
        // Check API key state when user types in the input field
        $('#api_key').on('input', function() {
            checkApiKeyState();
        });
    });
    </script>
    <?php
}

// Function to clean up duplicate API key entries and ensure database consistency
function bot_eraser_cleanup_api_key_entries() {
    global $wpdb;
    
    // Get the current API key value
    $current_api_key = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", 'bot_eraser_api_key'));
    
    // Count total entries
    $total_entries = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name = %s", 'bot_eraser_api_key'));
    
    error_log('Boteraser Cleanup: Found ' . $total_entries . ' API key entries in database');
    
    if ($total_entries > 1) {
        // Remove ALL entries
        $deleted = $wpdb->delete($wpdb->options, array('option_name' => 'bot_eraser_api_key'));
        error_log('Boteraser Cleanup: Deleted ' . $deleted . ' duplicate entries');
        
        // Re-insert the single current value if it existed
        if (!empty($current_api_key)) {
            $wpdb->insert(
                $wpdb->options,
                array(
                    'option_name' => 'bot_eraser_api_key',
                    'option_value' => $current_api_key,
                    'autoload' => 'yes'
                ),
                array('%s', '%s', '%s')
            );
            error_log('Boteraser Cleanup: Re-inserted single API key entry');
        }
        
        // Clear all caches
        wp_cache_delete('bot_eraser_api_key', 'options');
        wp_cache_delete('alloptions', 'options');
        wp_cache_flush();
        
        return true; // Cleanup was performed
    }
    
    return false; // No cleanup needed
}

// Simple hash function to match JavaScript implementation
function bot_eraser_simple_hash($str) {
    $hash = 0;
    $len = strlen($str);
    if ($len === 0) return (string)$hash;
    
    for ($i = 0; $i < $len; $i++) {
        $char = ord($str[$i]);
        $hash = (($hash << 5) - $hash) + $char;
        $hash = $hash & 0xFFFFFFFF; // Convert to 32-bit integer
        if ($hash > 0x7FFFFFFF) {
            $hash -= 0x100000000; // Handle overflow
        }
    }
    return dechex(abs($hash));
}
