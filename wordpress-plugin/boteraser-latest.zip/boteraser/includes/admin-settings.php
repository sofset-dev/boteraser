<?php
/**
 * Boteraser Admin Settings Page
 *
 * @package Boteraser
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue admin styles and scripts
 */
function bot_eraser_enqueue_admin_assets($hook) {
    // Only load on Boteraser pages
    if (strpos($hook, 'bot-eraser') === false) {
        return;
    }

    // Enqueue Google Fonts
    wp_enqueue_style(
        'boteraser-google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    // Enqueue main admin CSS
    wp_enqueue_style(
        'boteraser-admin',
        BOT_ERASER_PLUGIN_URL . 'assets/css/admin.css',
        array(),
        BOT_ERASER_VERSION
    );

    // Enqueue main admin JS
    wp_enqueue_script(
        'boteraser-admin',
        BOT_ERASER_PLUGIN_URL . 'assets/js/admin.js',
        array('jquery'),
        BOT_ERASER_VERSION,
        true
    );
}
add_action('admin_enqueue_scripts', 'bot_eraser_enqueue_admin_assets');

/**
 * Add admin menu pages
 */
function bot_eraser_add_settings_page() {
    // Load custom SVG icon for WordPress admin menu
    $icon_file = BOT_ERASER_PLUGIN_DIR . 'logo-menu.svg';
    $icon_url = 'dashicons-shield'; // Fallback

    if (file_exists($icon_file)) {
        $svg_content = file_get_contents($icon_file);
        $icon_url = 'data:image/svg+xml;base64,' . base64_encode($svg_content);
    }

    add_menu_page(
        'Boteraser',
        'Boteraser',
        'manage_options',
        'bot-eraser',
        'bot_eraser_render_settings_page',
        $icon_url,
        100
    );

    add_submenu_page(
        'bot-eraser',
        __('Dashboard', 'bot-eraser'),
        __('Dashboard', 'bot-eraser'),
        'manage_options',
        'bot-eraser',
        'bot_eraser_render_settings_page'
    );

    add_submenu_page(
        'bot-eraser',
        __('Blocked IPs', 'bot-eraser'),
        __('Blocked IPs', 'bot-eraser'),
        'manage_options',
        'bot-eraser-blocked-ips',
        'bot_eraser_render_blocked_ips'
    );

    add_submenu_page(
        'bot-eraser',
        __('Logs', 'bot-eraser'),
        __('Logs', 'bot-eraser'),
        'manage_options',
        'bot-eraser-logs',
        'bot_eraser_render_logs_page'
    );

    add_submenu_page(
        'bot-eraser',
        __('FAQ', 'bot-eraser'),
        __('FAQ', 'bot-eraser'),
        'manage_options',
        'https://boteraser.com/faq/',
        ''
    );

    add_submenu_page(
        'bot-eraser',
        __('Sign Up', 'bot-eraser'),
        __('Sign Up', 'bot-eraser'),
        'manage_options',
        'https://user.boteraser.com/sign-up.php',
        ''
    );
}
add_action('admin_menu', 'bot_eraser_add_settings_page');

/**
 * Get dashboard statistics
 */
function bot_eraser_get_dashboard_stats() {
    $stats = array(
        'total_requests' => 0,
        'blocked_today' => 0,
        'unique_ips' => 0,
        'uptime' => 0
    );

    // Get total log entries
    $log_file = BOT_ERASER_LOG_PATH;
    if (file_exists($log_file)) {
        $stats['total_requests'] = count(file($log_file));
    }

    // Get blocked IPs count
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (is_array($blocked_ips)) {
            // Count IPs blocked today (still active)
            $today_start = strtotime('today');
            foreach ($blocked_ips as $ip => $expiry) {
                if ($expiry > time()) {
                    $stats['blocked_today']++;
                }
            }
        }
    }

    // Get unique IPs from logs (last 1000 entries for performance)
    if (file_exists($log_file)) {
        $lines = file($log_file);
        $recent_lines = array_slice($lines, -1000);
        $unique_ips = array();
        foreach ($recent_lines as $line) {
            if (preg_match('/^(\d+\.\d+\.\d+\.\d+)/', $line, $matches)) {
                $unique_ips[$matches[1]] = true;
            }
        }
        $stats['unique_ips'] = count($unique_ips);
    }

    // Get server uptime
    if (function_exists('sys_getloadavg')) {
        $uptime_file = '/proc/uptime';
        if (file_exists($uptime_file)) {
            $uptime = floatval(file_get_contents($uptime_file));
            $stats['uptime'] = intval($uptime);
        }
    }

    return $stats;
}

/**
 * Get recent blocked IPs for activity feed
 */
function bot_eraser_get_recent_blocked_ips($limit = 5) {
    $recent = array();
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';

    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (is_array($blocked_ips) && !empty($blocked_ips)) {
            // Sort by expiry time (most recent blocks first)
            arsort($blocked_ips);
            $count = 0;
            foreach ($blocked_ips as $ip => $expiry) {
                if ($expiry > time() && $count < $limit) {
                    $recent[] = array(
                        'ip' => $ip,
                        'expiry' => $expiry,
                        'time_ago' => human_time_diff(time() - (86400 - ($expiry - time())), time())
                    );
                    $count++;
                }
            }
        }
    }

    return $recent;
}

/**
 * SVG Icons helper
 */
function bot_eraser_icon($name, $class = '') {
    $icons = array(
        'shield' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>',
        'shield-check' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>',
        'shield-x' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="9" y1="9" x2="15" y2="15"></line><line x1="15" y1="9" x2="9" y2="15"></line></svg>',
        'key' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>',
        'check' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="20 6 9 17 4 12"></polyline></svg>',
        'check-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
        'x-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        'alert-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
        'info' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
        'loader' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>',
        'activity' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>',
        'server' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>',
        'database' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path></svg>',
        'cloud' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path></svg>',
        'globe' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>',
        'users' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        'ban' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>',
        'file-text' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>',
        'settings' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>',
        'external-link' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>',
        'refresh' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>',
        'clock' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>',
        'zap' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>',
        'trending-up' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>',
        'arrow-right' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
        'play' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>',
    );

    return isset($icons[$name]) ? $icons[$name] : '';
}

/**
 * Format uptime to human readable
 */
function bot_eraser_format_uptime($seconds) {
    $days = floor($seconds / 86400);
    $hours = floor(($seconds % 86400) / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $parts = array();
    if ($days > 0) $parts[] = $days . 'd';
    if ($hours > 0) $parts[] = $hours . 'h';
    if ($minutes > 0) $parts[] = $minutes . 'm';
    return !empty($parts) ? implode(' ', $parts) : '0m';
}

/**
 * Render the main settings page
 */
function bot_eraser_render_settings_page() {
    if (!current_user_can('manage_options')) return;

    // Clean up duplicate API key entries
    bot_eraser_cleanup_api_key_entries();

    // Handle form submissions
    $settings_saved = false;
    $api_validation_result = null;

    if (isset($_POST['bot_eraser_settings_nonce'])) {
        check_admin_referer('bot_eraser_settings', 'bot_eraser_settings_nonce');

        $api_key = sanitize_text_field($_POST['api_key']);
        $api_validation_result = bot_eraser_validate_api_key_with_server($api_key);

        // Save validation state
        $validation_state = array(
            'api_key_hash' => bot_eraser_simple_hash($api_key),
            'is_valid' => $api_validation_result['valid'] ?? false,
            'message' => $api_validation_result['message'] ?? '',
            'timestamp' => time()
        );
        update_option('bot_eraser_api_validation_state', $validation_state);

        // Save API key
        global $wpdb;
        $wpdb->delete($wpdb->options, array('option_name' => 'bot_eraser_api_key'));
        wp_cache_delete('bot_eraser_api_key', 'options');
        wp_cache_delete('alloptions', 'options');

        $wpdb->insert(
            $wpdb->options,
            array(
                'option_name' => 'bot_eraser_api_key',
                'option_value' => $api_key,
                'autoload' => 'yes'
            ),
            array('%s', '%s', '%s')
        );

        $settings_saved = true;

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Boteraser: API key saved successfully');
        }
    }

    // Handle manual execution
    $manual_execution_data = null;
    $manual_api_validation_result = null;

    if (isset($_POST['bot_eraser_manual_run']) && check_admin_referer('bot_eraser_manual_action', '_wpnonce')) {
        global $wpdb;
        $current_api_key = $wpdb->get_var($wpdb->prepare(
            "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s ORDER BY option_id DESC LIMIT 1",
            'bot_eraser_api_key'
        ));

        if (!empty($current_api_key)) {
            $manual_api_validation_result = bot_eraser_validate_api_key_with_server($current_api_key);

            $validation_state = array(
                'api_key_hash' => bot_eraser_simple_hash($current_api_key),
                'is_valid' => $manual_api_validation_result['valid'] ?? false,
                'message' => $manual_api_validation_result['message'] ?? '',
                'timestamp' => time()
            );
            update_option('bot_eraser_api_validation_state', $validation_state);
        }

        $manual_execution_data = bot_eraser_send_data_to_server();

        if (isset($manual_execution_data['status']) && $manual_execution_data['status'] === 'error') {
            $error_message = $manual_execution_data['message'] ?? '';
            if (!empty($current_api_key)) {
                $validation_state = array(
                    'api_key_hash' => bot_eraser_simple_hash($current_api_key),
                    'is_valid' => false,
                    'message' => $error_message,
                    'timestamp' => time()
                );
                update_option('bot_eraser_api_validation_state', $validation_state);
                $manual_api_validation_result = array('valid' => false, 'message' => $error_message);
            }
        }
    }

    // Get API key for form
    global $wpdb;
    $form_api_key = $wpdb->get_var($wpdb->prepare(
        "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s ORDER BY option_id DESC LIMIT 1",
        'bot_eraser_api_key'
    ));
    $form_api_key = $form_api_key ?: '';

    // Get validation state
    $validation_state = get_option('bot_eraser_api_validation_state', array());

    // Get dashboard stats
    $stats = bot_eraser_get_dashboard_stats();
    $recent_blocked = bot_eraser_get_recent_blocked_ips(5);

    // Localize script with config
    wp_localize_script('boteraser-admin', 'boteraser_config', array(
        'apiKey' => $form_api_key,
        'validationState' => $validation_state,
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('boteraser_ajax')
    ));
    ?>

    <div class="wrap boteraser-wrap">
        <!-- Header -->
        <div class="boteraser-header">
            <img src="<?php echo esc_url(BOT_ERASER_PLUGIN_URL . 'logo.svg'); ?>"
                 alt="Boteraser Logo"
                 class="boteraser-logo">
        </div>

        <!-- Notices -->
        <?php if ($settings_saved): ?>
            <div class="boteraser-notice <?php echo $api_validation_result['valid'] ? 'success' : 'warning'; ?>">
                <?php echo $api_validation_result['valid'] ? bot_eraser_icon('check-circle') : bot_eraser_icon('alert-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title">
                        <?php echo $api_validation_result['valid'] ? __('Settings Saved', 'bot-eraser') : __('Settings Saved with Warning', 'bot-eraser'); ?>
                    </p>
                    <p class="boteraser-notice-message">
                        <?php echo $api_validation_result['valid']
                            ? __('Your API key has been validated and saved successfully.', 'bot-eraser')
                            : __('API key saved but validation failed: ', 'bot-eraser') . esc_html($api_validation_result['message']); ?>
                    </p>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($manual_execution_data): ?>
            <div class="boteraser-notice <?php echo ($manual_execution_data['status'] === 'success') ? 'success' : 'error'; ?>">
                <?php echo ($manual_execution_data['status'] === 'success') ? bot_eraser_icon('check-circle') : bot_eraser_icon('x-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title"><?php _e('Manual Execution Completed', 'bot-eraser'); ?></p>
                    <p class="boteraser-notice-message"><?php _e('Results are displayed below.', 'bot-eraser'); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="boteraser-stats-grid">
            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon primary">
                    <?php echo bot_eraser_icon('activity'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($stats['total_requests']); ?>">
                        <?php echo number_format($stats['total_requests']); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Total Requests', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon error">
                    <?php echo bot_eraser_icon('ban'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($stats['blocked_today']); ?>">
                        <?php echo number_format($stats['blocked_today']); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Blocked IPs', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon success">
                    <?php echo bot_eraser_icon('users'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($stats['unique_ips']); ?>">
                        <?php echo number_format($stats['unique_ips']); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Unique IPs', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon warning">
                    <?php echo bot_eraser_icon('clock'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value">
                        <?php echo esc_html(bot_eraser_format_uptime($stats['uptime'])); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Server Uptime', 'bot-eraser'); ?></p>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="boteraser-content-wrapper">
            <!-- Left Column -->
            <div class="boteraser-left-column">
                <!-- API Key Card -->
                <div class="boteraser-card boteraser-api-section">
                    <div class="boteraser-card-header">
                        <h2 class="boteraser-card-title">
                            <?php echo bot_eraser_icon('key'); ?>
                            <?php _e('API Configuration', 'bot-eraser'); ?>
                        </h2>
                    </div>

                    <form method="post">
                        <?php wp_nonce_field('bot_eraser_settings', 'bot_eraser_settings_nonce'); ?>

                        <div class="boteraser-api-input-wrapper">
                            <span class="boteraser-api-icon"><?php echo bot_eraser_icon('key'); ?></span>
                            <input type="text"
                                   name="api_key"
                                   id="boteraser-api-key"
                                   class="boteraser-api-input <?php echo !empty($validation_state['is_valid']) ? 'valid' : (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid'] ? 'invalid' : ''); ?>"
                                   value="<?php echo esc_attr($form_api_key); ?>"
                                   placeholder="<?php _e('Enter your API key...', 'bot-eraser'); ?>"
                                   autocomplete="new-password">
                            <span class="boteraser-api-status-icon success"><?php echo bot_eraser_icon('check-circle'); ?></span>
                            <span class="boteraser-api-status-icon error"><?php echo bot_eraser_icon('x-circle'); ?></span>
                            <span class="boteraser-api-status-icon loading"><?php echo bot_eraser_icon('loader'); ?></span>
                        </div>

                        <!-- Large Status Indicator -->
                        <div class="boteraser-status-indicator <?php
                            if (!empty($validation_state['is_valid'])) echo 'valid visible';
                            elseif (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid']) echo 'invalid visible';
                        ?>">
                            <div class="boteraser-status-icon-svg">
                                <?php
                                if (!empty($validation_state['is_valid'])) {
                                    echo bot_eraser_icon('shield-check');
                                } elseif (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid']) {
                                    echo bot_eraser_icon('shield-x');
                                } else {
                                    echo bot_eraser_icon('shield');
                                }
                                ?>
                            </div>
                            <div class="boteraser-status-text">
                                <?php
                                if (!empty($validation_state['is_valid'])) {
                                    _e('API Key Valid', 'bot-eraser');
                                } elseif (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid']) {
                                    _e('Invalid API Key', 'bot-eraser');
                                } else {
                                    _e('Not Verified', 'bot-eraser');
                                }
                                ?>
                            </div>
                        </div>

                        <div class="boteraser-api-description">
                            <?php echo bot_eraser_icon('info'); ?>
                            <span>
                                <?php _e('Get your API key from the', 'bot-eraser'); ?>
                                <a href="https://user.boteraser.com/api.php" target="_blank">
                                    <?php _e('Boteraser Dashboard', 'bot-eraser'); ?>
                                    <?php echo bot_eraser_icon('external-link'); ?>
                                </a>
                            </span>
                        </div>

                        <div class="boteraser-btn-row">
                            <button type="submit" class="boteraser-btn boteraser-btn-primary">
                                <?php echo bot_eraser_icon('check'); ?>
                                <?php _e('Save Settings', 'bot-eraser'); ?>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Manual Execution Section -->
                <div class="boteraser-execution-section">
                    <div class="boteraser-card">
                        <div class="boteraser-card-header">
                            <h2 class="boteraser-card-title">
                                <?php echo bot_eraser_icon('zap'); ?>
                                <?php _e('Manual Execution', 'bot-eraser'); ?>
                            </h2>
                        </div>

                        <form method="post" name="boteraser_manual_run">
                            <?php wp_nonce_field('bot_eraser_manual_action', '_wpnonce', false); ?>
                            <input type="hidden" name="bot_eraser_manual_run" value="1">
                            <button type="submit" class="boteraser-btn boteraser-btn-success boteraser-btn-lg">
                                <?php echo bot_eraser_icon('play'); ?>
                                <?php _e('Run Boteraser Now', 'bot-eraser'); ?>
                            </button>
                        </form>

                        <div class="boteraser-progress-bar">
                            <div class="boteraser-progress-bar-fill"></div>
                        </div>

                        <?php
                        $data = $manual_execution_data ?: get_transient('bot_eraser_process_data');
                        if ($data):
                            $status_class = ($data['status'] === 'success') ? 'success' : 'error';
                        ?>
                        <div class="boteraser-results <?php echo esc_attr($status_class); ?>">
                            <div class="boteraser-results-header">
                                <h3>
                                    <?php echo ($status_class === 'success') ? bot_eraser_icon('check-circle') : bot_eraser_icon('x-circle'); ?>
                                    <?php _e('Execution Results', 'bot-eraser'); ?>
                                </h3>
                                <span class="boteraser-results-time"><?php echo date('M j, Y H:i:s'); ?></span>
                            </div>

                            <div class="boteraser-results-grid">
                                <!-- Server Metrics -->
                                <div class="boteraser-result-card">
                                    <h4><?php echo bot_eraser_icon('server'); ?> <?php _e('Server Metrics', 'bot-eraser'); ?></h4>
                                    <div class="metrics-box">
                                        <div class="metric">
                                            <label><?php _e('Load', 'bot-eraser'); ?></label>
                                            <div class="value"><?php echo esc_html($data['sent_data']['srv_load'] ?? 'N/A'); ?></div>
                                        </div>
                                        <div class="metric">
                                            <label><?php _e('Uptime', 'bot-eraser'); ?></label>
                                            <div class="value"><?php echo esc_html(bot_eraser_format_uptime($data['sent_data']['uptime'] ?? 0)); ?></div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Data Payload -->
                                <div class="boteraser-result-card">
                                    <h4><?php echo bot_eraser_icon('database'); ?> <?php _e('Data Payload', 'bot-eraser'); ?></h4>
                                    <pre><?php
                                        if (!empty($data['sent_data']['data'])) {
                                            echo esc_html(trim($data['sent_data']['data']));
                                        } else {
                                            _e('No data generated', 'bot-eraser');
                                        }
                                    ?></pre>
                                </div>

                                <!-- Server Response -->
                                <div class="boteraser-result-card">
                                    <h4><?php echo bot_eraser_icon('cloud'); ?> <?php _e('Server Response', 'bot-eraser'); ?></h4>
                                    <pre><?php echo esc_html($data['response'] ?? __('No response received', 'bot-eraser')); ?></pre>
                                </div>
                            </div>

                            <div class="boteraser-results-footer">
                                <span class="boteraser-status-badge <?php echo esc_attr($status_class); ?>">
                                    <?php echo ($status_class === 'success') ? bot_eraser_icon('check-circle') : bot_eraser_icon('x-circle'); ?>
                                    <?php echo ($status_class === 'success') ? __('SUCCESS', 'bot-eraser') : __('ERROR', 'bot-eraser'); ?>
                                </span>
                                <span class="boteraser-execution-message">
                                    <?php echo esc_html($data['message'] ?? __('No execution log', 'bot-eraser')); ?>
                                </span>
                            </div>
                        </div>
                        <?php
                            if (!$manual_execution_data && get_transient('bot_eraser_process_data')) {
                                delete_transient('bot_eraser_process_data');
                            }
                        endif;
                        ?>

                        <!-- Execution Timeline -->
                        <div class="boteraser-timeline">
                            <h4 class="boteraser-timeline-title"><?php _e('Recent Executions', 'bot-eraser'); ?></h4>
                            <div class="boteraser-timeline-list">
                                <!-- Populated by JavaScript -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column - Info Panel -->
            <div class="boteraser-info-panel">
                <!-- Quick Actions -->
                <div class="boteraser-info-card">
                    <h3><?php echo bot_eraser_icon('zap'); ?> <?php _e('Quick Actions', 'bot-eraser'); ?></h3>
                    <div class="boteraser-quick-actions">
                        <a href="<?php echo admin_url('admin.php?page=bot-eraser-logs'); ?>" class="boteraser-quick-action">
                            <?php echo bot_eraser_icon('file-text'); ?>
                            <span><?php _e('View Logs', 'bot-eraser'); ?></span>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=bot-eraser-blocked-ips'); ?>" class="boteraser-quick-action">
                            <?php echo bot_eraser_icon('ban'); ?>
                            <span><?php _e('Blocked IPs', 'bot-eraser'); ?></span>
                        </a>
                        <a href="https://user.boteraser.com/" target="_blank" class="boteraser-quick-action">
                            <?php echo bot_eraser_icon('external-link'); ?>
                            <span><?php _e('Boteraser Portal', 'bot-eraser'); ?></span>
                        </a>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="boteraser-info-card">
                    <h3><?php echo bot_eraser_icon('activity'); ?> <?php _e('Recent Blocked IPs', 'bot-eraser'); ?></h3>
                    <?php if (!empty($recent_blocked)): ?>
                    <div class="boteraser-recent-activity">
                        <?php foreach ($recent_blocked as $blocked): ?>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php echo esc_html($blocked['ip']); ?></span>
                            <span class="boteraser-activity-time"><?php echo esc_html($blocked['time_ago']); ?> ago</span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <p style="color: var(--be-gray-500); font-size: 14px;"><?php _e('No blocked IPs yet', 'bot-eraser'); ?></p>
                    <?php endif; ?>
                </div>

                <!-- About Card -->
                <div class="boteraser-info-card">
                    <h3><?php echo bot_eraser_icon('shield'); ?> <?php _e('About Boteraser', 'bot-eraser'); ?></h3>
                    <p><?php _e('Boteraser helps protect your WordPress site by:', 'bot-eraser'); ?></p>
                    <ul>
                        <li><?php echo bot_eraser_icon('check'); ?> <?php _e('Analyzing visitor traffic patterns', 'bot-eraser'); ?></li>
                        <li><?php echo bot_eraser_icon('check'); ?> <?php _e('Identifying potentially harmful requests', 'bot-eraser'); ?></li>
                        <li><?php echo bot_eraser_icon('check'); ?> <?php _e('Temporarily blocking suspicious IPs', 'bot-eraser'); ?></li>
                        <li><?php echo bot_eraser_icon('check'); ?> <?php _e('Providing detailed access logs', 'bot-eraser'); ?></li>
                    </ul>
                </div>

                <!-- Data Flow Diagram -->
                <div class="boteraser-info-card">
                    <h3><?php echo bot_eraser_icon('trending-up'); ?> <?php _e('Data Flow', 'bot-eraser'); ?></h3>
                    <div class="boteraser-data-flow">
                        <div class="boteraser-flow-step">
                            <?php echo bot_eraser_icon('globe'); ?>
                            <span><?php _e('Your Site', 'bot-eraser'); ?></span>
                        </div>
                        <span class="boteraser-flow-arrow">&rarr;</span>
                        <div class="boteraser-flow-step">
                            <?php echo bot_eraser_icon('database'); ?>
                            <span><?php _e('Local Logs', 'bot-eraser'); ?></span>
                        </div>
                        <span class="boteraser-flow-arrow">&rarr;</span>
                        <div class="boteraser-flow-step">
                            <?php echo bot_eraser_icon('cloud'); ?>
                            <span><?php _e('Boteraser Cloud', 'bot-eraser'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Clean up duplicate API key entries
 */
function bot_eraser_cleanup_api_key_entries() {
    global $wpdb;

    $current_api_key = $wpdb->get_var($wpdb->prepare(
        "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1",
        'bot_eraser_api_key'
    ));

    $total_entries = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name = %s",
        'bot_eraser_api_key'
    ));

    if ($total_entries > 1) {
        $wpdb->delete($wpdb->options, array('option_name' => 'bot_eraser_api_key'));

        if (!empty($current_api_key)) {
            $wpdb->insert(
                $wpdb->options,
                array(
                    'option_name' => 'bot_eraser_api_key',
                    'option_value' => $current_api_key,
                    'autoload' => 'yes'
                ),
                array('%s', '%s', '%s')
            );
        }

        wp_cache_delete('bot_eraser_api_key', 'options');
        wp_cache_delete('alloptions', 'options');
        wp_cache_flush();

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Boteraser: Cleaned up duplicate API key entries');
        }

        return true;
    }

    return false;
}

/**
 * Simple hash function for API key comparison
 */
function bot_eraser_simple_hash($str) {
    $hash = 0;
    $len = strlen($str);
    if ($len === 0) return (string)$hash;

    for ($i = 0; $i < $len; $i++) {
        $char = ord($str[$i]);
        $hash = (($hash << 5) - $hash) + $char;
        $hash = $hash & 0xFFFFFFFF;
        if ($hash > 0x7FFFFFFF) {
            $hash -= 0x100000000;
        }
    }
    return dechex(abs($hash));
}
