<?php
/**
 * Boteraser Admin Settings Page
 *
 * @package Boteraser
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue admin menu icon styles (on all admin pages)
 */
function bot_eraser_enqueue_menu_icon_styles() {
    echo '<style>
        /* Boteraser vertical menu - Align icon and text in all states */
        #adminmenu .toplevel_page_bot-eraser > a,
        #adminmenu .toplevel_page_bot-eraser:hover > a,
        #adminmenu .toplevel_page_bot-eraser:focus > a,
        #adminmenu .toplevel_page_bot-eraser.current > a,
        #adminmenu .toplevel_page_bot-eraser.wp-has-current-submenu > a,
        #adminmenu .toplevel_page_bot-eraser.wp-menu-open > a {
            display: flex !important;
            align-items: center !important;
            gap: 0 !important;
        }

        #adminmenu .toplevel_page_bot-eraser .wp-menu-image {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            margin-right: 0kartice n !important;
            padding-right: 0 !important;
        }

        #adminmenu .toplevel_page_bot-eraser .wp-menu-name {
            padding-left: 0 !important;
            margin-left: 0 !important;
        }

        #adminmenu .toplevel_page_bot-eraser .wp-menu-image img {
            width: 32px !important;
            height: 32px !important;
            opacity: 1 !important;
            transform: translate(2px, -2px) !important;
        }

        /* Lower icon when menu is in focus/active states */
        #adminmenu .toplevel_page_bot-eraser.current .wp-menu-image img,
        #adminmenu .toplevel_page_bot-eraser.wp-has-current-submenu .wp-menu-image img,
        #adminmenu .toplevel_page_bot-eraser.wp-menu-open .wp-menu-image img {
            position: relative !important;
            top: 4px !important;
        }

        /* Hide the before pseudo-element that WordPress uses for dashicons */
        #adminmenu .toplevel_page_bot-eraser .wp-menu-image:before {
            display: none !important;
        }

        /* Style Sign Up menu item with green background */
        #adminmenu .toplevel_page_bot-eraser .wp-submenu li a[href*="sign-up.php"] {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%) !important;
            color: #ffffff !important;
            font-weight: 600 !important;
            border-radius: 4px !important;
            margin: 4px 8px !important;
            padding: 8px 12px !important;
            transition: all 0.2s ease !important;
        }

        #adminmenu .toplevel_page_bot-eraser .wp-submenu li a[href*="sign-up.php"]:hover {
            background: linear-gradient(135deg, #059669 0%, #047857 100%) !important;
            color: #ffffff !important;
            transform: translateX(2px) !important;
            box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3) !important;
        }
    </style>';
}
add_action('admin_head', 'bot_eraser_enqueue_menu_icon_styles');

/**
 * Enqueue admin styles and scripts
 */
function bot_eraser_enqueue_admin_assets($hook) {
    // Only load on Boteraser pages
    if (strpos($hook, 'bot-eraser') === false) {
        return;
    }

    // Enqueue Google Fonts
    wp_enqueue_style(
        'boteraser-google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    // Enqueue main admin CSS
    wp_enqueue_style(
        'boteraser-admin',
        BOT_ERASER_PLUGIN_URL . 'assets/css/admin.css',
        array(),
        BOT_ERASER_VERSION
    );

    // Enqueue main admin JS
    wp_enqueue_script(
        'boteraser-admin',
        BOT_ERASER_PLUGIN_URL . 'assets/js/admin.js',
        array('jquery'),
        BOT_ERASER_VERSION,
        true
    );
}
add_action('admin_enqueue_scripts', 'bot_eraser_enqueue_admin_assets');

/**
 * Show privacy notice on first activation
 */
function bot_eraser_show_privacy_notice() {
    // Only show if not dismissed and user has admin capabilities
    if (!current_user_can('manage_options')) {
        return;
    }

    // Don't show if already dismissed
    if (get_option('bot_eraser_privacy_notice_dismissed')) {
        return;
    }
    ?>
    <div class="notice notice-warning is-dismissible" id="bot-eraser-privacy-notice" style="border-left-color: #ffc107; padding: 15px 20px;">
        <h2 style="margin-top: 0; display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 24px;">⚠️</span>
            <?php _e('Boteraser - Important Privacy Information', 'bot-eraser'); ?>
        </h2>
        <p style="font-size: 14px; margin: 10px 0;">
            <strong style="font-size: 15px;"><?php _e('This plugin sends data to an external service.', 'bot-eraser'); ?></strong>
        </p>
        <p style="font-size: 14px; margin: 10px 0;">
            <?php _e('Boteraser protects your site by sending visitor IP addresses and bot identifiers (browser type derived from device information) to our external threat analysis service at <strong>user.boteraser.com</strong>. This data is processed for security analysis and malicious IP blocking.', 'bot-eraser'); ?>
        </p>
        <p style="font-size: 14px; margin: 10px 0;">
            <?php printf(
                __('By using this plugin, you agree to transmit this data and you <strong>MUST disclose this in your website\'s Privacy Policy</strong>. Read our <a href="%s" target="_blank" style="color: #0073aa;">Privacy Policy</a> and <a href="%s" target="_blank" style="color: #0073aa;">Terms of Service</a> for complete details.', 'bot-eraser'),
                'https://boteraser.com/privacy-policy/',
                'https://boteraser.com/terms-of-service/'
            ); ?>
        </p>
        <div style="background: #fff; border: 1px solid #ddd; padding: 12px; margin: 15px 0; border-radius: 4px;">
            <p style="margin: 0 0 8px 0; font-weight: 600; font-size: 14px;">
                <?php _e('Data sent to external service:', 'bot-eraser'); ?>
            </p>
            <ul style="list-style: disc; padding-left: 25px; margin: 0; font-size: 14px;">
                <li><?php _e('Visitor IP addresses (personal data under GDPR)', 'bot-eraser'); ?></li>
                <li><?php _e('Bot identifiers', 'bot-eraser'); ?></li>
            </ul>
        </div>
        <p style="margin-top: 15px;">
            <button type="button" class="button button-primary" id="bot-eraser-dismiss-notice" style="padding: 8px 20px; font-size: 14px;">
                <?php _e('I Understand and Accept', 'bot-eraser'); ?>
            </button>
            <a href="https://boteraser.com/privacy-policy/" target="_blank" class="button" style="margin-left: 10px; padding: 8px 20px; font-size: 14px;">
                <?php _e('Read Privacy Policy', 'bot-eraser'); ?>
            </a>
        </p>
    </div>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#bot-eraser-dismiss-notice').on('click', function(e) {
            e.preventDefault();
            var button = $(this);
            button.prop('disabled', true).text('<?php _e('Processing...', 'bot-eraser'); ?>');

            $.post(ajaxurl, {
                action: 'bot_eraser_dismiss_privacy_notice',
                nonce: '<?php echo wp_create_nonce('bot_eraser_dismiss_notice'); ?>'
            }, function(response) {
                $('#bot-eraser-privacy-notice').fadeOut(300, function() {
                    $(this).remove();
                });
            }).fail(function() {
                button.prop('disabled', false).text('<?php _e('I Understand and Accept', 'bot-eraser'); ?>');
                alert('<?php _e('Error dismissing notice. Please try again.', 'bot-eraser'); ?>');
            });
        });

        // Handle native WordPress dismiss button
        $('#bot-eraser-privacy-notice').on('click', '.notice-dismiss', function() {
            $.post(ajaxurl, {
                action: 'bot_eraser_dismiss_privacy_notice',
                nonce: '<?php echo wp_create_nonce('bot_eraser_dismiss_notice'); ?>'
            });
        });
    });
    </script>
    <?php
}
add_action('admin_notices', 'bot_eraser_show_privacy_notice');

/**
 * AJAX handler for dismissing privacy notice
 */
function bot_eraser_dismiss_privacy_notice_ajax() {
    check_ajax_referer('bot_eraser_dismiss_notice', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
        return;
    }

    update_option('bot_eraser_privacy_notice_dismissed', true, false);
    wp_send_json_success();
}
add_action('wp_ajax_bot_eraser_dismiss_privacy_notice', 'bot_eraser_dismiss_privacy_notice_ajax');

/**
 * Add admin menu pages
 */
function bot_eraser_add_settings_page() {
    // Load custom SVG icon for WordPress admin menu
    $icon_file = BOT_ERASER_PLUGIN_DIR . 'assets/images/logo-menu.svg';
    $icon_url = 'dashicons-shield'; // Fallback

    if (file_exists($icon_file)) {
        $icon_url = BOT_ERASER_PLUGIN_URL . 'assets/images/logo-menu.svg';
    }

    add_menu_page(
        'Boteraser',
        'Boteraser',
        'manage_options',
        'bot-eraser',
        'bot_eraser_render_settings_page',
        $icon_url,
        100
    );

    add_submenu_page(
        'bot-eraser',
        __('Dashboard', 'bot-eraser'),
        __('Dashboard', 'bot-eraser'),
        'manage_options',
        'bot-eraser',
        'bot_eraser_render_settings_page'
    );

    add_submenu_page(
        'bot-eraser',
        __('Blocked IPs', 'bot-eraser'),
        __('Blocked IPs', 'bot-eraser'),
        'manage_options',
        'bot-eraser-blocked-ips',
        'bot_eraser_render_blocked_ips'
    );

    add_submenu_page(
        'bot-eraser',
        __('Logs', 'bot-eraser'),
        __('Logs', 'bot-eraser'),
        'manage_options',
        'bot-eraser-logs',
        'bot_eraser_render_logs_page'
    );

    add_submenu_page(
        'bot-eraser',
        __('FAQ', 'bot-eraser'),
        __('FAQ', 'bot-eraser'),
        'manage_options',
        'https://boteraser.com/faq/',
        ''
    );

    add_submenu_page(
        'bot-eraser',
        __('Contact Us', 'bot-eraser'),
        __('Contact Us', 'bot-eraser'),
        'manage_options',
        'https://boteraser.com/contact/',
        ''
    );

    add_submenu_page(
        'bot-eraser',
        __('Sign Up', 'bot-eraser'),
        __('Sign Up', 'bot-eraser'),
        'manage_options',
        'https://user.boteraser.com/sign-up.php',
        ''
    );
}
add_action('admin_menu', 'bot_eraser_add_settings_page');

/**
 * Add Boteraser to WordPress Admin Bar
 */
function bot_eraser_add_admin_bar_menu($wp_admin_bar) {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Get cached metrics (cache for 60 seconds)
    $metrics = get_transient('bot_eraser_admin_bar_metrics');

    if (false === $metrics) {
        $threat_level = bot_eraser_get_threat_level();
        $active_blocks = bot_eraser_get_active_blocks_today();
        $recent_activity = bot_eraser_get_recent_activity();
        $protection_rate = bot_eraser_get_protection_rate();

        $metrics = array(
            'threat_level' => $threat_level,
            'active_blocks' => $active_blocks,
            'recent_activity' => $recent_activity,
            'protection_rate' => $protection_rate
        );

        set_transient('bot_eraser_admin_bar_metrics', $metrics, 60);
    }

    // Load icon URL (same as vertical menu)
    $icon_url = BOT_ERASER_PLUGIN_URL . 'assets/images/logo-menu.svg';

    // Add main Boteraser menu item with icon
    $wp_admin_bar->add_node(array(
        'id'    => 'boteraser',
        'title' => '<img src="' . esc_url($icon_url) . '" class="boteraser-admin-bar-icon" alt="Boteraser"><span class="ab-label">Boteraser</span>',
        'href'  => admin_url('admin.php?page=bot-eraser'),
        'meta'  => array(
            'class' => 'boteraser-admin-bar-item',
        ),
    ));

    // Determine threat level color and label
    $threat_color = 'green';
    $threat_label = 'LOW';
    if ($metrics['threat_level']['level'] === 'high') {
        $threat_color = 'red';
        $threat_label = 'HIGH';
    } elseif ($metrics['threat_level']['level'] === 'medium') {
        $threat_color = 'orange';
        $threat_label = 'MEDIUM';
    }

    // Determine all metrics colors
    $blocked_count = $metrics['active_blocks']['count'];
    $blocked_color = 'green';
    if ($blocked_count > 20) {
        $blocked_color = 'red';
    } elseif ($blocked_count > 5) {
        $blocked_color = 'orange';
    }

    $activity_count = $metrics['recent_activity']['count'];
    $activity_color = 'green';
    if ($activity_count > 500) {
        $activity_color = 'red';
    } elseif ($activity_count > 200) {
        $activity_color = 'orange';
    }

    $blocked_traffic_pct = $metrics['protection_rate']['rate'];
    $blocked_traffic_color = 'green';
    if ($blocked_traffic_pct > 60) {
        $blocked_traffic_color = 'red';
    } elseif ($blocked_traffic_pct > 30) {
        $blocked_traffic_color = 'orange';
    }

    // Build custom dropdown HTML with status badges in 2x2 grid
    $dropdown_html = '
    <div class="boteraser-metrics-container">
        <div class="boteraser-metrics-header">
            <span class="boteraser-header-text">Security Overview</span>
        </div>
        <div class="boteraser-metrics-grid">
            <a href="' . admin_url('admin.php?page=bot-eraser') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $threat_color . '">
                    <span class="boteraser-circle-value">' . esc_html($threat_label) . '</span>
                </div>
                <div class="boteraser-metric-label">Threat Level</div>
            </a>
            <a href="' . admin_url('admin.php?page=bot-eraser-blocked-ips') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $blocked_color . '">
                    <span class="boteraser-circle-value">' . number_format($blocked_count) . '</span>
                </div>
                <div class="boteraser-metric-label">Blocked IPs</div>
            </a>
            <a href="' . admin_url('admin.php?page=bot-eraser-logs') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $activity_color . '">
                    <span class="boteraser-circle-value">' . number_format($activity_count) . '</span>
                </div>
                <div class="boteraser-metric-label">Last Hour</div>
            </a>
            <a href="' . admin_url('admin.php?page=bot-eraser') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $blocked_traffic_color . '">
                    <span class="boteraser-circle-value">' . $blocked_traffic_pct . '%</span>
                </div>
                <div class="boteraser-metric-label">Blocked Traffic</div>
            </a>
        </div>
    </div>';

    // Add single submenu item with grid HTML
    $wp_admin_bar->add_node(array(
        'parent' => 'boteraser',
        'id'     => 'boteraser-metrics',
        'title'  => $dropdown_html,
        'href'   => false,
    ));
}
add_action('admin_bar_menu', 'bot_eraser_add_admin_bar_menu', 100);

/**
 * Enqueue admin bar styles
 */
function bot_eraser_enqueue_admin_bar_styles() {
    if (!is_admin_bar_showing() || !current_user_can('manage_options')) {
        return;
    }

    echo '<style>
        /* Boteraser Admin Bar Icon */
        #wpadminbar .boteraser-admin-bar-icon {
            opacity: 0.9;
            vertical-align: middle !important;
            position: relative !important;
            top: 0px !important;
        }

        #wpadminbar .boteraser-admin-bar-item:hover .boteraser-admin-bar-icon {
            opacity: 1;
        }

        #wpadminbar .boteraser-admin-bar-item .ab-label {
            vertical-align: middle !important;
            position: relative !important;
            top: -2px !important;
        }

        /* Metrics Container */
        #wpadminbar .boteraser-metrics-container {
            background: #23282d !important;
            border-radius: 4px !important;
            padding: 10px 18px 36px 18px !important;
        }

        /* Metrics Header */
        #wpadminbar .boteraser-metrics-header {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            margin-bottom: 12px !important;
            padding-bottom: 10px !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1) !important;
        }

        #wpadminbar .boteraser-header-icon {
            font-size: 14px !important;
            margin-right: 6px !important;
        }

        #wpadminbar .boteraser-header-text {
            font-size: 13px !important;
            font-weight: 600 !important;
            color: #f0f0f1 !important;
            letter-spacing: 0.3px !important;
        }

        /* Metrics Grid Container */
        #wpadminbar .boteraser-metrics-grid {
            display: grid !important;
            grid-template-columns: repeat(2, 100px) !important;
            column-gap: 0px !important;
            row-gap: 30px !important;
            align-items: start !important;
        }

        /* Metric Items */
        #wpadminbar .boteraser-metric-item {
            display: flex !important;
            flex-direction: column !important;
            align-items: center !important;
            justify-content: flex-start !important;
            padding: 8px !important;
            text-decoration: none !important;
            transition: all 0.2s ease !important;
            cursor: pointer !important;
            background: transparent !important;
        }

        /* Status Circle */
        #wpadminbar .boteraser-status-circle {
            width: 65px !important;
            height: 65px !important;
            border-radius: 26px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            margin-bottom: 8px !important;
            transition: all 0.3s ease !important;
        }

        /* Circle value */
        #wpadminbar .boteraser-circle-value {
            font-size: 12px !important;
            font-weight: 700 !important;
            color: #f0f0f1 !important;
            text-align: center !important;
            text-shadow: none !important;
        }

        /* Circle Colors */
        #wpadminbar .boteraser-circle-green {
            background: transparent !important;
            border: 3px solid #10b981 !important;
            box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4) !important;
        }

        #wpadminbar .boteraser-circle-orange {
            background: transparent !important;
            border: 3px solid #f59e0b !important;
            box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.4) !important;
            animation: breathe-orange 2.5s ease-in-out infinite !important;
        }

        #wpadminbar .boteraser-circle-red {
            background: transparent !important;
            border: 3px solid #ef4444 !important;
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4) !important;
            animation: breathe-red 2s ease-in-out infinite !important;
        }

        /* Breathing Animations */
        @keyframes breathe-orange {
            0%, 100% {
                opacity: 1;
                transform: scale(1);
                box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.4);
            }
            50% {
                opacity: 0.75;
                transform: scale(1.05);
                box-shadow: 0 0 16px 4px rgba(245, 158, 11, 0.6);
            }
        }

        @keyframes breathe-red {
            0%, 100% {
                opacity: 1;
                transform: scale(1);
                box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4);
            }
            50% {
                opacity: 0.7;
                transform: scale(1.08);
                box-shadow: 0 0 20px 6px rgba(239, 68, 68, 0.7);
            }
        }

        /* Metric Label */
        #wpadminbar .boteraser-metric-label {
            font-size: 9px !important;
            font-weight: 600 !important;
            color: #a7aaad !important;
            text-transform: uppercase !important;
            letter-spacing: 0.2px !important;
            text-align: center !important;
            line-height: 1.2 !important;
            min-height: 22px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
        }

        /* Trend Indicator */
        #wpadminbar .boteraser-trend {
            font-size: 9px !important;
            margin-left: 3px !important;
            opacity: 0.85 !important;
            font-weight: 500 !important;
        }

        /* Hover Effects */
        #wpadminbar .boteraser-metric-item:hover {
            transform: translateY(-3px) !important;
        }

        #wpadminbar .boteraser-metric-item:hover .boteraser-status-circle {
            transform: scale(1.08) !important;
        }

        #wpadminbar .boteraser-metric-item:hover .boteraser-circle-green {
            box-shadow: 0 0 20px 6px rgba(16, 185, 129, 0.6) !important;
        }

        #wpadminbar .boteraser-metric-item:hover .boteraser-circle-orange {
            box-shadow: 0 0 20px 6px rgba(245, 158, 11, 0.7) !important;
        }

        #wpadminbar .boteraser-metric-item:hover .boteraser-circle-red {
            box-shadow: 0 0 24px 8px rgba(239, 68, 68, 0.8) !important;
        }

        #wpadminbar .boteraser-metric-item:hover .boteraser-metric-label {
            color: #d0d1d2 !important;
        }

        /* Dropdown Animation and Background */
        #wpadminbar #wp-admin-bar-boteraser .ab-submenu {
            animation: fadeInSlide 0.2s ease !important;
            background: #23282d !important;
            border-radius: 4px !important;
            box-shadow: 0 3px 15px rgba(0,0,0,0.2) !important;
        }

        @keyframes fadeInSlide {
            from {
                opacity: 0;
                transform: translateY(-8px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Remove default WordPress submenu styles */
        #wpadminbar #wp-admin-bar-boteraser-metrics > .ab-item {
            padding: 0 !important;
            background: transparent !important;
        }

        #wpadminbar #wp-admin-bar-boteraser-metrics:hover > .ab-item {
            background: transparent !important;
        }

        /* Responsive adjustments */
        @media screen and (max-width: 782px) {
            #wpadminbar .boteraser-metrics-grid {
                grid-template-columns: repeat(2, 150px) !important;
                gap: 12px !important;
                padding: 16px !important;
            }

            #wpadminbar .boteraser-metric-item {
                padding: 10px !important;
            }

            #wpadminbar .boteraser-status-circle {
                width: 70px !important;
                height: 70px !important;
            }

            #wpadminbar .boteraser-circle-value {
                font-size: 18px !important;
            }

            #wpadminbar .boteraser-metric-label {
                font-size: 10px !important;
            }
        }
    </style>';
}
add_action('admin_head', 'bot_eraser_enqueue_admin_bar_styles');
add_action('wp_head', 'bot_eraser_enqueue_admin_bar_styles');

/**
 * Get dashboard statistics with trends
 */
function bot_eraser_get_dashboard_stats() {
    $stats = array(
        'total_requests' => 0,
        'blocked_today' => 0,
        'unique_ips' => 0,
        'uptime' => 0,
        'trends' => array(
            'total_requests' => array('direction' => 'neutral', 'percentage' => 0),
            'blocked_today' => array('direction' => 'neutral', 'percentage' => 0),
            'unique_ips' => array('direction' => 'neutral', 'percentage' => 0),
        )
    );

    // Get stored stats from yesterday for trend comparison
    $yesterday_stats = get_transient('bot_eraser_yesterday_stats');
    $current_day = date('Y-m-d');
    $stored_day = get_option('bot_eraser_stats_day', '');

    // Get total log entries
    $log_file = BOT_ERASER_LOG_PATH;
    if (file_exists($log_file)) {
        $stats['total_requests'] = count(file($log_file));
    }

    // Get blocked IPs count
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (is_array($blocked_ips)) {
            // Count IPs blocked today (still active)
            $today_start = strtotime('today');
            foreach ($blocked_ips as $ip => $expiry) {
                if ($expiry > time()) {
                    $stats['blocked_today']++;
                }
            }
        }
    }

    // Get unique IPs from logs (last 1000 entries for performance)
    if (file_exists($log_file)) {
        $lines = file($log_file);
        $recent_lines = array_slice($lines, -1000);
        $unique_ips = array();
        foreach ($recent_lines as $line) {
            if (preg_match('/^(\d+\.\d+\.\d+\.\d+)/', $line, $matches)) {
                $unique_ips[$matches[1]] = true;
            }
        }
        $stats['unique_ips'] = count($unique_ips);
    }

    // Get server uptime
    if (function_exists('sys_getloadavg')) {
        $uptime_file = '/proc/uptime';
        if (file_exists($uptime_file)) {
            $uptime = floatval(file_get_contents($uptime_file));
            $stats['uptime'] = intval($uptime);
        }
    }

    // Calculate trends if we have yesterday's data
    if ($yesterday_stats && is_array($yesterday_stats)) {
        // Total Requests trend
        if ($yesterday_stats['total_requests'] > 0) {
            $change = $stats['total_requests'] - $yesterday_stats['total_requests'];
            $percentage = abs(round(($change / $yesterday_stats['total_requests']) * 100));
            $stats['trends']['total_requests'] = array(
                'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
                'percentage' => $percentage
            );
        }

        // Blocked IPs trend
        if (isset($yesterday_stats['blocked_today'])) {
            $change = $stats['blocked_today'] - $yesterday_stats['blocked_today'];
            $percentage = $yesterday_stats['blocked_today'] > 0
                ? abs(round(($change / $yesterday_stats['blocked_today']) * 100))
                : ($stats['blocked_today'] > 0 ? 100 : 0);
            $stats['trends']['blocked_today'] = array(
                'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
                'percentage' => $percentage
            );
        }

        // Unique IPs trend
        if ($yesterday_stats['unique_ips'] > 0) {
            $change = $stats['unique_ips'] - $yesterday_stats['unique_ips'];
            $percentage = abs(round(($change / $yesterday_stats['unique_ips']) * 100));
            $stats['trends']['unique_ips'] = array(
                'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
                'percentage' => $percentage
            );
        }
    }

    // Store today's stats for tomorrow's comparison (once per day)
    if ($current_day !== $stored_day) {
        set_transient('bot_eraser_yesterday_stats', $stats, DAY_IN_SECONDS);
        update_option('bot_eraser_stats_day', $current_day);
    }

    return $stats;
}

/**
 * Calculate threat level based on current stats
 */
function bot_eraser_get_threat_level() {
    $log_file = BOT_ERASER_LOG_PATH;
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';

    $threat_level = 'low';
    $threat_score = 0;

    // Count active blocked IPs
    $blocked_count = 0;
    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (is_array($blocked_ips)) {
            foreach ($blocked_ips as $ip => $expiry) {
                if ($expiry > time()) {
                    $blocked_count++;
                }
            }
        }
    }

    // Threat scoring
    if ($blocked_count > 50) {
        $threat_score += 40;
    } elseif ($blocked_count > 20) {
        $threat_score += 25;
    } elseif ($blocked_count > 5) {
        $threat_score += 10;
    }

    // Check recent activity (last hour)
    if (file_exists($log_file)) {
        $lines = file($log_file);
        $recent_count = 0;
        $one_hour_ago = time() - 3600;

        foreach (array_reverse($lines) as $line) {
            // Match Apache log format: [13/Jan/2026:02:23:12 +0000]
            if (preg_match('/\[(\d{2})\/(\w{3})\/(\d{4}):(\d{2}):(\d{2}):(\d{2})\s+[^\]]+\]/', $line, $matches)) {
                $date_string = $matches[3] . '-' . $matches[2] . '-' . $matches[1] . ' ' . $matches[4] . ':' . $matches[5] . ':' . $matches[6];
                $timestamp = strtotime($date_string);
                if ($timestamp > $one_hour_ago) {
                    $recent_count++;
                } else {
                    break;
                }
            }
        }

        if ($recent_count > 500) {
            $threat_score += 30;
        } elseif ($recent_count > 200) {
            $threat_score += 15;
        }
    }

    // Determine threat level
    if ($threat_score >= 50) {
        $threat_level = 'high';
    } elseif ($threat_score >= 25) {
        $threat_level = 'medium';
    }

    return array(
        'level' => $threat_level,
        'score' => $threat_score,
        'blocked_count' => $blocked_count
    );
}

/**
 * Calculate protection rate
 */
function bot_eraser_get_protection_rate() {
    $log_file = BOT_ERASER_LOG_PATH;
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';

    $total_requests = 0;
    $blocked_requests = 0;

    // Count total requests
    if (file_exists($log_file)) {
        $total_requests = count(file($log_file));
    }

    // Count blocked IPs
    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (is_array($blocked_ips)) {
            $blocked_requests = count($blocked_ips);
        }
    }

    $rate = 0;
    if ($total_requests > 0) {
        $rate = round(($blocked_requests / $total_requests) * 100, 1);
    }

    return array(
        'rate' => $rate,
        'total' => $total_requests,
        'blocked' => $blocked_requests
    );
}

/**
 * Get recent activity (last hour)
 */
function bot_eraser_get_recent_activity() {
    $log_file = BOT_ERASER_LOG_PATH;
    $recent_count = 0;
    $previous_hour_count = 0;
    $trend = array('direction' => 'neutral', 'percentage' => 0);

    if (!file_exists($log_file)) {
        return array(
            'count' => 0,
            'trend' => $trend,
            'status' => 'normal'
        );
    }

    $lines = file($log_file);
    $one_hour_ago = time() - 3600;
    $two_hours_ago = time() - 7200;

    // Count requests in last hour and previous hour
    foreach (array_reverse($lines) as $line) {
        // Match Apache log format: [13/Jan/2026:02:23:12 +0000]
        if (preg_match('/\[(\d{2})\/(\w{3})\/(\d{4}):(\d{2}):(\d{2}):(\d{2})\s+[^\]]+\]/', $line, $matches)) {
            // Convert to timestamp: day/month/year:hour:min:sec
            $date_string = $matches[3] . '-' . $matches[2] . '-' . $matches[1] . ' ' . $matches[4] . ':' . $matches[5] . ':' . $matches[6];
            $timestamp = strtotime($date_string);

            if ($timestamp > $one_hour_ago) {
                $recent_count++;
            } elseif ($timestamp > $two_hours_ago) {
                $previous_hour_count++;
            } elseif ($timestamp <= $two_hours_ago) {
                break; // No need to process older entries
            }
        }
    }

    // Calculate trend
    if ($previous_hour_count > 0) {
        $change = $recent_count - $previous_hour_count;
        $percentage = abs(round(($change / $previous_hour_count) * 100));
        $trend = array(
            'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
            'percentage' => $percentage
        );
    } elseif ($recent_count > 0) {
        $trend = array('direction' => 'up', 'percentage' => 100);
    }

    // Determine status based on activity level
    $status = 'normal';
    if ($recent_count > 500) {
        $status = 'high';
    } elseif ($recent_count > 200) {
        $status = 'elevated';
    }

    return array(
        'count' => $recent_count,
        'trend' => $trend,
        'status' => $status
    );
}

/**
 * Get active blocks today
 */
function bot_eraser_get_active_blocks_today() {
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    $current_count = 0;
    $yesterday_count = 0;
    $trend = array('direction' => 'neutral', 'percentage' => 0);

    if (!file_exists($blocked_ips_file)) {
        return array(
            'count' => 0,
            'trend' => $trend,
            'status' => 'normal'
        );
    }

    $blocked_ips = include $blocked_ips_file;
    if (!is_array($blocked_ips)) {
        return array(
            'count' => 0,
            'trend' => $trend,
            'status' => 'normal'
        );
    }

    $current_time = time();

    // Count all currently active blocked IPs (same logic as dashboard stats)
    foreach ($blocked_ips as $ip => $expiry) {
        if ($expiry > $current_time) {
            $current_count++;
        }
    }

    // Get yesterday's count from stored stats for trend calculation
    $yesterday_stats = get_transient('bot_eraser_yesterday_stats');
    if ($yesterday_stats && isset($yesterday_stats['blocked_today'])) {
        $yesterday_count = $yesterday_stats['blocked_today'];
    }

    // Calculate trend
    if ($yesterday_count > 0) {
        $change = $current_count - $yesterday_count;
        $percentage = abs(round(($change / $yesterday_count) * 100));
        $trend = array(
            'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
            'percentage' => $percentage
        );
    } elseif ($current_count > 0) {
        $trend = array('direction' => 'up', 'percentage' => 100);
    }

    // Determine status
    $status = 'normal';
    if ($current_count > 20) {
        $status = 'high';
    } elseif ($current_count > 5) {
        $status = 'elevated';
    }

    return array(
        'count' => $current_count,
        'trend' => $trend,
        'status' => $status
    );
}

/**
 * Get recent blocked IPs for activity feed
 */
function bot_eraser_get_recent_blocked_ips($limit = 5) {
    $recent = array();
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';

    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (is_array($blocked_ips) && !empty($blocked_ips)) {
            // Sort by expiry time (most recent blocks first)
            arsort($blocked_ips);
            $count = 0;
            foreach ($blocked_ips as $ip => $expiry) {
                if ($expiry > time() && $count < $limit) {
                    $recent[] = array(
                        'ip' => $ip,
                        'expiry' => $expiry,
                        'time_ago' => human_time_diff(time() - (86400 - ($expiry - time())), time())
                    );
                    $count++;
                }
            }
        }
    }

    return $recent;
}

/**
 * SVG Icons helper
 */
function bot_eraser_icon($name, $class = '') {
    $icons = array(
        'shield' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>',
        'shield-check' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>',
        'shield-x' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="9" y1="9" x2="15" y2="15"></line><line x1="15" y1="9" x2="9" y2="15"></line></svg>',
        'key' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>',
        'check' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="20 6 9 17 4 12"></polyline></svg>',
        'check-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
        'x-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        'alert-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
        'info' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
        'loader' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>',
        'activity' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>',
        'server' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>',
        'database' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path></svg>',
        'cloud' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path></svg>',
        'globe' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>',
        'users' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        'ban' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>',
        'file-text' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>',
        'settings' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>',
        'external-link' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>',
        'refresh' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>',
        'clock' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>',
        'zap' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>',
        'trending-up' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>',
        'arrow-right' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
        'play' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>',
        'arrow-up' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>',
        'arrow-down' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline></svg>',
        'minus' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="5" y1="12" x2="19" y2="12"></line></svg>',
        'help-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
    );

    return isset($icons[$name]) ? $icons[$name] : '';
}

/**
 * Format uptime to human readable
 */
function bot_eraser_format_uptime($seconds) {
    $days = floor($seconds / 86400);
    $hours = floor(($seconds % 86400) / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $parts = array();
    if ($days > 0) $parts[] = $days . 'd';
    if ($hours > 0) $parts[] = $hours . 'h';
    if ($minutes > 0) $parts[] = $minutes . 'm';
    return !empty($parts) ? implode(' ', $parts) : '0m';
}

/**
 * Render the main settings page
 */
function bot_eraser_render_settings_page() {
    if (!current_user_can('manage_options')) return;

    // Check if privacy notice has been accepted
    $privacy_accepted = get_option('bot_eraser_privacy_notice_dismissed');

    // Clean up duplicate API key entries
    bot_eraser_cleanup_api_key_entries();

    // Handle form submissions
    $settings_saved = false;
    $api_validation_result = null;

    // Block form submission if privacy notice not accepted
    if (isset($_POST['bot_eraser_settings_nonce']) && $privacy_accepted) {
        check_admin_referer('bot_eraser_settings', 'bot_eraser_settings_nonce');

        $api_key = sanitize_text_field($_POST['api_key']);
        $api_validation_result = bot_eraser_validate_api_key_with_server($api_key);

        // Save validation state
        $validation_state = array(
            'api_key_hash' => bot_eraser_simple_hash($api_key),
            'is_valid' => $api_validation_result['valid'] ?? false,
            'message' => $api_validation_result['message'] ?? '',
            'timestamp' => time()
        );
        update_option('bot_eraser_api_validation_state', $validation_state);

        // Save API key
        global $wpdb;
        $wpdb->delete($wpdb->options, array('option_name' => 'bot_eraser_api_key'));
        wp_cache_delete('bot_eraser_api_key', 'options');
        wp_cache_delete('alloptions', 'options');

        $wpdb->insert(
            $wpdb->options,
            array(
                'option_name' => 'bot_eraser_api_key',
                'option_value' => $api_key,
                'autoload' => 'yes'
            ),
            array('%s', '%s', '%s')
        );

        $settings_saved = true;

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Boteraser: API key saved successfully');
        }
    }

    // Handle manual execution
    $manual_execution_data = null;

    // Block manual execution if privacy notice not accepted
    if (isset($_POST['bot_eraser_manual_run']) && check_admin_referer('bot_eraser_manual_action', '_wpnonce') && $privacy_accepted) {
        // Save last manual run time
        update_option('bot_eraser_last_manual_run', time());

        // Send data to server - this will also update validation state
        $manual_execution_data = bot_eraser_send_data_to_server('manual');

        // Update validation state based on execution result
        global $wpdb;
        $current_api_key = $wpdb->get_var($wpdb->prepare(
            "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s ORDER BY option_id DESC LIMIT 1",
            'bot_eraser_api_key'
        ));

        if (!empty($current_api_key)) {
            $error_message = $manual_execution_data['message'] ?? '';
            $is_success = ($manual_execution_data['status'] ?? 'error') === 'success';

            $validation_state = array(
                'api_key_hash' => bot_eraser_simple_hash($current_api_key),
                'is_valid' => $is_success,
                'message' => $error_message,
                'timestamp' => time()
            );
            update_option('bot_eraser_api_validation_state', $validation_state);
        }
    }

    // Get API key for form
    global $wpdb;
    $form_api_key = $wpdb->get_var($wpdb->prepare(
        "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s ORDER BY option_id DESC LIMIT 1",
        'bot_eraser_api_key'
    ));
    $form_api_key = $form_api_key ?: '';

    // Get validation state
    $validation_state = get_option('bot_eraser_api_validation_state', array());

    // Get dashboard stats
    $stats = bot_eraser_get_dashboard_stats();
    $recent_blocked = bot_eraser_get_recent_blocked_ips(5);
    $threat_level = bot_eraser_get_threat_level();
    $protection_rate = bot_eraser_get_protection_rate();
    $recent_activity = bot_eraser_get_recent_activity();
    $active_blocks_today = bot_eraser_get_active_blocks_today();

    // Localize script with config
    wp_localize_script('boteraser-admin', 'boteraser_config', array(
        'apiKey' => $form_api_key,
        'validationState' => $validation_state,
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('boteraser_ajax')
    ));
    ?>

    <div class="wrap boteraser-wrap">
        <!-- Header -->
        <div class="boteraser-header">
            <img src="<?php echo esc_url(BOT_ERASER_PLUGIN_URL . 'assets/images/logo.svg'); ?>"
                 alt="Boteraser Logo"
                 class="boteraser-logo">
        </div>

        <!-- Notices -->
        <?php if ($settings_saved): ?>
            <div class="boteraser-notice <?php echo $api_validation_result['valid'] ? 'success' : 'warning'; ?>">
                <?php echo $api_validation_result['valid'] ? bot_eraser_icon('check-circle') : bot_eraser_icon('alert-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title">
                        <?php echo $api_validation_result['valid'] ? __('Settings Saved', 'bot-eraser') : __('Settings Saved with Warning', 'bot-eraser'); ?>
                    </p>
                    <p class="boteraser-notice-message">
                        <?php echo $api_validation_result['valid']
                            ? __('Your API key has been validated and saved successfully.', 'bot-eraser')
                            : __('API key saved but validation failed: ', 'bot-eraser') . esc_html($api_validation_result['message']); ?>
                    </p>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($manual_execution_data): ?>
            <div class="boteraser-notice <?php echo ($manual_execution_data['status'] === 'success') ? 'success' : 'error'; ?>">
                <?php echo ($manual_execution_data['status'] === 'success') ? bot_eraser_icon('check-circle') : bot_eraser_icon('x-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title"><?php _e('Manual Execution Completed', 'bot-eraser'); ?></p>
                    <p class="boteraser-notice-message"><?php _e('Results are displayed below.', 'bot-eraser'); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="boteraser-stats-grid">
            <a href="<?php echo admin_url('admin.php?page=bot-eraser-logs'); ?>" class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Click to view detailed logs', 'bot-eraser'); ?>">
                <div class="boteraser-stat-icon purple">
                    <?php echo bot_eraser_icon('activity'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <div class="boteraser-stat-header">
                        <p class="boteraser-stat-value" data-count="<?php echo esc_attr($stats['total_requests']); ?>">
                            <?php echo number_format($stats['total_requests']); ?>
                        </p>
                        <span class="boteraser-stat-help" data-tooltip="<?php _e('Total number of requests logged in the system', 'bot-eraser'); ?>">
                            <?php echo bot_eraser_icon('help-circle'); ?>
                        </span>
                    </div>
                    <p class="boteraser-stat-label"><?php _e('Total Requests', 'bot-eraser'); ?></p>
                    <?php if ($stats['trends']['total_requests']['direction'] !== 'neutral'): ?>
                    <div class="boteraser-stat-trend <?php echo esc_attr($stats['trends']['total_requests']['direction']); ?>">
                        <?php echo bot_eraser_icon($stats['trends']['total_requests']['direction'] === 'up' ? 'arrow-up' : 'arrow-down'); ?>
                        <span><?php echo esc_html($stats['trends']['total_requests']['percentage']); ?>%</span>
                    </div>
                    <?php endif; ?>
                    <canvas class="boteraser-sparkline" data-metric="total_requests" width="100" height="30"></canvas>
                </div>
            </a>

            <a href="<?php echo admin_url('admin.php?page=bot-eraser-logs'); ?>" class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Click to view detailed logs', 'bot-eraser'); ?>">
                <div class="boteraser-stat-icon bronze">
                    <?php echo bot_eraser_icon('users'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <div class="boteraser-stat-header">
                        <p class="boteraser-stat-value" data-count="<?php echo esc_attr($stats['unique_ips']); ?>">
                            <?php echo number_format($stats['unique_ips']); ?>
                        </p>
                        <span class="boteraser-stat-help" data-tooltip="<?php _e('Number of unique IP addresses detected', 'bot-eraser'); ?>">
                            <?php echo bot_eraser_icon('help-circle'); ?>
                        </span>
                    </div>
                    <p class="boteraser-stat-label"><?php _e('Unique IPs', 'bot-eraser'); ?></p>
                    <?php if ($stats['trends']['unique_ips']['direction'] !== 'neutral'): ?>
                    <div class="boteraser-stat-trend <?php echo esc_attr($stats['trends']['unique_ips']['direction']); ?>">
                        <?php echo bot_eraser_icon($stats['trends']['unique_ips']['direction'] === 'up' ? 'arrow-up' : 'arrow-down'); ?>
                        <span><?php echo esc_html($stats['trends']['unique_ips']['percentage']); ?>%</span>
                    </div>
                    <?php endif; ?>
                    <canvas class="boteraser-sparkline" data-metric="unique_ips" width="100" height="30"></canvas>
                </div>
            </a>

            <a href="<?php echo admin_url('admin.php?page=bot-eraser-blocked-ips'); ?>" class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Click to view blocked IPs list', 'bot-eraser'); ?>">
                <div class="boteraser-stat-icon danger">
                    <?php echo bot_eraser_icon('shield-x'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <div class="boteraser-stat-header">
                        <p class="boteraser-stat-value" data-count="<?php echo esc_attr($stats['blocked_today']); ?>">
                            <?php echo number_format($stats['blocked_today']); ?>
                        </p>
                        <span class="boteraser-stat-help" data-tooltip="<?php _e('Currently active blocked IP addresses', 'bot-eraser'); ?>">
                            <?php echo bot_eraser_icon('help-circle'); ?>
                        </span>
                    </div>
                    <p class="boteraser-stat-label"><?php _e('Blocked IPs', 'bot-eraser'); ?></p>
                    <?php if ($stats['trends']['blocked_today']['direction'] !== 'neutral'): ?>
                    <div class="boteraser-stat-trend <?php echo esc_attr($stats['trends']['blocked_today']['direction']); ?>">
                        <?php echo bot_eraser_icon($stats['trends']['blocked_today']['direction'] === 'up' ? 'arrow-up' : 'arrow-down'); ?>
                        <span><?php echo esc_html($stats['trends']['blocked_today']['percentage']); ?>%</span>
                    </div>
                    <?php endif; ?>
                    <canvas class="boteraser-sparkline" data-metric="blocked_ips" width="100" height="30"></canvas>
                </div>
            </a>

            <div class="boteraser-stat-card" data-tooltip="<?php _e('Server uptime information', 'bot-eraser'); ?>">
                <div class="boteraser-stat-icon indigo">
                    <?php echo bot_eraser_icon('clock'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <div class="boteraser-stat-header">
                        <p class="boteraser-stat-value">
                            <?php echo esc_html(bot_eraser_format_uptime($stats['uptime'])); ?>
                        </p>
                        <span class="boteraser-stat-help" data-tooltip="<?php _e('How long the server has been running', 'bot-eraser'); ?>">
                            <?php echo bot_eraser_icon('help-circle'); ?>
                        </span>
                    </div>
                    <p class="boteraser-stat-label"><?php _e('Server Uptime', 'bot-eraser'); ?></p>
                </div>
            </div>

            <!-- New Additional Metrics -->
            <div class="boteraser-stat-card boteraser-stat-card-threat" data-tooltip="<?php _e('Current security threat level assessment', 'bot-eraser'); ?>">
                <div class="boteraser-stat-icon <?php echo esc_attr($threat_level['level'] === 'high' ? 'danger' : ($threat_level['level'] === 'medium' ? 'warning' : 'success')); ?>">
                    <?php echo bot_eraser_icon($threat_level['level'] === 'high' ? 'alert-circle' : ($threat_level['level'] === 'medium' ? 'shield' : 'shield-check')); ?>
                </div>
                <div class="boteraser-stat-content">
                    <div class="boteraser-stat-header">
                        <p class="boteraser-stat-value boteraser-threat-level-text <?php echo esc_attr($threat_level['level']); ?>">
                            <?php echo strtoupper(esc_html($threat_level['level'])); ?>
                        </p>
                        <span class="boteraser-stat-help" data-tooltip="<?php _e('Calculated based on blocked IPs and recent activity', 'bot-eraser'); ?>">
                            <?php echo bot_eraser_icon('help-circle'); ?>
                        </span>
                    </div>
                    <p class="boteraser-stat-label"><?php _e('Threat Level', 'bot-eraser'); ?></p>
                    <div class="boteraser-threat-bar">
                        <div class="boteraser-threat-bar-fill <?php echo esc_attr($threat_level['level']); ?>" style="width: <?php echo min($threat_level['score'], 100); ?>%;"></div>
                    </div>
                </div>
            </div>

            <div class="boteraser-stat-card" data-tooltip="<?php _e('Percentage of requests that were blocked', 'bot-eraser'); ?>">
                <div class="boteraser-stat-icon navy">
                    <?php echo bot_eraser_icon('shield-check'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <div class="boteraser-stat-header">
                        <p class="boteraser-stat-value">
                            <?php echo esc_html($protection_rate['rate']); ?>%
                        </p>
                        <span class="boteraser-stat-help" data-tooltip="<?php echo sprintf(__('Blocked %d out of %d total requests', 'bot-eraser'), $protection_rate['blocked'], $protection_rate['total']); ?>">
                            <?php echo bot_eraser_icon('help-circle'); ?>
                        </span>
                    </div>
                    <p class="boteraser-stat-label"><?php _e('Requests Blocked', 'bot-eraser'); ?></p>
                    <div class="boteraser-protection-circle">
                        <svg viewBox="0 0 36 36" class="boteraser-circular-chart">
                            <path class="boteraser-circle-bg" d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831" />
                            <path class="boteraser-circle" stroke-dasharray="<?php echo esc_attr($protection_rate['rate']); ?>, 100" d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831" />
                        </svg>
                    </div>
                </div>
            </div>

            <div class="boteraser-stat-card boteraser-stat-card-activity <?php echo esc_attr($recent_activity['status']); ?>" data-tooltip="<?php _e('Request activity in the last hour', 'bot-eraser'); ?>">
                <div class="boteraser-stat-icon <?php echo $recent_activity['status'] === 'high' ? 'crimson' : ($recent_activity['status'] === 'elevated' ? 'amber' : 'sky'); ?>">
                    <?php echo bot_eraser_icon('activity'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <div class="boteraser-stat-header">
                        <p class="boteraser-stat-value" data-count="<?php echo esc_attr($recent_activity['count']); ?>">
                            <?php echo number_format($recent_activity['count']); ?>
                        </p>
                        <span class="boteraser-stat-help" data-tooltip="<?php _e('Number of requests in the last 60 minutes', 'bot-eraser'); ?>">
                            <?php echo bot_eraser_icon('help-circle'); ?>
                        </span>
                    </div>
                    <p class="boteraser-stat-label"><?php _e('Last Hour', 'bot-eraser'); ?></p>
                    <div class="boteraser-stat-trend <?php echo esc_attr($recent_activity['trend']['direction']); ?>">
                        <?php
                        if ($recent_activity['trend']['direction'] === 'up') {
                            echo bot_eraser_icon('arrow-up');
                        } elseif ($recent_activity['trend']['direction'] === 'down') {
                            echo bot_eraser_icon('arrow-down');
                        } else {
                            echo bot_eraser_icon('minus');
                        }
                        ?>
                        <span>
                            <?php
                            if ($recent_activity['trend']['direction'] === 'neutral') {
                                _e('No change', 'bot-eraser');
                            } else {
                                echo esc_html($recent_activity['trend']['percentage']) . '% vs prev hour';
                            }
                            ?>
                        </span>
                    </div>
                    <canvas class="boteraser-sparkline" data-metric="recent_activity" width="100" height="30"></canvas>
                </div>
            </div>

            <div class="boteraser-stat-card boteraser-stat-card-blocks <?php echo esc_attr($active_blocks_today['status']); ?>" data-tooltip="<?php _e('Currently active blocked IP addresses', 'bot-eraser'); ?>">
                <div class="boteraser-stat-icon emerald">
                    <?php echo bot_eraser_icon('shield'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <div class="boteraser-stat-header">
                        <p class="boteraser-stat-value" data-count="<?php echo esc_attr($active_blocks_today['count']); ?>">
                            <?php echo number_format($active_blocks_today['count']); ?>
                        </p>
                        <span class="boteraser-stat-help" data-tooltip="<?php _e('Currently active blocked IP addresses', 'bot-eraser'); ?>">
                            <?php echo bot_eraser_icon('help-circle'); ?>
                        </span>
                    </div>
                    <p class="boteraser-stat-label"><?php _e('Active Blocks', 'bot-eraser'); ?></p>
                    <div class="boteraser-stat-trend <?php echo esc_attr($active_blocks_today['trend']['direction']); ?>">
                        <?php
                        if ($active_blocks_today['trend']['direction'] === 'up') {
                            echo bot_eraser_icon('arrow-up');
                        } elseif ($active_blocks_today['trend']['direction'] === 'down') {
                            echo bot_eraser_icon('arrow-down');
                        } else {
                            echo bot_eraser_icon('minus');
                        }
                        ?>
                        <span>
                            <?php
                            if ($active_blocks_today['trend']['direction'] === 'neutral') {
                                _e('No change', 'bot-eraser');
                            } else {
                                echo esc_html($active_blocks_today['trend']['percentage']) . '% vs yesterday';
                            }
                            ?>
                        </span>
                    </div>
                    <canvas class="boteraser-sparkline" data-metric="blocks_today" width="100" height="30"></canvas>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <?php
        // Check if we have results to display
        $has_results = false;
        $temp_data = $manual_execution_data ?: get_transient('bot_eraser_process_data');
        if ($temp_data && isset($temp_data['status']) && $temp_data['status'] === 'success') {
            $has_results = true;
        }
        ?>
        <div class="boteraser-content-wrapper <?php echo $has_results ? 'has-results' : ''; ?>">
            <!-- Left Column -->
            <div class="boteraser-left-column">
                <!-- API Key Card -->
                <div class="boteraser-card boteraser-api-section">
                    <div class="boteraser-card-header">
                        <h2 class="boteraser-card-title">
                            <?php echo bot_eraser_icon('key'); ?>
                            <?php _e('API Configuration', 'bot-eraser'); ?>
                        </h2>
                    </div>

                    <form method="post">
                        <?php wp_nonce_field('bot_eraser_settings', 'bot_eraser_settings_nonce'); ?>

                        <?php if (!$privacy_accepted): ?>
                        <div class="boteraser-notice warning" style="margin-bottom: 20px;">
                            <?php echo bot_eraser_icon('alert-triangle'); ?>
                            <div class="boteraser-notice-content">
                                <p class="boteraser-notice-title"><?php _e('Privacy Notice Required', 'bot-eraser'); ?></p>
                                <p class="boteraser-notice-message"><?php _e('Please accept the privacy notice above before configuring the plugin.', 'bot-eraser'); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="boteraser-api-input-wrapper">
                            <span class="boteraser-api-icon"><?php echo bot_eraser_icon('key'); ?></span>
                            <input type="password"
                                   name="api_key"
                                   id="boteraser-api-key"
                                   class="boteraser-api-input <?php echo !empty($validation_state['is_valid']) ? 'valid' : (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid'] ? 'invalid' : ''); ?>"
                                   value="<?php echo esc_attr($form_api_key); ?>"
                                   placeholder="<?php _e('Enter your API key...', 'bot-eraser'); ?>"
                                   autocomplete="new-password"
                                   <?php echo !$privacy_accepted ? 'disabled' : ''; ?>>
                            <span class="boteraser-api-status-icon success"><?php echo bot_eraser_icon('check-circle'); ?></span>
                            <span class="boteraser-api-status-icon error"><?php echo bot_eraser_icon('x-circle'); ?></span>
                            <span class="boteraser-api-status-icon loading"><?php echo bot_eraser_icon('loader'); ?></span>
                        </div>

                        <!-- Large Status Indicator -->
                        <div class="boteraser-status-indicator <?php
                            if (!empty($validation_state['is_valid'])) echo 'valid visible';
                            elseif (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid']) echo 'invalid visible';
                        ?>">
                            <div class="boteraser-status-icon-svg">
                                <?php
                                if (!empty($validation_state['is_valid'])) {
                                    echo bot_eraser_icon('shield-check');
                                } elseif (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid']) {
                                    echo bot_eraser_icon('shield-x');
                                } else {
                                    echo bot_eraser_icon('shield');
                                }
                                ?>
                            </div>
                            <div class="boteraser-status-text">
                                <?php
                                if (!empty($validation_state['is_valid'])) {
                                    _e('API Key Valid', 'bot-eraser');
                                } elseif (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid']) {
                                    _e('Invalid API Key', 'bot-eraser');
                                } else {
                                    _e('Not Verified', 'bot-eraser');
                                }
                                ?>
                            </div>
                        </div>

                        <div class="boteraser-api-description">
                            <?php echo bot_eraser_icon('info'); ?>
                            <span>
                                <?php _e('Get your API key from the', 'bot-eraser'); ?>
                                <a href="https://user.boteraser.com/api.php" target="_blank">
                                    <?php _e('Boteraser Dashboard', 'bot-eraser'); ?>
                                    <?php echo bot_eraser_icon('external-link'); ?>
                                </a>
                            </span>
                        </div>

                        <div class="boteraser-btn-row">
                            <button type="submit" class="boteraser-btn boteraser-btn-primary" <?php echo !$privacy_accepted ? 'disabled' : ''; ?>>
                                <?php echo bot_eraser_icon('check'); ?>
                                <?php _e('Save Settings', 'bot-eraser'); ?>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Manual Execution Section -->
                <div class="boteraser-execution-section">
                    <div class="boteraser-card">
                        <div class="boteraser-card-header">
                            <h2 class="boteraser-card-title">
                                <?php echo bot_eraser_icon('zap'); ?>
                                <?php _e('Manual Execution', 'bot-eraser'); ?>
                            </h2>
                        </div>

                        <form method="post" name="boteraser_manual_run">
                            <?php wp_nonce_field('bot_eraser_manual_action', '_wpnonce', false); ?>
                            <input type="hidden" name="bot_eraser_manual_run" value="1">
                            <button type="submit" class="boteraser-btn boteraser-btn-success boteraser-btn-lg" <?php echo !$privacy_accepted ? 'disabled' : ''; ?>>
                                <?php echo bot_eraser_icon('play'); ?>
                                <?php _e('Run Boteraser Now', 'bot-eraser'); ?>
                            </button>
                        </form>

                        <?php
                        $last_manual_run = get_option('bot_eraser_last_manual_run', 0);
                        if ($last_manual_run > 0):
                            $time_ago = human_time_diff($last_manual_run, time());
                        ?>
                        <div class="boteraser-last-run-info">
                            <?php echo bot_eraser_icon('clock'); ?>
                            <span><?php printf(__('Last run: %s ago', 'bot-eraser'), $time_ago); ?></span>
                        </div>
                        <?php endif; ?>

                        <div class="boteraser-progress-bar">
                            <div class="boteraser-progress-bar-fill"></div>
                        </div>

                        <?php
                        $data = $manual_execution_data ?: get_transient('bot_eraser_process_data');
                        if ($data):
                            $status_class = ($data['status'] === 'success') ? 'success' : 'error';
                            $message = $data['message'] ?? '';

                            // Only show execution results if status is success
                            if ($status_class === 'success'):
                        ?>
                        <div class="boteraser-results <?php echo esc_attr($status_class); ?>">
                            <div class="boteraser-results-header">
                                <h3>
                                    <?php echo bot_eraser_icon('check-circle'); ?>
                                    <?php _e('Execution Results', 'bot-eraser'); ?>
                                </h3>
                                <span class="boteraser-results-time"><?php echo date('M j, Y H:i:s'); ?></span>
                            </div>

                            <div class="boteraser-results-grid">
                                <!-- Server Metrics -->
                                <div class="boteraser-result-card">
                                    <h4><?php echo bot_eraser_icon('server'); ?> <?php _e('Server Metrics', 'bot-eraser'); ?></h4>
                                    <div class="metrics-box">
                                        <div class="metric">
                                            <label><?php echo bot_eraser_icon('activity'); ?> <?php _e('Load', 'bot-eraser'); ?></label>
                                            <div class="value"><?php echo esc_html($data['sent_data']['srv_load'] ?? 'N/A'); ?></div>
                                        </div>
                                        <div class="metric">
                                            <label><?php echo bot_eraser_icon('clock'); ?> <?php _e('Uptime', 'bot-eraser'); ?></label>
                                            <div class="value"><?php echo esc_html(bot_eraser_format_uptime($data['sent_data']['uptime'] ?? 0)); ?></div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Data Payload -->
                                <div class="boteraser-result-card">
                                    <h4><?php echo bot_eraser_icon('database'); ?> <?php _e('Data Payload', 'bot-eraser'); ?></h4>
                                    <pre><?php
                                        if (!empty($data['sent_data']['data'])) {
                                            echo esc_html(trim($data['sent_data']['data']));
                                        } else {
                                            _e('No data generated', 'bot-eraser');
                                        }
                                    ?></pre>
                                </div>

                                <!-- Server Response -->
                                <div class="boteraser-result-card">
                                    <h4><?php echo bot_eraser_icon('cloud'); ?> <?php _e('Server Response', 'bot-eraser'); ?></h4>
                                    <pre><?php echo esc_html($data['response'] ?? __('No response received', 'bot-eraser')); ?></pre>
                                </div>
                            </div>

                            <div class="boteraser-results-footer">
                                <span class="boteraser-status-badge success">
                                    <?php echo bot_eraser_icon('check-circle'); ?>
                                    <?php _e('SUCCESS', 'bot-eraser'); ?>
                                </span>
                                <span class="boteraser-execution-message">
                                    <?php echo esc_html($message ?: __('No execution log', 'bot-eraser')); ?>
                                </span>
                            </div>
                        </div>
                        <?php
                            endif; // End if ($status_class === 'success')
                            // If status is error, status indicator will be updated via JavaScript

                            if (!$manual_execution_data && get_transient('bot_eraser_process_data')) {
                                delete_transient('bot_eraser_process_data');
                            }
                        endif;
                        ?>
                    </div>
                </div>
            </div>

            <!-- Right Column - Info Panel -->
            <div class="boteraser-info-panel">
                <!-- Quick Actions -->
                <div class="boteraser-info-card">
                    <h3><?php echo bot_eraser_icon('zap'); ?> <?php _e('Quick Actions', 'bot-eraser'); ?></h3>
                    <div class="boteraser-quick-actions">
                        <a href="<?php echo admin_url('admin.php?page=bot-eraser-logs'); ?>" class="boteraser-quick-action">
                            <?php echo bot_eraser_icon('file-text'); ?>
                            <span><?php _e('View Logs', 'bot-eraser'); ?></span>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=bot-eraser-blocked-ips'); ?>" class="boteraser-quick-action">
                            <?php echo bot_eraser_icon('shield-x'); ?>
                            <span><?php _e('Blocked IPs', 'bot-eraser'); ?></span>
                        </a>
                        <a href="https://user.boteraser.com/" target="_blank" class="boteraser-quick-action">
                            <?php echo bot_eraser_icon('external-link'); ?>
                            <span><?php _e('Boteraser Portal', 'bot-eraser'); ?></span>
                        </a>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="boteraser-info-card">
                    <h3><?php echo bot_eraser_icon('activity'); ?> <?php _e('Recent Blocked IPs', 'bot-eraser'); ?></h3>
                    <?php if (!empty($recent_blocked)): ?>
                    <div class="boteraser-recent-activity">
                        <?php foreach ($recent_blocked as $blocked): ?>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php echo esc_html($blocked['ip']); ?></span>
                            <span class="boteraser-activity-time"><?php echo esc_html($blocked['time_ago']); ?> ago</span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <p style="color: var(--be-gray-500); font-size: 14px;"><?php _e('No blocked IPs yet', 'bot-eraser'); ?></p>
                    <?php endif; ?>
                </div>

                <!-- How It Works Card -->
                <div class="boteraser-info-card">
                    <h3><?php echo bot_eraser_icon('settings'); ?> <?php _e('How It Works', 'bot-eraser'); ?></h3>
                    <ol style="margin-left: 20px; line-height: 1.8;">
                        <li><?php _e('Log all visitor access attempts locally', 'bot-eraser'); ?></li>
                        <li><?php _e('Identifies traffic volume patterns', 'bot-eraser'); ?></li>
                        <li><?php _e('Sends IP addresses and bot identifiers (browser type derived from device information) to user.boteraser.com for security analysis', 'bot-eraser'); ?></li>
                        <li><?php _e('Receives updated blocking rules periodically', 'bot-eraser'); ?></li>
                    </ol>

                    <div class="boteraser-privacy-notice" style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin-top: 20px; border-radius: 4px;">
                        <h4 style="margin-top: 0; color: #856404; display: flex; align-items: center; gap: 8px;">
                            <span style="font-size: 20px;">⚠️</span>
                            <?php _e('IMPORTANT PRIVACY NOTICE', 'bot-eraser'); ?>
                        </h4>
                        <p style="margin-bottom: 12px; color: #856404;">
                            <?php _e('This plugin sends visitor IP addresses (personal data under GDPR) to an external service at user.boteraser.com for security threat analysis.', 'bot-eraser'); ?>
                        </p>
                        <p style="margin-bottom: 12px; color: #856404; font-weight: 600;">
                            <?php _e('You MUST disclose this data collection in your website\'s Privacy Policy.', 'bot-eraser'); ?>
                        </p>
                        <p style="margin: 0;">
                            <a href="https://boteraser.com/privacy-policy/" target="_blank" style="color: #0073aa; text-decoration: none; font-weight: 500; margin-right: 15px;">
                                <?php _e('Privacy Policy', 'bot-eraser'); ?> →
                            </a>
                            <a href="https://boteraser.com/terms-of-service/" target="_blank" style="color: #0073aa; text-decoration: none; font-weight: 500; margin-right: 15px;">
                                <?php _e('Terms of Service', 'bot-eraser'); ?> →
                            </a>
                            <a href="https://boteraser.com/faq/" target="_blank" style="color: #0073aa; text-decoration: none; font-weight: 500;">
                                <?php _e('Learn More', 'bot-eraser'); ?> →
                            </a>
                        </p>
                    </div>
                </div>

                <!-- Data Flow Diagram -->
                <div class="boteraser-info-card">
                    <h3><?php echo bot_eraser_icon('trending-up'); ?> <?php _e('Data Flow', 'bot-eraser'); ?></h3>
                    <div class="boteraser-data-flow">
                        <div class="boteraser-flow-step">
                            <?php echo bot_eraser_icon('globe'); ?>
                            <span><?php _e('Your Site', 'bot-eraser'); ?></span>
                        </div>
                        <span class="boteraser-flow-arrow">&rarr;</span>
                        <div class="boteraser-flow-step">
                            <?php echo bot_eraser_icon('database'); ?>
                            <span><?php _e('Local Logs', 'bot-eraser'); ?></span>
                        </div>
                        <span class="boteraser-flow-arrow">&rarr;</span>
                        <div class="boteraser-flow-step">
                            <?php echo bot_eraser_icon('cloud'); ?>
                            <span><?php _e('Boteraser Cloud', 'bot-eraser'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Clean up duplicate API key entries
 */
function bot_eraser_cleanup_api_key_entries() {
    global $wpdb;

    $current_api_key = $wpdb->get_var($wpdb->prepare(
        "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1",
        'bot_eraser_api_key'
    ));

    $total_entries = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name = %s",
        'bot_eraser_api_key'
    ));

    if ($total_entries > 1) {
        $wpdb->delete($wpdb->options, array('option_name' => 'bot_eraser_api_key'));

        if (!empty($current_api_key)) {
            $wpdb->insert(
                $wpdb->options,
                array(
                    'option_name' => 'bot_eraser_api_key',
                    'option_value' => $current_api_key,
                    'autoload' => 'yes'
                ),
                array('%s', '%s', '%s')
            );
        }

        wp_cache_delete('bot_eraser_api_key', 'options');
        wp_cache_delete('alloptions', 'options');
        wp_cache_flush();

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Boteraser: Cleaned up duplicate API key entries');
        }

        return true;
    }

    return false;
}

/**
 * Simple hash function for API key comparison
 */
function bot_eraser_simple_hash($str) {
    $hash = 0;
    $len = strlen($str);
    if ($len === 0) return (string)$hash;

    for ($i = 0; $i < $len; $i++) {
        $char = ord($str[$i]);
        $hash = (($hash << 5) - $hash) + $char;
        $hash = $hash & 0xFFFFFFFF;
        if ($hash > 0x7FFFFFFF) {
            $hash -= 0x100000000;
        }
    }
    return dechex(abs($hash));
}
