<?php
/**
 * Boteraser Admin Settings Page
 *
 * @package Boteraser
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Threshold constants — extract magic numbers so they're named and centralised.
 */
define('BOTERASER_MOBILE_BREAKPOINT', 782);

define('BOTERASER_BLOCKED_LOW', 1);
define('BOTERASER_BLOCKED_MEDIUM', 5);
define('BOTERASER_BLOCKED_HIGH', 20);

define('BOTERASER_ACTIVITY_MEDIUM', 200);
define('BOTERASER_ACTIVITY_HIGH', 500);

define('BOTERASER_LOG_SIZE_WARN_KB', 2000);
define('BOTERASER_LOG_SIZE_CRIT_KB', 5000);

/**
 * Parse an Apache-style log timestamp from a line and return a Unix timestamp,
 * or false when the line doesn't contain a recognised timestamp.
 *
 * Accepts both "dd/Mmm/yyyy:hh:mm:ss +zzzz" and "dd/Mmm/yyyy:hh:mm:ss" forms.
 */
function bot_eraser_parse_log_timestamp($line) {
    if (preg_match('/\[(\d{2}\/\w{3}\/\d{4}:\d{2}:\d{2}:\d{2}\s[+\-]\d{4})\]/', $line, $m)) {
        return strtotime($m[1]);
    }
    if (preg_match('/\[(\d{2})\/(\w{3})\/(\d{4}):(\d{2}):(\d{2}):(\d{2})\s/', $line, $m)) {
        return strtotime($m[3] . '-' . $m[2] . '-' . $m[1] . ' ' . $m[4] . ':' . $m[5] . ':' . $m[6]);
    }
    return false;
}

/**
 * Enqueue global admin styles (menu icon, admin bar) on all admin pages and frontend when admin bar is visible
 */
function bot_eraser_enqueue_global_assets() {
    // CSS
    wp_enqueue_style(
        'boteraser-admin-global',
        BOT_ERASER_PLUGIN_URL . 'assets/css/admin.css',
        array(),
        filemtime(BOT_ERASER_PLUGIN_DIR . 'assets/css/admin.css')
    );

    // JS — admin bar toggle + privacy notice (runs everywhere)
    wp_enqueue_script(
        'boteraser-admin-global',
        BOT_ERASER_PLUGIN_URL . 'assets/js/admin-global.js',
        array('jquery'),
        filemtime(BOT_ERASER_PLUGIN_DIR . 'assets/js/admin-global.js'),
        true
    );

    wp_localize_script('boteraser-admin-global', 'boteraser_global', array(
        'mobileBreakpoint'      => BOTERASER_MOBILE_BREAKPOINT,
        'privacyNonce'          => wp_create_nonce('bot_eraser_dismiss_notice'),
        'privacyProcessingText' => __('Processing...', 'bot-eraser'),
        'privacyAcceptText'     => __('I Understand and Accept', 'bot-eraser'),
        'privacyErrorText'      => __('Error dismissing notice. Please try again.', 'bot-eraser'),
    ));
}
add_action('admin_enqueue_scripts', 'bot_eraser_enqueue_global_assets');

// On frontend, only load assets when the admin bar is actually shown
function bot_eraser_enqueue_frontend_assets() {
    if (is_admin_bar_showing()) {
        // CSS
        wp_enqueue_style(
            'boteraser-admin-global',
            BOT_ERASER_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            filemtime(BOT_ERASER_PLUGIN_DIR . 'assets/css/admin.css')
        );

        // JS — only the admin-bar toggle part (privacy notice is admin-only)
        wp_enqueue_script(
            'boteraser-admin-global',
            BOT_ERASER_PLUGIN_URL . 'assets/js/admin-global.js',
            array(),
            filemtime(BOT_ERASER_PLUGIN_DIR . 'assets/js/admin-global.js'),
            true
        );

        wp_localize_script('boteraser-admin-global', 'boteraser_global', array(
            'mobileBreakpoint' => BOTERASER_MOBILE_BREAKPOINT,
        ));
    }
}
add_action('wp_enqueue_scripts', 'bot_eraser_enqueue_frontend_assets');

/**
 * Enqueue admin styles and scripts
 */
function bot_eraser_enqueue_admin_assets($hook) {
    // Only load on Boteraser pages
    if (strpos($hook, 'bot-eraser') === false) {
        return;
    }

    // Enqueue Google Fonts
    wp_enqueue_style(
        'boteraser-google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    // Enqueue main admin CSS
    wp_enqueue_style(
        'boteraser-admin',
        BOT_ERASER_PLUGIN_URL . 'assets/css/admin.css',
        array(),
        filemtime(BOT_ERASER_PLUGIN_DIR . 'assets/css/admin.css')
    );

    // Enqueue main admin JS
    wp_enqueue_script(
        'boteraser-admin',
        BOT_ERASER_PLUGIN_URL . 'assets/js/admin.js',
        array('jquery'),
        filemtime(BOT_ERASER_PLUGIN_DIR . 'assets/js/admin.js'),
        true
    );

}
add_action('admin_enqueue_scripts', 'bot_eraser_enqueue_admin_assets');

/**
 * Show privacy notice on first activation
 */
function bot_eraser_show_privacy_notice() {
    // Only show if not dismissed and user has admin capabilities
    if (!current_user_can('manage_options')) {
        return;
    }

    // Don't show if already dismissed
    if (get_option('bot_eraser_privacy_notice_dismissed')) {
        return;
    }
    ?>
    <div class="notice notice-warning is-dismissible boteraser-privacy-notice-global" id="bot-eraser-privacy-notice">
        <h2 class="boteraser-privacy-notice-global-title">
            <span class="boteraser-privacy-notice-global-icon">!</span>
            <?php _e('Boteraser - Important Privacy Information', 'bot-eraser'); ?>
        </h2>
        <p class="boteraser-privacy-notice-global-copy boteraser-privacy-notice-global-copy-strong">
            <strong><?php _e('This plugin sends data to an external service.', 'bot-eraser'); ?></strong>
        </p>
        <p class="boteraser-privacy-notice-global-copy">
            <?php _e('This plugin locally analyzes visitor IP addresses, bot identifiers, and threat-related data (considered personal data under GDPR) and transmits this data to Boteraser Cloud for threat detection, malware analysis, and vulnerability analysis.', 'bot-eraser'); ?>
        </p>
        <p class="boteraser-privacy-notice-global-copy">
            <?php printf(
                __('By using this plugin, you agree to transmit this data and you <strong>MUST disclose this in your website\'s Privacy Policy</strong>. Read our <a href="%s" target="_blank" class="boteraser-inline-link">Privacy Policy</a> and <a href="%s" target="_blank" class="boteraser-inline-link">Terms of Service</a> for complete details.', 'bot-eraser'),
                'https://boteraser.com/privacy-policy/',
                'https://boteraser.com/terms-of-service/'
            ); ?>
        </p>
        <div class="boteraser-privacy-notice-global-box">
            <p class="boteraser-privacy-notice-global-box-title">
                <?php _e('Data sent to external service:', 'bot-eraser'); ?>
            </p>
            <ul class="boteraser-privacy-notice-global-list">
                <li><?php _e('Visitor IP addresses (personal data under GDPR)', 'bot-eraser'); ?></li>
                <li><?php _e('Bot identifiers', 'bot-eraser'); ?></li>
            </ul>
        </div>
        <p class="boteraser-privacy-notice-global-actions">
            <button type="button" class="button button-primary boteraser-privacy-notice-global-button" id="bot-eraser-dismiss-notice">
                <?php _e('I Understand and Accept', 'bot-eraser'); ?>
            </button>
            <a href="https://boteraser.com/privacy-policy/" target="_blank" class="button boteraser-privacy-notice-global-button boteraser-privacy-notice-global-button-secondary">
                <?php _e('Read Privacy Policy', 'bot-eraser'); ?>
            </a>
        </p>
    </div>
    <?php
}
add_action('admin_notices', 'bot_eraser_show_privacy_notice');

/**
 * AJAX handler for dismissing privacy notice
 */
function bot_eraser_dismiss_privacy_notice_ajax() {
    check_ajax_referer('bot_eraser_dismiss_notice', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
        return;
    }

    update_option('bot_eraser_privacy_notice_dismissed', true, false);
    wp_send_json_success();
}
add_action('wp_ajax_bot_eraser_dismiss_privacy_notice', 'bot_eraser_dismiss_privacy_notice_ajax');

/**
 * Add admin menu pages
 */
function bot_eraser_add_settings_page() {
    // Load custom SVG icon for WordPress admin menu
    $icon_file = BOT_ERASER_PLUGIN_DIR . 'assets/images/logo-menu.svg';
    $icon_url = 'dashicons-shield'; // Fallback

    if (file_exists($icon_file)) {
        $icon_url = BOT_ERASER_PLUGIN_URL . 'assets/images/logo-menu.svg';
    }

    add_menu_page(
        'Boteraser',
        'Boteraser',
        'manage_options',
        'bot-eraser',
        'bot_eraser_render_settings_page',
        $icon_url,
        100
    );

    add_submenu_page(
        'bot-eraser',
        __('Dashboard', 'bot-eraser'),
        __('Dashboard', 'bot-eraser'),
        'manage_options',
        'bot-eraser',
        'bot_eraser_render_settings_page'
    );

    add_submenu_page(
        'bot-eraser',
        __('Blocked IPs', 'bot-eraser'),
        __('Blocked IPs', 'bot-eraser'),
        'manage_options',
        'bot-eraser-blocked-ips',
        'bot_eraser_render_blocked_ips'
    );

    add_submenu_page(
        'bot-eraser',
        __('Logs', 'bot-eraser'),
        __('Logs', 'bot-eraser'),
        'manage_options',
        'bot-eraser-logs',
        'bot_eraser_render_logs_page'
    );

    add_submenu_page(
        'bot-eraser',
        __('Security Scan', 'bot-eraser'),
        __('Security Scan', 'bot-eraser'),
        'manage_options',
        'bot-eraser-scanner',
        'boteraser_render_scanner_page'
    );

    add_submenu_page(
        'bot-eraser',
        __('Quarantine', 'bot-eraser'),
        __('Quarantine', 'bot-eraser'),
        'manage_options',
        'bot-eraser-quarantine',
        'boteraser_render_quarantine_page'
    );

    add_submenu_page(
        'bot-eraser',
        __('Vulnerabilities', 'bot-eraser'),
        __('Vulnerabilities', 'bot-eraser'),
        'manage_options',
        'bot-eraser-vulnerabilities',
        'boteraser_render_vulnerabilities_page'
    );

    add_submenu_page(
        'bot-eraser',
        __('FAQ', 'bot-eraser'),
        __('FAQ', 'bot-eraser'),
        'manage_options',
        'https://boteraser.com/faq/',
        ''
    );

    add_submenu_page(
        'bot-eraser',
        __('Contact Us', 'bot-eraser'),
        __('Contact Us', 'bot-eraser'),
        'manage_options',
        'https://boteraser.com/contact/',
        ''
    );

    add_submenu_page(
        'bot-eraser',
        __('Sign Up', 'bot-eraser'),
        __('Sign Up', 'bot-eraser'),
        'manage_options',
        'https://user.boteraser.com/sign-up.php',
        ''
    );
}
add_action('admin_menu', 'bot_eraser_add_settings_page');

/**
 * Add Boteraser to WordPress Admin Bar
 */
function bot_eraser_add_admin_bar_menu($wp_admin_bar) {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Get cached metrics (cache for 60 seconds)
    $metrics = get_transient('bot_eraser_admin_bar_metrics');

    if (false === $metrics) {
        $threat_level = bot_eraser_get_threat_level();
        $active_blocks = bot_eraser_get_new_blocks_today();
        $recent_activity = bot_eraser_get_recent_activity();
        $protection_rate = bot_eraser_get_protection_rate();
        $last_scan = function_exists('boteraser_get_last_scan') ? boteraser_get_last_scan() : null;
        $scan_summary = $last_scan['summary'] ?? null;

        $metrics = array(
            'threat_level'    => $threat_level,
            'active_blocks'   => $active_blocks,
            'recent_activity' => $recent_activity,
            'protection_rate' => $protection_rate,
            'malware_score'   => $scan_summary ? (int) $scan_summary['score'] : null,
            'malware_threats' => $scan_summary ? ((int) $scan_summary['high'] + (int) $scan_summary['medium']) : null,
        );

        set_transient('bot_eraser_admin_bar_metrics', $metrics, 60);
    }

    // Load icon URL (same as vertical menu)
    $icon_url = BOT_ERASER_PLUGIN_URL . 'assets/images/logo-menu.svg';

    // Add main Boteraser menu item with icon
    $wp_admin_bar->add_node(array(
        'id'    => 'boteraser',
        'title' => '<img src="' . esc_url($icon_url) . '" class="boteraser-admin-bar-icon" alt="Boteraser"><span class="ab-label">Boteraser</span>',
        'href'  => admin_url('admin.php?page=bot-eraser'),
        'meta'  => array(
            'class' => 'boteraser-admin-bar-item menupop',
        ),
    ));

    // Determine threat level color and label
    $threat_color = 'green';
    $threat_label = 'LOW';
    if ($metrics['threat_level']['level'] === 'high') {
        $threat_color = 'red';
        $threat_label = 'HIGH';
    } elseif ($metrics['threat_level']['level'] === 'medium') {
        $threat_color = 'orange';
        $threat_label = 'MEDIUM';
    }

    // Determine all metrics colors
    $blocked_count = $metrics['active_blocks']['count'];
    $blocked_color = 'green';
    if ($blocked_count > BOTERASER_BLOCKED_MEDIUM) {
        $blocked_color = 'red';
    } elseif ($blocked_count > BOTERASER_BLOCKED_LOW) {
        $blocked_color = 'orange';
    }

    $activity_count = $metrics['recent_activity']['count'];
    $activity_color = 'green';
    if ($activity_count > BOTERASER_ACTIVITY_HIGH) {
        $activity_color = 'red';
    } elseif ($activity_count > BOTERASER_ACTIVITY_MEDIUM) {
        $activity_color = 'orange';
    }

    $blocked_traffic_pct = $metrics['protection_rate']['rate'];
    $blocked_traffic_color = 'green';
    if ($blocked_traffic_pct > 60) {
        $blocked_traffic_color = 'red';
    } elseif ($blocked_traffic_pct > 30) {
        $blocked_traffic_color = 'orange';
    }

    // Malware metrics (null when no scan has run yet)
    $malware_score   = $metrics['malware_score'];
    $malware_threats = $metrics['malware_threats'];

    if ($malware_score === null) {
        $malware_score_value = '—';
        $malware_score_color = 'gray';
    } else {
        $malware_score_value = $malware_score . '/100';
        if ($malware_score < 60) {
            $malware_score_color = 'red';
        } elseif ($malware_score < 75) {
            $malware_score_color = 'orange';
        } else {
            $malware_score_color = 'green';
        }
    }

    if ($malware_threats === null) {
        $malware_threats_value = '—';
        $malware_threats_color = 'gray';
    } else {
        $malware_threats_value = number_format_i18n($malware_threats);
        if ($malware_threats >= 5) {
            $malware_threats_color = 'red';
        } elseif ($malware_threats > 0) {
            $malware_threats_color = 'orange';
        } else {
            $malware_threats_color = 'green';
        }
    }

    // Build custom dropdown HTML with status badges in 2x2 grid
    $dropdown_html = '
    <div class="boteraser-metrics-container">
        <div class="boteraser-metrics-header">
            <span class="boteraser-header-text">Security Overview</span>
        </div>
        <div class="boteraser-metrics-grid">
            <a href="' . admin_url('admin.php?page=bot-eraser') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $threat_color . '">
                    <span class="boteraser-circle-value">' . esc_html($threat_label) . '</span>
                </div>
                <div class="boteraser-metric-label">Threat Level</div>
            </a>
            <a href="' . admin_url('admin.php?page=bot-eraser-blocked-ips') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $blocked_color . '">
                    <span class="boteraser-circle-value">' . number_format($blocked_count) . '</span>
                </div>
                <div class="boteraser-metric-label">Blocked IPs</div>
            </a>
            <a href="' . admin_url('admin.php?page=bot-eraser-logs') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $activity_color . '">
                    <span class="boteraser-circle-value">' . number_format($activity_count) . '</span>
                </div>
                <div class="boteraser-metric-label">Last Hour</div>
            </a>
            <a href="' . admin_url('admin.php?page=bot-eraser') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $blocked_traffic_color . '">
                    <span class="boteraser-circle-value">' . $blocked_traffic_pct . '%</span>
                </div>
                <div class="boteraser-metric-label">Blocked Traffic</div>
            </a>
            <a href="' . admin_url('admin.php?page=bot-eraser-scanner') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $malware_score_color . '">
                    <span class="boteraser-circle-value">' . esc_html($malware_score_value) . '</span>
                </div>
                <div class="boteraser-metric-label">Health Score</div>
            </a>
            <a href="' . admin_url('admin.php?page=bot-eraser-scanner') . '" class="boteraser-metric-item">
                <div class="boteraser-status-circle boteraser-circle-' . $malware_threats_color . '">
                    <span class="boteraser-circle-value">' . esc_html($malware_threats_value) . '</span>
                </div>
                <div class="boteraser-metric-label">Threats Found</div>
            </a>
        </div>
    </div>';

    // Add single submenu item with grid HTML
    $wp_admin_bar->add_node(array(
        'parent' => 'boteraser',
        'id'     => 'boteraser-metrics',
        'title'  => $dropdown_html,
        'href'   => false,
    ));
}
add_action('admin_bar_menu', 'bot_eraser_add_admin_bar_menu', 100);

/**
 * Get dashboard statistics with trends
 */
function bot_eraser_get_dashboard_stats() {
    $stats = array(
        'total_requests' => 0,
        'blocked_today' => 0,
        'unique_ips' => 0,
        'uptime' => null,
        'trends' => array(
            'total_requests' => array('direction' => 'neutral', 'percentage' => 0),
            'blocked_today' => array('direction' => 'neutral', 'percentage' => 0),
            'unique_ips' => array('direction' => 'neutral', 'percentage' => 0),
        )
    );

    // Get stored stats from yesterday for trend comparison
    $yesterday_stats = get_transient('bot_eraser_yesterday_stats');
    $current_day = date('Y-m-d');
    $stored_day = get_option('bot_eraser_stats_day', '');

    // Get total log entries
    $log_file = BOT_ERASER_LOG_PATH;
    if (file_exists($log_file)) {
        $stats['total_requests'] = count(file($log_file));
    }

    // Get blocked IPs count
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (is_array($blocked_ips)) {
            // Count IPs blocked today (still active)
            $today_start = strtotime('today');
            foreach ($blocked_ips as $ip => $expiry) {
                if ($expiry > time()) {
                    $stats['blocked_today']++;
                }
            }
        }
    }

    // Get unique IPs from logs (last 1000 entries for performance)
    if (file_exists($log_file)) {
        $lines = file($log_file);
        $recent_lines = array_slice($lines, -1000);
        $unique_ips = array();
        foreach ($recent_lines as $line) {
            if (preg_match('/^(\d+\.\d+\.\d+\.\d+)/', $line, $matches)) {
                $unique_ips[$matches[1]] = true;
            }
        }
        $stats['unique_ips'] = count($unique_ips);
    }

    // Get server uptime
    if (function_exists('sys_getloadavg')) {
        $uptime_file = '/proc/uptime';
        if (file_exists($uptime_file)) {
            $uptime = floatval(file_get_contents($uptime_file));
            $stats['uptime'] = $uptime > 0 ? intval($uptime) : 0;
        }
    }

    // Calculate trends if we have yesterday's data
    if ($yesterday_stats && is_array($yesterday_stats)) {
        // Total Requests trend
        if ($yesterday_stats['total_requests'] > 0) {
            $change = $stats['total_requests'] - $yesterday_stats['total_requests'];
            $percentage = abs(round(($change / $yesterday_stats['total_requests']) * 100));
            $stats['trends']['total_requests'] = array(
                'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
                'percentage' => $percentage
            );
        }

        // Blocked IPs trend
        if (isset($yesterday_stats['blocked_today'])) {
            $change = $stats['blocked_today'] - $yesterday_stats['blocked_today'];
            $percentage = $yesterday_stats['blocked_today'] > 0
                ? abs(round(($change / $yesterday_stats['blocked_today']) * 100))
                : ($stats['blocked_today'] > 0 ? 100 : 0);
            $stats['trends']['blocked_today'] = array(
                'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
                'percentage' => $percentage
            );
        }

        // Unique IPs trend
        if ($yesterday_stats['unique_ips'] > 0) {
            $change = $stats['unique_ips'] - $yesterday_stats['unique_ips'];
            $percentage = abs(round(($change / $yesterday_stats['unique_ips']) * 100));
            $stats['trends']['unique_ips'] = array(
                'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
                'percentage' => $percentage
            );
        }
    }

    // Store today's stats for tomorrow's comparison (once per day)
    if ($current_day !== $stored_day) {
        set_transient('bot_eraser_yesterday_stats', $stats, DAY_IN_SECONDS);
        update_option('bot_eraser_stats_day', $current_day);
    }

    return $stats;
}

/**
 * Calculate threat level based on current stats
 */
function bot_eraser_get_threat_level() {
    $log_file = BOT_ERASER_LOG_PATH;
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';

    $threat_level = 'low';
    $threat_score = 0;

    // Count active blocked IPs
    $blocked_count = 0;
    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (is_array($blocked_ips)) {
            foreach ($blocked_ips as $ip => $expiry) {
                if ($expiry > time()) {
                    $blocked_count++;
                }
            }
        }
    }

    // Threat scoring
    if ($blocked_count > BOTERASER_BLOCKED_HIGH) {
        $threat_score += 40;
    } elseif ($blocked_count > BOTERASER_BLOCKED_MEDIUM) {
        $threat_score += 25;
    } elseif ($blocked_count > BOTERASER_BLOCKED_LOW) {
        $threat_score += 10;
    }

    // Check recent activity (last hour)
    if (file_exists($log_file)) {
        $lines = file($log_file);
        $recent_count = 0;
        $one_hour_ago = time() - HOUR_IN_SECONDS;

        foreach (array_reverse($lines) as $line) {
            $timestamp = bot_eraser_parse_log_timestamp($line);
            if ($timestamp === false) {
                continue;
            }
            if ($timestamp > $one_hour_ago) {
                $recent_count++;
            } else {
                break;
            }
        }

        if ($recent_count > BOTERASER_ACTIVITY_HIGH) {
            $threat_score += 30;
        } elseif ($recent_count > BOTERASER_ACTIVITY_MEDIUM) {
            $threat_score += 15;
        }
    }

    // Determine threat level
    if ($threat_score >= 50) {
        $threat_level = 'high';
    } elseif ($threat_score >= 25) {
        $threat_level = 'medium';
    }

    return array(
        'level' => $threat_level,
        'score' => $threat_score,
        'blocked_count' => $blocked_count
    );
}

/**
 * Calculate protection rate
 */
function bot_eraser_get_protection_rate() {
    $log_file = BOT_ERASER_LOG_PATH;
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';

    $unique_ips = array();
    $blocked_ips = array();

    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (!is_array($blocked_ips)) $blocked_ips = array();
    }

    if (file_exists($log_file)) {
        $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $ip = strtok($line, ' ');
            if ($ip) $unique_ips[$ip] = true;
        }
    }

    $total_unique = count($unique_ips);
    $blocked_count = count($blocked_ips);

    $rate = 0;
    if ($total_unique > 0) {
        $rate = round(($blocked_count / $total_unique) * 100, 1);
    }

    return array(
        'rate' => $rate,
        'total' => $total_unique,
        'blocked' => $blocked_count
    );
}

/**
 * Calculate Bot & IP Protection strength (0-100).
 * Bot/IP protection requires an active API key. Without it the module is OFF (0%).
 * With a valid API key the entire layer is active (100%).
 */
function bot_eraser_get_bot_ip_strength() {
    $validation_state = get_option('bot_eraser_api_validation_state', array());
    $api_active       = !empty($validation_state['is_valid']);

    $components = array(
        array(
            'key'     => 'request_logging',
            'label'   => __('Request logging & traffic analysis', 'bot-eraser'),
            'weight'  => 15,
            'active'  => $api_active,
            'premium' => true,
        ),
        array(
            'key'     => 'ip_blocklist',
            'label'   => __('IP blocklist enforcement', 'bot-eraser'),
            'weight'  => 15,
            'active'  => $api_active,
            'premium' => true,
        ),
        array(
            'key'     => 'bot_detection',
            'label'   => __('Bot signature detection', 'bot-eraser'),
            'weight'  => 15,
            'active'  => $api_active,
            'premium' => true,
        ),
        array(
            'key'     => 'cloud_threat_intel',
            'label'   => __('Cloud Threat Intelligence', 'bot-eraser'),
            'weight'  => 20,
            'active'  => $api_active,
            'premium' => true,
        ),
        array(
            'key'     => 'auto_updating_lists',
            'label'   => __('Auto-updating block lists', 'bot-eraser'),
            'weight'  => 10,
            'active'  => $api_active,
            'premium' => true,
        ),
        array(
            'key'     => 'country_blocking',
            'label'   => __('Country blocking', 'bot-eraser'),
            'weight'  => 10,
            'active'  => $api_active,
            'premium' => true,
        ),
        array(
            'key'     => 'manual_lists',
            'label'   => __('Manual lists (whitelist, greylist, blacklist)', 'bot-eraser'),
            'weight'  => 15,
            'active'  => $api_active,
            'premium' => true,
        ),
    );

    $score = 0;
    foreach ($components as $c) {
        if (!empty($c['active'])) {
            $score += $c['weight'];
        }
    }

    // Treat 'premium' as a unified "fully unlocked" flag so the renderer can
    // share the same template across both pillars.
    return array(
        'score'      => min(100, $score),
        'premium'    => $api_active,
        'api_active' => $api_active,
        'components' => $components,
    );
}

/**
 * Calculate Malware Protection strength (0-100).
 * Without Premium (cloud) max is 60%. Premium unlocks the remaining 40%.
 */
function bot_eraser_get_malware_strength() {
    $validation_state = get_option('bot_eraser_api_validation_state', array());
    $premium_active   = !empty($validation_state['is_valid']);

    $last_scan    = function_exists('boteraser_get_last_scan') ? boteraser_get_last_scan() : null;
    $summary      = $last_scan['summary'] ?? null;
    $completed_at = $last_scan['completed_at'] ?? null;
    $recent_scan  = ($completed_at && (time() - (int) $completed_at) < (7 * DAY_IN_SECONDS));

    $components = array(
        array(
            'key'      => 'local_file_scanner',
            'label'    => __('Local file scanning', 'bot-eraser'),
            'weight'   => 15,
            'active'   => true,
            'premium'  => false,
        ),
        array(
            'key'      => 'database_scan',
            'label'    => __('Database scan', 'bot-eraser'),
            'weight'   => 15,
            'active'   => (bool) $summary,
            'premium'  => false,
        ),
        array(
            'key'      => 'uploads_scan',
            'label'    => __('Uploads folder check', 'bot-eraser'),
            'weight'   => 15,
            'active'   => (bool) $summary,
            'premium'  => false,
        ),
        array(
            'key'      => 'recent_scan',
            'label'    => __('Recent scan (last 7 days)', 'bot-eraser'),
            'weight'   => 15,
            'active'   => $recent_scan,
            'premium'  => false,
        ),
        array(
            'key'      => 'cloud_signatures',
            'label'    => __('Cloud malware signatures', 'bot-eraser'),
            'weight'   => 15,
            'active'   => $premium_active,
            'premium'  => true,
        ),
        array(
            'key'      => 'realtime_updates',
            'label'    => __('Auto-update signature lists', 'bot-eraser'),
            'weight'   => 15,
            'active'   => $premium_active,
            'premium'  => true,
        ),
        array(
            'key'      => 'auto_scan',
            'label'    => __('Scheduled scan (files, themes & plugins)', 'bot-eraser'),
            'weight'   => 10,
            'active'   => $premium_active,
            'premium'  => true,
        ),
    );

    $score = 0;
    foreach ($components as $c) {
        if (!empty($c['active'])) {
            $score += $c['weight'];
        }
    }

    return array(
        'score'      => min(100, $score),
        'premium'    => $premium_active,
        'components' => $components,
    );
}

/**
 * Map a 0-100 strength score to a state (low/medium/high) and label.
 */
function bot_eraser_strength_state($score) {
    if ($score >= 70) {
        return array('state' => 'high', 'label' => __('Strong coverage', 'bot-eraser'));
    }
    if ($score >= 40) {
        return array('state' => 'medium', 'label' => __('Partial coverage', 'bot-eraser'));
    }
    return array('state' => 'low', 'label' => __('Limited coverage', 'bot-eraser'));
}

/**
 * Get recent activity (last hour)
 */
function bot_eraser_get_recent_activity() {
    $log_file = BOT_ERASER_LOG_PATH;
    $recent_count = 0;
    $previous_hour_count = 0;
    $trend = array('direction' => 'neutral', 'percentage' => 0);

    if (!file_exists($log_file)) {
        return array(
            'count' => 0,
            'trend' => $trend,
            'status' => 'normal'
        );
    }

    $lines = file($log_file);
    $one_hour_ago = time() - HOUR_IN_SECONDS;
    $two_hours_ago = time() - (2 * HOUR_IN_SECONDS);

    // Count requests in last hour and previous hour
    foreach (array_reverse($lines) as $line) {
        $timestamp = bot_eraser_parse_log_timestamp($line);
        if ($timestamp === false) {
            continue;
        }

        if ($timestamp > $one_hour_ago) {
            $recent_count++;
        } elseif ($timestamp > $two_hours_ago) {
            $previous_hour_count++;
        } elseif ($timestamp <= $two_hours_ago) {
            break; // No need to process older entries
        }
    }

    // Calculate trend
    if ($previous_hour_count > 0) {
        $change = $recent_count - $previous_hour_count;
        $percentage = abs(round(($change / $previous_hour_count) * 100));
        $trend = array(
            'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
            'percentage' => $percentage
        );
    } elseif ($recent_count > 0) {
        $trend = array('direction' => 'up', 'percentage' => 100);
    }

    // Determine status based on activity level
    $status = 'normal';
    if ($recent_count > BOTERASER_ACTIVITY_HIGH) {
        $status = 'high';
    } elseif ($recent_count > BOTERASER_ACTIVITY_MEDIUM) {
        $status = 'elevated';
    }

    return array(
        'count' => $recent_count,
        'trend' => $trend,
        'status' => $status
    );
}

/**
 * Get active blocks today
 */
function bot_eraser_get_new_blocks_today() {
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    $current_count = 0;
    $yesterday_count = 0;
    $trend = array('direction' => 'neutral', 'percentage' => 0);

    if (!file_exists($blocked_ips_file)) {
        return array(
            'count' => 0,
            'trend' => $trend,
            'status' => 'normal'
        );
    }

    $blocked_ips = include $blocked_ips_file;
    if (!is_array($blocked_ips)) {
        return array(
            'count' => 0,
            'trend' => $trend,
            'status' => 'normal'
        );
    }

    $current_time = time();
    $today_start = strtotime('today');

    // Count IPs that were added today (blocked_at = expiry - 86400 >= today_start) and are still active
    foreach ($blocked_ips as $ip => $expiry) {
        $blocked_at = $expiry - 86400;
        if ($expiry > $current_time && $blocked_at >= $today_start) {
            $current_count++;
        }
    }

    // Get yesterday's new blocks count for trend calculation
    $yesterday_stats = get_transient('bot_eraser_yesterday_stats');
    if ($yesterday_stats && isset($yesterday_stats['new_blocks_today'])) {
        $yesterday_count = $yesterday_stats['new_blocks_today'];
    }

    // Calculate trend
    if ($yesterday_count > 0) {
        $change = $current_count - $yesterday_count;
        $percentage = abs(round(($change / $yesterday_count) * 100));
        $trend = array(
            'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'neutral'),
            'percentage' => $percentage
        );
    } elseif ($current_count > 0) {
        $trend = array('direction' => 'up', 'percentage' => 100);
    }

    // Determine status
    $status = 'normal';
    if ($current_count > BOTERASER_BLOCKED_MEDIUM) {
        $status = 'high';
    } elseif ($current_count > BOTERASER_BLOCKED_LOW) {
        $status = 'elevated';
    }

    return array(
        'count' => $current_count,
        'trend' => $trend,
        'status' => $status
    );
}

/**
 * Get sparkline data for last 7 days from log file
 */
function bot_eraser_get_sparkline_data() {
    $log_file         = BOT_ERASER_LOG_PATH;
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    $num_slots        = 8;

    $slots = array(
        'total_requests'   => array_fill(0, $num_slots, 0),
        'unique_ips'       => array_fill(0, $num_slots, 0),
        'blocked_ips'      => array_fill(0, $num_slots, 0),
        'blocked_today'    => array_fill(0, $num_slots, 0),
        'recent_activity'  => array_fill(0, $num_slots, 0),
        'new_blocks_today' => array_fill(0, $num_slots, 0),
        'malware_score'    => array_fill(0, $num_slots, 0),
        'malware_high'     => array_fill(0, $num_slots, 0),
        'malware_medium'   => array_fill(0, $num_slots, 0),
        'malware_low'      => array_fill(0, $num_slots, 0),
    );
    $unique_ips_per_slot = array_fill(0, $num_slots, array());

    // Parse log: divide full time range (first to last entry) into 8 equal time slots
    if (file_exists($log_file)) {
        $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        // Extract timestamps from first and last line to determine full time range
        $ts_first = null;
        $ts_last  = null;
        foreach ($lines as $line) {
            $ts_first = bot_eraser_parse_log_timestamp($line);
            if ($ts_first !== false) {
                break;
            }
        }
        foreach (array_reverse($lines) as $line) {
            $ts_last = bot_eraser_parse_log_timestamp($line);
            if ($ts_last !== false) {
                break;
            }
        }

        if ($ts_first !== null && $ts_last !== null && $ts_last > $ts_first) {
            $range     = $ts_last - $ts_first;
            $slot_size = $range / $num_slots;

            foreach ($lines as $line) {
                $ts = bot_eraser_parse_log_timestamp($line);
                if ($ts === false) {
                    continue;
                }
                // Extract IP for unique-IP counting
                if (preg_match('/^(\S+)/', $line, $m_ip)) {
                    $ip = $m_ip[1];
                } else {
                    continue;
                }
                $idx = min((int) floor(($ts - $ts_first) / $slot_size), $num_slots - 1);
                $slots['total_requests'][$idx]++;
                $slots['recent_activity'][$idx]++;
                $unique_ips_per_slot[$idx][$ip] = true;
            }
        }
    }

    foreach ($unique_ips_per_slot as $idx => $ips) {
        $slots['unique_ips'][$idx] = count($ips);
    }

    // blocked_ips / blocked_today: divide by time range using blocked_at = expiry - 86400
    $blocked_ips_map_tmp = file_exists($blocked_ips_file) ? include $blocked_ips_file : array();
    $blocked_ips_map     = is_array($blocked_ips_map_tmp) ? $blocked_ips_map_tmp : array();

    if (!empty($blocked_ips_map)) {
        $blocked_times = array();
        foreach ($blocked_ips_map as $ip => $expiry) {
            $blocked_times[$ip] = $expiry - 86400;
        }
        $bt_first = min($blocked_times);
        $bt_last  = max($blocked_times);
        $bt_range = max(1, $bt_last - $bt_first);
        $bt_slot  = $bt_range / $num_slots;

        $today_start = strtotime('today');
        foreach ($blocked_times as $ip => $blocked_at) {
            $idx = min((int) floor(($blocked_at - $bt_first) / $bt_slot), $num_slots - 1);
            $slots['blocked_ips'][$idx]++;
            $slots['blocked_today'][$idx]++;
            if ($blocked_at >= $today_start) {
                $slots['new_blocks_today'][$idx]++;
            }
        }
    }

    // malware scan history: distribute entries into 8 time slots
    $scan_history = get_option('boteraser_scan_history', array());
    $malware_times = array();
    $malware_data  = array();
    if (!empty($scan_history)) {
        foreach ($scan_history as $entry) {
            $malware_times[] = $entry['time'];
            $malware_data[]  = $entry;
        }
        $mw_first = min($malware_times);
        $mw_last  = max($malware_times);
        $mw_range = max(1, $mw_last - $mw_first);
        $mw_slot  = $mw_range / $num_slots;

        foreach ($malware_data as $entry) {
            $idx = min((int) floor(($entry['time'] - $mw_first) / $mw_slot), $num_slots - 1);
            // Use the latest entry's values for each slot (overwrite, last-wins)
            $slots['malware_score'][$idx]  = (int) $entry['score'];
            $slots['malware_high'][$idx]   = (int) $entry['high'];
            $slots['malware_medium'][$idx] = (int) $entry['medium'];
            $slots['malware_low'][$idx]    = (int) $entry['low'];
        }
    }

    // Determine logStart: prefer log file timestamp, fall back to earliest scan
    if (isset($ts_first)) {
        $slots['logStart'] = date('d M Y H:i', $ts_first);
    } elseif (!empty($malware_times)) {
        $slots['logStart'] = date('d M Y H:i', min($malware_times));
    } else {
        $slots['logStart'] = null;
    }

    return $slots;
}

/**
 * Get recent blocked IPs for activity feed
 */
function bot_eraser_get_recent_blocked_ips($limit = 5) {
    $recent = array();
    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';

    if (file_exists($blocked_ips_file)) {
        $blocked_ips = include $blocked_ips_file;
        if (is_array($blocked_ips) && !empty($blocked_ips)) {
            // Sort by expiry time (most recent blocks first)
            arsort($blocked_ips);
            $count = 0;
            foreach ($blocked_ips as $ip => $expiry) {
                if ($expiry > time() && $count < $limit) {
                    $recent[] = array(
                        'ip' => $ip,
                        'expiry' => $expiry,
                        'time_ago' => human_time_diff(time() - (86400 - ($expiry - time())), time())
                    );
                    $count++;
                }
            }
        }
    }

    return $recent;
}

/**
 * Get recent malware findings from the last scan.
 */
function bot_eraser_get_recent_malware_findings($limit = 5) {
    if (!function_exists('boteraser_get_last_scan')) {
        $scanner_engine = BOT_ERASER_PLUGIN_DIR . 'includes/scanner/scan-engine.php';
        if (file_exists($scanner_engine)) {
            require_once $scanner_engine;
        }
    }

    if (!function_exists('boteraser_get_last_scan')) {
        return array();
    }

    $last_scan    = boteraser_get_last_scan();
    $findings     = $last_scan['findings'] ?? array();
    $completed_at = $last_scan['completed_at'] ?? null;
    $whitelist    = get_option(defined('BOTERASER_SCAN_WHITELIST') ? BOTERASER_SCAN_WHITELIST : 'boteraser_scan_whitelist', array());

    if (empty($findings)) {
        return array();
    }

    $severity_rank = array('HIGH' => 3, 'MEDIUM' => 2, 'LOW' => 1);

    $visible = array();
    foreach ($findings as $finding) {
        $file = $finding['file'] ?? '';
        if ($file !== '' && in_array($file, (array) $whitelist, true)) {
            continue;
        }
        $visible[] = $finding;
    }

    usort($visible, function($a, $b) use ($severity_rank) {
        $ra = $severity_rank[strtoupper($a['severity'] ?? '')] ?? 0;
        $rb = $severity_rank[strtoupper($b['severity'] ?? '')] ?? 0;
        return $rb <=> $ra;
    });

    $visible = array_slice($visible, 0, $limit);

    $result = array();
    foreach ($visible as $finding) {
        $result[] = array(
            'file'     => $finding['file'] ?? '—',
            'severity' => strtoupper($finding['severity'] ?? 'LOW'),
            'time_ago' => $completed_at ? human_time_diff((int) $completed_at, time()) : '',
        );
    }

    return $result;
}

/**
 * SVG Icons helper
 */
function bot_eraser_icon($name, $class = '') {
    $icons = array(
        'shield' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>',
        'shield-check' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>',
        'shield-x' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="9" y1="9" x2="15" y2="15"></line><line x1="15" y1="9" x2="9" y2="15"></line></svg>',
        'key' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>',
        'check' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="20 6 9 17 4 12"></polyline></svg>',
        'check-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
        'x-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        'alert-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
        'alert-triangle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
        'info' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
        'loader' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>',
        'activity' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>',
        'server' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>',
        'database' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path></svg>',
        'cloud' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path></svg>',
        'globe' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>',
        'users' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        'ban' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>',
        'file-text' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>',
        'settings' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>',
        'external-link' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>',
        'refresh' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>',
        'refresh-cw' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>',
        'upload' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="16 16 12 12 8 16"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path></svg>',
        'git-merge' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="18" cy="18" r="3"></circle><circle cx="6" cy="6" r="3"></circle><path d="M6 21V9a9 9 0 0 0 9 9"></path></svg>',
        'clock' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>',
        'zap' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>',
        'trending-up' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>',
        'arrow-right' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
        'play' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>',
        'arrow-up' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>',
        'arrow-down' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline></svg>',
        'minus' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="5" y1="12" x2="19" y2="12"></line></svg>',
        'help-circle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
        'scan' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M3 7V5a2 2 0 0 1 2-2h2"></path><path d="M17 3h2a2 2 0 0 1 2 2v2"></path><path d="M21 17v2a2 2 0 0 1-2 2h-2"></path><path d="M7 21H5a2 2 0 0 1-2-2v-2"></path><line x1="3" y1="12" x2="21" y2="12"></line></svg>',
        'lock' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>',
        'pause' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>',
        'shield-off' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M19.69 14a6.9 6.9 0 0 0 .31-2V5l-8-3-3.16 1.18"></path><path d="M4.73 4.73L4 5v7c0 6 8 10 8 10a20.29 20.29 0 0 0 5.62-4.38"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>',
        'mail' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>',
        'package' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"></line><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>',
        'layout' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>',
        'folder' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>',
        'archive' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>',
        'power' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path><line x1="12" y1="2" x2="12" y2="12"></line></svg>',
        'file-x' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="9.5" y1="12.5" x2="14.5" y2="17.5"></line><line x1="14.5" y1="12.5" x2="9.5" y2="17.5"></line></svg>',
        'rotate-ccw' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>',
        'cloud-lightning' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M19 16.9A5 5 0 0 0 18 7h-1.26a8 8 0 1 0-11.62 9"></path><polyline points="13 11 9 17 15 17 11 23"></polyline></svg>',
        'folder-check' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="' . esc_attr($class) . '"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L13.6 3.9A2 2 0 0 0 11.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2z"></path><path d="m9 13 2 2 4-4"></path></svg>',
    );

    return isset($icons[$name]) ? $icons[$name] : '';
}

/**
 * Format uptime to human readable
 */
function bot_eraser_format_uptime($seconds) {
    $days = floor($seconds / 86400);
    $hours = floor(($seconds % 86400) / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $parts = array();
    if ($days > 0) $parts[] = $days . 'd';
    if ($hours > 0) $parts[] = $hours . 'h';
    if ($minutes > 0) $parts[] = $minutes . 'm';
    if ($seconds === null) return 'N/A';
    return !empty($parts) ? implode(' ', $parts) : '0m';
}
/**
 * Boteraser Admin Styles
 * Premium WordPress Plugin UI
 *
 * @package Boteraser
 * @version 1.0.0
 */
 
/**
 * Render a shared admin page header.
 *
 * @param array $args Header configuration.
 */
function bot_eraser_render_page_header($args = array()) {
    $defaults = array(
        'variant'  => 'standard',
        'modifiers'=> array(),
        'eyebrow'  => '',
        'title'    => '',
        'subtitle' => '',
        'status'   => null,
        'metrics'  => array(),
        'aside'    => '',
    );

    $args = wp_parse_args($args, $defaults);

    $classes = array('boteraser-header', 'boteraser-hero', 'boteraser-page-header');

    if ($args['variant'] === 'hero') {
        $classes[] = 'boteraser-hero-slim';
        $classes[] = 'boteraser-page-header-hero';
    } else {
        $classes[] = 'boteraser-hero-compact';
        $classes[] = 'boteraser-page-header-standard';
    }

    if (is_array($args['modifiers'])) {
        foreach ($args['modifiers'] as $modifier) {
            $modifier = sanitize_html_class($modifier);
            if ($modifier !== '') {
                $classes[] = $modifier;
            }
        }
    }
    ?>
    <div class="<?php echo esc_attr(implode(' ', $classes)); ?>">
        <div class="boteraser-hero-main">
            <div class="boteraser-hero-brand">
                <div class="boteraser-hero-logo-shell">
                    <img src="<?php echo esc_url(BOT_ERASER_PLUGIN_URL . 'assets/images/logo.svg'); ?>" alt="Boteraser" class="boteraser-logo">
                </div>
                <?php if (!empty($args['metrics']) && is_array($args['metrics'])): ?>
                    <div class="boteraser-hero-telemetry boteraser-hero-kpis">
                        <?php foreach ($args['metrics'] as $metric):
                            $tone = !empty($metric['tone']) ? $metric['tone'] : 'neutral';
                        ?>
                            <div class="boteraser-hero-kpi boteraser-hero-kpi--<?php echo esc_attr($tone); ?>"<?php echo !empty($metric['id']) ? ' id="' . esc_attr($metric['id']) . '"' : ''; ?>>
                                <span class="boteraser-hero-kpi-label"><?php echo esc_html($metric['label'] ?? ''); ?></span>
                                <div class="boteraser-hero-kpi-value-row">
                                    <strong class="boteraser-hero-kpi-value"><?php echo esc_html($metric['value'] ?? ''); ?></strong>
                                    <?php if (!empty($metric['badge'])): ?>
                                        <span class="boteraser-hero-kpi-badge"><?php echo esc_html($metric['badge']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($metric['context'])): ?>
                                    <span class="boteraser-hero-kpi-context"><?php echo esc_html($metric['context']); ?></span>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="boteraser-hero-copy">
                <?php if (!empty($args['eyebrow'])): ?>
                    <span class="boteraser-hero-eyebrow"><?php echo esc_html($args['eyebrow']); ?></span>
                <?php endif; ?>
                <h1 class="boteraser-header-title">
                    <?php echo esc_html($args['title']); ?>
                    <?php if (is_array($args['status']) && !empty($args['status']['label']) && !empty($args['status']['class'])): ?>
                        <span class="boteraser-hero-status boteraser-hero-status-<?php echo esc_attr($args['status']['class']); ?>">
                            <span class="boteraser-hero-status-dot" aria-hidden="true"></span>
                            <span class="boteraser-hero-status-text"><?php echo esc_html($args['status']['label']); ?></span>
                        </span>
                    <?php endif; ?>
                </h1>
                <?php if (!empty($args['subtitle'])): ?>
                    <p class="boteraser-header-subtitle"><?php echo esc_html($args['subtitle']); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($args['aside'])): ?>
            <?php echo $args['aside']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Render the main settings page
 */
/**
 * Render a half-circle (semicircle) protection strength gauge.
 *
 * @param int    $score 0-100
 * @param string $state low|medium|high
 * @param string $label Human-readable state label.
 */
function bot_eraser_render_strength_gauge($score, $state, $label = '') {
    $score = max(0, min(100, (int) $score));
    // Shield fill rises from the bottom: 100% → fully filled, 0% → empty.
    // ViewBox is 0..100 vertically so the rect math is direct.
    $fill_y      = 100 - $score;
    $clip_id     = 'be-shield-clip-' . wp_unique_id();
    $halo_id     = 'be-shield-halo-' . wp_unique_id();
    $hilight_id  = 'be-shield-hilight-' . wp_unique_id();
    // Lucide-style soft shield path scaled to a 100x100 viewBox.
    // Original Lucide: M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z (24x24)
    // Scaled ~×4.16 and centered: top tip y≈8, base of crown y≈21, bottom tip y≈92.
    $shield_path = 'M50 8 L83 21 L83 50 C83 71 67 88 50 92 C33 88 17 71 17 50 L17 21 Z';
    ?>
    <div class="boteraser-score boteraser-score-<?php echo esc_attr($state); ?>"
         role="progressbar"
         aria-valuenow="<?php echo esc_attr($score); ?>"
         aria-valuemin="0" aria-valuemax="100">
        <div class="boteraser-score-info">
            <div class="boteraser-score-num">
                <span class="boteraser-score-num-value"><?php echo esc_html($score); ?></span>
                <span class="boteraser-score-num-suffix">%</span>
            </div>
            <?php if ($label !== ''): ?>
                <span class="boteraser-score-badge"><?php echo esc_html($label); ?></span>
            <?php endif; ?>
        </div>
        <svg class="boteraser-score-shield" viewBox="17 8 66 84" aria-hidden="true">
            <defs>
                <clipPath id="<?php echo esc_attr($clip_id); ?>">
                    <path d="<?php echo esc_attr($shield_path); ?>"></path>
                </clipPath>
                <!-- Radial glow halo behind the shield, in state color -->
                <radialGradient id="<?php echo esc_attr($halo_id); ?>" cx="50%" cy="55%" r="50%">
                    <stop offset="0%"   stop-color="currentColor" stop-opacity="0.35"></stop>
                    <stop offset="60%"  stop-color="currentColor" stop-opacity="0.08"></stop>
                    <stop offset="100%" stop-color="currentColor" stop-opacity="0"></stop>
                </radialGradient>
                <!-- Inner highlight: soft white sheen on the upper-left -->
                <linearGradient id="<?php echo esc_attr($hilight_id); ?>" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%"  stop-color="#fff" stop-opacity="0.55"></stop>
                    <stop offset="55%" stop-color="#fff" stop-opacity="0"></stop>
                </linearGradient>
            </defs>

            <!-- Glow halo behind the shield -->
            <ellipse class="boteraser-score-shield-halo"
                     cx="50" cy="55" rx="48" ry="46"
                     fill="url(#<?php echo esc_attr($halo_id); ?>)"></ellipse>

            <!-- Empty shield background -->
            <path class="boteraser-score-shield-bg" d="<?php echo esc_attr($shield_path); ?>"></path>

            <!-- Liquid fill rising from the bottom -->
            <g clip-path="url(#<?php echo esc_attr($clip_id); ?>)">
                <rect class="boteraser-score-shield-fill"
                      x="0"
                      y="<?php echo esc_attr($fill_y); ?>"
                      width="100"
                      height="<?php echo esc_attr($score); ?>"></rect>
                <!-- Inner highlight sheen, also clipped to the shield shape -->
                <path class="boteraser-score-shield-hilight"
                      d="<?php echo esc_attr($shield_path); ?>"
                      fill="url(#<?php echo esc_attr($hilight_id); ?>)"></path>
            </g>

            <!-- Outline drawn last so fill sits flush -->
            <path class="boteraser-score-shield-outline" d="<?php echo esc_attr($shield_path); ?>"></path>

            <!-- Checkmark only shown when state is high -->
            <path class="boteraser-score-shield-check"
                  d="M34 52 L46 64 L68 40"
                  fill="none" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
    </div>
    <?php
}

function bot_eraser_render_settings_page() {
    if (!current_user_can('manage_options')) return;

    // Check if privacy notice has been accepted
    $privacy_accepted = get_option('bot_eraser_privacy_notice_dismissed');

    // Clean up duplicate API key entries
    bot_eraser_cleanup_api_key_entries();

    // Auto-detect system software versions if not yet saved
    $sys_versions = bot_eraser_vuln_detect_versions();
    foreach (array('php', 'os', 'openssh') as $key) {
        $opt = 'boteraser_sys_' . $key;
        if (!get_option($opt) || $opt === 'boteraser_sys_php') {
            update_option($opt, sanitize_text_field($sys_versions[$key] ?? ''));
        }
    }
    if (!empty($sys_versions['webserver']) && empty(get_option('boteraser_sys_webserver'))) {
        update_option('boteraser_sys_webserver', sanitize_text_field($sys_versions['webserver']));
    }

    // Handle form submissions
    $settings_saved = false;
    $api_validation_result = null;

    // Block form submission if privacy notice not accepted
    if (isset($_POST['bot_eraser_settings_nonce']) && $privacy_accepted) {
        check_admin_referer('bot_eraser_settings', 'bot_eraser_settings_nonce');

        // Handle disconnect/remove API key
        if (!empty($_POST['bot_eraser_remove_api_key'])) {
            global $wpdb;
            $wpdb->delete($wpdb->options, array('option_name' => 'bot_eraser_api_key'));
            wp_cache_delete('bot_eraser_api_key', 'options');
            wp_cache_delete('alloptions', 'options');
            delete_option('bot_eraser_api_validation_state');
            wp_safe_redirect(add_query_arg('page', 'bot-eraser', admin_url('admin.php')));
            exit;
        }

        $api_key = sanitize_text_field($_POST['api_key']);
        $api_validation_result = bot_eraser_validate_api_key_with_server($api_key);

        // Save validation state
        $validation_state = array(
            'api_key_hash' => bot_eraser_simple_hash($api_key),
            'is_valid' => $api_validation_result['valid'] ?? false,
            'message' => $api_validation_result['message'] ?? '',
            'timestamp' => time()
        );
        update_option('bot_eraser_api_validation_state', $validation_state);

        // Save API key
        global $wpdb;
        $wpdb->delete($wpdb->options, array('option_name' => 'bot_eraser_api_key'));
        wp_cache_delete('bot_eraser_api_key', 'options');
        wp_cache_delete('alloptions', 'options');

        $wpdb->insert(
            $wpdb->options,
            array(
                'option_name' => 'bot_eraser_api_key',
                'option_value' => $api_key,
                'autoload' => 'yes'
            ),
            array('%s', '%s', '%s')
        );

        $settings_saved = true;

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Boteraser: API key saved successfully');
        }
    }

    // Handle manual execution
    $manual_execution_data = null;

    // Block manual execution if privacy notice not accepted
    if (isset($_POST['bot_eraser_manual_run']) && check_admin_referer('bot_eraser_manual_action', '_wpnonce') && $privacy_accepted) {
        // Save last manual run time
        update_option('bot_eraser_last_manual_run', time());

        // Send data to server - this will also update validation state
        $manual_execution_data = bot_eraser_send_data_to_server('manual');

        // Update validation state based on execution result
        global $wpdb;
        $current_api_key = $wpdb->get_var($wpdb->prepare(
            "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s ORDER BY option_id DESC LIMIT 1",
            'bot_eraser_api_key'
        ));

        if (!empty($current_api_key)) {
            $error_message = $manual_execution_data['message'] ?? '';
            $is_success = ($manual_execution_data['status'] ?? 'error') === 'success';

            $validation_state = array(
                'api_key_hash' => bot_eraser_simple_hash($current_api_key),
                'is_valid' => $is_success,
                'message' => $error_message,
                'timestamp' => time()
            );
            update_option('bot_eraser_api_validation_state', $validation_state);
        }
    }

    // Get API key for form
    global $wpdb;
    $form_api_key = $wpdb->get_var($wpdb->prepare(
        "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s ORDER BY option_id DESC LIMIT 1",
        'bot_eraser_api_key'
    ));
    $form_api_key = $form_api_key ?: '';

    // Get validation state
    $validation_state = get_option('bot_eraser_api_validation_state', array());

    // Get dashboard stats
    $stats = bot_eraser_get_dashboard_stats();
    $recent_blocked = bot_eraser_get_recent_blocked_ips(5);
    $threat_level = bot_eraser_get_threat_level();
    $protection_rate = bot_eraser_get_protection_rate();
    $recent_activity = bot_eraser_get_recent_activity();
    $new_blocks_today = bot_eraser_get_new_blocks_today();
    $notify_email     = get_option('boteraser_notify_email', get_option('admin_email'));
    $notify_enabled   = (bool) get_option('boteraser_notify_enabled', false);
    $api_connected = !empty($validation_state['is_valid']);
    $setup_steps = array(
        array(
            'label' => __('Privacy accepted', 'bot-eraser'),
            'description' => __('Compliance notice acknowledged for cloud processing.', 'bot-eraser'),
            'complete' => (bool) $privacy_accepted,
        ),
        array(
            'label' => __('API key connected', 'bot-eraser'),
            'description' => __('Secure connection to Boteraser Cloud is verified.', 'bot-eraser'),
            'complete' => $api_connected,
        ),
        array(
            'label' => __('Traffic monitoring live', 'bot-eraser'),
            'description' => __('Request logging is active and dashboard metrics are updating.', 'bot-eraser'),
            'complete' => !empty($stats['total_requests']),
        ),
    );
    $setup_completed = count(array_filter($setup_steps, function($step) {
        return !empty($step['complete']);
    }));

    // Ensure scanner engine is loaded so the malware helpers can read last-scan results
    $scanner_engine = BOT_ERASER_PLUGIN_DIR . 'includes/scanner/scan-engine.php';
    if (file_exists($scanner_engine)) {
        require_once $scanner_engine;
    }

    // Protection strength gauges and recent malware findings
    $bot_ip_strength       = bot_eraser_get_bot_ip_strength();
    $malware_strength      = bot_eraser_get_malware_strength();
    $bot_ip_state          = bot_eraser_strength_state($bot_ip_strength['score']);
    $malware_state         = bot_eraser_strength_state($malware_strength['score']);
    $recent_malware        = bot_eraser_get_recent_malware_findings(5);
    $last_scan_for_dash    = function_exists('boteraser_get_last_scan') ? boteraser_get_last_scan() : null;
    $rmf_scanned           = !empty($last_scan_for_dash['completed_at']);

    // Quarantine data
    if (!function_exists('boteraser_quarantine_list')) {
        $quarantine_file = BOT_ERASER_PLUGIN_DIR . 'includes/quarantine.php';
        if (file_exists($quarantine_file)) require_once $quarantine_file;
    }
    $dash_quarantine_items = function_exists('boteraser_quarantine_list') ? boteraser_quarantine_list() : array();
    $dash_quarantine_count = count($dash_quarantine_items);
    $dash_quarantine_high  = count(array_filter($dash_quarantine_items, fn($e) => ($e['severity'] ?? '') === 'HIGH'));

    // Upload scanner data
    $dash_upload_alerts      = get_option('boteraser_upload_alerts', array());
    $dash_upload_alert_count = count($dash_upload_alerts);
    $dash_upload_last_alert  = !empty($dash_upload_alerts) ? end($dash_upload_alerts) : null;
    $dash_upload_active      = $api_connected; // upload scanner requires premium/API

    // File integrity monitor
    $dash_baseline_time    = get_option('boteraser_baseline_time', null);
    $dash_baseline_files   = get_option('boteraser_file_baseline', array());
    $dash_integrity_changed = array();
    $dash_integrity_deleted = array();
    if (!empty($dash_baseline_files)) {
        foreach ($dash_baseline_files as $rel_path => $saved_hash) {
            $full_path = ABSPATH . $rel_path;
            if (!file_exists($full_path)) {
                $dash_integrity_deleted[] = $rel_path;
            } elseif (md5_file($full_path) !== $saved_hash) {
                $dash_integrity_changed[] = array(
                    'file'  => $rel_path,
                    'mtime' => filemtime($full_path),
                );
            }
        }
        // Sort changed files by most recently modified
        usort($dash_integrity_changed, fn($a, $b) => $b['mtime'] - $a['mtime']);
    }
    $dash_integrity_changed_count = count($dash_integrity_changed);
    $dash_integrity_deleted_count = count($dash_integrity_deleted);
    $dash_integrity_total         = $dash_integrity_changed_count + $dash_integrity_deleted_count;
    $dash_integrity_tone          = $dash_integrity_total === 0 ? 'low' : ($dash_integrity_deleted_count > 0 ? 'high' : 'medium');
    $last_scan_summary     = $last_scan_for_dash['summary'] ?? null;
    $last_scan_completed   = $last_scan_for_dash['completed_at'] ?? null;
    // Engine stores completed_at as a UNIX timestamp; older runs may
    // have written a string, so accept both.
    $last_scan_timestamp   = is_numeric($last_scan_completed)
        ? (int) $last_scan_completed
        : (int) strtotime((string) $last_scan_completed);

    if ($last_scan_summary) {
        $dash_score_int = (int) $last_scan_summary['score'];
        $dash_score_tone = $dash_score_int >= 75 ? 'low' : ($dash_score_int >= 50 ? 'medium' : 'high');
        $dash_context_parts = array();
        if ($last_scan_timestamp) {
            $dash_context_parts[] = sprintf(__('Last scan: %s ago', 'bot-eraser'), human_time_diff($last_scan_timestamp, time()));
        }
        $dash_context_parts[] = sprintf(
            /* translators: 1: number of files scanned, 2: scan duration in seconds */
            __('%1$s files, %2$ss', 'bot-eraser'),
            number_format_i18n((int) $last_scan_summary['files_scanned']),
            (int) ($last_scan_for_dash['duration'] ?? 0)
        );
        $dash_score_context = implode(' — ', $dash_context_parts);
    } else {
        $dash_score_tone    = 'neutral';
        $dash_score_context = __('No scan yet', 'bot-eraser');
    }

    $dash_auto_scan_enabled = $api_connected && (bool) get_option('boteraser_auto_scan_enabled', false);
    $dash_auto_scan_next    = wp_next_scheduled('boteraser_auto_scan_hook');

    if ($dash_auto_scan_enabled && $dash_auto_scan_next) {
        $dash_next_scan_value   = date_i18n('d.m.Y H:i', $dash_auto_scan_next);
        $dash_next_scan_context = __('Next automatic scan run', 'bot-eraser');
        $dash_next_scan_tone    = 'low';
    } elseif ($dash_auto_scan_enabled) {
        $dash_next_scan_value   = __('Pending', 'bot-eraser');
        $dash_next_scan_context = __('Waiting for cron', 'bot-eraser');
        $dash_next_scan_tone    = 'medium';
    } else {
        $dash_next_scan_value   = null;
        $dash_next_scan_context = null;
        $dash_next_scan_tone    = null;
    }

    $hero_metrics = array(
        array(
            'label'   => __('Threat level', 'bot-eraser'),
            'value'   => strtoupper($threat_level['level']),
            'context' => __('Current detection state', 'bot-eraser'),
            'tone'    => $threat_level['level'],
        ),
        array(
            'label'   => __('Requests blocked', 'bot-eraser'),
            'value'   => esc_html($protection_rate['rate']) . '%',
            'context' => __('Protection efficiency', 'bot-eraser'),
            'tone'    => 'neutral',
        ),
        array(
            'label'   => __('Health Score', 'bot-eraser'),
            'value'   => $last_scan_summary ? esc_html($last_scan_summary['score']) . '/100' : '—',
            'badge'   => $last_scan_summary ? esc_html($last_scan_summary['grade']) : '',
            'context' => $dash_score_context,
            'tone'    => $dash_score_tone,
            'id'      => 'be-hero-last-scan',
        ),
    );

    $hero_metrics[] = array(
        'label'   => __('Next scan', 'bot-eraser'),
        'value'   => $dash_auto_scan_enabled ? $dash_next_scan_value : '—',
        'context' => $dash_auto_scan_enabled ? $dash_next_scan_context : __('Automatic scan off', 'bot-eraser'),
        'tone'    => $dash_auto_scan_enabled ? $dash_next_scan_tone : 'neutral',
        'id'      => 'be-hero-next-scan',
    );

    // Localize script with config
    wp_localize_script('boteraser-admin', 'boteraser_config', array(
        'apiKey'          => $form_api_key,
        'validationState' => $validation_state,
        'ajaxUrl'         => admin_url('admin-ajax.php'),
        'nonce'           => wp_create_nonce('boteraser_ajax'),
        'scanNonce'       => wp_create_nonce('boteraser_scan_nonce'),
        'sysDetectNonce'  => wp_create_nonce('boteraser_sys_detect'),
        'sparklineData'   => bot_eraser_get_sparkline_data(),
        'lastScan'        => boteraser_get_last_scan_summary(),
    ));

    // Live status badge
    if ($privacy_accepted && $api_connected && $threat_level['level'] !== 'high') {
        $dash_status_class = 'operational';
        $dash_status_label = __('Operational', 'bot-eraser');
    } elseif ($privacy_accepted && $api_connected) {
        $dash_status_class = 'attention';
        $dash_status_label = __('Action needed', 'bot-eraser');
    } else {
        $dash_status_class = 'setup';
        $dash_status_label = __('Setup required', 'bot-eraser');
    }

    // Build setup aside HTML
    $setup_total   = count($setup_steps);
    $setup_percent = $setup_total > 0 ? (int) round(($setup_completed / $setup_total) * 100) : 0;
    $setup_items   = '';
    foreach ($setup_steps as $step) {
        $done         = !empty($step['complete']);
        $mark_icon    = $done ? bot_eraser_icon('check-circle') : bot_eraser_icon('clock');
        $setup_items .= sprintf(
            '<li class="boteraser-hero-setup-item %s"><span class="boteraser-hero-setup-mark">%s</span><span class="boteraser-hero-setup-label">%s</span></li>',
            $done ? 'complete' : 'pending',
            $mark_icon,
            esc_html($step['label'])
        );
    }
    $ring_fill = sprintf(
        '<svg class="boteraser-hero-setup-ring-svg" viewBox="0 0 36 36" aria-hidden="true"><circle class="boteraser-hero-setup-ring-track" cx="18" cy="18" r="16" fill="none" stroke-width="3"></circle><circle class="boteraser-hero-setup-ring-fill" cx="18" cy="18" r="16" fill="none" stroke-width="3" stroke-dasharray="100" stroke-dashoffset="%d" pathLength="100" transform="rotate(-90 18 18)" stroke-linecap="round"></circle></svg><span class="boteraser-hero-setup-ring-label">%s%%</span>',
        100 - $setup_percent,
        esc_html($setup_percent)
    );
    $dash_aside = sprintf(
        '<aside class="boteraser-hero-setup %s"><div class="boteraser-hero-setup-header"><div><p class="boteraser-hero-setup-eyebrow">%s</p><h3 class="boteraser-hero-setup-title">%s</h3></div><div class="boteraser-hero-setup-ring %s" style="--be-ring-progress: %s%%;">%s</div></div><ul class="boteraser-hero-setup-list">%s</ul></aside>',
        $setup_completed === $setup_total ? 'is-complete' : '',
        esc_html__('Setup Progress', 'bot-eraser'),
        esc_html(sprintf(__('%1$d of %2$d steps completed', 'bot-eraser'), $setup_completed, $setup_total)),
        $setup_completed === $setup_total ? 'complete' : '',
        esc_attr($setup_percent),
        $ring_fill,
        $setup_items
    );
    ?>

    <div class="wrap boteraser-wrap<?php echo $threat_level['level'] === 'high' ? ' boteraser-threat-high' : ''; ?>">
        <?php bot_eraser_render_page_header(array(
            'variant'  => 'standard',
            'title'    => __('Boteraser Security Console', 'bot-eraser'),
            'subtitle' => __('Two layers of protection. Bot & IP blocking and malware scanning — including cloud-verified file analysis — controlled from one place.', 'bot-eraser'),
            'status'   => array('class' => $dash_status_class, 'label' => $dash_status_label),
            'metrics'  => $hero_metrics,
            'aside'    => $dash_aside,
        )); ?>

        <!-- Two-pillar protection overview -->
        <div class="boteraser-protection-pillars">
            <?php
            $pillars = array(
                array(
                    'id'              => 'bot-ip',
                    'eyebrow'         => __('Pillar 1', 'bot-eraser'),
                    'title'           => __('Bot & IP Protection', 'bot-eraser'),
                    'icon'            => 'shield',
                    'strength'        => $bot_ip_strength,
                    'state'           => $bot_ip_state,
                    'cta_label'       => __('Manage Blocked IPs', 'bot-eraser'),
                    'cta_url'         => admin_url('admin.php?page=bot-eraser-blocked-ips'),
                    'cta_icon'        => 'shield-x',
                    'alt_label'       => __('View Logs', 'bot-eraser'),
                    'alt_url'         => admin_url('admin.php?page=bot-eraser-logs'),
                    'alt_icon'        => 'activity',
                    'requires_api'    => true,
                    'upgrade_message' => __('Bot &amp; IP protection requires an active API key. Connect one to enable this layer.', 'bot-eraser'),
                ),
                array(
                    'id'              => 'malware',
                    'eyebrow'         => __('Pillar 2', 'bot-eraser'),
                    'title'           => __('Malware Protection', 'bot-eraser'),
                    'icon'            => 'shield-check',
                    'strength'        => $malware_strength,
                    'state'           => $malware_state,
                    'cta_label'       => __('Run Scan Now', 'bot-eraser'),
                    'cta_url'         => admin_url('admin.php?page=bot-eraser-scanner'),
                    'cta_icon'        => 'play',
                    'alt_label'       => __('View Findings', 'bot-eraser'),
                    'alt_url'         => admin_url('admin.php?page=bot-eraser-scanner'),
                    'alt_icon'        => 'file-text',
                    'requires_api'    => false,
                    'upgrade_message' => '',
                ),
            );
            foreach ($pillars as $pillar):
                $strength = $pillar['strength'];
                $state    = $pillar['state'];
            ?>
            <div class="boteraser-pillar boteraser-pillar-<?php echo esc_attr($pillar['id']); ?> boteraser-pillar-state-<?php echo esc_attr($state['state']); ?>">
                <div class="boteraser-pillar-header">
                    <span class="boteraser-pillar-icon"><?php echo bot_eraser_icon($pillar['icon']); ?></span>
                    <div>
                        <span class="boteraser-pillar-eyebrow"><?php echo esc_html($pillar['eyebrow']); ?></span>
                        <h2 class="boteraser-pillar-title"><?php echo esc_html($pillar['title']); ?></h2>
                    </div>
                </div>

                <div class="boteraser-pillar-gauge-wrap">
                    <?php bot_eraser_render_strength_gauge($strength['score'], $state['state'], $state['label']); ?>
                </div>

                <ul class="boteraser-pillar-features">
                    <?php foreach ($strength['components'] as $component): ?>
                        <li class="boteraser-pillar-feature <?php echo !empty($component['active']) ? 'is-active' : 'is-inactive'; ?> <?php echo !empty($component['premium']) ? 'is-premium' : ''; ?>">
                            <span class="boteraser-pillar-feature-mark">
                                <?php echo !empty($component['active']) ? bot_eraser_icon('check-circle') : bot_eraser_icon('x-circle'); ?>
                            </span>
                            <span class="boteraser-pillar-feature-label">
                                <?php echo esc_html($component['label']); ?>
                                <?php if (!empty($component['premium'])): ?>
                                    <span class="boteraser-pillar-feature-tag"><?php _e('Premium', 'bot-eraser'); ?></span>
                                <?php endif; ?>
                            </span>
                            <span class="boteraser-pillar-feature-weight">+<?php echo (int) $component['weight']; ?>%</span>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <?php if (!$strength['premium']):
                    if (!empty($pillar['requires_api'])) {
                        $upgrade_text = $pillar['upgrade_message'];
                        $upgrade_class = 'boteraser-pillar-upgrade boteraser-pillar-upgrade-api';
                    } else {
                        $upgrade_text = sprintf(__('Unlock the remaining %d%% with Premium.', 'bot-eraser'), max(0, 100 - (int) $strength['score']));
                        $upgrade_class = 'boteraser-pillar-upgrade';
                    }
                ?>
                <div class="<?php echo esc_attr($upgrade_class); ?>">
                    <?php echo bot_eraser_icon(!empty($pillar['requires_api']) ? 'key' : 'zap'); ?>
                    <span><?php echo wp_kses($upgrade_text, array('strong' => array(), 'em' => array())); ?></span>
                </div>
                <?php endif; ?>

                <div class="boteraser-pillar-actions">
                    <a href="<?php echo esc_url($pillar['cta_url']); ?>" class="boteraser-btn boteraser-btn-primary">
                        <?php echo bot_eraser_icon($pillar['cta_icon']); ?>
                        <?php echo esc_html($pillar['cta_label']); ?>
                    </a>
                    <a href="<?php echo esc_url($pillar['alt_url']); ?>" class="boteraser-btn boteraser-btn-secondary">
                        <?php echo bot_eraser_icon($pillar['alt_icon']); ?>
                        <?php echo esc_html($pillar['alt_label']); ?>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Extended Protection (pre-WordPress blocking) toggle card -->
        <?php bot_eraser_prepend_render_card(); ?>

        <!-- Notices -->
        <?php if ($settings_saved): ?>
            <div class="boteraser-notice <?php echo $api_validation_result['valid'] ? 'success' : 'warning'; ?>">
                <?php echo $api_validation_result['valid'] ? bot_eraser_icon('check-circle') : bot_eraser_icon('alert-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title">
                        <?php echo $api_validation_result['valid'] ? __('Settings Saved', 'bot-eraser') : __('Settings Saved with Warning', 'bot-eraser'); ?>
                    </p>
                    <p class="boteraser-notice-message">
                        <?php echo $api_validation_result['valid']
                            ? __('Your API key has been validated and saved successfully.', 'bot-eraser')
                            : __('API key saved but validation failed: ', 'bot-eraser') . esc_html($api_validation_result['message']); ?>
                    </p>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($manual_execution_data): ?>
            <div class="boteraser-notice <?php echo ($manual_execution_data['status'] === 'success') ? 'success' : 'error'; ?>">
                <?php echo ($manual_execution_data['status'] === 'success') ? bot_eraser_icon('check-circle') : bot_eraser_icon('x-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title"><?php _e('Manual Execution Completed', 'bot-eraser'); ?></p>
                    <p class="boteraser-notice-message"><?php _e('Results are displayed below.', 'bot-eraser'); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="boteraser-stats-stack">
            <section class="boteraser-snapshot" data-snapshot>
                <div class="boteraser-snapshot-header">
                    <div class="boteraser-snapshot-heading">
                        <p class="boteraser-snapshot-eyebrow"><?php _e('Security Snapshot', 'bot-eraser'); ?></p>
                        <h2 class="boteraser-snapshot-title"><?php _e('Metrics across protection layers', 'bot-eraser'); ?></h2>
                    </div>
                    <div class="boteraser-snapshot-tabs" role="tablist" aria-label="<?php esc_attr_e('Snapshot sections', 'bot-eraser'); ?>">
                        <button type="button" class="boteraser-snapshot-tab is-active" data-snapshot-tab="bot-ip" role="tab" aria-selected="true"><?php _e('Bot &amp; IP', 'bot-eraser'); ?></button>
                        <button type="button" class="boteraser-snapshot-tab" data-snapshot-tab="malware" role="tab" aria-selected="false"><?php _e('Malware', 'bot-eraser'); ?></button>
                        <button type="button" class="boteraser-snapshot-tab" data-snapshot-tab="traffic" role="tab" aria-selected="false"><?php _e('Traffic', 'bot-eraser'); ?></button>
                    </div>
                </div>

                <div class="boteraser-snapshot-panel is-active" data-snapshot-panel="bot-ip" role="tabpanel">
                    <div class="boteraser-stats-grid boteraser-stats-grid-featured">
                        <div class="boteraser-stat-card boteraser-stat-card-link boteraser-stat-card-threat boteraser-stat-card-featured" data-tooltip="<?php _e('Current security threat level assessment', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-blocked-ips')); ?>">
                            <div class="boteraser-stat-icon <?php echo esc_attr($threat_level['level'] === 'high' ? 'danger' : ($threat_level['level'] === 'medium' ? 'warning' : 'success')); ?>">
                                <?php echo bot_eraser_icon($threat_level['level'] === 'high' ? 'alert-circle' : ($threat_level['level'] === 'medium' ? 'shield' : 'shield-check')); ?>
                            </div>
                            <div class="boteraser-stat-content">
                                <div class="boteraser-stat-header">
                                    <p class="boteraser-stat-value boteraser-threat-level-text <?php echo esc_attr($threat_level['level']); ?>">
                                        <?php echo strtoupper(esc_html($threat_level['level'])); ?>
                                    </p>
                                    <span class="boteraser-stat-help" data-tooltip="<?php _e('Calculated based on blocked IPs and recent activity', 'bot-eraser'); ?>">
                                        <?php echo bot_eraser_icon('help-circle'); ?>
                                    </span>
                                </div>
                                <p class="boteraser-stat-label"><?php _e('Threat Level', 'bot-eraser'); ?></p>
                                <div class="boteraser-threat-bar">
                                    <div class="boteraser-threat-bar-fill <?php echo esc_attr($threat_level['level']); ?>" style="width: <?php echo min($threat_level['score'], 100); ?>%;"></div>
                                </div>
                            </div>
                        </div>
                        <?php
                        $blocked_count      = $new_blocks_today['count'];
                        $blocked_icon_color = $blocked_count > BOTERASER_BLOCKED_MEDIUM ? 'danger' : ($blocked_count > BOTERASER_BLOCKED_LOW ? 'warning' : 'success');
                        $activity_count     = $recent_activity['count'];
                        $activity_icon_color = $activity_count > 500 ? 'danger' : ($activity_count >= 200 ? 'warning' : 'success');
                        $prot_rate          = number_format($protection_rate['rate'], 1);
                        $prot_icon_color    = $protection_rate['rate'] > 60 ? 'danger' : ($protection_rate['rate'] >= 30 ? 'warning' : 'success');
                        ?>
                        <div class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('IPs newly blocked today', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-blocked-ips')); ?>">
                            <div class="boteraser-stat-icon <?php echo esc_attr($blocked_icon_color); ?>"><?php echo bot_eraser_icon('ban'); ?></div>
                            <div class="boteraser-stat-content">
                                <div class="boteraser-stat-header">
                                    <p class="boteraser-stat-value"><?php echo number_format($blocked_count); ?></p>
                                    <span class="boteraser-stat-help" data-tooltip="<?php _e('IPs newly blocked today', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span>
                                </div>
                                <p class="boteraser-stat-label"><?php _e('New Blocks Today', 'bot-eraser'); ?></p>
                                <div class="boteraser-sparkline" data-metric="new_blocks_today"></div>
                            </div>
                        </div>
                        <div class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Requests detected in the last hour', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-logs')); ?>">
                            <div class="boteraser-stat-icon <?php echo esc_attr($activity_icon_color); ?>"><?php echo bot_eraser_icon('activity'); ?></div>
                            <div class="boteraser-stat-content">
                                <div class="boteraser-stat-header">
                                    <p class="boteraser-stat-value"><?php echo number_format($activity_count); ?></p>
                                    <span class="boteraser-stat-help" data-tooltip="<?php _e('Requests detected in the last hour', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span>
                                </div>
                                <p class="boteraser-stat-label"><?php _e('Last Hour', 'bot-eraser'); ?></p>
                                <div class="boteraser-sparkline" data-metric="recent_activity"></div>
                            </div>
                        </div>
                        <div class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Percentage of traffic blocked', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-blocked-ips')); ?>">
                            <div class="boteraser-stat-icon <?php echo esc_attr($prot_icon_color); ?>"><?php echo bot_eraser_icon('trending-up'); ?></div>
                            <div class="boteraser-stat-content">
                                <div class="boteraser-stat-header">
                                    <p class="boteraser-stat-value"><?php echo $prot_rate; ?>%</p>
                                    <span class="boteraser-stat-help" data-tooltip="<?php _e('Percentage of traffic blocked', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span>
                                </div>
                                <p class="boteraser-stat-label"><?php _e('Requests Blocked', 'bot-eraser'); ?></p>
                                <div class="boteraser-sparkline" data-metric="blocked_ips"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="boteraser-snapshot-panel" data-snapshot-panel="malware" role="tabpanel" hidden>
                    <div class="boteraser-stats-grid boteraser-stats-grid-featured">
                        <?php
                        $mscore = $last_scan_summary['score'] ?? null;
                        $mhigh  = $last_scan_summary['high'] ?? 0;
                        $mmed   = $last_scan_summary['medium'] ?? 0;
                        $mlow   = $last_scan_summary['low'] ?? 0;
                        ?>
                        <div class="boteraser-stat-card boteraser-stat-card-link boteraser-stat-card-featured" data-tooltip="<?php _e('Overall site health score from last scan. Higher is better.', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>">
                            <div class="boteraser-stat-icon <?php echo $mscore >= 75 ? 'success' : ($mscore >= 50 ? 'warning' : 'danger'); ?>"><?php echo bot_eraser_icon('shield-check'); ?></div>
                            <div class="boteraser-stat-content"><div class="boteraser-stat-header"><p class="boteraser-stat-value"><?php echo $mscore !== null ? esc_html($mscore) : '—'; ?></p><span class="boteraser-stat-help" data-tooltip="<?php _e('Overall site health score from last scan. Higher is better.', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span></div><p class="boteraser-stat-label"><?php _e('Health Score', 'bot-eraser'); ?></p><div class="boteraser-sparkline" data-metric="malware_score"></div></div>
                        </div>
                        <div class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('High severity malware findings', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>"><div class="boteraser-stat-icon danger"><?php echo bot_eraser_icon('alert-circle'); ?></div><div class="boteraser-stat-content"><div class="boteraser-stat-header"><p class="boteraser-stat-value"><?php echo number_format($mhigh); ?></p><span class="boteraser-stat-help" data-tooltip="<?php _e('High severity malware findings', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span></div><p class="boteraser-stat-label"><?php _e('HIGH', 'bot-eraser'); ?></p><div class="boteraser-sparkline" data-metric="malware_high"></div></div></div>
                        <div class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Medium severity malware findings', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>"><div class="boteraser-stat-icon warning"><?php echo bot_eraser_icon('alert-circle'); ?></div><div class="boteraser-stat-content"><div class="boteraser-stat-header"><p class="boteraser-stat-value"><?php echo number_format($mmed); ?></p><span class="boteraser-stat-help" data-tooltip="<?php _e('Medium severity malware findings', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span></div><p class="boteraser-stat-label"><?php _e('MEDIUM', 'bot-eraser'); ?></p><div class="boteraser-sparkline" data-metric="malware_medium"></div></div></div>
                        <div class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Low severity malware findings', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>"><div class="boteraser-stat-icon teal"><?php echo bot_eraser_icon('info'); ?></div><div class="boteraser-stat-content"><div class="boteraser-stat-header"><p class="boteraser-stat-value"><?php echo number_format($mlow); ?></p><span class="boteraser-stat-help" data-tooltip="<?php _e('Low severity malware findings', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span></div><p class="boteraser-stat-label"><?php _e('LOW', 'bot-eraser'); ?></p><div class="boteraser-sparkline" data-metric="malware_low"></div></div></div>
                    </div>
                </div>

                <div class="boteraser-snapshot-panel" data-snapshot-panel="traffic" role="tabpanel" hidden>
                    <div class="boteraser-stats-grid boteraser-stats-grid-featured">
                        <div class="boteraser-stat-card boteraser-stat-card-link boteraser-stat-card-featured" data-tooltip="<?php _e('Total requests recorded in the log', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-logs')); ?>"><div class="boteraser-stat-icon primary"><?php echo bot_eraser_icon('activity'); ?></div><div class="boteraser-stat-content"><div class="boteraser-stat-header"><p class="boteraser-stat-value"><?php echo number_format($stats['total_requests']); ?></p><span class="boteraser-stat-help" data-tooltip="<?php _e('Total requests recorded in the log', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span></div><p class="boteraser-stat-label"><?php _e('Total Requests', 'bot-eraser'); ?></p><div class="boteraser-sparkline" data-metric="total_requests"></div></div></div>
                        <div class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Number of distinct IP addresses seen', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-logs')); ?>"><div class="boteraser-stat-icon teal"><?php echo bot_eraser_icon('users'); ?></div><div class="boteraser-stat-content"><div class="boteraser-stat-header"><p class="boteraser-stat-value"><?php echo number_format($stats['unique_ips']); ?></p><span class="boteraser-stat-help" data-tooltip="<?php _e('Number of distinct IP addresses seen', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span></div><p class="boteraser-stat-label"><?php _e('Unique IPs', 'bot-eraser'); ?></p><div class="boteraser-sparkline" data-metric="unique_ips"></div></div></div>
                        <div class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Percentage of total traffic that was blocked', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-logs')); ?>"><div class="boteraser-stat-icon <?php echo $protection_rate['rate'] > 50 ? 'danger' : 'teal'; ?>"><?php echo bot_eraser_icon('shield-off'); ?></div><div class="boteraser-stat-content"><div class="boteraser-stat-header"><p class="boteraser-stat-value"><?php echo number_format($protection_rate['rate'], 1); ?>%</p><span class="boteraser-stat-help" data-tooltip="<?php _e('Percentage of total traffic that was blocked', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span></div><p class="boteraser-stat-label"><?php _e('Blocked Traffic', 'bot-eraser'); ?></p><div class="boteraser-sparkline" data-metric="blocked_ips"></div></div></div>
                        <div class="boteraser-stat-card boteraser-stat-card-link" data-tooltip="<?php _e('Total number of blocked requests', 'bot-eraser'); ?>" data-href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-blocked-ips')); ?>"><div class="boteraser-stat-icon crimson"><?php echo bot_eraser_icon('ban'); ?></div><div class="boteraser-stat-content"><div class="boteraser-stat-header"><p class="boteraser-stat-value"><?php echo number_format($protection_rate['blocked']); ?></p><span class="boteraser-stat-help" data-tooltip="<?php _e('Total number of blocked requests', 'bot-eraser'); ?>"><?php echo bot_eraser_icon('help-circle'); ?></span></div><p class="boteraser-stat-label"><?php _e('Blocked Requests', 'bot-eraser'); ?></p><div class="boteraser-sparkline" data-metric="blocked_ips"></div></div></div>
                    </div>
                </div>
            </div>
    </section>

            <!-- Live Traffic -->
            <div class="boteraser-card be-live-bar-card be-dash-live-card">
                <div class="boteraser-card-header">
                    <h2 class="boteraser-card-title"><?php echo bot_eraser_icon('activity'); ?> <?php _e('Live Traffic', 'bot-eraser'); ?></h2>
                    <div class="be-live-bar-actions">
                        <span id="be-live-status-dash" class="be-live-status offline">● <?php _e('Offline', 'bot-eraser'); ?></span>
                        <button type="button" id="be-live-toggle-dash" class="boteraser-btn boteraser-btn-primary boteraser-btn-sm"><?php echo bot_eraser_icon('play'); ?> <?php _e('Go Live', 'bot-eraser'); ?></button>
                    </div>
                </div>
                <canvas id="be-live-canvas-dash" width="880" height="80" class="be-live-canvas"></canvas>
                <div class="be-live-legend">
                    <span><span class="be-live-legend-dot be-live-legend-dot--ok"></span> OK (200)</span>
                                        <span><span class="be-live-legend-dot be-live-legend-dot--err"></span> Errors 4xx/5xx</span>
                                        <span><span class="be-live-legend-dot be-live-legend-dot--idle"></span> Idle</span>
                </div>
                <div id="be-live-latest-dash" class="be-live-latest"></div>
            </div>
            <?php wp_localize_script('boteraser-admin', 'boteraser_live_dash', array(
                'ajaxUrl'      => admin_url('admin-ajax.php'),
                'nonce'        => wp_create_nonce('boteraser_live_traffic'),
                'iconPlay'     => bot_eraser_icon('play'),
                'iconPause'    => bot_eraser_icon('pause'),
                'lblGoLive'    => __('Go Live', 'bot-eraser'),
                'lblPause'     => __('Pause', 'bot-eraser'),
                'lblLive'      => __('Live', 'bot-eraser'),
                'lblOffline'   => __('Offline', 'bot-eraser'),
                'labelPrefix'  => '● ',
            )); ?>

             <!-- API + Quick Actions Row -->
             <div class="boteraser-content-wrapper">
                 <div class="boteraser-left-column">
                     <div class="boteraser-card boteraser-api-section boteraser-api-section-full">
                         <div class="boteraser-card-header"><h2 class="boteraser-card-title"><?php echo bot_eraser_icon('key'); ?> <?php _e('API Configuration', 'bot-eraser'); ?></h2></div>
                         <form method="post"><?php wp_nonce_field('bot_eraser_settings', 'bot_eraser_settings_nonce'); ?>
                             <div class="boteraser-api-input-wrapper">
                                 <span class="boteraser-api-icon"><?php echo bot_eraser_icon('key'); ?></span>
                                 <input type="password" name="api_key" id="boteraser-api-key"
                                     class="boteraser-api-input <?php echo !empty($validation_state['is_valid']) ? 'valid' : (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid'] ? 'invalid' : ''); ?>"
                                     value="<?php echo esc_attr($form_api_key); ?>"
                                     placeholder="<?php _e('Enter your API key...', 'bot-eraser'); ?>"
                                     autocomplete="new-password"
                                     <?php echo !$privacy_accepted ? 'disabled' : ''; ?>>
                                 <span class="boteraser-api-status-icon success"><?php echo bot_eraser_icon('check-circle'); ?></span>
                                 <span class="boteraser-api-status-icon error"><?php echo bot_eraser_icon('x-circle'); ?></span>
                                 <span class="boteraser-api-status-icon loading"><?php echo bot_eraser_icon('loader'); ?></span>
                             </div>
                             <?php
                             $indicator_class = '';
                             $indicator_icon  = '';
                             $indicator_text  = '';
                             if (!empty($validation_state['is_valid'])) {
                                 $indicator_class = 'valid visible';
                                 $indicator_icon  = bot_eraser_icon('shield-check');
                                 $indicator_text  = __('Connected', 'bot-eraser');
                             } elseif (!empty($form_api_key) && isset($validation_state['is_valid']) && !$validation_state['is_valid']) {
                                 $indicator_class = 'invalid visible';
                                 $indicator_icon  = bot_eraser_icon('shield-off');
                                 $indicator_text  = __('Not Connected', 'bot-eraser');
                             }
                             ?>
                             <?php if ($indicator_class): ?>
                             <div class="boteraser-status-indicator <?php echo esc_attr($indicator_class); ?>">
                                 <span class="boteraser-status-icon-svg"><?php echo $indicator_icon; ?></span>
                                 <span class="boteraser-status-text"><?php echo $indicator_text; ?></span>
                             </div>
                             <?php endif; ?>
                             <div class="boteraser-api-actions-row">
                                 <button type="submit" class="boteraser-btn boteraser-btn-primary" <?php echo !$privacy_accepted ? 'disabled' : ''; ?>><?php echo bot_eraser_icon('check'); ?> <?php _e('Save', 'bot-eraser'); ?></button>
                                 <?php if (!empty($form_api_key)): ?>
                                 <button type="submit" name="bot_eraser_remove_api_key" value="1" class="boteraser-btn boteraser-btn-secondary"
                                     onclick="return confirm('<?php esc_attr_e('Remove API key and disconnect?', 'bot-eraser'); ?>');">
                                     <?php echo bot_eraser_icon('x'); ?> <?php _e('Disconnect', 'bot-eraser'); ?>
                                 </button>
                                 <?php endif; ?>
                             </div>
                             <p class="boteraser-api-description"><?php echo bot_eraser_icon('info'); ?> <?php _e('Get your API key from the', 'bot-eraser'); ?> <a href="https://user.boteraser.com/api.php" target="_blank"><?php _e('Boteraser Dashboard', 'bot-eraser'); ?> <?php echo bot_eraser_icon('external-link'); ?></a></p>
                         </form>
                     </div>
                 </div>
                 <div class="boteraser-info-panel">
                     <div class="boteraser-info-card boteraser-info-card-featured">
                         <span class="boteraser-info-card-eyebrow"><?php _e('Navigation', 'bot-eraser'); ?></span>
                         <h3><?php echo bot_eraser_icon('zap'); ?> <?php _e('Quick Actions', 'bot-eraser'); ?></h3>
                         <div class="boteraser-quick-actions">
                             <a href="<?php echo admin_url('admin.php?page=bot-eraser-logs'); ?>" class="boteraser-quick-action"><?php echo bot_eraser_icon('file-text'); ?><span class="boteraser-quick-action-copy"><strong><?php _e('View Logs', 'bot-eraser'); ?></strong><small><?php _e('Inspect recent request activity.', 'bot-eraser'); ?></small></span></a>
                             <a href="<?php echo admin_url('admin.php?page=bot-eraser-blocked-ips'); ?>" class="boteraser-quick-action"><?php echo bot_eraser_icon('shield-x'); ?><span class="boteraser-quick-action-copy"><strong><?php _e('Blocked IPs', 'bot-eraser'); ?></strong><small><?php _e('Review active blocks.', 'bot-eraser'); ?></small></span></a>
                             <a href="<?php echo admin_url('admin.php?page=bot-eraser-scanner'); ?>" class="boteraser-quick-action"><?php echo bot_eraser_icon('scan'); ?><span class="boteraser-quick-action-copy"><strong><?php _e('Security Scan', 'bot-eraser'); ?></strong><small><?php _e('Run malware scan.', 'bot-eraser'); ?></small></span></a>
                             <a href="<?php echo admin_url('admin.php?page=bot-eraser-vulnerabilities'); ?>" class="boteraser-quick-action"><?php echo bot_eraser_icon('shield-x'); ?><span class="boteraser-quick-action-copy"><strong><?php _e('Vulnerabilities', 'bot-eraser'); ?></strong><small><?php _e('Review known vulnerabilities.', 'bot-eraser'); ?></small></span></a>
                             <a href="https://user.boteraser.com/" target="_blank" class="boteraser-quick-action"><?php echo bot_eraser_icon('external-link'); ?><span class="boteraser-quick-action-copy"><strong><?php _e('Boteraser Portal', 'bot-eraser'); ?></strong><small><?php _e('Cloud dashboard.', 'bot-eraser'); ?></small></span></a>
                         </div>
                     </div>
                 </div>
             </div>

             <!-- Known Vulnerabilities + System Software -->
             <div class="be-bf-sys-grid">
                 <?php $vsum = bot_eraser_vuln_get_summary(); ?>
                 <div class="boteraser-card be-vuln-card">
                     <div class="boteraser-card-header"><h2 class="boteraser-card-title"><?php echo bot_eraser_icon('shield-x'); ?> <?php _e('Known Vulnerabilities', 'bot-eraser'); ?></h2></div>
                     <?php if ($vsum['total'] > 0): ?>
                     <div class="be-vuln-summary-grid">
                         <div class="be-vuln-summary-item critical"><span class="be-vuln-summary-count"><?php echo $vsum['critical']; ?></span><span class="be-vuln-summary-label"><?php _e('Critical', 'bot-eraser'); ?></span></div>
                         <div class="be-vuln-summary-item warning"><span class="be-vuln-summary-count"><?php echo $vsum['warning']; ?></span><span class="be-vuln-summary-label"><?php _e('Warning', 'bot-eraser'); ?></span></div>
                         <div class="be-vuln-summary-item info"><span class="be-vuln-summary-count"><?php echo $vsum['info']; ?></span><span class="be-vuln-summary-label"><?php _e('Info', 'bot-eraser'); ?></span></div>
                     </div>
                     <?php if ($vsum['checked_at']): ?><p class="boteraser-text-muted"><?php printf(__('Last checked: %s ago', 'bot-eraser'), human_time_diff($vsum['checked_at'])); ?></p><?php endif; ?>
                     <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-vulnerabilities')); ?>" class="boteraser-btn boteraser-btn-primary boteraser-btn-sm"><?php _e('View All', 'bot-eraser'); ?></a>
                     <?php else: ?><p class="boteraser-empty-copy"><?php _e('No vulnerabilities found.', 'bot-eraser'); ?></p><?php endif; ?>
                 </div>
                 <?php
                 $sys_ws_raw = get_option('boteraser_sys_webserver', '');
                 $sys_ws_parts = $sys_ws_raw ? explode('/', $sys_ws_raw, 2) : array();
                 $sys_ws_display = $sys_ws_raw ? ucfirst($sys_ws_parts[0]) . (!empty($sys_ws_parts[1]) ? ' ' . $sys_ws_parts[1] : '') : '—';
                 ?>
                 <div class="boteraser-card be-sys-card">
                     <div class="boteraser-card-header"><h2 class="boteraser-card-title"><?php echo bot_eraser_icon('server'); ?> <?php _e('System Software', 'bot-eraser'); ?></h2><button type="button" id="be-sys-refresh-btn" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm"><?php echo bot_eraser_icon('refresh-cw'); ?> <?php _e('Refresh', 'bot-eraser'); ?></button></div>
                     <div class="boteraser-sys-grid">
                         <div class="boteraser-sys-readonly"><span class="boteraser-sys-label"><?php _e('Web Server', 'bot-eraser'); ?></span><span class="boteraser-sys-value" id="be-sys-web"><?php echo esc_html($sys_ws_display); ?></span></div>
                         <div class="boteraser-sys-readonly"><span class="boteraser-sys-label">PHP</span><span class="boteraser-sys-value" id="be-sys-php"><?php echo esc_html(get_option('boteraser_sys_php', '') ?: '—'); ?></span></div>
                         <div class="boteraser-sys-readonly"><span class="boteraser-sys-label">OpenSSH</span><span class="boteraser-sys-value" id="be-sys-openssh"><?php echo esc_html(get_option('boteraser_sys_openssh', '') ?: '—'); ?></span></div>
                         <div class="boteraser-sys-readonly"><span class="boteraser-sys-label"><?php _e('OS', 'bot-eraser'); ?></span><span class="boteraser-sys-value" id="be-sys-linux"><?php echo esc_html(get_option('boteraser_sys_os', '') ?: '—'); ?></span></div>
                     </div>
                 </div>

                 <?php
                 $ip_source     = get_option('bot_eraser_ip_source', 'remote_addr');
                 $ip_detected   = function_exists('bot_eraser_get_visitor_ip') ? bot_eraser_get_visitor_ip() : '';
                 $ip_source_opts = array(
                     'remote_addr'     => __('Direct connection (REMOTE_ADDR) — recommended', 'bot-eraser'),
                     'cloudflare'      => __('Behind Cloudflare (CF-Connecting-IP)', 'bot-eraser'),
                     'x_forwarded_for' => __('Behind proxy (X-Forwarded-For)', 'bot-eraser'),
                     'x_real_ip'       => __('Behind proxy (X-Real-IP)', 'bot-eraser'),
                 );
                 ?>
                 <div class="boteraser-card be-sys-card" id="be-ipsrc-card">
                     <div class="boteraser-card-header"><h2 class="boteraser-card-title"><?php echo bot_eraser_icon('globe'); ?> <?php _e('Visitor IP Detection', 'bot-eraser'); ?></h2></div>
                     <p class="boteraser-card-intro" style="margin:0 0 10px;font-size:13px;color:#6b7280;">
                         <?php _e('How BotEraser reads the real visitor IP behind proxies/CDNs. This affects rate limiting, IP blocking and bot detection across the whole plugin.', 'bot-eraser'); ?>
                     </p>
                     <div class="be-bf-setting-field" style="max-width:360px;">
                         <label for="be-ipsrc-select"><?php _e('IP source', 'bot-eraser'); ?></label>
                         <select id="be-ipsrc-select" class="be-bf-input" data-nonce="<?php echo esc_attr(wp_create_nonce('boteraser_ajax')); ?>">
                             <?php foreach ($ip_source_opts as $val => $label) {
                                 printf('<option value="%s" %s>%s</option>', esc_attr($val), selected($ip_source, $val, false), esc_html($label));
                             } ?>
                         </select>
                     </div>
                     <div class="boteraser-sys-readonly" style="margin-top:10px;">
                         <span class="boteraser-sys-label"><?php _e('Detected now', 'bot-eraser'); ?></span>
                         <span class="boteraser-sys-value" id="be-ipsrc-detected"><?php echo esc_html($ip_detected ?: '—'); ?></span>
                     </div>
                     <p style="margin:8px 0 0;font-size:12px;color:#6b7280;">
                         <?php _e('Default uses the direct connection IP, which cannot be spoofed. Select a header only if this site sits behind Cloudflare or another reverse proxy/CDN.', 'bot-eraser'); ?>
                         <span id="be-ipsrc-status" class="be-bf-save-status"></span>
                     </p>
                 </div>
                <?php
                $bf_enabled    = bot_eraser_bf_is_enabled();
                $bf_data       = bot_eraser_bf_cleanup(bot_eraser_bf_load_data());
                $bf_max_att    = bot_eraser_bf_max_attempts();
                $bf_window_min = bot_eraser_bf_window_minutes();
                $bf_block_min  = bot_eraser_bf_block_minutes();
                $bf_flagged    = count($bf_data);
                $bf_blocked    = count(array_filter($bf_data, function($e) use ($bf_max_att) {
                    return $e['count'] >= $bf_max_att;
                }));
                ?>
                <div class="boteraser-card be-bf-card" id="be-bf-dash-card">
                    <div class="boteraser-card-header">
                        <h2 class="boteraser-card-title"><?php echo bot_eraser_icon('lock'); ?> <?php _e('Brute Force Monitor', 'bot-eraser'); ?></h2>
                        <label class="boteraser-toggle-label">
                            <input type="checkbox" id="be-bf-toggle" <?php checked($bf_enabled); ?>>
                            <span class="boteraser-toggle-slider"></span>
                            <span class="boteraser-toggle-text"><?php echo $bf_enabled ? esc_html__('Enabled', 'bot-eraser') : esc_html__('Disabled', 'bot-eraser'); ?></span>
                        </label>
                    </div>
                    <p class="boteraser-card-intro">
                        <?php printf(
                            __('After %1$d failed logins within %2$d minutes, the IP is locked out for %3$s. Confirmed bots are also fingerprinted in the cloud for global blocking.', 'bot-eraser'),
                            $bf_max_att,
                            $bf_window_min,
                            $bf_block_min >= 60
                                ? sprintf(_n('%d hour', '%d hours', $bf_block_min / 60, 'bot-eraser'), $bf_block_min / 60)
                                : sprintf(_n('%d minute', '%d minutes', $bf_block_min, 'bot-eraser'), $bf_block_min)
                        ); ?>
                    </p>
                    <div class="be-bf-summary-grid">
                        <div class="be-bf-summary-item"><span class="be-bf-summary-count"><?php echo $bf_flagged; ?></span><span class="be-bf-summary-label"><?php _e('Tracked IPs', 'bot-eraser'); ?></span></div>
                        <div class="be-bf-summary-item blocked"><span class="be-bf-summary-count"><?php echo $bf_blocked; ?></span><span class="be-bf-summary-label"><?php _e('Blocked', 'bot-eraser'); ?></span></div>
                    </div>
                    <div class="be-bf-settings" id="be-bf-settings" <?php echo $bf_enabled ? '' : 'style="display:none;"'; ?>>
                        <div class="be-bf-settings-row">
                            <div class="be-bf-setting-field">
                                <label for="be-bf-max-attempts"><?php _e('Max attempts', 'bot-eraser'); ?></label>
                                <input type="number" id="be-bf-max-attempts" value="<?php echo (int) $bf_max_att; ?>" min="1" max="50" class="be-bf-input">
                            </div>
                            <div class="be-bf-setting-field">
                                <label for="be-bf-window-minutes"><?php _e('Time window (minutes)', 'bot-eraser'); ?></label>
                                <select id="be-bf-window-minutes" class="be-bf-input">
                                    <?php
                                    $bf_window_options = array(1, 5, 10, 15, 30, 60, 120, 360, 720, 1440);
                                    foreach ($bf_window_options as $option) {
                                        $label = $option . ' ' . __('min', 'bot-eraser');
                                        if ($option >= 60) {
                                            $hours = $option / 60;
                                            /* translators: %d: number of hours */
                                            $label = sprintf(_n('%d hour', '%d hours', $hours, 'bot-eraser'), $hours);
                                        }
                                        printf(
                                            '<option value="%d" %s>%s</option>',
                                            $option,
                                            selected($bf_window_min, $option, false),
                                            $label
                                        );
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="be-bf-setting-field">
                                <label for="be-bf-block-minutes"><?php _e('Block time', 'bot-eraser'); ?></label>
                                <select id="be-bf-block-minutes" class="be-bf-input">
                                    <?php
                                    $bf_block_options = array(5, 10, 15, 30, 60, 120, 240, 360, 1440);
                                    foreach ($bf_block_options as $option) {
                                        $label = $option . ' ' . __('min', 'bot-eraser');
                                        if ($option >= 60) {
                                            $hours = $option / 60;
                                            /* translators: %d: number of hours */
                                            $label = sprintf(_n('%d hour', '%d hours', $hours, 'bot-eraser'), $hours);
                                        }
                                        printf(
                                            '<option value="%d" %s>%s</option>',
                                            $option,
                                            selected($bf_block_min, $option, false),
                                            $label
                                        );
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="be-bf-setting-field be-bf-setting-actions">
                                <button type="button" id="be-bf-save-settings" class="boteraser-btn boteraser-btn-primary boteraser-btn-sm"><?php _e('Save', 'bot-eraser'); ?></button>
                                <span id="be-bf-save-status" class="be-bf-save-status"></span>
                            </div>
                        </div>
                    </div>
                </div>
             </div>

             <!-- WAF Ruleset + Notification Emails -->
             <div class="be-bf-sys-grid">
                 <?php
                 $waf_count  = (int) get_option('bot_eraser_waf_count', 0);
                 $waf_synced = (int) get_option('bot_eraser_waf_synced', 0);
                 $waf_synced_label = $waf_synced > 0
                     ? sprintf(__('%s ago', 'bot-eraser'), human_time_diff($waf_synced))
                     : __('never', 'bot-eraser');
                 ?>
                 <div class="boteraser-card be-sys-card" id="be-waf-card">
                     <div class="boteraser-card-header">
                         <h2 class="boteraser-card-title"><?php echo bot_eraser_icon('shield'); ?> <?php _e('WAF Ruleset', 'bot-eraser'); ?></h2>
                         <button type="button" id="be-waf-sync-btn" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm" data-nonce="<?php echo esc_attr(wp_create_nonce('boteraser_ajax')); ?>"><?php echo bot_eraser_icon('refresh-cw'); ?> <?php _e('Sync now', 'bot-eraser'); ?></button>
                     </div>
                     <p class="boteraser-card-intro">
                         <?php printf(
                             __('WAF rules: %1$s, last sync: %2$s', 'bot-eraser'),
                             '<strong id="be-waf-count">' . esc_html(number_format_i18n($waf_count)) . '</strong>',
                             '<span id="be-waf-synced">' . esc_html($waf_synced_label) . '</span>'
                         ); ?>
                         <span id="be-waf-sync-status" class="be-bf-save-status"></span>
                     </p>
                 </div>
                 <div class="boteraser-card be-sys-card">
                     <div class="boteraser-card-header"><h2 class="boteraser-card-title"><?php echo bot_eraser_icon('mail'); ?> <?php _e('Notification Emails', 'bot-eraser'); ?></h2></div>
                     <?php if ($notify_enabled): ?>
                     <p class="boteraser-card-intro" style="margin:0 0 8px;font-size:13px;color:#6b7280;"><?php esc_html_e('Scan summaries and malware alerts are sent to:', 'bot-eraser'); ?></p>
                     <div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:10px 14px;font-size:13px;color:#1e293b;word-break:break-all;"><?php echo esc_html($notify_email); ?></div>
                     <?php else: ?>
                     <p class="boteraser-empty-copy"><?php _e('Email notifications are currently disabled.', 'bot-eraser'); ?></p>
                     <?php endif; ?>
                     <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm" style="margin-top:8px;"><?php _e('Manage', 'bot-eraser'); ?></a>
                 </div>
             </div>

            <!-- Threat Lists (locally cached, auto-synced hourly) -->
            <div class="be-bf-sys-grid">
                <div class="boteraser-card be-sys-card" id="be-lists-card">
                    <div class="boteraser-card-header">
                        <h2 class="boteraser-card-title"><?php echo bot_eraser_icon('file-text'); ?> <?php _e('Threat Lists', 'bot-eraser'); ?></h2>
                        <button type="button" id="be-list-sync-btn" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm" data-nonce="<?php echo esc_attr(wp_create_nonce('boteraser_ajax')); ?>"><?php echo bot_eraser_icon('refresh-cw'); ?> <?php _e('Sync now', 'bot-eraser'); ?></button>
                    </div>
                    <p class="boteraser-card-intro" style="margin:0 0 8px;font-size:13px;color:#6b7280;">
                        <?php esc_html_e('Blocklists pulled from the server hourly and matched against every visitor locally.', 'bot-eraser'); ?>
                        <span id="be-list-sync-status" class="be-bf-save-status"></span>
                    </p>
                    <?php
                    $be_list_labels = array(
                        'blacklist_ips'     => __('Blacklisted IPs', 'bot-eraser'),
                        'blacklist_bots'    => __('Blacklisted bots', 'bot-eraser'),
                        'blacklist'         => __('Blacklist', 'bot-eraser'),
                        'rate_limited_bots' => __('Rate-limited bots', 'bot-eraser'),
                        'greylist'          => __('Greylist', 'bot-eraser'),
                        'whitelist'         => __('Whitelist', 'bot-eraser'),
                    );
                    ?>
                    <div class="boteraser-sys-grid">
                        <?php foreach ($be_list_labels as $be_list_key => $be_list_label):
                            $be_list_count  = (int) get_option('bot_eraser_list_count_' . $be_list_key, 0);
                            $be_list_synced = (int) get_option('bot_eraser_list_synced_' . $be_list_key, 0);
                            $be_list_when   = $be_list_synced > 0
                                ? sprintf(__('%s ago', 'bot-eraser'), human_time_diff($be_list_synced))
                                : __('never', 'bot-eraser');
                        ?>
                        <div class="boteraser-sys-readonly">
                            <span class="boteraser-sys-label"><?php echo esc_html($be_list_label); ?></span>
                            <span class="boteraser-sys-value"><span id="be-list-count-<?php echo esc_attr($be_list_key); ?>"><?php echo esc_html(number_format_i18n($be_list_count)); ?></span> <span style="color:#9ca3af;font-weight:normal;">· <span id="be-list-when-<?php echo esc_attr($be_list_key); ?>"><?php echo esc_html($be_list_when); ?></span></span></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php
                $be_map        = bot_eraser_get_map();
                $be_country    = is_array($be_map) && isset($be_map['country']) ? $be_map['country'] : array();
                $be_country_on = !empty($be_country['enabled']);
                $be_country_n  = (int) ($be_country['count'] ?? 0);
                ?>
                <div class="boteraser-card be-sys-card" id="be-country-card">
                    <div class="boteraser-card-header">
                        <h2 class="boteraser-card-title"><?php echo bot_eraser_icon('globe'); ?> <?php _e('Country Blocking', 'bot-eraser'); ?></h2>
                    </div>
                    <p class="boteraser-card-intro" style="margin:0 0 8px;font-size:13px;color:#6b7280;">
                        <?php esc_html_e('Comparison runs on the server (the geo list is never downloaded). Visitor IPs are checked every 5 minutes.', 'bot-eraser'); ?>
                    </p>
                    <div class="boteraser-sys-grid">
                        <div class="boteraser-sys-readonly">
                            <span class="boteraser-sys-label"><?php _e('Blocked countries', 'bot-eraser'); ?></span>
                            <span class="boteraser-sys-value" id="be-country-val"><?php echo $be_country_on ? esc_html(number_format_i18n($be_country_n)) : esc_html__('Off', 'bot-eraser'); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Manual Execution -->
                    <div class="boteraser-card boteraser-execution-card">
                        <div class="boteraser-card-header">
                            <h2 class="boteraser-card-title">
                                <?php echo bot_eraser_icon('zap'); ?>
                                <?php _e('Manual Execution', 'bot-eraser'); ?>
                            </h2>
                        </div>

                        <div class="boteraser-execution-hero">
                            <div class="boteraser-execution-copy">
                                <span class="boteraser-execution-eyebrow"><?php _e('On-Demand Security Sync', 'bot-eraser'); ?></span>
                                <p class="boteraser-execution-intro"><?php _e('Trigger a manual protection cycle when you want to push local telemetry, verify the cloud response and review the latest processing payload.', 'bot-eraser'); ?></p>
                                <div class="boteraser-execution-pills">
                                    <span class="boteraser-execution-pill"><?php _e('Cloud handoff', 'bot-eraser'); ?></span>
                                    <span class="boteraser-execution-pill"><?php _e('Local payload review', 'bot-eraser'); ?></span>
                                    <span class="boteraser-execution-pill"><?php _e('Operator initiated', 'bot-eraser'); ?></span>
                                </div>
                            </div>

                            <div class="boteraser-execution-actions">
                                <button type="button" id="be-manual-run-btn"
                                        class="boteraser-btn boteraser-btn-success boteraser-btn-lg"
                                        data-nonce="<?php echo esc_attr(wp_create_nonce('bot_eraser_manual_run')); ?>"
                                        <?php echo !$privacy_accepted ? 'disabled' : ''; ?>>
                                    <?php echo bot_eraser_icon('play'); ?>
                                    <?php _e('Run Boteraser Now', 'bot-eraser'); ?>
                                </button>

                                <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-logs')); ?>" class="boteraser-btn boteraser-btn-secondary">
                                    <?php echo bot_eraser_icon('file-text'); ?>
                                    <?php _e('Review Latest Logs', 'bot-eraser'); ?>
                                </a>
                            </div>
                        </div>

                        <?php
                        $last_manual_run = get_option('bot_eraser_last_manual_run', 0);
                        if ($last_manual_run > 0):
                            $time_ago = human_time_diff($last_manual_run, time());
                        ?>
                        <div class="boteraser-last-run-info">
                            <?php echo bot_eraser_icon('clock'); ?>
                            <span><?php printf(__('Last run: %s ago', 'bot-eraser'), $time_ago); ?></span>
                        </div>
                        <?php endif; ?>

                        <div class="boteraser-progress-bar boteraser-execution-progress">
                            <div class="boteraser-progress-bar-fill"></div>
                        </div>

                        <?php
                        $data = $manual_execution_data ?: get_transient('bot_eraser_process_data');
                        if ($data):
                            $status_class = ($data['status'] === 'success') ? 'success' : 'error';
                            $message = $data['message'] ?? '';
                            if ($status_class === 'success'):
                        ?>
                        <div class="boteraser-results <?php echo esc_attr($status_class); ?>">
                            <div class="boteraser-results-header">
                                <h3>
                                    <?php echo bot_eraser_icon('check-circle'); ?>
                                    <?php _e('Execution Results', 'bot-eraser'); ?>
                                </h3>
                                <span class="boteraser-results-time"><?php echo date('M j, Y H:i:s'); ?></span>
                            </div>

                            <div class="boteraser-results-grid">
                                <div class="boteraser-result-card">
                                    <h4><?php echo bot_eraser_icon('server'); ?> <?php _e('Server Metrics', 'bot-eraser'); ?></h4>
                                    <div class="metrics-box">
                                        <div class="metric">
                                            <label><?php echo bot_eraser_icon('activity'); ?> <?php _e('Load', 'bot-eraser'); ?></label>
                                            <div class="value"><?php echo esc_html($data['sent_data']['srv_load'] ?? 'N/A'); ?></div>
                                        </div>
                                        <div class="metric">
                                            <label><?php echo bot_eraser_icon('clock'); ?> <?php _e('Uptime', 'bot-eraser'); ?></label>
                                            <div class="value"><?php echo esc_html(bot_eraser_format_uptime($data['sent_data']['uptime'] ?? null)); ?></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="boteraser-result-card">
                                    <h4><?php echo bot_eraser_icon('database'); ?> <?php _e('Data Payload', 'bot-eraser'); ?></h4>
                                    <pre><?php
                                        if (!empty($data['sent_data']['data'])) {
                                            echo esc_html(trim($data['sent_data']['data']));
                                        } else {
                                            _e('No data generated', 'bot-eraser');
                                        }
                                    ?></pre>
                                </div>

                                <div class="boteraser-result-card">
                                    <h4><?php echo bot_eraser_icon('cloud'); ?> <?php _e('Server Response', 'bot-eraser'); ?></h4>
                                    <pre><?php echo esc_html($data['response'] ?? __('No response received', 'bot-eraser')); ?></pre>
                                </div>
                            </div>

                            <div class="boteraser-results-footer">
                                <span class="boteraser-status-badge success">
                                    <?php echo bot_eraser_icon('check-circle'); ?>
                                    <?php _e('SUCCESS', 'bot-eraser'); ?>
                                </span>
                                <span class="boteraser-execution-message">
                                    <?php echo esc_html($message ?: __('No execution log', 'bot-eraser')); ?>
                                </span>
                            </div>
                        </div>
                        <?php
                            endif;
                            if (!$manual_execution_data && get_transient('bot_eraser_process_data')) {
                                delete_transient('bot_eraser_process_data');
                            }
                        endif;
                        ?>
                    </div>

            <!-- Cards grid - full width -->
            <?php
            $last_scan = boteraser_get_last_scan();
            $scan_summary = $last_scan['summary'] ?? null;
            $_dash_validation_state = get_option('bot_eraser_api_validation_state', array());
            $_dash_premium_enabled  = !empty($_dash_validation_state['is_valid']);
            ?>
            <div class="boteraser-inline-cards boteraser-inline-cards-3col">
                    <div class="boteraser-info-card be-scan-widget">
                        <span class="boteraser-info-card-eyebrow"><?php _e('Security Scanner', 'bot-eraser'); ?></span>
                        <h3>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                            <?php _e('Security Scan', 'bot-eraser'); ?>
                            <?php if ($_dash_premium_enabled): ?>
                                <span class="be-scan-mode-badge be-scan-mode-enhanced"><?php _e('LOCAL + CLOUD', 'bot-eraser'); ?></span>
                            <?php else: ?>
                                <span class="be-scan-mode-badge be-scan-mode-local"><?php _e('LOCAL', 'bot-eraser'); ?></span>
                            <?php endif; ?>
                        </h3>
                        <?php if ($_dash_premium_enabled): ?>
                        <p class="boteraser-info-card-intro"><?php _e('Scan combines local integrity checks with remote threat intelligence from the cloud.', 'bot-eraser'); ?></p>
                        <?php else: ?>
                        <p class="boteraser-info-card-intro"><?php _e('Run a local integrity scan from the sidebar when you want a quick malware and checksum review.', 'bot-eraser'); ?></p>
                        <?php endif; ?>

                        <?php if ($scan_summary): ?>
                        <div class="be-scan-score-wrap">
                            <div class="be-scan-score-circle be-score-<?php echo $scan_summary['score'] >= 75 ? 'good' : ($scan_summary['score'] >= 50 ? 'medium' : 'bad'); ?>">
                                <span class="be-scan-score-number"><?php echo $scan_summary['score']; ?></span>
                                <span class="be-scan-score-label">/ 100</span>
                            </div>
                            <div class="be-scan-score-info">
                                <div class="be-scan-grade"><?php echo esc_html($scan_summary['grade']); ?></div>
                                <div class="be-scan-meta">
                                    <?php if ($last_scan['completed_at']): ?>
                                    <span><?php echo human_time_diff($last_scan['completed_at']); ?> ago</span>
                                    <?php endif; ?>
                                </div>
                                <div class="be-scan-counts">
                                    <span class="be-scan-count high"><?php echo $scan_summary['high']; ?> HIGH</span>
                                    <span class="be-scan-count medium"><?php echo $scan_summary['medium']; ?> MED</span>
                                    <span class="be-scan-count low"><?php echo $scan_summary['low']; ?> LOW</span>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <p class="boteraser-empty-copy"><?php _e('No scan has been run yet.', 'bot-eraser'); ?></p>
                        <?php endif; ?>

                        <div class="be-scan-controls">
                            <button type="button" id="be-scan-start-btn" class="boteraser-btn boteraser-btn-primary boteraser-btn-sm">
                                <svg id="be-scan-toggle-icon-play" class="be-btn-icon-sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                                <svg id="be-scan-toggle-icon-stop" class="be-btn-icon-sm be-hidden" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="14" height="14"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>
                                <span id="be-scan-toggle-label"><?php _e('Run Scan', 'bot-eraser'); ?></span>
                            </button>
                            <button type="button" id="be-scan-stop-btn" class="be-hidden"></button>
                            <button type="button" id="be-baseline-save-widget" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm">
                                <svg class="be-btn-icon-sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                <?php _e('Save Baseline', 'bot-eraser'); ?>
                            </button>
                        </div>

                        <div id="be-scan-progress-wrap" class="be-scan-progress-wrap be-hidden">
                            <div class="boteraser-progress-bar active">
                                <div class="boteraser-progress-bar-fill be-progress-bar-fill-static" id="be-scan-progress-fill"></div>
                            </div>
                            <div id="be-scan-status-text" class="be-scan-status-text"></div>
                        </div>
                    </div>

                    <div class="boteraser-info-card">
                        <span class="boteraser-info-card-eyebrow"><?php _e('Architecture', 'bot-eraser'); ?></span>
                        <h3><?php echo bot_eraser_icon('trending-up'); ?> <?php _e('Data Flow', 'bot-eraser'); ?></h3>
                        <p class="boteraser-info-card-intro"><?php _e('Threat telemetry moves through a narrow path so you can reason about what stays local and what goes to the cloud.', 'bot-eraser'); ?></p>
                        <div class="boteraser-data-flow">
                            <div class="boteraser-flow-step">
                                <?php echo bot_eraser_icon('globe'); ?>
                                <span><?php _e('Your Site', 'bot-eraser'); ?></span>
                            </div>
                            <span class="boteraser-flow-arrow">&rarr;</span>
                            <div class="boteraser-flow-step">
                                <?php echo bot_eraser_icon('database'); ?>
                                <span><?php _e('Local Data', 'bot-eraser'); ?></span>
                            </div>
                            <span class="boteraser-flow-arrow">&rarr;</span>
                            <div class="boteraser-flow-step">
                                <?php echo bot_eraser_icon('cloud'); ?>
                                <span><?php _e('Boteraser Cloud', 'bot-eraser'); ?></span>
                            </div>
                        </div>
                    </div>

                    <?php
                    $log_file = BOT_ERASER_LOG_PATH;
                    $log_size_kb = file_exists($log_file) ? round(filesize($log_file) / 1024, 1) : 0;
                    $log_lines   = file_exists($log_file) ? count(file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES)) : 0;
                    $log_modified = file_exists($log_file) ? filemtime($log_file) : null;
                    $log_status = $log_size_kb > BOTERASER_LOG_SIZE_CRIT_KB ? 'danger' : ($log_size_kb > BOTERASER_LOG_SIZE_WARN_KB ? 'warning' : 'success');
                    $log_status_label = $log_size_kb > BOTERASER_LOG_SIZE_CRIT_KB ? __('Critical', 'bot-eraser') : ($log_size_kb > BOTERASER_LOG_SIZE_WARN_KB ? __('Large', 'bot-eraser') : __('Healthy', 'bot-eraser'));

                    $blocked_ips_file = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
                    $blocked_ips = file_exists($blocked_ips_file) ? include $blocked_ips_file : [];
                    $repeated_offenders = [];
                    if (file_exists($log_file) && is_array($blocked_ips)) {
                        $ip_counts = [];
                        foreach (file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                            if (preg_match('/^(\d+\.\d+\.\d+\.\d+)/', $line, $m)) {
                                $ip_counts[$m[1]] = ($ip_counts[$m[1]] ?? 0) + 1;
                            }
                        }
                        foreach ($blocked_ips as $ip => $expiry) {
                            if (isset($ip_counts[$ip])) {
                                $repeated_offenders[$ip] = $ip_counts[$ip];
                            }
                        }
                        arsort($repeated_offenders);
                        $repeated_offenders = array_slice($repeated_offenders, 0, 5, true);
                    }
                    ?>

                    <!-- Log Health -->
                    <div class="boteraser-info-card">
                        <span class="boteraser-info-card-eyebrow"><?php _e('Log Health', 'bot-eraser'); ?></span>
                        <h3><?php echo bot_eraser_icon('file-text'); ?> <?php _e('Log File Status', 'bot-eraser'); ?></h3>
                        <p class="boteraser-info-card-intro"><?php _e('Current state of the local access log used for threat analysis.', 'bot-eraser'); ?></p>
                        <div class="boteraser-recent-activity">
                            <div class="boteraser-activity-item">
                                <span class="boteraser-activity-ip"><?php _e('Size', 'bot-eraser'); ?></span>
                                <span class="boteraser-activity-time"><?php echo esc_html($log_size_kb); ?> KB</span>
                            </div>
                            <div class="boteraser-activity-item">
                                <span class="boteraser-activity-ip"><?php _e('Entries', 'bot-eraser'); ?></span>
                                <span class="boteraser-activity-time"><?php echo number_format($log_lines); ?></span>
                            </div>
                            <div class="boteraser-activity-item">
                                <span class="boteraser-activity-ip"><?php _e('Last write', 'bot-eraser'); ?></span>
                                <span class="boteraser-activity-time"><?php echo $log_modified ? human_time_diff($log_modified) . ' ago' : '—'; ?></span>
                            </div>
                            <div class="boteraser-activity-item">
                                <span class="boteraser-activity-ip"><?php _e('Status', 'bot-eraser'); ?></span>
                                <span class="boteraser-finding-pill <?php echo $log_status === 'success' ? 'low' : ($log_status === 'warning' ? 'medium' : 'high'); ?>"><?php echo esc_html($log_status_label); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Server Load -->
                    <?php $load_avg = function_exists('sys_getloadavg') ? sys_getloadavg() : null; ?>
                    <div class="boteraser-info-card">
                        <span class="boteraser-info-card-eyebrow"><?php _e('Server Status', 'bot-eraser'); ?></span>
                        <h3><?php echo bot_eraser_icon('activity'); ?> <?php _e('Server Load', 'bot-eraser'); ?></h3>
                        <p class="boteraser-info-card-intro"><?php _e('Average CPU load over the last 1, 5 and 15 minutes.', 'bot-eraser'); ?></p>
                        <?php if ($load_avg): ?>
                        <p class="boteraser-stat-value"><?php echo esc_html(number_format($load_avg[0], 2)); ?></p>
                        <div class="boteraser-recent-activity">
                            <div class="boteraser-activity-item">
                                <span class="boteraser-activity-ip"><?php _e('1 min', 'bot-eraser'); ?></span>
                                <span class="boteraser-activity-time"><?php echo esc_html(number_format($load_avg[0], 2)); ?></span>
                            </div>
                            <div class="boteraser-activity-item">
                                <span class="boteraser-activity-ip"><?php _e('5 min', 'bot-eraser'); ?></span>
                                <span class="boteraser-activity-time"><?php echo esc_html(number_format($load_avg[1], 2)); ?></span>
                            </div>
                            <div class="boteraser-activity-item">
                                <span class="boteraser-activity-ip"><?php _e('15 min', 'bot-eraser'); ?></span>
                                <span class="boteraser-activity-time"><?php echo esc_html(number_format($load_avg[2], 2)); ?></span>
                            </div>
                        </div>
                        <?php else: ?>
                        <p class="boteraser-empty-copy"><?php _e('Load data unavailable.', 'bot-eraser'); ?></p>
                        <?php endif; ?>
                    </div>

                    <!-- How It Works - spans both rows in col 3 -->
                    <div class="boteraser-info-card be-how-it-works-span">
                        <span class="boteraser-info-card-eyebrow"><?php _e('Protection Flow', 'bot-eraser'); ?></span>
                        <h3><?php echo bot_eraser_icon('settings'); ?> <?php _e('How It Works', 'bot-eraser'); ?></h3>
                        <p class="boteraser-info-card-intro"><?php _e('Boteraser combines local telemetry with cloud analysis to keep blocking rules current.', 'bot-eraser'); ?></p>
                        <ol class="boteraser-process-list">
                            <li><?php _e('Log all visitor access attempts locally', 'bot-eraser'); ?></li>
                            <li><?php _e('Identifies traffic volume patterns', 'bot-eraser'); ?></li>
                            <li><?php _e('Analyzes visitor IP addresses and bot identifiers, and sends threat data to Boteraser Cloud for security analysis', 'bot-eraser'); ?></li>
                            <li><?php _e('Receives updated blocking rules periodically', 'bot-eraser'); ?></li>
                            <li><?php _e('Scans site files for malware and verifies findings against Boteraser Cloud signature database', 'bot-eraser'); ?></li>
                        </ol>
                        <div class="boteraser-privacy-panel">
                            <h4 class="boteraser-privacy-panel-title">
                                <span class="boteraser-privacy-panel-icon">!</span>
                                <?php _e('IMPORTANT PRIVACY NOTICE', 'bot-eraser'); ?>
                            </h4>
                            <p><?php _e('This plugin locally analyzes visitor IP addresses, bot identifiers, and threat-related data (considered personal data under GDPR) and transmits this data to Boteraser Cloud for threat detection, malware analysis, and vulnerability analysis.', 'bot-eraser'); ?></p>
                            <p class="boteraser-privacy-panel-strong"><?php _e('You MUST disclose this data collection in your website\'s Privacy Policy.', 'bot-eraser'); ?></p>
                            <p class="boteraser-privacy-panel-links">
                                <a href="https://boteraser.com/privacy-policy/" target="_blank" class="boteraser-inline-link"><?php _e('Privacy Policy', 'bot-eraser'); ?></a>
                                <a href="https://boteraser.com/terms-of-service/" target="_blank" class="boteraser-inline-link"><?php _e('Terms of Service', 'bot-eraser'); ?></a>
                                <a href="https://boteraser.com/faq/" target="_blank" class="boteraser-inline-link"><?php _e('Learn More', 'bot-eraser'); ?></a>
                            </p>
                    </div>
                </div>
            </div>
            </div>

        <!-- Below-execution cards: full width, inline grid -->
        <div class="boteraser-below-execution">
                <!-- Server Status -->
                <div class="boteraser-info-card">
                    <span class="boteraser-info-card-eyebrow"><?php _e('Server Status', 'bot-eraser'); ?></span>
                    <h3><?php echo bot_eraser_icon('clock'); ?> <?php _e('Server Uptime', 'bot-eraser'); ?></h3>
                    <p class="boteraser-info-card-intro"><?php _e('How long the server has been running without interruption.', 'bot-eraser'); ?></p>
                    <p class="boteraser-stat-value"><?php echo esc_html(bot_eraser_format_uptime($stats['uptime'])); ?></p>
                </div>

                <!-- Recent Activity -->
                <div class="boteraser-info-card">
                    <span class="boteraser-info-card-eyebrow"><?php _e('Live Feed', 'bot-eraser'); ?></span>
                    <h3><?php echo bot_eraser_icon('activity'); ?> <?php _e('Recent Blocked IPs', 'bot-eraser'); ?></h3>
                    <p class="boteraser-info-card-intro"><?php printf(__('Showing the latest %d blocked addresses reaching the local block list.', 'bot-eraser'), count($recent_blocked)); ?></p>
                    <?php if (!empty($recent_blocked)): ?>
                    <div class="boteraser-recent-activity">
                        <?php foreach ($recent_blocked as $blocked): ?>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php echo esc_html($blocked['ip']); ?></span>
                            <span class="boteraser-activity-time"><?php echo esc_html($blocked['time_ago']); ?> ago</span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <p class="boteraser-empty-copy"><?php _e('No blocked IPs yet', 'bot-eraser'); ?></p>
                    <?php endif; ?>
                </div>

                <!-- Repeated Offenders -->
                <div class="boteraser-info-card">
                    <span class="boteraser-info-card-eyebrow"><?php _e('Threat Intel', 'bot-eraser'); ?></span>
                    <h3><?php echo bot_eraser_icon('alert-circle'); ?> <?php _e('Repeated Offenders', 'bot-eraser'); ?></h3>
                    <p class="boteraser-info-card-intro"><?php _e('Blocked IPs with the most logged requests — persistent threats.', 'bot-eraser'); ?></p>
                    <?php if (!empty($repeated_offenders)): ?>
                    <div class="boteraser-recent-activity">
                        <?php foreach ($repeated_offenders as $ip => $count): ?>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php echo esc_html($ip); ?></span>
                            <span class="boteraser-activity-time"><?php echo number_format($count); ?> req</span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <p class="boteraser-empty-copy"><?php _e('No repeated offenders found.', 'bot-eraser'); ?></p>
                    <?php endif; ?>
                </div>

                <!-- Scan Results -->
                <div class="boteraser-info-card">
                    <span class="boteraser-info-card-eyebrow"><?php _e('Latest Scan', 'bot-eraser'); ?></span>
                    <h3><?php echo bot_eraser_icon('shield', 'be-heading-icon'); ?> <?php _e('Scan Results', 'bot-eraser'); ?></h3>
                    <p class="boteraser-info-card-intro"><?php _e('Files flagged during the most recent malware scan, grouped by severity.', 'bot-eraser'); ?></p>
                    <?php $rmf_has_findings = !empty($recent_malware); if ($rmf_has_findings): ?>
                    <div class="boteraser-recent-activity">
                        <?php foreach ($recent_malware as $finding):
                            $sev = strtolower($finding['severity']);
                        ?>
                        <div class="boteraser-activity-item boteraser-activity-finding">
                            <span class="boteraser-activity-ip" title="<?php echo esc_attr($finding['file']); ?>"><?php echo esc_html(basename($finding['file'])); ?></span>
                            <span class="boteraser-finding-pill <?php echo esc_attr($sev); ?>"><?php echo esc_html($finding['severity']); ?></span>
                            <?php if (!empty($finding['time_ago'])): ?>
                            <span class="boteraser-activity-time"><?php echo esc_html($finding['time_ago']); ?> ago</span>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <p class="boteraser-info-card-footer">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-inline-link">
                            <?php _e('View all findings', 'bot-eraser'); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>
                    <?php elseif ($rmf_scanned): ?>
                    <div class="boteraser-scan-clean">
                        <?php echo bot_eraser_icon('check-circle'); ?>
                        <span><?php _e('No threats found', 'bot-eraser'); ?></span>
                    </div>
                    <p class="boteraser-info-card-footer">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-inline-link">
                            <?php _e('View scan report', 'bot-eraser'); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>
                    <?php else: ?>
                    <p class="boteraser-info-card-footer">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-inline-link">
                            <?php _e('Run a scan now', 'bot-eraser'); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>
                    <?php endif; ?>
                </div>

                <!-- Quarantine -->
                <div class="boteraser-info-card">
                    <span class="boteraser-info-card-eyebrow"><?php _e('File Quarantine', 'bot-eraser'); ?></span>
                    <h3><?php echo bot_eraser_icon('shield-x', 'be-heading-icon'); ?> <?php _e('Quarantine', 'bot-eraser'); ?></h3>
                    <p class="boteraser-info-card-intro"><?php _e('Files moved to quarantine during malware scans.', 'bot-eraser'); ?></p>
                    <?php if ($dash_quarantine_count > 0): ?>
                    <div class="boteraser-recent-activity">
                        <?php foreach (array_slice($dash_quarantine_items, 0, 5) as $qitem): ?>
                        <div class="boteraser-activity-item boteraser-activity-finding">
                            <span class="boteraser-activity-ip" title="<?php echo esc_attr($qitem['original_path'] ?? ''); ?>"><?php echo esc_html(basename($qitem['original_path'] ?? '—')); ?></span>
                            <?php if (!empty($qitem['severity'])): ?>
                            <span class="boteraser-finding-pill <?php echo esc_attr(strtolower($qitem['severity'])); ?>"><?php echo esc_html($qitem['severity']); ?></span>
                            <?php endif; ?>
                            <span class="boteraser-activity-time"><?php echo !empty($qitem['quarantined_at']) ? esc_html(human_time_diff((int) $qitem['quarantined_at'], time())) . ' ago' : '—'; ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <p class="boteraser-info-card-footer">
                        <?php if ($dash_quarantine_high > 0): ?>
                        <span class="boteraser-finding-pill high" class="boteraser-quarantine-high-pill"><?php echo (int) $dash_quarantine_high; ?> HIGH</span>
                        <?php endif; ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-inline-link">
                            <?php printf(_n('View %d quarantined file', 'View %d quarantined files', $dash_quarantine_count, 'bot-eraser'), $dash_quarantine_count); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>
                    <?php else: ?>
                    <p class="boteraser-empty-copy"><?php _e('No files in quarantine.', 'bot-eraser'); ?></p>
                    <p class="boteraser-info-card-footer">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-inline-link">
                            <?php _e('Open Scanner', 'bot-eraser'); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>
                    <?php endif; ?>
                </div>

                <!-- Upload Scanner -->
                <div class="boteraser-info-card">
                    <span class="boteraser-info-card-eyebrow"><?php _e('Upload Protection', 'bot-eraser'); ?></span>
                    <h3><?php echo bot_eraser_icon('upload', 'be-heading-icon'); ?> <?php _e('Upload Scanner', 'bot-eraser'); ?></h3>
                    <p class="boteraser-info-card-intro"><?php _e('Automatic malware scan on every file, plugin and theme upload.', 'bot-eraser'); ?></p>
                    <div class="boteraser-recent-activity">
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Status', 'bot-eraser'); ?></span>
                            <?php if ($dash_upload_active): ?>
                            <span class="boteraser-finding-pill low"><?php _e('Active', 'bot-eraser'); ?></span>
                            <?php else: ?>
                            <span class="boteraser-finding-pill medium"><?php _e('Requires API', 'bot-eraser'); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Pending alerts', 'bot-eraser'); ?></span>
                            <span class="boteraser-activity-time <?php echo $dash_upload_alert_count > 0 ? 'boteraser-text-danger' : ''; ?>"><?php echo (int) $dash_upload_alert_count; ?></span>
                        </div>
                        <?php if ($dash_upload_last_alert): ?>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Last alert', 'bot-eraser'); ?></span>
                            <span class="boteraser-activity-time"><?php echo esc_html(human_time_diff((int) $dash_upload_last_alert['time'], time())); ?> ago</span>
                        </div>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Type', 'bot-eraser'); ?></span>
                            <span class="boteraser-activity-time"><?php echo esc_html(ucfirst($dash_upload_last_alert['type'] ?? '—')); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($dash_upload_alert_count > 0): ?>
                    <p class="boteraser-info-card-footer">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-inline-link">
                            <?php printf(_n('Review %d upload alert', 'Review %d upload alerts', $dash_upload_alert_count, 'bot-eraser'), $dash_upload_alert_count); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>
                    <?php endif; ?>
                </div>

                <!-- WordPress Updates -->
                <?php
                $wp_updates_plugins = get_site_transient('update_plugins');
                $wp_updates_themes  = get_site_transient('update_themes');
                $wp_updates_core    = get_site_transient('update_core');
                $updates_plugins_count = isset($wp_updates_plugins->response) ? count($wp_updates_plugins->response) : 0;
                $updates_themes_count  = isset($wp_updates_themes->response)  ? count($wp_updates_themes->response)  : 0;
                $updates_core_needed   = false;
                if (isset($wp_updates_core->updates)) {
                    foreach ($wp_updates_core->updates as $core_update) {
                        if (isset($core_update->response) && $core_update->response === 'upgrade') {
                            $updates_core_needed = true;
                            break;
                        }
                    }
                }
                $updates_total = $updates_plugins_count + $updates_themes_count + ($updates_core_needed ? 1 : 0);
                $updates_tone  = $updates_total > 0 ? ($updates_core_needed ? 'high' : 'medium') : 'low';
                ?>
                <div class="boteraser-info-card">
                    <span class="boteraser-info-card-eyebrow"><?php _e('Patch Status', 'bot-eraser'); ?></span>
                    <h3><?php echo bot_eraser_icon('refresh-cw', 'be-heading-icon'); ?> <?php _e('WordPress Updates', 'bot-eraser'); ?></h3>
                    <p class="boteraser-info-card-intro"><?php _e('Outdated components are a primary attack vector. Keep everything current.', 'bot-eraser'); ?></p>
                    <div class="boteraser-recent-activity">
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('WordPress core', 'bot-eraser'); ?></span>
                            <?php if ($updates_core_needed): ?>
                            <span class="boteraser-finding-pill high"><?php _e('Update available', 'bot-eraser'); ?></span>
                            <?php else: ?>
                            <span class="boteraser-finding-pill low"><?php _e('Up to date', 'bot-eraser'); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Plugins', 'bot-eraser'); ?></span>
                            <?php if ($updates_plugins_count > 0): ?>
                            <span class="boteraser-finding-pill medium"><?php printf(_n('%d update', '%d updates', $updates_plugins_count, 'bot-eraser'), $updates_plugins_count); ?></span>
                            <?php else: ?>
                            <span class="boteraser-finding-pill low"><?php _e('Up to date', 'bot-eraser'); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Themes', 'bot-eraser'); ?></span>
                            <?php if ($updates_themes_count > 0): ?>
                            <span class="boteraser-finding-pill medium"><?php printf(_n('%d update', '%d updates', $updates_themes_count, 'bot-eraser'), $updates_themes_count); ?></span>
                            <?php else: ?>
                            <span class="boteraser-finding-pill low"><?php _e('Up to date', 'bot-eraser'); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($updates_total > 0): ?>
                    <p class="boteraser-info-card-footer">
                        <a href="<?php echo esc_url(admin_url('update-core.php')); ?>" class="boteraser-inline-link">
                            <?php printf(_n('Apply %d pending update', 'Apply %d pending updates', $updates_total, 'bot-eraser'), $updates_total); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>
                    <?php else: ?>
                    <p class="boteraser-info-card-footer">
                        <a href="<?php echo esc_url(admin_url('update-core.php')); ?>" class="boteraser-inline-link">
                            <?php _e('Check for updates', 'bot-eraser'); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>
                    <?php endif; ?>
                </div>

                <!-- File Integrity Monitor -->
                <div class="boteraser-info-card">
                    <span class="boteraser-info-card-eyebrow"><?php _e('Integrity Monitor', 'bot-eraser'); ?></span>
                    <h3><?php echo bot_eraser_icon('git-merge', 'be-heading-icon'); ?> <?php _e('File Integrity', 'bot-eraser'); ?></h3>
                    <p class="boteraser-info-card-intro"><?php _e('WordPress core files compared against the saved baseline (wp-admin &amp; wp-includes).', 'bot-eraser'); ?></p>

                    <?php if (!$dash_baseline_time): ?>
                    <p class="boteraser-empty-copy"><?php _e('No baseline saved yet. Run a scan and save a baseline to start monitoring.', 'bot-eraser'); ?></p>
                    <p class="boteraser-info-card-footer">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-inline-link">
                            <?php _e('Go to Scanner', 'bot-eraser'); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>

                    <?php elseif ($dash_integrity_total === 0): ?>
                    <div class="boteraser-scan-clean">
                        <?php echo bot_eraser_icon('check-circle'); ?>
                        <span><?php _e('All core files match baseline', 'bot-eraser'); ?></span>
                    </div>
                    <div class="boteraser-recent-activity" class="boteraser-mt-10">
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Baseline saved', 'bot-eraser'); ?></span>
                            <span class="boteraser-activity-time"><?php echo esc_html(human_time_diff((int) $dash_baseline_time, time())); ?> ago</span>
                        </div>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Files tracked', 'bot-eraser'); ?></span>
                            <span class="boteraser-activity-time"><?php echo number_format(count($dash_baseline_files)); ?></span>
                        </div>
                    </div>

                    <?php else: ?>
                    <div class="boteraser-recent-activity">
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Baseline saved', 'bot-eraser'); ?></span>
                            <span class="boteraser-activity-time"><?php echo esc_html(human_time_diff((int) $dash_baseline_time, time())); ?> ago</span>
                        </div>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Modified', 'bot-eraser'); ?></span>
                            <?php if ($dash_integrity_changed_count > 0): ?>
                            <span class="boteraser-finding-pill medium"><?php echo (int) $dash_integrity_changed_count; ?></span>
                            <?php else: ?>
                            <span class="boteraser-finding-pill low">0</span>
                            <?php endif; ?>
                        </div>
                        <div class="boteraser-activity-item">
                            <span class="boteraser-activity-ip"><?php _e('Deleted', 'bot-eraser'); ?></span>
                            <?php if ($dash_integrity_deleted_count > 0): ?>
                            <span class="boteraser-finding-pill high"><?php echo (int) $dash_integrity_deleted_count; ?></span>
                            <?php else: ?>
                            <span class="boteraser-finding-pill low">0</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if (!empty($dash_integrity_changed)): ?>
                    <div class="boteraser-recent-activity" class="boteraser-mt-8">
                        <?php foreach (array_slice($dash_integrity_changed, 0, 4) as $fim_file): ?>
                        <div class="boteraser-activity-item boteraser-activity-finding">
                            <span class="boteraser-activity-ip" title="<?php echo esc_attr($fim_file['file']); ?>"><?php echo esc_html(basename($fim_file['file'])); ?></span>
                            <span class="boteraser-finding-pill medium"><?php _e('modified', 'bot-eraser'); ?></span>
                            <span class="boteraser-activity-time"><?php echo esc_html(human_time_diff((int) $fim_file['mtime'], time())); ?> ago</span>
                        </div>
                        <?php endforeach; ?>
                        <?php if (!empty($dash_integrity_deleted)): ?>
                        <div class="boteraser-activity-item boteraser-activity-finding">
                            <span class="boteraser-activity-ip"><?php echo esc_html(basename($dash_integrity_deleted[0])); ?></span>
                            <span class="boteraser-finding-pill high"><?php _e('deleted', 'bot-eraser'); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    <p class="boteraser-info-card-footer">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-inline-link">
                            <?php printf(_n('Review %d changed file', 'Review %d changed files', $dash_integrity_total, 'bot-eraser'), $dash_integrity_total); ?>
                            <?php echo bot_eraser_icon('external-link', 'be-inline-icon'); ?>
                        </a>
                    </p>
                    <?php endif; ?>
                </div>

        </div>
        </div>
    </div>
    <?php
}

/**
 * Helper: get last scan summary for Dashboard widget
 */
function boteraser_get_last_scan_summary() {
    $results = get_option('boteraser_last_scan_results', null);
    if (!$results) return null;
    return array(
        'summary'      => $results['summary'] ?? null,
        'completed_at' => $results['completed_at'] ?? null,
    );
}

/**
 * Security Scan page render
 */
function boteraser_render_scanner_page() {
    if (!current_user_can('manage_options')) return;

    require_once BOT_ERASER_PLUGIN_DIR . 'includes/scanner/scan-engine.php';

    // Upload alerts data
    $upload_alerts       = get_option('boteraser_upload_alerts', array());
    $upload_alerts       = is_array($upload_alerts) ? array_values($upload_alerts) : array();
    $upload_alert_count  = count($upload_alerts);
    $upload_alert_nonce  = wp_create_nonce('boteraser_upload_alert_nonce');

    $last_scan    = boteraser_get_last_scan();
    $summary      = $last_scan['summary']      ?? null;
    $findings     = $last_scan['findings']     ?? array();
    $completed_at = $last_scan['completed_at'] ?? null;
    $whitelist    = get_option(BOTERASER_SCAN_WHITELIST, array());
    $baseline_time = get_option('boteraser_baseline_time', null);
    $scanner_validation_state = get_option('bot_eraser_api_validation_state', array());
    $scanner_premium_enabled = !empty($scanner_validation_state['is_valid']);
    $scanner_strength = function_exists('bot_eraser_get_malware_strength') ? bot_eraser_get_malware_strength() : array('components' => array());
    $scanner_premium_features = array_values(array_filter($scanner_strength['components'] ?? array(), function($component) {
        return !empty($component['premium']);
    }));
    $visible_findings = array_values(array_filter($findings, function($finding) use ($whitelist) {
        return !in_array($finding['file'], $whitelist, true);
    }));
    $visible_findings_total = count($visible_findings);
    $visible_findings_counts = array(
        'HIGH' => 0,
        'MEDIUM' => 0,
        'LOW' => 0,
    );
    foreach ($visible_findings as $visible_finding) {
        $severity_key = strtoupper($visible_finding['severity'] ?? '');
        if (isset($visible_findings_counts[$severity_key])) {
            $visible_findings_counts[$severity_key]++;
        }
    }
    $auto_scan_enabled  = (bool) get_option('boteraser_auto_scan_enabled', false);
    $auto_scan_interval = function_exists('bot_eraser_auto_scan_interval_slug')
        ? bot_eraser_auto_scan_interval_slug(get_option('boteraser_auto_scan_interval', 'boteraser_daily'))
        : 'boteraser_daily';
    $auto_scan_next     = wp_next_scheduled('boteraser_auto_scan_hook');
    $auto_scan_last_run = (int) get_option('boteraser_auto_scan_last_run', 0);
    $notify_enabled     = (bool) get_option('boteraser_notify_enabled', false);
    $notify_email       = get_option('boteraser_notify_email', get_option('admin_email'));
    $auto_scan_files_themes_plugins = (bool) get_option('boteraser_auto_scan_files_themes_plugins', false);
    $auto_scan_intervals = array(
        'boteraser_6h'     => __('Every 6 hours', 'bot-eraser'),
        'twicedaily'       => __('Twice daily', 'bot-eraser'),
        'boteraser_daily'  => __('Once daily', 'bot-eraser'),
    );
    $scanner_module_defaults = array(
        'mod_core'        => true,
        'mod_plugins'     => true,
        'mod_themes'      => true,
        'mod_filenames'   => true,
        'mod_uploads'     => true,
        'mod_htaccess'    => true,
        'mod_database'    => true,
        'mod_cron'        => true,
        'mod_files'       => true,
        'mod_permissions' => true,
        'mod_patterns'    => false,
        'mod_malware_api' => false,
    );
    $scanner_module_settings = get_option('boteraser_scanner_module_settings', array());
    $scanner_module_settings = wp_parse_args(is_array($scanner_module_settings) ? $scanner_module_settings : array(), $scanner_module_defaults);
    $scanner_module_groups = array(
        array(
            'title' => __('Integrity Checks', 'bot-eraser'),
            'icon'  => 'shield-check',
            'color' => 'integrity',
            'items' => array(
                array('name' => 'mod_core', 'label' => __('Core Integrity', 'bot-eraser'), 'icon' => 'shield', 'checked' => !empty($scanner_module_settings['mod_core']), 'hint' => __('Compare WordPress core files against official checksums.', 'bot-eraser')),
                array('name' => 'mod_plugins', 'label' => __('Plugin Integrity', 'bot-eraser'), 'icon' => 'package', 'checked' => !empty($scanner_module_settings['mod_plugins']), 'hint' => __('Verify installed plugins against their WordPress.org releases.', 'bot-eraser')),
                array('name' => 'mod_themes', 'label' => __('Theme Integrity', 'bot-eraser'), 'icon' => 'layout', 'checked' => !empty($scanner_module_settings['mod_themes']), 'hint' => __('Verify installed themes against their official releases.', 'bot-eraser')),
            ),
        ),
        array(
            'title' => __('Scan Modules', 'bot-eraser'),
            'icon'  => 'scan',
            'color' => 'modules',
            'items' => array(
                array('name' => 'mod_filenames', 'label' => __('Malware Filenames', 'bot-eraser'), 'icon' => 'file-text', 'checked' => !empty($scanner_module_settings['mod_filenames']), 'hint' => __('Detect known malware filenames and suspicious naming patterns.', 'bot-eraser')),
                array('name' => 'mod_uploads', 'label' => __('Uploads Folder', 'bot-eraser'), 'icon' => 'upload', 'checked' => !empty($scanner_module_settings['mod_uploads']), 'hint' => __('Flag executable files in uploads, which are often malicious.', 'bot-eraser')),
                array('name' => 'mod_htaccess', 'label' => __('.htaccess in Uploads', 'bot-eraser'), 'icon' => 'settings', 'checked' => !empty($scanner_module_settings['mod_htaccess']), 'hint' => __('Detect .htaccess files in the uploads folder that enable PHP execution or redirect to external domains.', 'bot-eraser')),
                array('name' => 'mod_files', 'label' => __('File Walk Scan', 'bot-eraser'), 'icon' => 'folder', 'checked' => !empty($scanner_module_settings['mod_files']), 'hint' => __('Walk all files to detect PHP in uploads and suspicious double extensions.', 'bot-eraser')),
                array('name' => 'mod_permissions', 'label' => __('File Permissions', 'bot-eraser'), 'icon' => 'lock', 'checked' => !empty($scanner_module_settings['mod_permissions']), 'hint' => __('Flag files with overly permissive access (0777, 0775).', 'bot-eraser')),
                array('name' => 'mod_database', 'label' => __('Database Scan', 'bot-eraser'), 'icon' => 'database', 'checked' => !empty($scanner_module_settings['mod_database']), 'hint' => __('Look for injected payloads and suspicious entries in the database.', 'bot-eraser')),
                array('name' => 'mod_cron', 'label' => __('Cron / Backdoor', 'bot-eraser'), 'icon' => 'clock', 'checked' => !empty($scanner_module_settings['mod_cron']), 'hint' => __('Look for suspicious scheduled tasks and cron persistence.', 'bot-eraser')),
                array(
                    'name'     => 'bf_protection_info',
                    'label'    => __('Brute Force Protection', 'bot-eraser'),
                    'icon'     => 'shield',
                    'checked'  => bot_eraser_bf_is_enabled(),
                    'hint'     => sprintf(
                        /* translators: 1: max attempts, 2: window in minutes */
                        __('Runtime login protection. After %1$d failed attempts in %2$d minutes, the IP is redirected to cloud for fingerprinting and global blocking. Configured on the Dashboard.', 'bot-eraser'),
                        bot_eraser_bf_max_attempts(),
                        bot_eraser_bf_window_minutes()
                    ),
                    'runtime'  => true,
                ),
            ),
        ),
        array(
            'title' => __('Automation & Protection', 'bot-eraser'),
            'icon'  => 'zap',
            'color' => 'automation',
            'description' => $scanner_premium_enabled
                ? __('Premium heuristics are enabled for this scan profile.', 'bot-eraser')
                : __('Premium heuristics unlock after you connect and validate an API key.', 'bot-eraser'),
            'items' => array(
                array(
                    'name'    => 'mod_malware_api',
                    'label'   => __('Malware Signature Lookup', 'bot-eraser'),
                    'icon'    => 'cloud',
                    'checked' => $scanner_premium_enabled && !empty($scanner_module_settings['mod_malware_api']),
                    'hint'    => __('Send file hashes to the Boteraser cloud for malware signature verification. Catches known malware that local heuristics may miss.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
                array(
                    'name'    => 'mod_patterns',
                    'label'   => __('Deep Code Scan', 'bot-eraser'),
                    'icon'    => 'scan',
                    'checked' => $scanner_premium_enabled && !empty($scanner_module_settings['mod_patterns']),
                    'hint'    => __('Pattern-based heuristics. Useful for deeper review, but may flag legitimate code.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
                array(
                    'name'    => 'auto_scan_enabled',
                    'label'   => __('Automatic Scan', 'bot-eraser'),
                    'icon'    => 'refresh-cw',
                    'checked' => $scanner_premium_enabled && $auto_scan_enabled,
                    'hint'    => __('Run a malware scan automatically via WP-Cron at the chosen interval.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
                array(
                    'name'    => 'auto_scan_files_themes_plugins',
                    'label'   => __('Auto File, Theme & Plugin Scan', 'bot-eraser'),
                    'icon'    => 'refresh',
                    'checked' => $scanner_premium_enabled && $auto_scan_files_themes_plugins,
                    'hint'    => __('Automatically scan all files, themes and plugins for integrity and malware on each scheduled run. Requires Premium.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
                array(
                    'name'    => 'notify_enabled',
                    'label'   => __('Email Notifications', 'bot-eraser'),
                    'icon'    => 'mail',
                    'checked' => $scanner_premium_enabled && $notify_enabled,
                    'hint'    => __('Receive a scan summary email after each automatic or manual scan completes. Separate multiple addresses with commas.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
                array(
                    'name'    => 'auto_quarantine',
                    'label'   => __('Auto-Quarantine Malware', 'bot-eraser'),
                    'icon'    => 'shield-off',
                    'checked' => $scanner_premium_enabled && (bool) get_option('boteraser_auto_quarantine', false),
                    'hint'    => __('Automatically move confirmed malware signature matches to quarantine when a scan completes. Only applies to files verified by the cloud signature database.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
                array(
                    'name'    => 'waf_ruleset',
                    'label'   => __('WAF Ruleset', 'bot-eraser'),
                    'icon'    => 'shield',
                    'checked' => $scanner_premium_enabled && (bool) get_option('boteraser_waf_enabled', false),
                    'hint'    => __('Continuously sync the full WAF rule set from the cloud and use it to block SQLi, XSS, RCE, LFI/RFI and scanner traffic at the request level. Requires Premium.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
            ),
        ),
        array(
            'title' => __('Upload & Plugin Protection', 'bot-eraser'),
            'icon'  => 'shield-check',
            'items' => array(
                array(
                    'name'    => 'block_php_uploads',
                    'label'   => __('Block PHP Execution', 'bot-eraser'),
                    'icon'    => 'ban',
                    'checked' => (bool) get_option('boteraser_block_php_uploads', true),
                    'hint'    => __('Create .htaccess in uploads to prevent PHP file execution.', 'bot-eraser'),
                    'premium' => false,
                    'enabled' => true,
                ),
                array(
                    'name'    => 'block_dangerous_ext',
                    'label'   => __('Block Dangerous Extensions', 'bot-eraser'),
                    'icon'    => 'file-x',
                    'checked' => (bool) get_option('boteraser_block_dangerous_ext', true),
                    'hint'    => __('Prevent upload of .php, .phtml, .phar, .exe, .sh and other dangerous file types.', 'bot-eraser'),
                    'premium' => false,
                    'enabled' => true,
                ),
                array(
                    'name'    => 'auto_quarantine_uploads',
                    'label'   => __('Auto-Quarantine Uploads', 'bot-eraser'),
                    'icon'    => 'archive',
                    'checked' => $scanner_premium_enabled && (bool) get_option('boteraser_auto_quarantine_uploads', false),
                    'hint'    => __('Automatically quarantine HIGH severity files uploaded via Media Library.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
                array(
                    'name'    => 'scan_before_activation',
                    'label'   => __('Scan Before Activation', 'bot-eraser'),
                    'icon'    => 'scan',
                    'checked' => (bool) get_option('boteraser_scan_before_activation', true),
                    'hint'    => __('Scan plugins for malware before activation and show warning if threats detected.', 'bot-eraser'),
                    'premium' => false,
                    'enabled' => true,
                ),
                array(
                    'name'    => 'auto_deactivate_plugins',
                    'label'   => __('Auto-Deactivate Malware', 'bot-eraser'),
                    'icon'    => 'power',
                    'checked' => $scanner_premium_enabled && (bool) get_option('boteraser_auto_deactivate_plugins', false),
                    'hint'    => __('Automatically deactivate plugins if HIGH severity malware detected.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
                array(
                    'name'    => 'rollback_on_update',
                    'label'   => __('Rollback on Update', 'bot-eraser'),
                    'icon'    => 'rotate-ccw',
                    'checked' => (bool) get_option('boteraser_rollback_on_update', true),
                    'hint'    => __('Backup plugin before update and rollback if new version contains malware.', 'bot-eraser'),
                    'premium' => false,
                    'enabled' => true,
                ),
                array(
                    'name'    => 'realtime_cloud_scan',
                    'label'   => __('Real-Time Cloud Scan', 'bot-eraser'),
                    'icon'    => 'cloud-lightning',
                    'checked' => $scanner_premium_enabled && (bool) get_option('boteraser_realtime_cloud_scan', false),
                    'hint'    => __('Check file hash against cloud malware database before saving to disk.', 'bot-eraser'),
                    'premium' => true,
                    'enabled' => $scanner_premium_enabled,
                ),
                array(
                    'name'    => 'whitelist_safe_plugins',
                    'label'   => __('Whitelist Safe Plugins', 'bot-eraser'),
                    'icon'    => 'check-circle',
                    'checked' => (bool) get_option('boteraser_whitelist_safe_plugins', true),
                    'hint'    => __('Skip scanning for known safe plugins from WordPress.org repository.', 'bot-eraser'),
                    'premium' => false,
                    'enabled' => true,
                ),
            ),
        ),
    );
    $scanner_status_class = empty($summary) ? 'setup' : (($summary['high'] ?? 0) > 0 ? 'watch' : 'safe');
    $scanner_status_label = empty($summary)
        ? __('Not Scanned', 'bot-eraser')
        : ((($summary['high'] ?? 0) > 0) ? __('Action Recommended', 'bot-eraser') : __('Scanner Healthy', 'bot-eraser'));
    $scanner_status_message = empty($summary)
        ? __('Run your first scan to build a baseline and review file integrity.', 'bot-eraser')
        : ((($summary['high'] ?? 0) > 0)
            ? __('High-severity findings are present. Review results before applying destructive actions.', 'bot-eraser')
            : __('No critical findings in the latest scan. Keep the baseline current and rescan after updates.', 'bot-eraser'));

    wp_localize_script('boteraser-admin', 'boteraser_scanner', array(
        'ajaxUrl'  => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('boteraser_scan_nonce'),
        'findings' => $findings,
    ));
    if ($summary) {
        $score_int = (int) $summary['score'];
        $score_tone = $score_int >= 75 ? 'low' : ($score_int >= 50 ? 'medium' : 'high');
        $score_health_tone = $score_int >= 75 ? 'good' : ($score_int >= 50 ? 'warn' : 'bad');
        $core_grade = !empty($summary['grade']) ? $summary['grade'] : ($score_int >= 75 ? 'GOOD' : ($score_int >= 50 ? 'WARNING' : 'CRITICAL'));
        switch ($core_grade) {
            case 'EXCELLENT':
            case 'GOOD':
                $core_tone = 'good';
                break;
            case 'WARNING':
                $core_tone = 'warn';
                break;
            case 'POOR':
            case 'CRITICAL':
                $core_tone = 'bad';
                break;
            default:
                $core_tone = 'good';
        }
        $core_high_n = (int) $summary['high'];
        $core_med_n  = (int) $summary['medium'];
        $core_low_n  = (int) $summary['low'];
        if ($core_high_n > 0) {
            $core_summary = sprintf(
                _n('%d critical threat found in the last scan.', '%d critical threats found in the last scan.', $core_high_n, 'bot-eraser'),
                $core_high_n
            );
        } elseif ($core_med_n > 0) {
            $core_summary = sprintf(
                _n('%d warning found in the last scan.', '%d warnings found in the last scan.', $core_med_n, 'bot-eraser'),
                $core_med_n
            );
        } else {
            $core_summary = __('No critical threats detected in the last scan.', 'bot-eraser');
        }
        $core_cta_label = ($core_high_n > 0 || $core_med_n > 0) ? __('Review Findings', 'bot-eraser') : __('Run New Scan', 'bot-eraser');
        $core_hist = get_option('boteraser_scan_history', array());
        $core_hist = is_array($core_hist) ? $core_hist : array();
        if (count($core_hist) >= 2) {
            $core_prev  = (int) ($core_hist[count($core_hist) - 2]['score'] ?? 0);
            $core_delta = $score_int - $core_prev;
        } else {
            $core_delta = null;
        }
        $core_spark = array();
        foreach (array_slice($core_hist, -6) as $core_h) {
            $core_spark[] = max(0, min(100, (int) ($core_h['score'] ?? 0)));
        }
        $score_context_parts = array();
        if ($completed_at) {
            $score_context_parts[] = sprintf(__('Last scan: %s ago', 'bot-eraser'), human_time_diff($completed_at));
        }
        $score_context_parts[] = sprintf(
            /* translators: 1: number of files scanned, 2: scan duration in seconds */
            __('%1$s files, %2$ss', 'bot-eraser'),
            number_format_i18n((int) $summary['files_scanned']),
            (int) $summary['duration']
        );
        $score_context = implode(' — ', $score_context_parts);
    } else {
        $score_int          = 0;
        $score_tone         = 'neutral';
        $score_health_tone  = 'neutral';
        $score_context      = __('No scan yet', 'bot-eraser');
        $core_grade         = __('NOT SCANNED', 'bot-eraser');
        $core_tone          = 'neutral';
        $core_high_n        = 0;
        $core_med_n         = 0;
        $core_low_n         = 0;
        $core_summary       = __('This site has not been scanned yet.', 'bot-eraser');
        $core_cta_label     = __('Run First Scan', 'bot-eraser');
        $core_delta         = null;
        $core_spark         = array();
    }
    $scanner_header_metrics = array(
        array(
            'id'      => 'be-hero-score',
            'label'   => __('Health Score', 'bot-eraser'),
            'value'   => $summary ? $summary['score'] . '/100' : '—',
            'badge'   => $summary ? $summary['grade'] : '',
            'context' => $score_context,
            'tone'    => $score_tone,
        ),
        array(
            'id'      => 'be-hero-high-findings',
            'label'   => __('High findings', 'bot-eraser'),
            'value'   => $summary ? number_format($summary['high']) : '0',
            'context' => __('Critical issues detected', 'bot-eraser'),
            'tone'    => ($summary && (int) $summary['high'] > 0) ? 'high' : 'low',
        ),
        array(
            'label'   => __('Next scan', 'bot-eraser'),
            'value'   => ($scanner_premium_enabled && $auto_scan_enabled && $auto_scan_next)
                ? date_i18n('d.m.Y H:i', $auto_scan_next)
                : __('Not scheduled', 'bot-eraser'),
            'context' => ($scanner_premium_enabled && $auto_scan_enabled && $auto_scan_next)
                ? __('Next automatic scan run', 'bot-eraser')
                : ($scanner_premium_enabled
                    ? __('Enable Automatic Scan to schedule', 'bot-eraser')
                    : __('Available with Premium', 'bot-eraser')),
            'tone'    => ($scanner_premium_enabled && $auto_scan_enabled && $auto_scan_next) ? 'low' : 'medium',
            'id'      => 'be-hero-next-scan',
        ),
    );

    $scanner_header_aside = sprintf(
        '<div class="boteraser-hero-aside boteraser-hero-aside-scanner boteraser-hero-aside-%1$s"><span class="boteraser-hero-status-badge %1$s">%2$s</span><p class="boteraser-hero-status-text">%3$s</p></div>',
        esc_attr($scanner_status_class),
        esc_html($scanner_status_label),
        esc_html($scanner_status_message)
    );
    ?>
    <div class="wrap boteraser-wrap">
        <?php bot_eraser_render_page_header(array(
            'variant'  => 'hero',
            'title'    => __('Scanner Command Center', 'bot-eraser'),
            'subtitle' => __('Run integrity checks, compare baselines and triage suspicious files with a clearer security workflow.', 'bot-eraser'),
            'metrics'  => $scanner_header_metrics,
            'aside'    => $scanner_header_aside,
        )); ?>

        <!-- Scanner Card with Metrics Strip -->
        <div class="boteraser-card be-scanner-top-card">
            <div class="be-scanner-columns">
                <!-- Status column: health score, actions, progress -->
                <div class="be-scanner-col-status">
                    <!-- Professional Metrics Strip -->
                    <div class="be-scanner-metrics-strip">
                        <!-- Health Score Card -->
                        <div class="be-metric-card score">
                            <div class="be-metric-header">
                                <span class="be-metric-label"><?php _e('Health Score', 'bot-eraser'); ?></span>
                                <?php echo bot_eraser_icon('shield-check', 'be-metric-icon'); ?>
                            </div>
                            <div class="be-metric-score-body">
                                <div class="be-status-minimal be-core-<?php echo esc_attr($core_tone); ?>"
                                     role="meter"
                                     aria-valuenow="<?php echo esc_attr($summary ? $score_int : 0); ?>"
                                     aria-valuemin="0" aria-valuemax="100"
                                     aria-label="<?php esc_attr_e('Site security status', 'bot-eraser'); ?>">
                                    <div class="be-sm-gauge"<?php if ($summary): ?> style="--sm-arc: <?php echo esc_attr(min(100, max(0, $score_int)) / 100); ?>;"<?php endif; ?>>
                                        <?php if ($summary): ?>
                                            <svg viewBox="0 0 200 200" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
                                                <circle class="be-sm-gauge-track" cx="100" cy="100" r="84"></circle>
                                                <circle class="be-sm-gauge-fill" cx="100" cy="100" r="84" pathLength="100" transform="rotate(-90 100 100)"></circle>
                                                <circle class="be-sm-gauge-shine" cx="100" cy="100" r="84" pathLength="100" transform="rotate(-90 100 100)"></circle>
                                            </svg>
                                        <?php endif; ?>
                                        <div class="be-sm-hero">
                                            <span class="be-sm-score"><?php echo $summary ? esc_html($summary['score']) : '—'; ?></span>
                                            <?php if ($summary): ?><span class="be-sm-max">/100</span><?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="be-sm-grade-row">
                                        <span class="be-sm-grade"><?php echo esc_html($core_grade); ?></span>
                                        <?php if ($summary && $core_delta !== null):
                                            if ($core_delta > 0) { $delta_sign = '+' . $core_delta; $delta_arrow = '&uarr;'; $delta_word = __('Improving', 'bot-eraser'); $delta_tone = 'up'; }
                                            elseif ($core_delta < 0) { $delta_sign = (string) $core_delta; $delta_arrow = '&darr;'; $delta_word = __('Declining', 'bot-eraser'); $delta_tone = 'down'; }
                                            else { $delta_sign = '0'; $delta_arrow = '&rarr;'; $delta_word = __('Stable', 'bot-eraser'); $delta_tone = 'flat'; }
                                        ?>
                                            <span class="be-sm-delta be-sm-delta-<?php echo esc_attr($delta_tone); ?>"><?php echo $delta_arrow; ?> <?php echo esc_html($delta_sign); ?> <?php echo esc_html($delta_word); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($summary): ?>
                                        <div class="be-sm-bar" aria-hidden="true">
                                            <?php $sm_lit = (int) round($score_int / 10); for ($sm_s = 0; $sm_s < 10; $sm_s++): ?>
                                                <span class="be-sm-seg <?php echo $sm_s < $sm_lit ? 'be-sm-seg-on' : ''; ?>"></span>
                                            <?php endfor; ?>
                                        </div>
                                        <?php if (count($core_spark) >= 2):
                                            $sm_pts = array();
                                            $sm_n = count($core_spark);
                                            for ($sm_i = 0; $sm_i < $sm_n; $sm_i++) {
                                                $sm_x = $sm_n > 1 ? round(($sm_i / ($sm_n - 1)) * 100, 2) : 0;
                                                $sm_y = round(100 - $core_spark[$sm_i], 2);
                                                $sm_pts[] = $sm_x . ',' . $sm_y;
                                            }
                                        ?>
                                            <svg class="be-sm-spark" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
                                                <polyline points="<?php echo esc_attr(implode(' ', $sm_pts)); ?>"></polyline>
                                            </svg>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <p class="be-sm-summary"><?php echo esc_html($core_summary); ?></p>
                                    <?php if ($summary && $completed_at): ?>
                                        <p class="be-core-meta"><?php echo esc_html(sprintf(__('%1$s files scanned %2$s ago', 'bot-eraser'), number_format_i18n((int) $summary['files_scanned']), human_time_diff($completed_at))); ?></p>
                                    <?php endif; ?>
                                    <button type="button" class="be-core-cta boteraser-btn boteraser-btn-primary" data-be-trigger="be-scanner-toggle" data-be-scroll="#be-scanner-toggle">
                                        <?php echo esc_html($core_cta_label); ?>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- HIGH Findings -->
                        <div class="be-metric-card high">
                            <div class="be-metric-header">
                                <span class="be-metric-label"><?php _e('High', 'bot-eraser'); ?></span>
                                <?php echo bot_eraser_icon('alert-circle', 'be-metric-icon'); ?>
                            </div>
                            <div class="be-metric-value"><?php echo $summary ? $summary['high'] : 0; ?></div>
                            <div class="be-metric-subtitle"><?php _e('Critical issues', 'bot-eraser'); ?></div>
                        </div>

                        <!-- MEDIUM Findings -->
                        <div class="be-metric-card medium">
                            <div class="be-metric-header">
                                <span class="be-metric-label"><?php _e('Medium', 'bot-eraser'); ?></span>
                                <?php echo bot_eraser_icon('alert-triangle', 'be-metric-icon'); ?>
                            </div>
                            <div class="be-metric-value"><?php echo $summary ? $summary['medium'] : 0; ?></div>
                            <div class="be-metric-subtitle"><?php _e('Warnings', 'bot-eraser'); ?></div>
                        </div>

                        <!-- LOW Findings -->
                        <div class="be-metric-card low">
                            <div class="be-metric-header">
                                <span class="be-metric-label"><?php _e('Low', 'bot-eraser'); ?></span>
                                <?php echo bot_eraser_icon('info', 'be-metric-icon'); ?>
                            </div>
                            <div class="be-metric-value"><?php echo $summary ? $summary['low'] : 0; ?></div>
                            <div class="be-metric-subtitle"><?php _e('Informational', 'bot-eraser'); ?></div>
                        </div>
                    </div>

                    <?php if (!empty($scanner_premium_features)): ?>
                    <div class="be-scanner-premium-panel <?php echo $scanner_premium_enabled ? 'is-enabled' : 'is-locked'; ?>">
                        <div class="be-scanner-premium-panel-header">
                            <div>
                                <p class="be-scanner-premium-panel-eyebrow"><?php _e('Premium Scanner Features', 'bot-eraser'); ?></p>
                                <h3 class="be-scanner-premium-panel-title"><?php _e('Additional cloud-backed coverage', 'bot-eraser'); ?></h3>
                            </div>
                            <span class="be-scanner-premium-panel-badge"><?php echo $scanner_premium_enabled ? esc_html__('Unlocked', 'bot-eraser') : esc_html__('Locked', 'bot-eraser'); ?></span>
                        </div>
                        <p class="be-scanner-premium-panel-copy">
                            <?php echo $scanner_premium_enabled
                                ? esc_html__('Your validated API key unlocks the premium malware intelligence layer shown on the dashboard.', 'bot-eraser')
                                : esc_html__('These premium malware intelligence features are visible on the dashboard and unlock when a valid API key is connected.', 'bot-eraser'); ?>
                        </p>
                        <div class="be-scanner-premium-feature-list">
                            <?php foreach ($scanner_premium_features as $premium_feature): ?>
                            <div class="be-scanner-premium-feature <?php echo !empty($premium_feature['active']) ? 'is-active' : 'is-inactive'; ?>">
                                <span class="be-scanner-premium-feature-mark">
                                    <?php echo !empty($premium_feature['active']) ? bot_eraser_icon('check-circle') : bot_eraser_icon('lock'); ?>
                                </span>
                                <div class="be-scanner-premium-feature-copy">
                                    <strong>
                                        <?php echo esc_html($premium_feature['label']); ?>
                                        <span class="be-scanner-module-badge"><?php _e('Premium', 'bot-eraser'); ?></span>
                                    </strong>
                                    <small>
                                        <?php echo !empty($premium_feature['active'])
                                            ? esc_html__('Available with your current API connection.', 'bot-eraser')
                                            : esc_html__('Available after you connect a valid API key.', 'bot-eraser'); ?>
                                    </small>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Modules column: toggle option cards -->
                <div class="be-scanner-col-modules">
                    <div class="be-scanner-modules be-card-grid-layout">
                        <?php foreach ($scanner_module_groups as $module_group): ?>
                        <div class="be-card-section">
                            <div class="be-card-section-header">
                                <?php if (!empty($module_group['icon'])): ?>
                                <span class="be-card-section-icon"><?php echo bot_eraser_icon($module_group['icon'], 'be-section-icon-svg'); ?></span>
                                <?php endif; ?>
                                <h3 class="be-card-section-title"><?php echo esc_html($module_group['title']); ?></h3>
                                <?php if (!empty($module_group['description'])): ?>
                                <p class="be-card-section-description"><?php echo esc_html($module_group['description']); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="be-card-grid">
                                <?php foreach ($module_group['items'] as $module_item): ?>
                                <?php
                                    $item_id      = esc_attr($module_item['name']);
                                    $is_runtime   = !empty($module_item['runtime']);
                                    $is_premium   = !empty($module_item['premium']);
                                    $is_enabled   = !empty($module_item['enabled']);
                                    $is_locked    = isset($module_item['enabled']) && !$module_item['enabled'];
                                    $item_classes = 'be-feature-card';
                                    if ($is_runtime) {
                                        $item_classes .= ' is-runtime';
                                    } elseif ($is_premium) {
                                        $item_classes .= ' is-premium';
                                        if ($is_enabled) $item_classes .= ' is-enabled';
                                        if ($is_locked) $item_classes .= ' is-locked';
                                    } else {
                                        $item_classes .= ' is-free';
                                    }
                                    if (!$module_item['checked'] && !$is_runtime) {
                                        $item_classes .= ' is-disabled';
                                    }
                                    $input_id = ($module_item['name'] === 'auto_scan_enabled') ? 'be-auto-scan-enabled'
                                              : (($module_item['name'] === 'notify_enabled') ? 'be-notify-enabled'
                                              : (($module_item['name'] === 'auto_scan_files_themes_plugins') ? 'be-auto-scan-files-themes-plugins'
                                              : (($module_item['name'] === 'auto_quarantine') ? 'be-auto-quarantine'
                                              : (($module_item['name'] === 'block_php_uploads') ? 'be-block-php-uploads'
                                              : (($module_item['name'] === 'block_dangerous_ext') ? 'be-block-dangerous-ext'
                                              : (($module_item['name'] === 'auto_quarantine_uploads') ? 'be-auto-quarantine-uploads'
                                              : (($module_item['name'] === 'scan_before_activation') ? 'be-scan-before-activation'
                                              : (($module_item['name'] === 'auto_deactivate_plugins') ? 'be-auto-deactivate-plugins'
                                              : (($module_item['name'] === 'rollback_on_update') ? 'be-rollback-on-update'
                                              : (($module_item['name'] === 'realtime_cloud_scan') ? 'be-realtime-cloud-scan'
                                              : (($module_item['name'] === 'whitelist_safe_plugins') ? 'be-whitelist-safe-plugins'
                                              : (($module_item['name'] === 'waf_ruleset') ? 'be-waf-ruleset' : ''))))))))))));
                                    $icon_name = $module_item['icon'] ?? 'settings';
                                ?>
                                <?php if ($is_runtime): ?>
                                <div class="<?php echo $item_classes; ?>" title="<?php echo esc_attr($module_item['hint']); ?>">
                                    <div class="be-card-icon"><?php echo bot_eraser_icon($icon_name, 'be-card-icon-svg'); ?></div>
                                    <div class="be-card-content">
                                        <div class="be-card-header">
                                            <h4 class="be-card-title"><?php echo esc_html($module_item['label']); ?></h4>
                                            <span class="be-card-badge be-badge-runtime"><?php _e('Runtime', 'bot-eraser'); ?></span>
                                        </div>
                                        <p class="be-card-description"><?php echo esc_html($module_item['hint']); ?></p>
                                    </div>
                                    <div class="be-card-status">
                                        <?php echo $module_item['checked'] ? bot_eraser_icon('check-circle', 'be-status-active') : bot_eraser_icon('x-circle', 'be-status-inactive'); ?>
                                    </div>
                                </div>
                                <?php else: ?>
                                <label class="<?php echo $item_classes; ?>" <?php if ($input_id) echo 'for="' . esc_attr($input_id) . '"'; ?> title="<?php echo esc_attr($module_item['hint']); ?>">
                                    <div class="be-card-icon"><?php echo bot_eraser_icon($icon_name, 'be-card-icon-svg'); ?></div>
                                    <div class="be-card-content">
                                        <div class="be-card-header">
                                            <h4 class="be-card-title"><?php echo esc_html($module_item['label']); ?></h4>
                                            <?php if ($is_premium): ?>
                                                <span class="be-card-badge be-badge-premium"><?php _e('Premium', 'bot-eraser'); ?></span>
                                            <?php else: ?>
                                                <span class="be-card-badge be-badge-free"><?php _e('Free', 'bot-eraser'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if ($module_item['name'] === 'notify_enabled'): ?>
                                            <p class="be-card-description"><?php esc_html_e('Enter one or more email addresses, separated by commas.', 'bot-eraser'); ?></p>
                                        <?php else: ?>
                                            <p class="be-card-description"><?php echo esc_html($module_item['hint']); ?></p>
                                        <?php endif; ?>
                                        <?php if ($module_item['name'] === 'auto_scan_enabled'): ?>
                                        <div class="be-auto-scan-controls <?php echo !$scanner_premium_enabled ? 'is-locked' : ''; ?>" onclick="event.stopPropagation();">
                                            <span class="be-auto-scan-controls-label"><?php _e('Frequency', 'bot-eraser'); ?></span>
                                            <select id="be-auto-scan-interval" <?php disabled(!$scanner_premium_enabled); ?>>
                                                <?php foreach ($auto_scan_intervals as $slug => $label): ?>
                                                <option value="<?php echo esc_attr($slug); ?>" <?php selected($auto_scan_interval, $slug); ?>><?php echo esc_html($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <span class="be-auto-scan-status" id="be-auto-scan-status" aria-live="polite">
                                                <?php if ($scanner_premium_enabled && $auto_scan_enabled && $auto_scan_next): ?>
                                                    <?php printf(esc_html__('Next scan: %s', 'bot-eraser'), esc_html(date_i18n('d.m.Y H:i', $auto_scan_next))); ?>
                                                <?php elseif ($scanner_premium_enabled && $auto_scan_last_run): ?>
                                                    <?php printf(esc_html__('Last scan: %s', 'bot-eraser'), esc_html(date_i18n('d.m.Y H:i', $auto_scan_last_run))); ?>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($module_item['name'] === 'notify_enabled'): ?>
                                        <div class="be-notify-email-row" onclick="event.stopPropagation();">
                                            <input type="text"
                                                id="be-notify-email"
                                                class="be-notify-email-input"
                                                value="<?php echo esc_attr($notify_email); ?>"
                                                placeholder="<?php echo esc_attr(get_option('admin_email') . ', ' . __('another@example.com', 'bot-eraser')); ?>">
                                            <span class="be-auto-scan-status" id="be-notify-email-status" aria-live="polite"></span>
                                            <span class="be-auto-scan-status" id="be-notify-status" aria-live="polite"></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="be-card-toggle">
                                        <input type="checkbox"
                                            <?php if ($input_id) echo 'id="' . esc_attr($input_id) . '" '; ?>name="<?php echo $item_id; ?>"
                                            <?php if ($module_item['checked']) echo 'checked="checked"'; ?>
                                            <?php disabled($is_locked); ?>>
                                        <span class="be-toggle-slider"></span>
                                    </div>
                                </label>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="be-scanner-action-bar">
                        <div class="be-scanner-action-btns">
                            <button type="button" id="be-scanner-toggle" class="boteraser-btn boteraser-btn-primary boteraser-btn-xl">
                                <svg id="be-scanner-toggle-icon-play" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                                <svg id="be-scanner-toggle-icon-stop" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="18" height="18" style="display:none"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>
                                <span id="be-scanner-toggle-label"><?php _e('Start Scan', 'bot-eraser'); ?></span>
                            </button>
                            <button type="button" id="be-baseline-save" class="boteraser-btn boteraser-btn-secondary">
                                <svg class="be-btn-icon-sm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                <?php _e('Save Baseline', 'bot-eraser'); ?>
                            </button>
                        </div>
                        <?php if ($baseline_time): ?>
                        <div class="be-scanner-baseline-time">Baseline: <?php echo date('d.m.Y H:i', $baseline_time); ?></div>
                        <?php endif; ?>
                    </div>

                    <!-- Progress bar (inline, below buttons) -->
                    <div id="be-scanner-progress-wrap" class="be-scanner-progress-wrap be-hidden">
                        <div class="be-scanner-elapsed-row">
                            <span class="be-scanner-elapsed-label"><?php _e('Elapsed', 'bot-eraser'); ?></span>
                            <span id="be-scanner-elapsed" class="be-scanner-elapsed-val">0s</span>
                            <span class="be-scanner-elapsed-label be-scanner-pct-label"><?php _e('Progress', 'bot-eraser'); ?></span>
                            <span id="be-scanner-pct" class="be-scanner-elapsed-val be-scanner-pct-val">0%</span>
                        </div>
                        <div class="boteraser-progress-bar active be-scanner-progress-bar">
                            <div class="boteraser-progress-bar-fill be-progress-bar-fill-static be-progress-bar-fill-slow" id="be-scanner-progress-fill"></div>
                        </div>
                        <div class="be-scanner-progress-meta">
                            <span id="be-scanner-phase-label" class="be-scanner-phase-label"></span>
                            <span id="be-scanner-files-count" class="be-scanner-files-count">0 files</span>
                        </div>
                        <div id="be-scanner-current-file" class="be-scanner-current-file"></div>
                    </div>

                    <div class="be-scanner-summary-strip">
                        <div class="be-scanner-summary-item">
                            <span class="be-scanner-summary-label"><?php _e('Default mode', 'bot-eraser'); ?></span>
                            <strong><?php _e('Balanced integrity scan', 'bot-eraser'); ?></strong>
                        </div>
                        <div class="be-scanner-summary-item">
                            <span class="be-scanner-summary-label"><?php _e('Deep code scan', 'bot-eraser'); ?></span>
                            <strong><?php echo $scanner_premium_enabled ? esc_html__('Premium option unlocked', 'bot-eraser') : esc_html__('Premium option available with API key', 'bot-eraser'); ?></strong>
                        </div>
                        <div class="be-scanner-summary-item">
                            <span class="be-scanner-summary-label"><?php _e('Last runtime', 'bot-eraser'); ?></span>
                            <strong><?php echo $summary ? esc_html($summary['duration']) . 's' : __('Not available', 'bot-eraser'); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Scanner view tabs -->
        <div class="boteraser-snapshot-tabs be-scanner-view-tabs" role="tablist" data-be-scanner>
            <button type="button" class="boteraser-snapshot-tab is-active" data-be-scanner-tab="results" role="tab" aria-selected="true">
                <?php _e('Scan Results', 'bot-eraser'); ?>
            </button>
            <button type="button" class="boteraser-snapshot-tab" data-be-scanner-tab="upload-alerts" role="tab" aria-selected="false">
                <?php _e('Upload Alerts', 'bot-eraser'); ?>
                <?php if ($upload_alert_count > 0): ?>
                    <span class="be-ua-tab-badge"><?php echo $upload_alert_count; ?></span>
                <?php endif; ?>
            </button>
        </div>

        <div data-be-scanner-panel="results">

        <!-- Results Table -->
        <div class="boteraser-card <?php echo empty($visible_findings) ? 'be-hidden' : ''; ?>" id="be-scanner-results-card">
            <div class="boteraser-card-header">
                <h2 class="boteraser-card-title">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
                    Scan Results
                </h2>
                <div class="be-results-filter">
                    <button type="button" class="be-filter-btn active" data-filter="all">All</button>
                    <button type="button" class="be-filter-btn" data-filter="HIGH">HIGH</button>
                    <button type="button" class="be-filter-btn" data-filter="MEDIUM">MEDIUM</button>
                    <button type="button" class="be-filter-btn" data-filter="LOW">LOW</button>
                </div>
            </div>

            <div class="be-findings-summary">
                <div class="be-findings-summary-primary">
                    <span class="be-findings-summary-label"><?php _e('Visible findings', 'bot-eraser'); ?></span>
                    <strong><?php echo number_format($visible_findings_total); ?></strong>
                    <p><?php _e('Review high-severity rows first, then quarantine or ignore only after verification.', 'bot-eraser'); ?></p>
                </div>
                <div class="be-findings-summary-breakdown">
                    <span class="be-findings-chip high"><?php echo number_format($visible_findings_counts['HIGH']); ?> HIGH</span>
                    <span class="be-findings-chip medium"><?php echo number_format($visible_findings_counts['MEDIUM']); ?> MEDIUM</span>
                    <span class="be-findings-chip low"><?php echo number_format($visible_findings_counts['LOW']); ?> LOW</span>
                </div>
            </div>

            <div class="boteraser-table-wrapper">
                <table class="boteraser-table" id="be-findings-table">
                    <thead>
                        <tr>
                            <th class="be-findings-col-severity">Severity</th>
                            <th>File / Location</th>
                            <th>Detection Type</th>
                            <th class="be-findings-col-score">Score</th>
                            <th class="be-findings-col-action">Action</th>
                        </tr>
                    </thead>
                    <tbody id="be-findings-tbody">
                        <?php foreach ($visible_findings as $finding):
                            $sev = $finding['severity'];
                            $file = $finding['file'];
                            $score = $finding['score'];
                            $label = $finding['findings'][0]['label'] ?? '';
                            $details = $finding['findings'][0]['details'] ?? '';
                        ?>
                        <tr class="be-finding-row be-finding-row-<?php echo esc_attr(strtolower($sev)); ?>" data-severity="<?php echo esc_attr($sev); ?>" data-file="<?php echo esc_attr($file); ?>">
                            <td>
                                <span class="be-severity-badge <?php echo strtolower($sev); ?>"><?php echo $sev; ?></span>
                            </td>
                            <td>
                                <span class="be-file-path" title="<?php echo esc_attr($file); ?>"><?php echo esc_html($file); ?></span>
                                <?php if ($details): ?>
                                <div class="be-finding-detail"><?php echo esc_html(substr($details, 0, 120)); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="be-detection-type-cell">
                                    <strong><?php echo esc_html($label); ?></strong>
                                    <span><?php echo $sev === 'HIGH' ? esc_html__('Immediate review recommended', 'bot-eraser') : ($sev === 'MEDIUM' ? esc_html__('Needs confirmation before action', 'bot-eraser') : esc_html__('Low-confidence signal', 'bot-eraser')); ?></span>
                                </div>
                            </td>
                            <td><span class="be-score-pill <?php echo strtolower($sev); ?>"><?php echo $score; ?></span></td>
                            <td class="be-action-btns">
                                <?php
                                $is_diffable = !in_array($finding['ext'], array('db', 'cron'), true)
                                    && (
                                        strpos($file, 'wp-includes/') === 0
                                        || strpos($file, 'wp-admin/') === 0
                                        || strpos($file, 'wp-content/plugins/') === 0
                                        || strpos($file, 'wp-content/themes/') === 0
                                        || preg_match('/^wp-[a-z].*\.php$/', $file)
                                    );
                                ?>
                                <?php if ($is_diffable): ?>
                                <button type="button" class="boteraser-btn boteraser-btn-primary boteraser-btn-sm be-btn-diff" data-file="<?php echo esc_attr($file); ?>">View Diff</button>
                                <?php endif; ?>
                                <?php if ($finding['ext'] !== 'db' && $finding['ext'] !== 'cron'): ?>
                                <button type="button" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-btn-quarantine be-btn-action-safe" data-file="<?php echo esc_attr($file); ?>">Quarantine</button>
                                <button type="button" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-btn-delete be-btn-action-danger" data-file="<?php echo esc_attr($file); ?>">Delete</button>
                                <?php endif; ?>
                                <button type="button" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-btn-whitelist be-btn-action-muted" data-file="<?php echo esc_attr($file); ?>">Ignore</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Empty state -->
        <?php if ($summary && empty($visible_findings)): ?>
        <div class="boteraser-card" id="be-scanner-empty-state-card">
            <div class="boteraser-empty-state">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>
                <p>No malware found</p>
                <p>Your site looks clean. Last scan: <?php echo date('d.m.Y H:i', $completed_at); ?></p>
            </div>
        </div>
        <?php else: ?>
        <div class="boteraser-card be-hidden" id="be-scanner-empty-state-card">
            <div class="boteraser-empty-state">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>
                <p>No malware found</p>
                <p>The latest scan finished clean.</p>
            </div>
        </div>
        <?php endif; ?>

        </div><!-- /data-be-scanner-panel="results" -->

        <!-- Upload Alerts Panel -->
        <div data-be-scanner-panel="upload-alerts" hidden>
            <div class="boteraser-card" id="be-upload-alerts-card">
                <div class="boteraser-card-header">
                    <h2 class="boteraser-card-title">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18"><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path><polyline points="16 16 12 12 8 16"></polyline><line x1="12" y1="12" x2="12" y2="21"></line></svg>
                        <?php _e('Upload Alerts', 'bot-eraser'); ?>
                        <?php if ($upload_alert_count > 0): ?>
                            <span class="be-ua-tab-badge be-ua-title-badge"><?php echo $upload_alert_count; ?></span>
                        <?php endif; ?>
                    </h2>
                    <?php if ($upload_alert_count > 0): ?>
                    <button type="button" id="be-ua-dismiss-all"
                            class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm"
                            data-nonce="<?php echo esc_attr($upload_alert_nonce); ?>">
                        <?php _e('Dismiss All', 'bot-eraser'); ?>
                    </button>
                    <?php endif; ?>
                </div>

                <p class="boteraser-card-intro">
                    <?php _e('Files, plugins, and themes that were scanned on upload or installation and flagged as suspicious. Dismiss alerts only after reviewing the findings.', 'bot-eraser'); ?>
                </p>

                <?php if (empty($upload_alerts)): ?>
                    <div class="boteraser-empty-state">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>
                        <p><?php _e('No upload alerts', 'bot-eraser'); ?></p>
                        <p><?php _e('All uploads and installations have been clean so far.', 'bot-eraser'); ?></p>
                    </div>
                <?php else: ?>
                    <div class="boteraser-table-wrapper">
                        <table class="boteraser-table" id="be-ua-table">
                            <thead>
                                <tr>
                                    <th class="be-findings-col-severity"><?php _e('Severity', 'bot-eraser'); ?></th>
                                    <th><?php _e('Type', 'bot-eraser'); ?></th>
                                    <th><?php _e('Name', 'bot-eraser'); ?></th>
                                    <th><?php _e('Findings', 'bot-eraser'); ?></th>
                                    <th><?php _e('Date', 'bot-eraser'); ?></th>
                                    <th class="be-findings-col-action"><?php _e('Action', 'bot-eraser'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="be-ua-tbody">
                                <?php foreach ($upload_alerts as $idx => $alert):
                                    $sev       = strtoupper($alert['severity'] ?? 'HIGH');
                                    $type      = $alert['type'] ?? 'file';
                                    $type_icons = array('plugin' => '🔌', 'theme' => '🎨', 'file' => '📄');
                                    $type_icon  = $type_icons[$type] ?? '📄';
                                    $type_label = ucfirst($type);
                                    $alert_time = isset($alert['time']) ? date_i18n('d.m.Y H:i', $alert['time']) : '—';
                                    $findings_list = array_slice($alert['findings'] ?? array(), 0, 3);
                                    $extra = max(0, count($alert['findings'] ?? array()) - 3);
                                    $is_quarantined = $alert['findings'][0]['_quarantined'] ?? false;
                                    $quarantined_files = $alert['findings'][0]['_quarantined_files'] ?? array();
                                    $deactivated_plugin = $alert['findings'][0]['_deactivated_plugin'] ?? null;
                                ?>
                                <tr class="be-ua-row" data-idx="<?php echo $idx; ?>">
                                    <td style="white-space:nowrap;">
                                        <span class="be-severity-badge <?php echo strtolower($sev); ?>"><?php echo esc_html($sev); ?></span>
                                        <?php if ($is_quarantined): ?>
                                            <span class="be-severity-badge" style="background:#0f766e;color:#fff;border-color:#0f766e;margin-left:4px;">&#128274; <?php _e('Quarantined', 'bot-eraser'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><span title="<?php echo esc_attr($type_label); ?>"><?php echo $type_icon; ?> <?php echo esc_html($type_label); ?></span></td>
                                    <td>
                                        <span class="be-file-path" title="<?php echo esc_attr($alert['name'] ?? ''); ?>"><?php echo esc_html($alert['name'] ?? '—'); ?></span>
                                        <?php if ($is_quarantined && count($quarantined_files) > 0): ?>
                                            <div style="font-size:11px;color:#0f766e;margin-top:2px;">
                                                <?php echo esc_html(sprintf(__('%d file(s) quarantined', 'bot-eraser'), count($quarantined_files))); ?>
                                                <?php if ($deactivated_plugin): ?>
                                                    &middot; <?php _e('auto-deactivated', 'bot-eraser'); ?>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <ul class="be-ua-findings-list">
                                            <?php foreach ($findings_list as $f): ?>
                                                <li><?php echo esc_html($f['label'] ?? $f['type'] ?? '—'); ?></li>
                                            <?php endforeach; ?>
                                            <?php if ($extra > 0): ?>
                                                <li class="be-ua-findings-more">+<?php echo $extra; ?> <?php _e('more', 'bot-eraser'); ?></li>
                                            <?php endif; ?>
                                        </ul>
                                    </td>
                                    <td><span class="be-ua-date"><?php echo esc_html($alert_time); ?></span></td>
                                    <td class="be-action-btns">
                                        <?php if ($is_quarantined): ?>
                                            <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-quarantine')); ?>"
                                               class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm" style="margin-right:4px;">
                                                &#128274; <?php _e('Quarantine', 'bot-eraser'); ?>
                                            </a>
                                        <?php endif; ?>
                                        <button type="button"
                                                class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-ua-dismiss-one"
                                                data-idx="<?php echo $idx; ?>"
                                                data-nonce="<?php echo esc_attr($upload_alert_nonce); ?>">
                                            <?php _e('Dismiss', 'bot-eraser'); ?>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div><!-- /data-be-scanner-panel="upload-alerts" -->

    </div>

    <!-- Confirm modal -->
    <div id="be-confirm-modal" class="be-confirm-modal be-hidden">
        <div class="be-confirm-modal-dialog">
            <h3 id="be-modal-title" class="be-confirm-modal-title"></h3>
            <p id="be-modal-body" class="be-confirm-modal-body"></p>
            <div class="be-confirm-modal-actions">
                <button type="button" id="be-modal-cancel" class="boteraser-btn boteraser-btn-secondary">Cancel</button>
                <button type="button" id="be-modal-confirm" class="boteraser-btn boteraser-btn-primary">Confirm</button>
            </div>
        </div>
    </div>

    <!-- File diff modal -->
    <div id="be-diff-modal" class="be-diff-modal" >
        <div id="be-diff-modal-overlay" class="be-diff-modal-overlay"></div>
        <div class="be-diff-modal-dialog">
            <div class="be-diff-modal-header">
                <div class="be-diff-modal-title-row">
                    <span class="be-diff-modal-icon">&#128269;</span>
                    <div>
                        <div class="be-diff-modal-title">File Comparison</div>
                        <div class="be-diff-modal-file" id="be-diff-file-name"></div>
                    </div>
                </div>
                <button type="button" id="be-diff-modal-close" class="be-diff-modal-close" title="Close">&times;</button>
            </div>
            <div id="be-diff-loading" class="be-diff-loading">
                <div class="be-diff-spinner"></div>
                <span>Fetching original from WordPress.org&hellip;</span>
            </div>
            <div id="be-diff-error" class="be-diff-error" ></div>
            <div id="be-diff-clean" class="be-diff-clean" >
                <div class="be-diff-clean-icon">&#10003;</div>
                <strong><?php _e('File is identical to the original', 'bot-eraser'); ?></strong>
                <p><?php _e('This file matches the official WordPress.org version exactly. It has most likely not been modified or compromised.', 'bot-eraser'); ?></p>
            </div>
            <div id="be-diff-content" class="be-diff-content" >
                <div class="be-diff-source-row">
                    <span class="be-diff-source-badge">Source: <strong id="be-diff-source-label"></strong></span>
                    <span class="be-diff-legend">
                        <span class="be-diff-legend-del">&#9646; Removed (original)</span>
                        <span class="be-diff-legend-add">&#9646; Added (compromised)</span>
                    </span>
                </div>
                <div class="be-diff-columns">
                    <div class="be-diff-col">
                        <div class="be-diff-col-header">Original (WordPress.org)</div>
                        <pre class="be-diff-pre" id="be-diff-original"></pre>
                    </div>
                    <div class="be-diff-col">
                        <div class="be-diff-col-header be-diff-col-header-current">Current file (possibly compromised)</div>
                        <pre class="be-diff-pre" id="be-diff-current"></pre>
                    </div>
                </div>
            </div>
            <div class="be-diff-modal-footer">
                <span class="be-diff-warning">&#9888; A backup will be saved automatically before replacing the file.</span>
                <div class="be-diff-footer-actions">
                    <button type="button" id="be-diff-modal-close-btn" class="boteraser-btn boteraser-btn-secondary" onclick="jQuery('#be-diff-modal').hide();">Close</button>
                    <button type="button" id="be-diff-restore-btn" class="boteraser-btn boteraser-btn-primary">
                        &#8635; Restore Original File
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Quarantine page render
 */
function boteraser_render_quarantine_page() {
    if (!current_user_can('manage_options')) return;

    require_once BOT_ERASER_PLUGIN_DIR . 'includes/quarantine.php';

    $items     = boteraser_quarantine_list();
    $total     = count($items);
    $total_size = 0;
    foreach ($items as $entry) {
        $total_size += (int) ($entry['size'] ?? 0);
    }

    $download_action_url = admin_url('admin-post.php');
    $download_nonce      = wp_create_nonce('boteraser_quarantine_download');

    wp_localize_script('boteraser-admin', 'boteraser_quarantine', array(
        'ajaxUrl'      => admin_url('admin-ajax.php'),
        'nonce'        => wp_create_nonce('boteraser_scan_nonce'),
        'emptyTitle'   => __('No files in quarantine', 'bot-eraser'),
        'emptyMessage' => __('When you quarantine a finding from the Security Scan, it will appear here. Files are stored outside the web root and protected from direct access.', 'bot-eraser'),
    ));
    $quarantine_header_metrics = array(
        array(
            'id'    => 'be-q-kpi-items',
            'label' => __('Items', 'bot-eraser'),
            'value' => number_format($total),
        ),
        array(
            'id'    => 'be-q-kpi-size',
            'label' => __('Total size', 'bot-eraser'),
            'value' => size_format($total_size, 1) ?: '0 B',
        ),
        array(
            'label'      => __('Storage path', 'bot-eraser'),
            'value'      => 'wp-content/uploads/boteraser/quarantine/',
            'value_class'=> 'boteraser-hero-inline-value-mono',
        ),
    );

    // Aside: newest + oldest entry timestamps. Listed is already
    // sorted newest-first, so first/last give the bookends cheaply.
    $newest_ts = $total > 0 ? (int) ($items[array_key_first($items)]['quarantined_at'] ?? 0) : 0;
    $oldest_ts = $total > 0 ? (int) ($items[array_key_last($items)]['quarantined_at'] ?? 0) : 0;
    $aside_rows = '';
    $rendered_q_rows = 0;
    if ($total > 0) {
        $aside_rows .= sprintf(
            '<li class="boteraser-hero-aside-item"><span class="boteraser-hero-aside-item-key">%s</span><span class="boteraser-hero-aside-item-val">%s</span></li>',
            esc_html__('Newest', 'bot-eraser'),
            $newest_ts ? esc_html(human_time_diff($newest_ts) . ' ' . __('ago', 'bot-eraser')) : '—'
        );
        $aside_rows .= sprintf(
            '<li class="boteraser-hero-aside-item"><span class="boteraser-hero-aside-item-key">%s</span><span class="boteraser-hero-aside-item-val">%s</span></li>',
            esc_html__('Oldest', 'bot-eraser'),
            $oldest_ts ? esc_html(human_time_diff($oldest_ts) . ' ' . __('ago', 'bot-eraser')) : '—'
        );
        $rendered_q_rows = 2;
    } else {
        $aside_rows = '<li class="boteraser-hero-aside-item is-empty">' . esc_html__('Quarantine is empty.', 'bot-eraser') . '</li>';
        $rendered_q_rows = 1;
    }
    for ($i = $rendered_q_rows; $i < 4; $i++) {
        $aside_rows .= '<li class="boteraser-hero-aside-item is-placeholder"><span class="boteraser-hero-aside-item-key">·</span><span class="boteraser-hero-aside-item-val">·</span></li>';
    }
    $quarantine_aside = sprintf(
        '<div class="boteraser-hero-aside boteraser-hero-aside-list"><p class="boteraser-hero-aside-eyebrow">%s</p><h3 class="boteraser-hero-aside-title">%s</h3><ul class="boteraser-hero-aside-items">%s</ul><p class="boteraser-hero-aside-foot is-placeholder">·</p></div>',
        esc_html__('Quarantine summary', 'bot-eraser'),
        esc_html(sprintf(_n('%s file held', '%s files held', $total, 'bot-eraser'), number_format_i18n($total))),
        $aside_rows
    );
    ?>
    <div class="wrap boteraser-wrap">
        <?php bot_eraser_render_page_header(array(
            'variant'   => 'standard',
            'modifiers' => array('boteraser-hero-quarantine'),
            'title'     => __('Quarantined Files', 'bot-eraser'),
            'subtitle'  => __('Files moved out of the web root from the Security Scan. Restore, delete or download them for forensic review.', 'bot-eraser'),
            'metrics'   => $quarantine_header_metrics,
            'aside'     => $quarantine_aside,
        )); ?>

        <div class="boteraser-card be-quarantine-card">
            <div class="boteraser-card-header">
                <h2 class="boteraser-card-title">
                    <?php echo bot_eraser_icon('shield'); ?>
                    <?php _e('Quarantine Inventory', 'bot-eraser'); ?>
                </h2>
                <div class="be-quarantine-card-actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser-scanner')); ?>" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm">
                        <?php echo bot_eraser_icon('shield-check'); ?>
                        <?php _e('Back to Scanner', 'bot-eraser'); ?>
                    </a>
                </div>
            </div>

            <?php if (empty($items)): ?>
                <div class="be-quarantine-empty">
                    <?php echo bot_eraser_icon('shield-check'); ?>
                    <h3><?php _e('No files in quarantine', 'bot-eraser'); ?></h3>
                    <p><?php _e('When you quarantine a finding from the Security Scan, it will appear here. Files are stored outside the web root and protected from direct access.', 'bot-eraser'); ?></p>
                </div>
            <?php else: ?>
                <div class="boteraser-table-wrapper">
                    <table class="boteraser-table be-quarantine-table">
                        <thead>
                            <tr>
                                <th><?php _e('Original Path', 'bot-eraser'); ?></th>
                                <th><?php _e('Severity', 'bot-eraser'); ?></th>
                                <th><?php _e('Size', 'bot-eraser'); ?></th>
                                <th><?php _e('Quarantined', 'bot-eraser'); ?></th>
                                <th class="be-quarantine-actions-col"><?php _e('Actions', 'bot-eraser'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $entry):
                                $severity = strtolower($entry['severity'] ?? '');
                                $sev_label = $entry['severity'] ?: '—';
                                $stored = $entry['stored_name'] ?? '';
                                $download_url = add_query_arg(array(
                                    'action'      => 'boteraser_quarantine_download',
                                    'stored_name' => rawurlencode($stored),
                                    '_wpnonce'    => $download_nonce,
                                ), $download_action_url);
                            ?>
                            <tr data-stored="<?php echo esc_attr($stored); ?>" data-bytes="<?php echo (int) ($entry['size'] ?? 0); ?>">
                                <td>
                                    <span class="be-quarantine-path" title="<?php echo esc_attr($entry['original_path']); ?>">
                                        <?php echo esc_html($entry['original_path']); ?>
                                    </span>
                                    <span class="be-quarantine-stored-name"><?php echo esc_html($stored); ?></span>
                                </td>
                                <td>
                                    <?php if ($sev_label !== '—'): ?>
                                        <span class="boteraser-finding-pill <?php echo esc_attr($severity); ?>"><?php echo esc_html($sev_label); ?></span>
                                    <?php else: ?>
                                        <span class="be-quarantine-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html(size_format((int) ($entry['size'] ?? 0), 1) ?: '0 B'); ?></td>
                                <td>
                                    <?php
                                    $ts = (int) ($entry['quarantined_at'] ?? 0);
                                    if ($ts) {
                                        echo esc_html(date_i18n('M j, Y H:i', $ts));
                                        echo ' <span class="be-quarantine-muted">(' . esc_html(human_time_diff($ts, time())) . ' ago)</span>';
                                    } else {
                                        echo '—';
                                    }
                                    ?>
                                </td>
                                <td class="be-quarantine-actions-col">
                                    <div class="be-quarantine-actions">
                                        <button type="button" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-q-restore" data-stored="<?php echo esc_attr($stored); ?>">
                                            <?php echo bot_eraser_icon('arrow-up'); ?>
                                            <?php _e('Restore', 'bot-eraser'); ?>
                                        </button>
                                        <a href="<?php echo esc_url($download_url); ?>" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm">
                                            <?php echo bot_eraser_icon('database'); ?>
                                            <?php _e('Download', 'bot-eraser'); ?>
                                        </a>
                                        <button type="button" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-q-delete" data-stored="<?php echo esc_attr($stored); ?>">
                                            <?php echo bot_eraser_icon('x-circle'); ?>
                                            <?php _e('Delete', 'bot-eraser'); ?>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <div class="be-quarantine-help">
                <p>
                    <strong><?php _e('Restore', 'bot-eraser'); ?></strong>
                    <?php _e('moves the file back to its original path. The original location must be empty for restore to succeed.', 'bot-eraser'); ?>
                </p>
                <p>
                    <strong><?php _e('Download', 'bot-eraser'); ?></strong>
                    <?php _e('streams the raw bytes (with a .bin extension to neutralize accidental execution) for forensic analysis.', 'bot-eraser'); ?>
                </p>
                <p>
                    <strong><?php _e('Delete', 'bot-eraser'); ?></strong>
                    <?php _e('permanently removes the file from disk. This cannot be undone.', 'bot-eraser'); ?>
                </p>
            </div>
        </div>
    </div>

    <div id="be-confirm-modal" class="be-confirm-modal be-hidden">
        <div class="be-confirm-modal-dialog">
            <h3 id="be-modal-title" class="be-confirm-modal-title"></h3>
            <p id="be-modal-body" class="be-confirm-modal-body"></p>
            <div class="be-confirm-modal-actions">
                <button type="button" id="be-modal-cancel" class="boteraser-btn boteraser-btn-secondary">Cancel</button>
                <button type="button" id="be-modal-confirm" class="boteraser-btn boteraser-btn-primary">Confirm</button>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Clean up duplicate API key entries
 */
function bot_eraser_cleanup_api_key_entries() {
    global $wpdb;

    $current_api_key = $wpdb->get_var($wpdb->prepare(
        "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1",
        'bot_eraser_api_key'
    ));

    $total_entries = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name = %s",
        'bot_eraser_api_key'
    ));

    if ($total_entries > 1) {
        $wpdb->delete($wpdb->options, array('option_name' => 'bot_eraser_api_key'));

        if (!empty($current_api_key)) {
            $wpdb->insert(
                $wpdb->options,
                array(
                    'option_name' => 'bot_eraser_api_key',
                    'option_value' => $current_api_key,
                    'autoload' => 'yes'
                ),
                array('%s', '%s', '%s')
            );
        }

        wp_cache_delete('bot_eraser_api_key', 'options');
        wp_cache_delete('alloptions', 'options');
        wp_cache_flush();

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Boteraser: Cleaned up duplicate API key entries');
        }

        return true;
    }

    return false;
}

/**
 * Simple hash function for API key comparison
 */
function bot_eraser_simple_hash($str) {
    $hash = 0;
    $len = strlen($str);
    if ($len === 0) return (string)$hash;

    for ($i = 0; $i < $len; $i++) {
        $char = ord($str[$i]);
        $hash = (($hash << 5) - $hash) + $char;
        $hash = $hash & 0xFFFFFFFF;
        if ($hash > 0x7FFFFFFF) {
            $hash -= 0x100000000;
        }
    }
    return dechex(abs($hash));
}

function bot_eraser_ajax_manual_run() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied', 403);
    }
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bot_eraser_manual_run')) {
        wp_send_json_error('Security check failed', 403);
    }
    if (!get_option('bot_eraser_privacy_notice_dismissed')) {
        wp_send_json_error('Privacy notice must be accepted');
    }

    update_option('bot_eraser_last_manual_run', time());
    $result = bot_eraser_send_data_to_server('manual');
    wp_send_json_success($result);
}
add_action('wp_ajax_bot_eraser_manual_run', 'bot_eraser_ajax_manual_run');

/**
 * AJAX handler for Brute Force settings (toggle + threshold).
 */
function boteraser_ajax_save_bf_settings() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied', 403);
    }
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'boteraser_ajax')) {
        wp_send_json_error('Security check failed', 403);
    }

    $enabled      = !empty($_POST['enabled']) && $_POST['enabled'] !== '0';
    $max_attempts = isset($_POST['max_attempts']) ? max(1, min(50, (int) $_POST['max_attempts'])) : 5;
    $window_min   = isset($_POST['window_minutes']) ? max(1, min(1440, (int) $_POST['window_minutes'])) : 15;
    $block_min    = isset($_POST['block_minutes']) ? max(1, min(1440, (int) $_POST['block_minutes'])) : 15;

    update_option('boteraser_bf_enabled', $enabled, false);
    update_option('boteraser_bf_max_attempts', $max_attempts, false);
    update_option('boteraser_bf_window_minutes', $window_min, false);
    update_option('boteraser_bf_block_minutes', $block_min, false);

    wp_cache_delete('boteraser_bf_enabled', 'options');
    wp_cache_delete('boteraser_bf_max_attempts', 'options');
    wp_cache_delete('boteraser_bf_window_minutes', 'options');
    wp_cache_delete('boteraser_bf_block_minutes', 'options');
    wp_cache_delete('alloptions', 'options');

    wp_send_json_success(array(
        'enabled'       => $enabled,
        'max_attempts'  => $max_attempts,
        'window_minutes' => $window_min,
        'block_minutes' => $block_min,
    ));
}
add_action('wp_ajax_boteraser_save_bf_settings', 'boteraser_ajax_save_bf_settings');

/**
 * AJAX handler for the visitor IP source. Whitelisted values only; anything else
 * falls back to the safe 'remote_addr'. Returns the freshly detected IP for the UI.
 */
function boteraser_ajax_save_ip_source() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied', 403);
    }
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'boteraser_ajax')) {
        wp_send_json_error('Security check failed', 403);
    }

    $allowed = array('remote_addr', 'cloudflare', 'x_forwarded_for', 'x_real_ip');
    $source  = isset($_POST['source']) ? sanitize_text_field(wp_unslash($_POST['source'])) : 'remote_addr';
    if (!in_array($source, $allowed, true)) {
        $source = 'remote_addr';
    }

    update_option('bot_eraser_ip_source', $source, false);
    wp_cache_delete('bot_eraser_ip_source', 'options');
    wp_cache_delete('alloptions', 'options');

    wp_send_json_success(array(
        'source'   => $source,
        'detected' => function_exists('bot_eraser_get_visitor_ip') ? bot_eraser_get_visitor_ip() : '',
    ));
}
add_action('wp_ajax_boteraser_save_ip_source', 'boteraser_ajax_save_ip_source');

/**
 * AJAX handler: trigger an immediate WAF ruleset sync from the dashboard.
 */
function boteraser_ajax_waf_sync() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied', 403);
    }
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'boteraser_ajax')) {
        wp_send_json_error('Security check failed', 403);
    }
    if (!function_exists('bot_eraser_waf_sync')) {
        wp_send_json_error('WAF sync unavailable');
    }

    bot_eraser_waf_sync();

    $synced = (int) get_option('bot_eraser_waf_synced', 0);
    wp_send_json_success(array(
        'count'        => (int) get_option('bot_eraser_waf_count', 0),
        'synced_label' => $synced > 0
            ? sprintf(__('%s ago', 'bot-eraser'), human_time_diff($synced))
            : __('never', 'bot-eraser'),
    ));
}
add_action('wp_ajax_boteraser_waf_sync', 'boteraser_ajax_waf_sync');

/**
 * AJAX handler: trigger an immediate threat-list sync from the dashboard and
 * return the refreshed per-list counts / timestamps + country status.
 */
function boteraser_ajax_list_sync() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied', 403);
    }
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'boteraser_ajax')) {
        wp_send_json_error('Security check failed', 403);
    }
    if (!function_exists('bot_eraser_list_sync')) {
        wp_send_json_error('List sync unavailable');
    }

    bot_eraser_list_sync();

    $lists = array();
    foreach (array('blacklist_ips', 'blacklist_bots', 'blacklist', 'rate_limited_bots', 'greylist', 'whitelist') as $name) {
        $synced = (int) get_option('bot_eraser_list_synced_' . $name, 0);
        $lists[$name] = array(
            'count' => number_format_i18n((int) get_option('bot_eraser_list_count_' . $name, 0)),
            'when'  => $synced > 0 ? sprintf(__('%s ago', 'bot-eraser'), human_time_diff($synced)) : __('never', 'bot-eraser'),
        );
    }

    $map     = bot_eraser_get_map();
    $country = is_array($map) && isset($map['country']) ? $map['country'] : array();

    wp_send_json_success(array(
        'lists'   => $lists,
        'country' => !empty($country['enabled'])
            ? number_format_i18n((int) ($country['count'] ?? 0))
            : __('Off', 'bot-eraser'),
    ));
}
add_action('wp_ajax_boteraser_list_sync', 'boteraser_ajax_list_sync');

function boteraser_render_vulnerabilities_page() {
    if (!current_user_can('manage_options')) return;
    $data = bot_eraser_vuln_get_data();
    $summary = bot_eraser_vuln_get_summary();
    $results = isset($data['results']) ? $data['results'] : array();
    $checked_at = isset($data['checked_at']) ? (int) $data['checked_at'] : 0;
    $filter = isset($_GET['severity']) ? sanitize_text_field($_GET['severity']) : 'all';
    $header_metrics = array(
        array('label' => __('Critical', 'bot-eraser'), 'value' => number_format($summary['critical']), 'value_class' => 'boteraser-hero-inline-value-critical'),
        array('label' => __('Warnings', 'bot-eraser'), 'value' => number_format($summary['warning']), 'value_class' => 'boteraser-hero-inline-value-warning'),
        array('label' => __('Info', 'bot-eraser'), 'value' => number_format($summary['info']), 'value_class' => 'boteraser-hero-inline-value-info'),
    );
    $aside_rows = '';
    if ($checked_at) {
        $aside_rows .= sprintf('<li class="boteraser-hero-aside-item"><span class="boteraser-hero-aside-item-key">%s</span><span class="boteraser-hero-aside-item-val">%s</span></li>', esc_html__('Last checked', 'bot-eraser'), esc_html(human_time_diff($checked_at) . ' ' . __('ago', 'bot-eraser')));
    } else {
        $aside_rows .= '<li class="boteraser-hero-aside-item is-empty">' . esc_html__('Not yet checked', 'bot-eraser') . '</li>';
    }
    $aside_rows .= sprintf('<li class="boteraser-hero-aside-item"><span class="boteraser-hero-aside-item-key">%s</span><span class="boteraser-hero-aside-item-val">%s</span></li>', esc_html__('Source', 'bot-eraser'), esc_html__('Boteraser Cloud', 'bot-eraser'));
    for ($i = 2; $i < 4; $i++) { $aside_rows .= '<li class="boteraser-hero-aside-item is-placeholder"><span class="boteraser-hero-aside-item-key">·</span><span class="boteraser-hero-aside-item-val">·</span></li>'; }
    $aside = sprintf('<div class="boteraser-hero-aside boteraser-hero-aside-list"><p class="boteraser-hero-aside-eyebrow">%s</p><h3 class="boteraser-hero-aside-title">%s</h3><ul class="boteraser-hero-aside-items">%s</ul><p class="boteraser-hero-aside-foot is-placeholder">·</p></div>', esc_html__('Vulnerability check', 'bot-eraser'), esc_html(sprintf(_n('%d vulnerability found', '%d vulnerabilities found', $summary['total'], 'bot-eraser'), $summary['total'])), $aside_rows);
    wp_localize_script('boteraser-admin', 'boteraser_vuln', array(
        'ajaxUrl'        => admin_url('admin-ajax.php'),
        'nonce'          => wp_create_nonce('boteraser_vuln_nonce'),
        'iconLoader'     => bot_eraser_icon('loader'),
        'lblChecking'    => __('Checking...', 'bot-eraser'),
        'lblCheckFailed' => __('Check failed.', 'bot-eraser'),
        'lblNetworkError'=> __('Network error.', 'bot-eraser'),
    ));
    $all_items = array();
    foreach ($results as $software => $item) {
        $vulns = isset($item['vulnerabilities']) ? $item['vulnerabilities'] : array();
        foreach ($vulns as $v) { $all_items[] = array_merge($v, array('software' => $software, 'version' => isset($item['version']) ? $item['version'] : '')); }
    }
    if ($filter !== 'all') { $all_items = array_filter($all_items, function($v) use ($filter) { $sev = isset($v['severity']) ? (float) $v['severity'] : 0; if ($filter === 'critical') return $sev >= 7.0; if ($filter === 'warning') return $sev >= 4.0 && $sev < 7.0; if ($filter === 'info') return $sev < 4.0; return true; }); }
    ?>
    <div class="wrap boteraser-wrap">
        <?php bot_eraser_render_page_header(array('variant' => 'standard', 'modifiers' => array('boteraser-hero-vulnerabilities'), 'title' => __('Vulnerabilities', 'bot-eraser'), 'subtitle' => __('Known CVEs in WordPress core, plugins, themes, and server software.', 'bot-eraser'), 'metrics' => $header_metrics, 'aside' => $aside)); ?>
        <div class="boteraser-card">
            <div class="boteraser-card-header"><h2 class="boteraser-card-title"><?php echo bot_eraser_icon('shield'); ?> <?php _e('Vulnerability Findings', 'bot-eraser'); ?></h2><div class="be-vuln-card-actions"><button type="button" id="be-vuln-check-btn" class="boteraser-btn boteraser-btn-primary boteraser-btn-sm"><?php echo bot_eraser_icon('refresh-cw'); ?> <?php _e('Check Now', 'bot-eraser'); ?></button><a href="<?php echo esc_url(admin_url('admin.php?page=bot-eraser')); ?>" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm"><?php echo bot_eraser_icon('settings'); ?> <?php _e('System Software', 'bot-eraser'); ?></a></div></div>
            <div class="be-vuln-filters">
                <a href="<?php echo esc_url(add_query_arg('severity', 'all')); ?>" class="boteraser-filter-btn <?php echo $filter === 'all' ? 'is-active' : ''; ?>"><?php _e('All', 'bot-eraser'); ?></a>
                <a href="<?php echo esc_url(add_query_arg('severity', 'critical')); ?>" class="boteraser-filter-btn critical <?php echo $filter === 'critical' ? 'is-active' : ''; ?>"><?php _e('Critical', 'bot-eraser'); ?> (<?php echo $summary['critical']; ?>)</a>
                <a href="<?php echo esc_url(add_query_arg('severity', 'warning')); ?>" class="boteraser-filter-btn warning <?php echo $filter === 'warning' ? 'is-active' : ''; ?>"><?php _e('Warning', 'bot-eraser'); ?> (<?php echo $summary['warning']; ?>)</a>
                <a href="<?php echo esc_url(add_query_arg('severity', 'info')); ?>" class="boteraser-filter-btn info <?php echo $filter === 'info' ? 'is-active' : ''; ?>"><?php _e('Info', 'bot-eraser'); ?> (<?php echo $summary['info']; ?>)</a>
            </div>
            <?php if (empty($all_items)): ?>
                <div class="be-vuln-empty"><?php echo bot_eraser_icon('shield-check'); ?><h3><?php _e('No vulnerabilities found', 'bot-eraser'); ?></h3><p><?php _e('All installed software appears to be up to date.', 'bot-eraser'); ?></p></div>
            <?php else: ?>
                <div class="boteraser-table-wrapper"><table class="boteraser-table be-vuln-table"><thead><tr><th><?php _e('Software', 'bot-eraser'); ?></th><th><?php _e('Version', 'bot-eraser'); ?></th><th><?php _e('CVE ID', 'bot-eraser'); ?></th><th><?php _e('Severity', 'bot-eraser'); ?></th><th><?php _e('Summary', 'bot-eraser'); ?></th><th><?php _e('Fixed In', 'bot-eraser'); ?></th></tr></thead><tbody>
                    <?php foreach ($all_items as $v): $sev_class = bot_eraser_vuln_severity_class(isset($v['severity']) ? $v['severity'] : 0); $sev_label = bot_eraser_vuln_severity_label(isset($v['severity']) ? $v['severity'] : 0); ?>
                    <tr class="be-vuln-row-<?php echo $sev_class; ?>"><td class="be-vuln-software"><?php echo esc_html($v['software']); ?></td><td class="be-vuln-version"><?php echo esc_html(isset($v['version']) ? $v['version'] : '—'); ?></td><td class="be-vuln-cve"><code><?php echo esc_html(isset($v['id']) ? $v['id'] : '—'); ?></code></td><td class="be-vuln-severity"><span class="be-vuln-severity-badge <?php echo $sev_class; ?>"><?php echo esc_html(isset($v['severity']) ? number_format((float) $v['severity'], 1) : '—'); ?><small><?php echo esc_html($sev_label); ?></small></span></td><td class="be-vuln-summary"><?php echo esc_html(isset($v['summary']) ? $v['summary'] : '—'); ?></td><td class="be-vuln-fixed"><?php echo esc_html(isset($v['fixed_version']) ? $v['fixed_version'] : '—'); ?></td></tr>
                    <?php endforeach; ?>
                </tbody></table></div>
            <?php endif; ?>
        </div>
        <div id="be-vuln-status" class="boteraser-progress-bar be-vuln-progress"><div class="boteraser-progress-bar-fill"></div></div>
    </div>
    <?php
}
