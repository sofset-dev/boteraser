<?php
if (!defined('ABSPATH')) {
    exit;
}

// ----------------------------------------------------------------------------
// WAF rule sync — periodically pulls rulesets from the server and
// compiles them to a local PHP cache for detection.php.
// The plugin holds NO logic here beyond I/O: fetch, parse, compile.
// ----------------------------------------------------------------------------

/**
 * Absolute path of the compiled rule cache.
 */
function bot_eraser_waf_cache_path(): string {
    $up = wp_upload_dir();
    return trailingslashit($up['basedir']) . 'boteraser/waf-rules.php';
}

/**
 * Map a CRS rule id to a detection category by its leading prefix.
 * Returns '' for an id outside the supported families.
 */
function bot_eraser_waf_id_category(string $id): string {
    $map = [
        '942' => 'sqli',
        '941' => 'xss',
        '932' => 'rce',
        '930' => 'lfi',
        '931' => 'rfi',
        '933' => 'php',
        '934' => 'ssti',
        '913' => 'scanner',
        '920' => 'protocol',
        '921' => 'protocol',
    ];
    return $map[substr($id, 0, 3)] ?? '';
}

/**
 * Fetch the ruleset and refresh the local cache. Hooked on the 6h cron.
 * 200 -> rebuild cache + ETag + timestamp. 304 -> keep cache. Any other
 * status / network error -> keep cache, log, never fatal.
 */
function bot_eraser_waf_sync() {
    $api_key = (string) get_option('bot_eraser_api_key', '');
    if ($api_key === '') {
        return;
    }

    $response = wp_remote_post(BOT_ERASER_WAF_URL, [
        'body'    => ['api_key' => $api_key],
        'headers' => ['If-None-Match' => (string) get_option('bot_eraser_waf_etag', '')],
        'timeout' => 20,
    ]);

    if (is_wp_error($response)) {
        error_log('Boteraser WAF sync: ' . $response->get_error_message());
        return;
    }

    $code = (int) wp_remote_retrieve_response_code($response);

    if ($code === 304) {
        return; // ruleset unchanged — keep the current cache as-is.
    }

    if ($code !== 200) {
        error_log('Boteraser WAF sync: unexpected HTTP ' . $code);
        return;
    }

    $body = (string) wp_remote_retrieve_body($response);
    if ($body === '') {
        error_log('Boteraser WAF sync: empty response body');
        return;
    }

    $categories = [];
    $scoped     = [];
    $count = 0;
    foreach (preg_split('/\r\n|\r|\n/', $body) as $line) {
        if (trim($line) === '') {
            continue;
        }
        $row = str_getcsv($line, ',', '"', '\\');
        if (count($row) < 4) {
            continue;
        }
        $id      = trim((string) $row[0]);
        $pattern = (string) $row[1];
        if ($pattern === '') {
            continue;
        }
        // Skip the header row and any unusable regex (invalid pattern -> false).
        if (@preg_match($pattern, '') === false) {
            continue;
        }
        $cat = bot_eraser_waf_id_category($id);
        if ($cat === '') {
            continue;
        }
        // Scope column (appended; absent in legacy CSV -> 'url'). url stays flat in
        // $categories (detection.php scans it against the URL). method/cookies/headers
        // go under _scoped so detection.php scans each against its own subject.
        $scope = isset($row[5]) ? trim((string) $row[5]) : 'url';
        if ($scope === '' || $scope === 'url') {
            $categories[$cat][] = $pattern;
        } elseif ($scope === 'method' || $scope === 'cookies') {
            $scoped[$scope][$cat][] = $pattern;
        } elseif (strpos($scope, 'headers:') === 0) {
            $hname = substr($scope, 8);
            if ($hname === '') {
                $hname = '*';
            }
            $scoped['headers'][$hname][$cat][] = $pattern;
        } else {
            continue; // unknown scope -> skip (never misapply to the URL)
        }
        $count++;
    }
    if ($scoped) {
        $categories['_scoped'] = $scoped;
    }

    if ($count === 0) {
        error_log('Boteraser WAF sync: no valid rules parsed');
        return;
    }

    $export = "<?php\nif (!defined('ABSPATH')) { exit; }\nreturn "
        . var_export($categories, true) . ";\n";

    $path = bot_eraser_waf_cache_path();
    if (!is_dir(dirname($path))) {
        wp_mkdir_p(dirname($path));
    }
    if (file_put_contents($path, $export, LOCK_EX) === false) {
        error_log('Boteraser WAF sync: failed to write ' . $path);
        return;
    }

    update_option('bot_eraser_waf_etag', (string) wp_remote_retrieve_header($response, 'etag'), false);
    update_option('bot_eraser_waf_synced', time(), false);
    update_option('bot_eraser_waf_count', $count, false);
}
add_action('bot_eraser_waf_sync', 'bot_eraser_waf_sync');

/**
 * Load the compiled rules, or null when the cache does not exist yet
 * (first boot before the first sync -> detection.php uses its defaults).
 */
function bot_eraser_waf_load_rules() {
    $path = bot_eraser_waf_cache_path();
    if (!is_file($path)) {
        return null;
    }
    $rules = include $path;
    return is_array($rules) ? $rules : null;
}

/**
 * Schedule the recurring 6h sync and bootstrap a one-off run when the cache
 * is still missing. Safe to call on every load (guards prevent duplicates).
 */
function bot_eraser_waf_schedule() {
    if (!wp_next_scheduled('bot_eraser_waf_sync')) {
        wp_schedule_event(time(), 'boteraser_6h', 'bot_eraser_waf_sync');
    }
    // First boot: no cache yet -> run once on the next cron tick (non-blocking).
    if (!is_file(bot_eraser_waf_cache_path())
        && (string) get_option('bot_eraser_api_key', '') !== ''
        && !wp_next_scheduled('bot_eraser_waf_sync_once')) {
        wp_schedule_single_event(time(), 'bot_eraser_waf_sync_once');
    }
}
add_action('bot_eraser_waf_sync_once', 'bot_eraser_waf_sync');
add_action('init', 'bot_eraser_waf_schedule');
