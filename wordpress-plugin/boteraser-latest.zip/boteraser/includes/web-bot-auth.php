<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Web Bot Auth — Ed25519-signed bot verification (RFC 9421).
 */

/**
 * Memoised entry point. Returns 'none' if signature headers are absent.
 */
function bot_eraser_wba_status() {
    // Memoised per-request verdict.
    static $verdict = null;
    if ($verdict !== null) return $verdict;
    $verdict = bot_eraser_wba_status_uncached();
    return $verdict;
}

/**
 * True only for a fully verified signature.
 */
function bot_eraser_wba_verify() {
    return bot_eraser_wba_status() === 'verified';
}

/**
 * Three-state verdict: 'none', 'verified', 'forged', 'unverifiable'.
 */
function bot_eraser_wba_status_uncached() {
    if (!function_exists('sodium_crypto_sign_verify_detached')) return 'none';

    $sig_input = trim($_SERVER['HTTP_SIGNATURE_INPUT'] ?? '');
    $sig_head  = trim($_SERVER['HTTP_SIGNATURE'] ?? '');
    $agent_raw = trim($_SERVER['HTTP_SIGNATURE_AGENT'] ?? '');

    // No signature headers.
    if ($sig_input === '' && $sig_head === '') return 'none';
    // Partial headers: can't verify.
    if ($sig_input === '' || $sig_head === '' || $agent_raw === '') return 'unverifiable';

    // Parse label and verbatim params for signature base.
    $eq = strpos($sig_input, '=');
    if ($eq === false) return 'unverifiable';
    $label   = substr($sig_input, 0, $eq);
    $sig_params = substr($sig_input, $eq + 1);
    if ($label === '' || $sig_params === '') return 'unverifiable';

    // Covered components in order.
    if (!preg_match('/^\((.*?)\)/', $sig_params, $m)) return 'unverifiable';
    $components = array_values(array_filter(array_map(
        function ($c) { return trim($c, " \"\t"); },
        explode(' ', trim($m[1]))
    ), 'strlen'));
    if (empty($components)) return 'unverifiable';

    $params = bot_eraser_wba_parse_params($sig_params);

    // Must be web-bot-auth and unexpired.
    if (($params['tag'] ?? '') !== 'web-bot-auth') return 'unverifiable';
    $keyid = $params['keyid'] ?? '';
    if ($keyid === '') return 'unverifiable';
    if (isset($params['alg']) && strtolower($params['alg']) !== 'ed25519') return 'unverifiable';

    $now = time();
    if (isset($params['created']) && (int) $params['created'] > $now + 300) return 'unverifiable'; // future-dated
    if (isset($params['expires']) && (int) $params['expires'] < $now) return 'unverifiable';        // expired

    // Build signature base (RFC 9421 §2.5).
    $base_lines = [];
    foreach ($components as $comp) {
        $value = bot_eraser_wba_component_value($comp, $agent_raw);
        if ($value === null) return 'unverifiable'; // unsupported component
        $base_lines[] = '"' . $comp . '": ' . $value;
    }
    $base_lines[] = '"@signature-params": ' . $sig_params;
    $base = implode("\n", $base_lines);

    // Parse signature from header.
    if (!preg_match('/' . preg_quote($label, '/') . '=:([A-Za-z0-9+\/=]+):/', $sig_head, $sm)) return 'unverifiable';
    $signature = base64_decode($sm[1], true);
    if ($signature === false || strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES) return 'unverifiable';

    // Resolve key by thumbprint; treat failures as unverifiable.
    $pubkey = bot_eraser_wba_resolve_key($agent_raw, $keyid);
    if ($pubkey === null) return 'unverifiable';

    // Verify with resolved key.
    return sodium_crypto_sign_verify_detached($signature, $base, $pubkey)
        ? 'verified' : 'forged';
}

/**
 * Render a covered-component value for the signature base.
 */
function bot_eraser_wba_component_value($comp, $agent_raw) {
    switch ($comp) {
        case '@authority':
            // Target URI authority, lowercased (RFC 9421 §2.2.2).
            $host = $_SERVER['HTTP_HOST'] ?? '';
            return $host === '' ? null : strtolower($host);
        case 'signature-agent':
            return $agent_raw;
        default:
            return null;
    }
}

/**
 * Parse @signature-params.
 */
function bot_eraser_wba_parse_params($sig_params) {
    $params = [];
    if (preg_match('/;created=(\d+)/', $sig_params, $m))  $params['created'] = $m[1];
    if (preg_match('/;expires=(\d+)/', $sig_params, $m))  $params['expires'] = $m[1];
    if (preg_match('/;keyid="([^"]+)"/', $sig_params, $m)) $params['keyid']   = $m[1];
    if (preg_match('/;alg="([^"]+)"/', $sig_params, $m))   $params['alg']     = $m[1];
    if (preg_match('/;tag="([^"]+)"/', $sig_params, $m))   $params['tag']     = $m[1];
    return $params;
}

/**
 * Fetch JWKS and return matching Ed25519 public key. Cached per host.
 */
/**
 * Trusted signer hosts. Empty by default (fail-closed).
 */
function bot_eraser_wba_allowed_hosts(): array {
    $hosts = get_option('bot_eraser_wba_allowed_signers', []);
    if (!is_array($hosts)) $hosts = [];
    $hosts = apply_filters('bot_eraser_wba_allowed_signers', $hosts);
    $out = [];
    foreach ((array) $hosts as $h) {
        $h = strtolower(trim((string) $h));
        if ($h !== '') $out[] = $h;
    }
    return $out;
}

/**
 * Check if signer host is trusted.
 */
function bot_eraser_wba_host_allowed($host): bool {
    foreach (bot_eraser_wba_allowed_hosts() as $a) {
        if ($host === $a || substr($host, -strlen('.' . $a)) === '.' . $a) {
            return true;
        }
    }
    return false;
}

function bot_eraser_wba_resolve_key($agent_raw, $keyid) {
    $host = bot_eraser_wba_agent_host($agent_raw);
    if ($host === null) return null;

    // Gate: deny unlisted hosts before fetch.
    if (!bot_eraser_wba_host_allowed($host)) return null;

    $keys = bot_eraser_wba_get_jwks($host);
    foreach ($keys as $jwk) {
        if (!is_array($jwk)) continue;
        if (($jwk['kty'] ?? '') !== 'OKP' || ($jwk['crv'] ?? '') !== 'Ed25519') continue;
        if (empty($jwk['x'])) continue;
        if (bot_eraser_wba_thumbprint($jwk) !== $keyid) continue;

        $pub = bot_eraser_wba_b64url_decode($jwk['x']);
        if ($pub !== false && strlen($pub) === SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
            return $pub;
        }
    }
    return null;
}

/**
 * Normalise Signature-Agent to bare FQDN.
 */
function bot_eraser_wba_agent_host($agent_raw) {
    $val = trim($agent_raw, " \"\t");
    if ($val === '') return null;
    if (stripos($val, 'http') === 0) {
        $host = parse_url($val, PHP_URL_HOST);
    } else {
        $host = $val;
    }
    if (!is_string($host) || $host === '') return null;
    if (!preg_match('/^[a-z0-9.-]+$/i', $host)) return null;
    return strtolower($host);
}

function bot_eraser_wba_get_jwks($host) {
    $key = 'bot_eraser_wba_jwks_' . md5($host);
    $cached = get_transient($key);
    if ($cached !== false) return is_array($cached) ? $cached : [];

    $url  = 'https://' . $host . '/.well-known/http-message-signatures-directory';
    $resp = wp_remote_get($url, ['timeout' => 5, 'sslverify' => true]);

    $keys = [];
    if (!is_wp_error($resp) && (int) wp_remote_retrieve_response_code($resp) === 200) {
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if (is_array($body) && isset($body['keys']) && is_array($body['keys'])) {
            $keys = $body['keys'];
        }
    }

    // Cache empty results briefly to avoid hammering.
    set_transient($key, $keys, empty($keys) ? HOUR_IN_SECONDS : DAY_IN_SECONDS);
    return $keys;
}

/**
 * RFC 8037 JWK thumbprint for Ed25519.
 */
function bot_eraser_wba_thumbprint($jwk) {
    $canon = '{"crv":"' . $jwk['crv'] . '","kty":"' . $jwk['kty'] . '","x":"' . $jwk['x'] . '"}';
    return rtrim(strtr(base64_encode(hash('sha256', $canon, true)), '+/', '-_'), '=');
}

function bot_eraser_wba_b64url_decode($data) {
    $pad = strlen($data) % 4;
    if ($pad) $data .= str_repeat('=', 4 - $pad);
    return base64_decode(strtr($data, '-_', '+/'), true);
}
