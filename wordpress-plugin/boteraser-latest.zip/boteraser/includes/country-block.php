<?php
if (!defined('ABSPATH')) {
    exit;
}

// ----------------------------------------------------------------------------
// Country blocking — comparison-only. The country/geo list is NEVER downloaded
// (licensing forbids redistribution and the dataset is huge). Instead, when the
// operator has selected one or more countries to block (delivered in the map),
// the plugin ships the recent visitor IPs to the server on the existing 5-min
// cron; the server does the geo lookup and returns the subset to block. Those
// IPs are written into the shared blocked-ips.php cache like any other block.
// ----------------------------------------------------------------------------

/**
 * Is country blocking active? Driven purely by the synced map — no local list.
 */
function bot_eraser_country_enabled(): bool {
    $map = bot_eraser_get_map();
    return is_array($map) && !empty($map['country']['enabled']);
}

/**
 * Block TTL (seconds) for a country match, from the map (default 24h).
 */
function bot_eraser_country_ttl(): int {
    $map = bot_eraser_get_map();
    return (int) ($map['country']['block_ttl'] ?? 86400);
}

/**
 * Recent unique visitor IPs from the access log (last 5 min window), capped.
 * Reuses the same parser the manual server sync uses.
 */
function bot_eraser_country_recent_ips(): array {
    if (!function_exists('bot_eraser_parse_log')) {
        return [];
    }
    $parsed = bot_eraser_parse_log();
    $data   = isset($parsed['data']) ? (string) $parsed['data'] : '';
    if ($data === '') {
        return [];
    }
    $ips = [];
    foreach (preg_split('/\r\n|\r|\n/', $data) as $line) {
        // Lines are "count ip bot".
        if (preg_match('/^\d+\s+([0-9a-fA-F.:]+)/', trim($line), $m)) {
            $ip = $m[1];
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)
                && !bot_eraser_is_self_ip($ip)) {
                $ips[$ip] = 1;
            }
        }
    }
    return array_slice(array_keys($ips), 0, BOT_ERASER_SERVER_MAX_IPS);
}

/**
 * Cron callback (hooked on the 5-min bot_eraser_cron_hook). Sends recent IPs for
 * server-side country comparison and blocks whatever the server returns. No-op
 * unless the operator has enabled country blocking in the map.
 */
function bot_eraser_country_check(): void {
    if (!bot_eraser_country_enabled()) {
        return;
    }
    $api_key = (string) get_option('bot_eraser_api_key', '');
    if ($api_key === '') {
        return;
    }
    $ips = bot_eraser_country_recent_ips();
    if (empty($ips)) {
        return;
    }

    $response = wp_remote_post(BOT_ERASER_COUNTRY_URL, [
        'body'      => ['api_key' => $api_key, 'ips' => implode("\n", $ips)],
        'timeout'   => 15,
        'sslverify' => true,
    ]);

    if (is_wp_error($response)) {
        error_log('Boteraser country check: ' . $response->get_error_message());
        return;
    }
    if ((int) wp_remote_retrieve_response_code($response) !== 200) {
        return;
    }

    $body = (string) wp_remote_retrieve_body($response);
    if ($body === '') {
        return;
    }

    $ttl     = bot_eraser_country_ttl();
    $to_block = array_slice(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $body))), 0, BOT_ERASER_SERVER_MAX_IPS);
    foreach ($to_block as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            continue;
        }
        if (!bot_eraser_is_ip_blocked($ip) && !bot_eraser_is_just_unblocked($ip)) {
            bot_eraser_list_block($ip, $ttl, 'country');
        }
    }
}
add_action('bot_eraser_cron_hook', 'bot_eraser_country_check');
