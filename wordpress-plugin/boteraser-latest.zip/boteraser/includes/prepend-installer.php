<?php
if (!defined('ABSPATH')) {
    exit;
}

// ----------------------------------------------------------------------------
// Extended protection installer & admin toggle. Writes .user.ini/.htaccess
// directive, writes loader + config snapshot, migrates list guards, renders UI.
// ----------------------------------------------------------------------------

function bot_eraser_prepend_target(): string {
    return BOT_ERASER_PLUGIN_DIR . 'boteraser-prepend.php';
}

function bot_eraser_prepend_loader_path(): string {
    return ABSPATH . 'boteraser-waf.php';
}

/**
 * Directive method per active SAPI. mod_php/LiteSpeed → .htaccess, FPM/FastCGI → .user.ini, else → 'manual'.
 */
function bot_eraser_prepend_server_mode(): string {
    $sapi = php_sapi_name();
    if (strpos($sapi, 'apache') !== false || $sapi === 'litespeed') {
        return 'htaccess';
    }
    if (strpos($sapi, 'fcgi') !== false || strpos($sapi, 'fpm') !== false || $sapi === 'cgi') {
        // Host may disable per-dir ini; only manual step works.
        return (string) ini_get('user_ini.filename') !== '' ? 'userini' : 'manual';
    }
    return 'manual';
}

function bot_eraser_prepend_directive_file(string $mode): string {
    return ABSPATH . ($mode === 'htaccess' ? '.htaccess' : '.user.ini');
}

/**
 * Directive block between markers. Comment char depends on file format.
 */
function bot_eraser_prepend_directive_block(string $mode): string {
    $loader = bot_eraser_prepend_loader_path();
    if ($mode === 'htaccess') {
        return "# BEGIN Boteraser WAF\n"
            . "<IfModule mod_php7.c>\n"
            . "php_value auto_prepend_file '" . $loader . "'\n"
            . "</IfModule>\n"
            . "<IfModule mod_php.c>\n"
            . "php_value auto_prepend_file '" . $loader . "'\n"
            . "</IfModule>\n"
            . "# END Boteraser WAF\n";
    }
    return "; BEGIN Boteraser WAF\n"
        . "auto_prepend_file = '" . $loader . "'\n"
        . "; END Boteraser WAF\n";
}

/**
 * Strip existing Boteraser block from content.
 */
function bot_eraser_prepend_strip_block(string $body): string {
    return (string) preg_replace('/[;#] BEGIN Boteraser WAF.*?[;#] END Boteraser WAF\n?/s', '', $body);
}

/**
 * Write loader to site root. Chains after any existing auto_prepend_file.
 */
function bot_eraser_prepend_write_loader(): bool {
    $prev = (string) ini_get('auto_prepend_file');
    if ($prev !== '' && (basename($prev) === 'boteraser-waf.php' || realpath($prev) === realpath(bot_eraser_prepend_target()))) {
        $prev = '';
    }
    $body = "<?php\n"
        . "// Boteraser extended protection loader (auto_prepend_file cilj).\n"
        . "// Bezbedan i kad plugin nestane: bez fajla je no-op, ne ruši sajt.\n"
        . '$boteraser_prepend = ' . var_export(bot_eraser_prepend_target(), true) . ";\n"
        . "if (is_file(\$boteraser_prepend)) {\n"
        . "    include_once \$boteraser_prepend;\n"
        . "}\n"
        . "unset(\$boteraser_prepend);\n";
    if ($prev !== '') {
        $body .= '$boteraser_prev_prepend = ' . var_export($prev, true) . ";\n"
            . "if (is_file(\$boteraser_prev_prepend)) {\n"
            . "    include_once \$boteraser_prev_prepend;\n"
            . "}\n"
            . "unset(\$boteraser_prev_prepend);\n";
    }
    return file_put_contents(bot_eraser_prepend_loader_path(), $body, LOCK_EX) !== false;
}

/**
 * Snapshot options for pre-WP phase. Written on enable, hourly sync, option change; no-op outside extended mode.
 */
function bot_eraser_prepend_write_config(bool $force = false): void {
    // Refresh even when directive added manually — constant proves execution.
    if (!$force && !get_option('bot_eraser_prepend_mode') && !defined('BOT_ERASER_PREPEND')) {
        return;
    }
    $dir = bot_eraser_list_dir();
    if (!is_dir($dir)) {
        wp_mkdir_p($dir);
    }

    // Public self IPs (hairpin NAT loopback) — resolved here, cached in snapshot.
    $self_ips = [];
    $host = parse_url(home_url(), PHP_URL_HOST) ?: '';
    if ($host !== '' && !filter_var($host, FILTER_VALIDATE_IP)) {
        $recs = @dns_get_record($host, DNS_A + DNS_AAAA);
        if (is_array($recs)) {
            foreach ($recs as $r) {
                if (!empty($r['ip']))   $self_ips[] = $r['ip'];
                if (!empty($r['ipv6'])) $self_ips[] = $r['ipv6'];
            }
        }
    }

    $cfg = [
        'ip_source'      => (string) get_option('bot_eraser_ip_source', 'remote_addr'),
        'self_ips'       => array_values(array_unique($self_ips)),
        'written'        => time(),
    ];
    $file = $dir . 'prepend-config.php';
    file_put_contents($file, "<?php\nreturn " . var_export($cfg, true) . ";\n", LOCK_EX);
    bot_eraser_invalidate_opcache($file);
}
add_action('bot_eraser_list_sync', 'bot_eraser_prepend_write_config', 20);
add_action('updated_option', function ($option) {
    if ($option === 'bot_eraser_ip_source') {
        bot_eraser_prepend_write_config();
    }
});

/**
 * Migrate compiled list guards: old ABSPATH-only guard would exit on pre-WP include. Rewrite guard; new syncs already write extended.
 */
function bot_eraser_prepend_fix_list_guards(): void {
    $old = "if (!defined('ABSPATH')) { exit; }";
    $new = "if (!defined('ABSPATH') && !defined('BOT_ERASER_PREPEND')) { exit; }";
    foreach ((glob(bot_eraser_list_dir() . '*.php') ?: []) as $file) {
        $body = file_get_contents($file);
        if ($body !== false && strpos($body, $old) !== false && strpos($body, 'BOT_ERASER_PREPEND') === false) {
            file_put_contents($file, str_replace($old, $new, $body), LOCK_EX);
            bot_eraser_invalidate_opcache($file);
        }
    }
}

/**
 * Manual setup snippet for php.ini and FPM pool config.
 */
function bot_eraser_prepend_manual_block(): string {
    $loader = bot_eraser_prepend_loader_path();
    return "; php.ini:\n"
        . "auto_prepend_file = '" . $loader . "'\n"
        . "; or PHP-FPM pool config:\n"
        . "php_admin_value[auto_prepend_file] = " . $loader;
}

/**
 * Enable extended protection. Returns status array. Prepares loader/guard/config even on manual-only servers.
 */
function bot_eraser_prepend_install(): array {
    $mode = bot_eraser_prepend_server_mode();
    if ($mode === 'manual') {
        bot_eraser_prepend_fix_list_guards();
        bot_eraser_prepend_write_loader();
        bot_eraser_prepend_write_config(true);
        return [
            'status'  => 'error',
            'message' => __('Extended protection cannot be enabled automatically on this server — the server PHP configuration does not allow it. If you can edit PHP settings, add the line below to activate it; otherwise your site remains fully protected in standard mode.', 'bot-eraser'),
            'block'   => bot_eraser_prepend_manual_block(),
        ];
    }

    bot_eraser_prepend_fix_list_guards();

    if (!bot_eraser_prepend_write_loader()) {
        return [
            'status'  => 'error',
            'message' => __('Extended protection could not be enabled — the loader file could not be written. Your site remains fully protected in standard mode.', 'bot-eraser'),
        ];
    }

    $block = bot_eraser_prepend_directive_block($mode);
    $file  = bot_eraser_prepend_directive_file($mode);
    $body  = is_file($file) ? (string) file_get_contents($file) : '';
    $body  = bot_eraser_prepend_strip_block($body);
    if ($body !== '' && substr($body, -1) !== "\n") {
        $body .= "\n";
    }
    if (file_put_contents($file, $body . $block, LOCK_EX) === false) {
        return [
            'status'  => 'error',
            'message' => sprintf(__('Extended protection could not be enabled — %s is not writable on this server. You can add the block below to it manually; otherwise your site remains fully protected in standard mode.', 'bot-eraser'), basename($file)),
            'block'   => $block,
        ];
    }

    update_option('bot_eraser_prepend_mode', $mode, false);
    bot_eraser_prepend_write_config(true);

    $note = $mode === 'userini'
        ? __('Enabled via .user.ini — PHP caches it, so it becomes active within ~5 minutes.', 'bot-eraser')
        : __('Enabled via .htaccess — active immediately.', 'bot-eraser');
    return ['status' => 'ok', 'message' => $note];
}

/**
 * Disable: remove directive from both files. Keep loader (no-op); deleting risks fatal errors during cache window.
 */
function bot_eraser_prepend_remove(): void {
    foreach (['userini', 'htaccess'] as $mode) {
        $file = bot_eraser_prepend_directive_file($mode);
        if (!is_file($file)) {
            continue;
        }
        $body = (string) file_get_contents($file);
        $stripped = bot_eraser_prepend_strip_block($body);
        if ($stripped !== $body) {
            file_put_contents($file, $stripped, LOCK_EX);
        }
    }
    delete_option('bot_eraser_prepend_mode');
}

/**
 * Admin dashboard card (no menu page). Handles POST, renders status + button + inline messages.
 */
function bot_eraser_prepend_render_card(): void {
    if (!current_user_can('manage_options')) {
        return;
    }

    $result = null;
    if (isset($_POST['bot_eraser_prepend_action']) && check_admin_referer('bot_eraser_prepend', 'bot_eraser_prepend_nonce')) {
        if ($_POST['bot_eraser_prepend_action'] === 'enable') {
            $result = bot_eraser_prepend_install();
        } else {
            bot_eraser_prepend_remove();
            $result = ['status' => 'ok', 'message' => __('Extended protection disabled. With .user.ini it can take ~5 minutes to fully switch off.', 'bot-eraser')];
        }
    }

    $mode = (string) get_option('bot_eraser_prepend_mode', '');
    // Constant exists only when prepend ran before WP in this request.
    $running = defined('BOT_ERASER_PREPEND');

    // Self-check: server cannot apply directive — clean up, toggle back to Off.
    if ($mode !== '' && !$running && bot_eraser_prepend_server_mode() === 'manual') {
        bot_eraser_prepend_remove();
        $mode = '';
    }

    if ($running) {
        $status = __('Active — unwanted traffic is blocked before WordPress loads.', 'bot-eraser');
        $badge  = '#16a34a';
    } elseif ($mode !== '') {
        $status = __('Enabled — waiting for PHP to pick up the directive (up to ~5 minutes for .user.ini).', 'bot-eraser');
        $badge  = '#d97706';
    } else {
        $status = __('Off — blocking runs after WordPress core loads.', 'bot-eraser');
        $badge  = '#64748b';
    }

    echo '<div class="boteraser-extended-card" style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px 20px;margin:var(--be-section-gap, 24px) 0;">';

    if ($result !== null) {
        // Transient message (+ optional PHP snippet): auto-fading.
        $color = $result['status'] === 'error' ? '#b91c1c' : '#166534';
        echo '<div id="boteraser-ext-msg" style="margin:0 0 10px;">';
        echo '<p style="margin:0;font-weight:600;color:' . esc_attr($color) . ';">' . esc_html($result['message']) . '</p>';
        if (!empty($result['block'])) {
            echo '<div style="position:relative;margin:8px 0 0;">'
                . '<button type="button" class="boteraser-copy-btn" title="' . esc_attr__('Copy to clipboard', 'bot-eraser') . '" style="position:absolute;top:8px;right:8px;padding:2px 10px;font-size:11px;cursor:pointer;border:1px solid #dcdcde;border-radius:4px;background:#fff;">' . esc_html__('Copy', 'bot-eraser') . '</button>'
                . '<pre style="background:#f6f7f7;border:1px solid #dcdcde;border-radius:6px;padding:12px;overflow:auto;margin:0;">' . esc_html($result['block']) . '</pre>'
                . '</div>';
        }
        echo '</div>';
        // After POST, scroll to card before starting fade timer.
        echo '<script>window.addEventListener("load",function(){var m=document.getElementById("boteraser-ext-msg");if(!m)return;'
            . 'm.scrollIntoView({behavior:"smooth",block:"center"});'
            . 'setTimeout(function(){m.style.transition="opacity .5s";m.style.opacity="0";setTimeout(function(){m.remove();},500);},15000);});</script>';
    }

    $btn_enable = '<button type="submit" name="bot_eraser_prepend_action" value="enable" class="boteraser-btn boteraser-btn-primary">'
        . bot_eraser_icon('zap') . esc_html__('Enable', 'bot-eraser') . '</button>';
    $btn_disable = '<button type="submit" name="bot_eraser_prepend_action" value="disable" class="boteraser-btn boteraser-btn-secondary">'
        . esc_html__('Disable', 'bot-eraser') . '</button>';

    echo '<div id="boteraser-ext-row" style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">';
    echo '<div class="boteraser-pillar-header" style="flex:1;min-width:280px;">';
    echo '<span class="boteraser-pillar-icon">' . bot_eraser_icon('zap') . '</span>';
    echo '<div>';
    echo '<span class="boteraser-pillar-eyebrow">' . esc_html__('Pre-WordPress Firewall', 'bot-eraser') . '</span>';
    echo '<h2 class="boteraser-pillar-title">' . esc_html__('Extended Protection', 'bot-eraser')
        . ' <span id="boteraser-ext-dot" style="display:inline-block;width:10px;height:10px;border-radius:50%;background:' . esc_attr($badge) . ';margin-left:4px;"></span></h2>';
    echo '<p style="margin:4px 0 0;color:#64748b;"><span id="boteraser-ext-status">' . esc_html($status) . '</span> '
        . esc_html__('Extended protection rejects blocked IPs and blacklisted bots before WordPress, themes, or other plugins consume any resources (via auto_prepend_file).', 'bot-eraser') . '</p>';
    echo '</div>';
    echo '</div>';

    echo '<form method="post" style="margin:0;" id="boteraser-ext-form">';
    wp_nonce_field('bot_eraser_prepend', 'bot_eraser_prepend_nonce');
    echo $mode === '' ? $btn_enable : $btn_disable;
    echo '</form>';
    echo '</div>';

    // AJAX submit: no reload, inline message auto-fades. Non-JS fallback: POST handler above.
    $cfg = wp_json_encode([
        'ajax'   => admin_url('admin-ajax.php'),
        'states' => [
            'off'     => ['text' => __('Off — blocking runs after WordPress core loads.', 'bot-eraser'), 'color' => '#64748b'],
            'waiting' => ['text' => __('Enabled — waiting for PHP to pick up the directive (up to ~5 minutes for .user.ini).', 'bot-eraser'), 'color' => '#d97706'],
        ],
        'buttons' => ['enable' => $btn_enable, 'disable' => $btn_disable],
        'copy'    => ['label' => __('Copy', 'bot-eraser'), 'tooltip' => __('Copy to clipboard', 'bot-eraser')],
    ]);
    echo '<script>(function(){var cfg=' . $cfg . ';'
        . 'var f=document.getElementById("boteraser-ext-form");if(!f)return;'
        . 'function showMsg(t,isErr,block){var old=document.getElementById("boteraser-ext-msg");if(old)old.remove();'
        . 'var w=document.createElement("div");w.id="boteraser-ext-msg";w.style.cssText="margin:0 0 10px;";'
        . 'var p=document.createElement("p");p.style.cssText="margin:0;font-weight:600;color:"+(isErr?"#b91c1c":"#166534");p.textContent=t;w.appendChild(p);'
        . 'if(block){var bw=document.createElement("div");bw.style.cssText="position:relative;margin:8px 0 0;";'
        . 'var cb=document.createElement("button");cb.type="button";cb.className="boteraser-copy-btn";cb.title=cfg.copy.tooltip;cb.textContent=cfg.copy.label;'
        . 'cb.style.cssText="position:absolute;top:8px;right:8px;padding:2px 10px;font-size:11px;cursor:pointer;border:1px solid #dcdcde;border-radius:4px;background:#fff;";bw.appendChild(cb);'
        . 'var c=document.createElement("pre");c.style.cssText="background:#f6f7f7;border:1px solid #dcdcde;border-radius:6px;padding:12px;overflow:auto;margin:0;";c.textContent=block;bw.appendChild(c);w.appendChild(bw);}'
        . 'var row=document.getElementById("boteraser-ext-row");row.parentNode.insertBefore(w,row);'
        . 'setTimeout(function(){w.style.transition="opacity .5s";w.style.opacity="0";setTimeout(function(){w.remove();},500);},15000);}'
        . 'document.addEventListener("click",function(e){var b=e.target.closest?e.target.closest(".boteraser-copy-btn"):null;if(!b)return;'
        . 'var pre=b.parentNode.querySelector("pre");if(!pre)return;'
        . 'var done=function(){var m=document.getElementById("boteraser-ext-msg");'
        . 'if(m){m.style.transition="opacity .5s";m.style.opacity="0";setTimeout(function(){m.remove();},500);}};'
        . 'if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(pre.textContent).then(done);}'
        . 'else{var r=document.createRange();r.selectNodeContents(pre);var s=getSelection();s.removeAllRanges();s.addRange(r);try{document.execCommand("copy");done();}catch(x){}s.removeAllRanges();}'
        . '});'
        . 'f.addEventListener("submit",function(e){e.preventDefault();'
        . 'var b=f.querySelector("button");if(!b||b.disabled)return;var act=b.value;b.disabled=true;'
        . 'var d=new FormData(f);d.append("action","bot_eraser_prepend_toggle");d.append("toggle",act);'
        . 'fetch(cfg.ajax,{method:"POST",credentials:"same-origin",body:d})'
        . '.then(function(r){return r.json();})'
        . '.then(function(res){'
        . 'var st=null,btn=null;'
        . 'if(act==="enable"&&res.status==="ok"){st="waiting";btn=cfg.buttons.disable;}'
        . 'else if(act==="disable"){st="off";btn=cfg.buttons.enable;}'
        . 'if(st){var s=cfg.states[st];'
        . 'var dot=document.getElementById("boteraser-ext-dot");if(dot)dot.style.background=s.color;'
        . 'var tx=document.getElementById("boteraser-ext-status");if(tx)tx.textContent=s.text;}'
        . 'if(btn){b.outerHTML=btn;}else{b.disabled=false;}'
        . 'showMsg(res.message,res.status!=="ok",res.block||"");'
        . '}).catch(function(){b.disabled=false;});'
        . '});})();</script>';

    echo '</div>';
}

/**
 * AJAX toggle — same as POST branch but returns JSON for inline card update.
 */
function bot_eraser_prepend_ajax_toggle(): void {
    if (!current_user_can('manage_options')) {
        wp_send_json(['status' => 'error', 'message' => __('Not allowed.', 'bot-eraser')], 403);
    }
    check_ajax_referer('bot_eraser_prepend', 'bot_eraser_prepend_nonce');

    if (($_POST['toggle'] ?? '') === 'enable') {
        $r = bot_eraser_prepend_install();
        wp_send_json(['status' => $r['status'], 'message' => $r['message'], 'block' => $r['block'] ?? '']);
    }

    bot_eraser_prepend_remove();
    wp_send_json(['status' => 'ok', 'message' => __('Extended protection disabled. With .user.ini it can take ~5 minutes to fully switch off.', 'bot-eraser')]);
}
add_action('wp_ajax_bot_eraser_prepend_toggle', 'bot_eraser_prepend_ajax_toggle');
