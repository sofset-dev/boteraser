<?php
if (!defined('ABSPATH')) {
    exit;
}

function bot_eraser_block_ips($ips) {
    if (empty($ips) || !is_array($ips)) {
        error_log('Boteraser Error: Invalid IP array provided');
        return false;
    }

    $cache_file = __DIR__ . '/blocked-ips.php';
    $blocked_ips = file_exists($cache_file) ? include $cache_file : [];
    
    foreach ($ips as $ip) {
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            $blocked_ips[$ip] = time() + 24 * 60 * 60; // Block for 24 hours
        }
    }
    
    file_put_contents($cache_file, '<?php return ' . var_export($blocked_ips, true) . ';');
    
    // Update WordPress transient if WordPress is loaded
    if (function_exists('set_transient')) {
        set_transient('bot_eraser_blocked_ips', $blocked_ips, 24 * 60 * 60);
    }
    
    return true;
}

function bot_eraser_is_ip_blocked($ip) {
    // Check file cache first
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
        if (isset($blocked_ips[$ip]) && time() < $blocked_ips[$ip]) {
            return true;
        }
    }
    
    // Check WordPress transient if available
    if (function_exists('get_transient')) {
        $blocked_ips = get_transient('bot_eraser_blocked_ips') ?: [];
        if (isset($blocked_ips[$ip]) && time() < $blocked_ips[$ip]) {
            return true;
        }
    }
    
    return false;
}

function bot_eraser_get_blocked_ips() {
    $blocked_ips = [];
    
    // Try file cache first
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
    }
    
    // Merge with WordPress transient if available
    if (function_exists('get_transient')) {
        $wp_blocked_ips = get_transient('bot_eraser_blocked_ips') ?: [];
        $blocked_ips = array_merge($blocked_ips, $wp_blocked_ips);
    }
    
    $current_time = time();
    $active_blocks = [];
    
    foreach ($blocked_ips as $ip => $expiry) {
        if ($current_time < $expiry) {
            $remaining_seconds = $expiry - $current_time;
            $remaining_hours = floor($remaining_seconds / 3600);
            $remaining_minutes = floor(($remaining_seconds % 3600) / 60);
            
            // Format as "3h 45m" or "45m" (if 0 hours) or "0m" (if less than 1 minute)
            if ($remaining_hours > 0) {
                $time_remaining = $remaining_hours . 'h ' . $remaining_minutes . 'm';
            } else {
                $time_remaining = max(1, $remaining_minutes) . 'm'; // Show at least 1m
            }
            
            $active_blocks[$ip] = [
                'ip' => $ip,
                'expires' => date('Y-m-d H:i:s', $expiry),
                'remaining' => $time_remaining,
                'sort_key' => $remaining_seconds // Sort by total seconds remaining
            ];
        }
    }
    
    // Sort by remaining hours in descending order
    uasort($active_blocks, function($a, $b) {
        return $b['sort_key'] - $a['sort_key'];
    });
    
    return $active_blocks;
}

// Add this new function near the other IP management functions
function bot_eraser_unblock_ip($ip) {
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (!file_exists($cache_file)) {
        return false;
    }

    $blocked_ips = include $cache_file;
    if (isset($blocked_ips[$ip])) {
        unset($blocked_ips[$ip]);
        file_put_contents($cache_file, '<?php return ' . var_export($blocked_ips, true) . ';');
        
        // Also remove from WordPress transient if available
        if (function_exists('get_transient')) {
            $wp_blocked_ips = get_transient('bot_eraser_blocked_ips') ?: [];
            if (isset($wp_blocked_ips[$ip])) {
                unset($wp_blocked_ips[$ip]);
                set_transient('bot_eraser_blocked_ips', $wp_blocked_ips, 24 * 60 * 60);
            }
        }
        return true;
    }
    return false;
}

// Modify the existing bot_eraser_render_blocked_ips function to add the unblock button
function bot_eraser_render_blocked_ips() {
    // Handle unblock action
    if (isset($_POST['action']) && $_POST['action'] === 'unblock_ip' && 
        isset($_POST['ip']) && isset($_POST['_wpnonce']) && 
        wp_verify_nonce($_POST['_wpnonce'], 'bot_eraser_unblock_ip')) {
        
        $ip = sanitize_text_field($_POST['ip']);
        if (bot_eraser_unblock_ip($ip)) {
            add_settings_error('bot-eraser', 'ip-unblocked', 
                sprintf(__('IP address %s has been unblocked.', 'bot-eraser'), $ip), 
                'updated');
        }
    }

    $blocked_ips = bot_eraser_get_blocked_ips();
    settings_errors('bot-eraser');
    
    // Pagination setup
    $per_page = isset($_GET['per_page']) ? max(10, intval($_GET['per_page'])) : 10;
    // Ensure per_page is one of the allowed values
    $allowed_per_page = [10, 20, 50, 100];
    if (!in_array($per_page, $allowed_per_page)) {
        $per_page = 10;
    }
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $total_items = count($blocked_ips);
    $total_pages = ceil($total_items / $per_page);
    
    // Slice the array for current page
    $offset = ($current_page - 1) * $per_page;
    $page_items = array_slice($blocked_ips, $offset, $per_page, true);
    ?>
    <div class="wrap">
        <div class="boteraser-header">
            <img src="<?php echo esc_url(BOT_ERASER_PLUGIN_URL . 'logo.svg'); ?>" 
                 alt="Boteraser Logo" 
                 class="boteraser-logo">
        </div>
        
        <div style="margin-bottom: 15px; display: flex; align-items: center; justify-content: space-between; gap: 15px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 15px;">
                <h2 style="margin: 0;"><?php echo sprintf(__('Blocked IP Addresses: <span style="color: red;">%d</span>', 'bot-eraser'), count($blocked_ips)); ?></h2>
            </div>
            
            <div style="display: flex; align-items: center; gap: 15px;">
                <span style="color: #666; font-size: 13px;">
                    Showing <?php echo number_format(($current_page - 1) * $per_page + 1); ?>-<?php echo number_format(min($current_page * $per_page, $total_items)); ?> of <?php echo number_format($total_items); ?> entries
                </span>
                
                <form method="get" style="display: inline; margin: 0;">
                    <?php foreach ($_GET as $key => $value): ?>
                        <?php if ($key !== 'per_page' && $key !== 'paged'): ?>
                            <input type="hidden" name="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>">
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <label for="per_page" style="margin-right: 5px;">Show:</label>
                    <select name="per_page" id="per_page" onchange="this.form.submit()" style="margin-right: 5px;">
                        <option value="10" <?php selected($per_page, 10); ?>>10</option>
                        <option value="20" <?php selected($per_page, 20); ?>>20</option>
                        <option value="50" <?php selected($per_page, 50); ?>>50</option>
                        <option value="100" <?php selected($per_page, 100); ?>>100</option>
                    </select>
                    <span>entries per page</span>
                </form>
            </div>
        </div>
        
        <style>
            .tablenav-pages .pagination-links {
                font-size: 16px;
            }
            .tablenav-pages .pagination-links a,
            .tablenav-pages .pagination-links span.current {
                font-size: 16px;
                min-width: 30px;
                height: 30px;
                line-height: 28px;
                text-decoration: none;
            }
        </style>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php _e('IP Address', 'bot-eraser'); ?></th>
                    <th><?php _e('Expires', 'bot-eraser'); ?></th>
                    <th><?php _e('Time Remaining', 'bot-eraser'); ?></th>
                    <th><?php _e('Actions', 'bot-eraser'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($blocked_ips)): ?>
                    <tr>
                        <td colspan="4"><?php _e('No IP addresses currently blocked', 'bot-eraser'); ?></td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($page_items as $data): ?>
                        <tr>
                            <td><?php echo esc_html($data['ip']); ?></td>
                            <td><?php echo esc_html($data['expires']); ?></td>
                            <td><?php echo esc_html($data['remaining']); ?></td>
                            <td>
                                <form method="post" style="display:inline;">
                                    <?php wp_nonce_field('bot_eraser_unblock_ip'); ?>
                                    <input type="hidden" name="action" value="unblock_ip">
                                    <input type="hidden" name="ip" value="<?php echo esc_attr($data['ip']); ?>">
                                    <button type="submit" class="button button-secondary" 
                                            onclick="return confirm('<?php echo esc_js(sprintf(__('Are you sure you want to unblock %s?', 'bot-eraser'), $data['ip'])); ?>')">
                                        <?php _e('Unblock', 'bot-eraser'); ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <?php if ($total_pages > 1): ?>
        <div class="tablenav bottom">
            <div class="tablenav-pages">
                <span class="displaying-num">
                    Showing <?php echo number_format(($current_page - 1) * $per_page + 1); ?> - 
                    <?php echo number_format(min($current_page * $per_page, $total_items)); ?> of 
                    <?php echo number_format($total_items); ?> entries
                </span>
                <span class="pagination-links">
                    <?php
                    $pagination_args = array(
                        'base' => add_query_arg(array('paged' => '%#%', 'per_page' => $per_page)),
                        'format' => '',
                        'prev_text' => __('&laquo;'),
                        'next_text' => __('&raquo;'),
                        'total' => $total_pages,
                        'current' => $current_page
                    );
                    echo paginate_links($pagination_args);
                    ?>
                </span>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Manually block a single IP address
 * 
 * @param string $ip IP address to block
 * @param int $duration Duration in hours (default 24)
 * @return bool True if IP was blocked, false if invalid
 */
function bot_eraser_manual_block_ip($ip, $duration = 24) {
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        error_log('Boteraser Error: Invalid IP address format');
        return false;
    }

    $cache_file = __DIR__ . '/blocked-ips.php';
    $blocked_ips = file_exists($cache_file) ? include $cache_file : [];
    $blocked_ips[$ip] = time() + ($duration * 3600);
    
    file_put_contents($cache_file, '<?php return ' . var_export($blocked_ips, true) . ';');
    return true;
}

/**
 * Block multiple IP addresses at once
 * 
 * @param array $ips Array of IP addresses to block
 * @param int $duration Duration in hours (default 24)
 * @return array Results with status for each IP
 */
function bot_eraser_manual_block_multiple($ips, $duration = 24) {
    $results = [];
    foreach ($ips as $ip) {
        $results[$ip] = bot_eraser_manual_block_ip($ip, $duration);
    }
    return $results;
}

// Usage example:
// bot_eraser_manual_block_ip('192.168.1.1'); // Block for 24 hours

/**
 * Block IP immediately and end request
 * 
 * @param string $ip IP address being blocked
 */
function bot_eraser_force_block($ip) {
    if (!headers_sent()) {
        header('HTTP/1.1 403 Forbidden');
        header('Status: 403 Forbidden');
        header('Retry-After: 3600');
        nocache_headers();
    }
    
    error_log("Boteraser: Blocked access attempt from IP: " . $ip);
    die('<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body><h1>Access Denied</h1><p>Your IP address has been blocked.</p></body></html>');
}

/**
 * Check if current visitor IP is blocked
 */
function bot_eraser_check_ip() {
    // Skip check for admin users
    if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
        return;
    }

    // Get real visitor IP
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? // Cloudflare
          $_SERVER['HTTP_TRUE_CLIENT_IP'] ?? // Akamai and others
          $_SERVER['HTTP_X_REAL_IP'] ?? // Nginx proxy
          $_SERVER['HTTP_X_FORWARDED_FOR'] ?? // Standard proxy header
          $_SERVER['HTTP_X_FORWARDED'] ?? // Some proxy variants
          $_SERVER['HTTP_FORWARDED_FOR'] ?? // RFC 7239
          $_SERVER['HTTP_FORWARDED'] ?? // RFC 7239
          $_SERVER['HTTP_VIA'] ?? // Via proxy
          $_SERVER['HTTP_CLIENT_IP'] ?? // Client IP
          $_SERVER['HTTP_X_CLIENT_IP'] ?? // Some CDNs
          $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'] ?? // Load balancers
          $_SERVER['REMOTE_ADDR'] ?? // Direct IP
          '0.0.0.0';
    
    $ip = explode(',', $ip)[0];
    $ip = filter_var(trim($ip), FILTER_VALIDATE_IP) ?: '0.0.0.0';

    if (bot_eraser_is_ip_blocked($ip)) {
        status_header(403);
        header('HTTP/1.1 403 Forbidden');
        header('Status: 403 Forbidden');
        header('Retry-After: 3600');
        nocache_headers();
        die('403 Forbidden - Access Denied');
    }
}

// Use multiple hooks to ensure blocking at different entry points
add_action('plugins_loaded', 'bot_eraser_check_ip', 1);
add_action('init', 'bot_eraser_check_ip', 1);
add_action('template_redirect', 'bot_eraser_check_ip', 1);

/**
 * Early IP blocking check
 */
function bot_eraser_early_block_check() {
    // Skip admin and AJAX only for logged-in administrators
    if (function_exists('current_user_can') && current_user_can('manage_options')) {
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }
    }

    // Get real visitor IP
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? // Cloudflare
          $_SERVER['HTTP_TRUE_CLIENT_IP'] ?? // Akamai and others
          $_SERVER['HTTP_X_REAL_IP'] ?? // Nginx proxy
          $_SERVER['HTTP_X_FORWARDED_FOR'] ?? // Standard proxy header
          $_SERVER['HTTP_X_FORWARDED'] ?? // Some proxy variants
          $_SERVER['HTTP_FORWARDED_FOR'] ?? // RFC 7239
          $_SERVER['HTTP_FORWARDED'] ?? // RFC 7239
          $_SERVER['HTTP_VIA'] ?? // Via proxy
          $_SERVER['HTTP_CLIENT_IP'] ?? // Client IP
          $_SERVER['HTTP_X_CLIENT_IP'] ?? // Some CDNs
          $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'] ?? // Load balancers
          $_SERVER['REMOTE_ADDR'] ?? // Direct IP
          '0.0.0.0';
    
    $ip = explode(',', $ip)[0];
    $ip = filter_var(trim($ip), FILTER_VALIDATE_IP) ?: '0.0.0.0';

    if (bot_eraser_is_ip_blocked($ip)) {
        error_log("Boteraser: Blocked access from IP: $ip");
        http_response_code(403);
        header('HTTP/1.1 403 Forbidden');
        header('Status: 403 Forbidden');
        header('Retry-After: 3600');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        die('403 Forbidden - Access Denied');
    }
}

// Hook into WordPress as early as possible
add_action('send_headers', 'bot_eraser_early_block_check', -9999);
add_action('parse_request', 'bot_eraser_early_block_check', -9999);
add_action('wp', 'bot_eraser_early_block_check', -9999);

// Also hook into template loading
add_action('template_redirect', 'bot_eraser_early_block_check', -9999);

// Catch other entry points
add_action('plugins_loaded', 'bot_eraser_early_block_check', -9999);
add_action('init', 'bot_eraser_early_block_check', -9999);
