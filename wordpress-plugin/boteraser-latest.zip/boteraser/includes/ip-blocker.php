<?php
if (!defined('ABSPATH')) {
    exit;
}

function bot_eraser_block_ips($ips) {
    if (empty($ips) || !is_array($ips)) {
        error_log('Boteraser Error: Invalid IP array provided');
        return false;
    }

    $cache_file = __DIR__ . '/blocked-ips.php';
    $blocked_ips = file_exists($cache_file) ? include $cache_file : [];

    // Clean up expired IPs before adding new ones
    $current_time = time();
    $blocked_ips = array_filter($blocked_ips, function($expiry) use ($current_time) {
        return $expiry > $current_time;
    });

    foreach ($ips as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP)) continue;
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) continue;
        $blocked_ips[$ip] = time() + 24 * 60 * 60; // Block for 24 hours
    }

    bot_eraser_write_ip_cache($cache_file, $blocked_ips);

    // Update WordPress transient if WordPress is loaded
    if (function_exists('set_transient')) {
        set_transient('bot_eraser_blocked_ips', $blocked_ips, 24 * 60 * 60);
    }

    return true;
}

function bot_eraser_is_ip_blocked($ip) {
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
        if (isset($blocked_ips[$ip]) && time() < $blocked_ips[$ip]) {
            return true;
        }
    }
    return false;
}

// Block seconds remaining; 0 if unblocked
function bot_eraser_block_remaining($ip) {
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
        if (isset($blocked_ips[$ip]) && time() < $blocked_ips[$ip]) {
            return $blocked_ips[$ip] - time();
        }
    }
    return 0;
}

function bot_eraser_get_blocked_ips() {
    $blocked_ips = [];

    // File is the single source of truth for the admin list
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (file_exists($cache_file)) {
        if (function_exists("opcache_invalidate")) {
            opcache_invalidate($cache_file, true);
        }
        $blocked_ips = include $cache_file;
    }

    $current_time = time();
    $active_blocks = [];
    $expired_found = false;

    foreach ($blocked_ips as $ip => $expiry) {
        if ($current_time < $expiry) {
            $remaining_seconds = $expiry - $current_time;
            $remaining_hours = floor($remaining_seconds / 3600);
            $remaining_minutes = floor(($remaining_seconds % 3600) / 60);

            // Format as "3h 45m" or "45m" (if 0 hours) or "0m" (if less than 1 minute)
            if ($remaining_hours > 0) {
                $time_remaining = $remaining_hours . 'h ' . $remaining_minutes . 'm';
            } else {
                $time_remaining = max(1, $remaining_minutes) . 'm'; // Show at least 1m
            }

            $active_blocks[$ip] = [
                'ip' => $ip,
                'expires' => date('Y-m-d H:i:s', $expiry),
                'remaining' => $time_remaining,
                'sort_key' => $remaining_seconds // Sort by total seconds remaining
            ];
        } else {
            $expired_found = true;
        }
    }

    // If we found expired IPs, clean up the file
    if ($expired_found && file_exists($cache_file)) {
        $cleaned_ips = array_filter($blocked_ips, function($expiry) use ($current_time) {
            return $expiry > $current_time;
        });
        bot_eraser_write_ip_cache($cache_file, $cleaned_ips);
    }

    // Sort by remaining hours in descending order
    uasort($active_blocks, function($a, $b) {
        return $b['sort_key'] - $a['sort_key'];
    });

    return $active_blocks;
}

/**
 * Clean up expired IP addresses from the blocked-ips.php file
 *
 * @return array ['removed' => count, 'remaining' => count]
 */
function bot_eraser_cleanup_expired_ips() {
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (!file_exists($cache_file)) {
        return ['removed' => 0, 'remaining' => 0];
    }

    $blocked_ips = include $cache_file;
    $current_time = time();
    $original_count = count($blocked_ips);

    // Filter out expired IPs
    $active_ips = array_filter($blocked_ips, function($expiry) use ($current_time) {
        return $expiry > $current_time;
    });

    $remaining_count = count($active_ips);
    $removed_count = $original_count - $remaining_count;

    // Update the file only if something was removed
    if ($removed_count > 0) {
        bot_eraser_write_ip_cache($cache_file, $active_ips);

        // Also update WordPress transient if available
        if (function_exists('set_transient')) {
            set_transient('bot_eraser_blocked_ips', $active_ips, 24 * 60 * 60);
        }
    }

    return ['removed' => $removed_count, 'remaining' => $remaining_count];
}

// Add this new function near the other IP management functions
function bot_eraser_unblock_ip($ip) {
    if (!filter_var($ip, FILTER_VALIDATE_IP)) return false;

    // Remove from file cache
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
        if (isset($blocked_ips[$ip])) {
            unset($blocked_ips[$ip]);
            bot_eraser_write_ip_cache($cache_file, $blocked_ips);
        }
    }

    // Remove from transient
    $wp_blocked_ips = get_transient('bot_eraser_blocked_ips') ?: [];
    if (isset($wp_blocked_ips[$ip])) {
        unset($wp_blocked_ips[$ip]);
        set_transient('bot_eraser_blocked_ips', $wp_blocked_ips, 24 * 60 * 60);
    }

    // Remove from block reasons
    $reasons = get_option('bot_eraser_block_reasons', []);
    if (is_array($reasons) && isset($reasons[$ip])) {
        unset($reasons[$ip]);
        update_option('bot_eraser_block_reasons', $reasons);
    }

    // Remove from fingerprint queue
    $queue = get_option('bot_eraser_fp_blacklist_queue', []);
    if (is_array($queue) && isset($queue[$ip])) {
        unset($queue[$ip]);
        update_option('bot_eraser_fp_blacklist_queue', $queue);
    }

    // Mark IP as just-unblocked for 10 minutes to prevent immediate re-block
    set_transient('bot_eraser_unblocked_' . md5($ip), 1, 10 * MINUTE_IN_SECONDS);

    return true;
}

function bot_eraser_is_just_unblocked($ip) {
    return get_transient('bot_eraser_unblocked_' . md5($ip)) !== false;
}

/**
 * Handle unblock IP via admin-post.php
 */
function bot_eraser_handle_unblock_ip() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have permission to perform this action.', 'bot-eraser'));
    }
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'bot_eraser_unblock_ip')) {
        wp_die(__('Security check failed.', 'bot-eraser'));
    }
    $ip = sanitize_text_field($_POST['ip'] ?? '');
    if ($ip) {
        bot_eraser_unblock_ip($ip);
    }
    wp_redirect(add_query_arg(['page' => 'bot-eraser-blocked-ips', 'unblocked' => urlencode($ip)], admin_url('admin.php')));
    exit;
}
add_action('admin_post_bot_eraser_unblock_ip', 'bot_eraser_handle_unblock_ip');

/**
 * AJAX handler for unblock IP
 */
function bot_eraser_ajax_unblock_ip() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied', 403);
    }
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bot_eraser_unblock_ip')) {
        wp_send_json_error('Security check failed', 403);
    }
    $ip = sanitize_text_field($_POST['ip'] ?? '');
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        wp_send_json_error('Invalid IP');
    }
    bot_eraser_unblock_ip($ip);
    wp_send_json_success();
}
add_action('wp_ajax_bot_eraser_unblock_ip', 'bot_eraser_ajax_unblock_ip');

/**
 * Render the blocked IPs page with premium styling
 */
function bot_eraser_render_blocked_ips() {
    try {
    // Fold in any pending live hit deltas so the Count column is current.
    if (function_exists('bot_eraser_hit_flush')) {
        bot_eraser_hit_flush();
    }

    $ip_unblocked = false;
    $unblocked_ip = '';

    if (isset($_GET['unblocked'])) {
        $ip_unblocked = true;
        $unblocked_ip = sanitize_text_field(urldecode($_GET['unblocked']));
    }

    $blocked_ips = bot_eraser_get_blocked_ips();

    // Ensure OPcache is fresh for the subsequent includes
    $be_cache_file = __DIR__ . "/blocked-ips.php";
    if (file_exists($be_cache_file) && function_exists("opcache_invalidate")) {
        opcache_invalidate($be_cache_file, true);
    }

    // Enrich every row with its hit count and derived bot name so the list can be
    // sorted by those columns (block_reasons is the durable store for both).
    $sort_reasons   = get_option('bot_eraser_block_reasons', []);
    if (!is_array($sort_reasons)) $sort_reasons = [];
    $sort_detection = function_exists('bot_eraser_get_detection_config') ? bot_eraser_get_detection_config() : [];
    foreach ($blocked_ips as $sort_ip => &$sort_row) {
        $r = $sort_reasons[$sort_ip] ?? null;
        $sort_row['count'] = is_array($r) && isset($r['count']) ? (int) $r['count'] : 0;
        $ua = is_array($r) && !empty($r['ua']) ? $r['ua'] : '';
        $bn = '';
        if ($ua !== '') {
            if (function_exists('bot_eraser_extract_bot_name')) {
                $bn = bot_eraser_extract_bot_name($ua, $sort_detection);
            }
            if ($bn === '' && function_exists('bot_eraser_detect_bot_name')) {
                $d  = bot_eraser_detect_bot_name($ua);
                $bn = ($d === 'N/A') ? '' : $d;
            }
        }
        $sort_row['bot_name'] = $bn;
        $sort_row['reason']   = is_array($r) && !empty($r['source']) ? (string) $r['source'] : '';
    }
    unset($sort_row);

    // Sorting: remaining time (default), hit count, or bot name. Empty bot names
    // always sink to the bottom regardless of direction.
    $sort = isset($_GET['be_sort']) ? sanitize_key($_GET['be_sort']) : 'remaining';
    if (!in_array($sort, ['remaining', 'expires', 'count', 'bot', 'reason'], true)) $sort = 'remaining';
    $dir  = (isset($_GET['be_dir']) && $_GET['be_dir'] === 'asc') ? 'asc' : 'desc';
    $mult = ($dir === 'asc') ? 1 : -1;
    if ($sort === 'count') {
        uasort($blocked_ips, function ($a, $b) use ($mult) {
            return ($a['count'] <=> $b['count']) * $mult ?: strcmp($a['ip'], $b['ip']);
        });
    } elseif ($sort === 'bot' || $sort === 'reason') {
        // Rows store the bot label under 'bot_name'; map the column key to it.
        $key = ($sort === 'bot') ? 'bot_name' : 'reason';
        uasort($blocked_ips, function ($a, $b) use ($mult, $key) {
            $ae = ($a[$key] === ''); $be = ($b[$key] === '');
            if ($ae !== $be) return $ae ? 1 : -1; // empty values always sink to the bottom
            return strcasecmp($a[$key], $b[$key]) * $mult ?: strcmp($a['ip'], $b['ip']);
        });
    } else {
        // 'remaining' and 'expires' share the same ordering (expiry = now + remaining).
        uasort($blocked_ips, function ($a, $b) use ($mult) {
            return ($a['sort_key'] <=> $b['sort_key']) * $mult;
        });
    }

    // Pagination setup
    $per_page = isset($_GET['per_page']) ? max(10, intval($_GET['per_page'])) : 10;
    $allowed_per_page = [10, 20, 50, 100];
    if (!in_array($per_page, $allowed_per_page)) {
        $per_page = 10;
    }
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $total_items = count($blocked_ips);
    $total_pages = max(1, ceil($total_items / $per_page));

    // Slice the array for current page
    $offset = ($current_page - 1) * $per_page;
    $page_items = array_slice($blocked_ips, $offset, $per_page, true);

    // Calculate stats
    $expiring_soon = 0;
    foreach ($blocked_ips as $data) {
        if ($data['sort_key'] < 3600) { // Less than 1 hour remaining
            $expiring_soon++;
        }
    }

    // Hero KPI: Last block, Peak hour, Threat level
    $cache_file = __DIR__ . '/blocked-ips.php';
    $all_blocks_raw = file_exists($cache_file) ? (array) include($cache_file) : array();

    // Last block — most recently added = highest expiry (expiry = block_time + 24h)
    $last_block_label = '—';
    if (!empty($all_blocks_raw)) {
        $newest_expiry = max($all_blocks_raw);
        $block_time    = $newest_expiry - BOT_ERASER_BLOCK_DURATION;
        $diff          = time() - $block_time;
        if ($diff < 60) {
            $last_block_label = $diff . ' ' . __('sec ago', 'bot-eraser');
        } elseif ($diff < 3600) {
            $last_block_label = round($diff / 60) . ' ' . __('min ago', 'bot-eraser');
        } elseif ($diff < BOT_ERASER_BLOCK_DURATION) {
            $last_block_label = round($diff / 3600) . ' ' . __('hrs ago', 'bot-eraser');
        } else {
            $last_block_label = date_i18n(get_option('date_format'), $block_time);
        }
    }

    // Peak hour — hour of day with most blocks based on expiry times
    $hour_counts = array_fill(0, 24, 0);
    foreach ($all_blocks_raw as $expiry) {
        $block_time = $expiry - BOT_ERASER_BLOCK_DURATION;
        $hour_counts[(int) date('G', $block_time)]++;
    }
    $peak_hour_index = array_search(max($hour_counts), $hour_counts);
    $peak_hour_label = !empty($all_blocks_raw)
        ? date_i18n('H:00', mktime($peak_hour_index, 0, 0))
        : '—';

    // Threat level
    $threat_level = bot_eraser_get_threat_level();
    $threat_value = !empty($all_blocks_raw) ? strtoupper($threat_level['level']) : '—';
    $threat_tone  = $threat_level['level'];

    $hero_metrics = array(
        array(
            'label'   => __('Last block', 'bot-eraser'),
            'value'   => $last_block_label,
            'context' => __('Most recent block added', 'bot-eraser'),
            'tone'    => 'neutral',
        ),
        array(
            'label'   => __('Peak hour', 'bot-eraser'),
            'value'   => $peak_hour_label,
            'context' => __('Hour with most blocks', 'bot-eraser'),
            'tone'    => 'neutral',
        ),
        array(
            'label'   => __('Threat level', 'bot-eraser'),
            'value'   => $threat_value,
            'context' => __('Current detection state', 'bot-eraser'),
            'tone'    => $threat_tone,
        ),
    );
    ?>

    <?php
    // Build "Expiring soonest" aside — top 3 with the lowest sort_key.
    // Always pad to 3 rows so every aside on this stack lines up the
    // same height regardless of how much real data we have.
    $expiring_list = $blocked_ips;
    uasort($expiring_list, function($a, $b) { return $a['sort_key'] - $b['sort_key']; });
    $expiring_top = array_slice($expiring_list, 0, 3, true);

    $aside_items = '';
    foreach ($expiring_top as $row) {
        $aside_items .= sprintf(
            '<li class="boteraser-hero-aside-item"><span class="boteraser-hero-aside-item-key">%s</span><span class="boteraser-hero-aside-item-val">%s</span></li>',
            esc_html($row['ip']),
            esc_html($row['remaining'])
        );
    }
    $rendered_rows = count($expiring_top);
    if ($rendered_rows === 0) {
        $aside_items = '<li class="boteraser-hero-aside-item is-empty">' . esc_html__('No active blocks.', 'bot-eraser') . '</li>';
        $rendered_rows = 1;
    }
    for ($i = $rendered_rows; $i < 4; $i++) {
        $aside_items .= '<li class="boteraser-hero-aside-item is-placeholder"><span class="boteraser-hero-aside-item-key">·</span><span class="boteraser-hero-aside-item-val">·</span></li>';
    }
    $blocked_ips_aside = sprintf(
        '<div class="boteraser-hero-aside boteraser-hero-aside-list"><p class="boteraser-hero-aside-eyebrow">%s</p><h3 class="boteraser-hero-aside-title">%s</h3><ul class="boteraser-hero-aside-items">%s</ul><p class="boteraser-hero-aside-foot is-placeholder">·</p></div>',
        esc_html__('Expiring soonest', 'bot-eraser'),
        esc_html(sprintf(_n('%s active block', '%s active blocks', $total_items, 'bot-eraser'), number_format_i18n($total_items))),
        $aside_items
    );
    ?>
    <div class="wrap boteraser-wrap">
        <?php bot_eraser_render_page_header(array(
            'variant'  => 'standard',
            'title'    => __('Blocked IPs', 'bot-eraser'),
            'subtitle' => __('Review active IP blocks, monitor expirations, and keep mitigation rules easy to audit.', 'bot-eraser'),
            'metrics'  => $hero_metrics,
            'aside'    => $blocked_ips_aside,
        )); ?>

        <!-- Notices -->
        <?php if ($ip_unblocked): ?>
            <div class="boteraser-notice success">
                <?php echo bot_eraser_icon('check-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title"><?php _e('IP Unblocked', 'bot-eraser'); ?></p>
                    <p class="boteraser-notice-message">
                        <?php printf(__('IP address %s has been successfully unblocked.', 'bot-eraser'), '<strong>' . esc_html($unblocked_ip) . '</strong>'); ?>
                    </p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="boteraser-stats-grid">
            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon danger">
                    <?php echo bot_eraser_icon('shield-x'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" id="be-stat-total" data-count="<?php echo esc_attr($total_items); ?>">
                        <?php echo number_format($total_items); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Total Blocked', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon warning">
                    <?php echo bot_eraser_icon('clock'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" id="be-stat-expiring" data-count="<?php echo esc_attr($expiring_soon); ?>">
                        <?php echo number_format($expiring_soon); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Expiring Soon', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon primary">
                    <?php echo bot_eraser_icon('shield'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value">24h</p>
                    <p class="boteraser-stat-label"><?php _e('Block Duration', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon success">
                    <?php echo bot_eraser_icon('check-circle'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" id="be-stat-status"><?php echo $total_items > 0 ? __('Active', 'bot-eraser') : __('Clear', 'bot-eraser'); ?></p>
                    <p class="boteraser-stat-label"><?php _e('Protection Status', 'bot-eraser'); ?></p>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="boteraser-card">
            <!-- Filter Bar -->
            <div class="boteraser-filter-bar">
                <div class="boteraser-filter-group">
                    <span class="boteraser-status-badge <?php echo $total_items > 0 ? 'error' : 'success'; ?>">
                        <?php echo $total_items > 0 ? bot_eraser_icon('shield-x') : bot_eraser_icon('check-circle'); ?>
                        <?php echo $total_items > 0
                            ? sprintf(_n('%d IP Blocked', '%d IPs Blocked', $total_items, 'bot-eraser'), $total_items)
                            : __('No Blocked IPs', 'bot-eraser'); ?>
                    </span>
                </div>

                <?php if ($total_items > 0): ?>
                <div class="boteraser-filter-group">
                    <span class="boteraser-filter-label">
                        <?php printf(
                            __('Showing %s-%s of %s', 'bot-eraser'),
                            number_format(min(($current_page - 1) * $per_page + 1, $total_items)),
                            number_format(min($current_page * $per_page, $total_items)),
                            number_format($total_items)
                        ); ?>
                    </span>

                    <form method="get" style="margin: 0; display: flex; align-items: center; gap: 8px;">
                        <?php
                        $allowed_params = ['page', 'unblocked'];
                        foreach ($allowed_params as $param_key):
                            if (isset($_GET[$param_key])):
                        ?>
                                <input type="hidden" name="<?php echo esc_attr($param_key); ?>" value="<?php echo esc_attr($_GET[$param_key]); ?>">
                        <?php
                            endif;
                        endforeach;
                        ?>
                        <label for="per_page" class="boteraser-filter-label"><?php _e('Show:', 'bot-eraser'); ?></label>
                        <select name="per_page" id="per_page" class="boteraser-filter-select" onchange="this.form.submit()">
                            <option value="10" <?php selected($per_page, 10); ?>>10</option>
                            <option value="20" <?php selected($per_page, 20); ?>>20</option>
                            <option value="50" <?php selected($per_page, 50); ?>>50</option>
                            <option value="100" <?php selected($per_page, 100); ?>>100</option>
                        </select>
                    </form>
                </div>
                <?php endif; ?>
            </div>

            <!-- Blocked IPs Table -->
            <?php if (empty($blocked_ips)): ?>
                <div class="boteraser-empty-state">
                    <?php echo bot_eraser_icon('shield-check'); ?>
                    <p style="margin-top: 16px; font-size: 16px;"><?php _e('No IP addresses currently blocked', 'bot-eraser'); ?></p>
                    <p style="font-size: 14px;"><?php _e('Your site is protected. blacklisted IPs will appear here when detected.', 'bot-eraser'); ?></p>
                </div>
            <?php else: ?>
                <div class="boteraser-table-wrapper">
                    <table class="boteraser-table">
                        <?php
                        $block_reasons = get_option('bot_eraser_block_reasons', []);
                        if (!is_array($block_reasons)) $block_reasons = [];
                        // Signal descriptions from detection.php (single source of truth)
                        $signal_descriptions = [];
                        if (function_exists('bot_eraser_get_detection_config')) {
                            foreach (bot_eraser_get_detection_config()['signals'] ?? [] as $_sig_key => $_sig_def) {
                                if (is_array($_sig_def) && !empty($_sig_def['desc'])) {
                                    $signal_descriptions[$_sig_key] = $_sig_def['desc'];
                                }
                            }
                        }
                        ?>
                        <?php
                        $detection_config = function_exists('bot_eraser_get_detection_config') ? bot_eraser_get_detection_config() : [];

                        // Build a sortable column header with TWO separate clickable arrow
                        // buttons: ▲ sorts ascending, ▼ sorts descending. The active
                        // direction is highlighted so the current sort is obvious.
                        $sort_header = function ($key, $label) use ($sort, $dir) {
                            $asc_active  = ($sort === $key && $dir === 'asc');
                            $desc_active = ($sort === $key && $dir === 'desc');
                            $asc_url     = esc_url(add_query_arg(['be_sort' => $key, 'be_dir' => 'asc',  'paged' => 1]));
                            $desc_url    = esc_url(add_query_arg(['be_sort' => $key, 'be_dir' => 'desc', 'paged' => 1]));
                            $base        = 'display:inline-block;padding:1px 5px;margin-left:3px;border:1px solid #c3c4c7;border-radius:3px;font-size:10px;line-height:1.4;text-decoration:none;cursor:pointer;';
                            $on          = 'background:#2271b1;color:#fff;border-color:#2271b1;';
                            $off         = 'background:#fff;color:#50575e;';
                            return '<span style="white-space:nowrap;">'
                                . '<a href="' . $asc_url . '" title="' . esc_attr__('Sort ascending', 'bot-eraser') . '" style="' . $base . 'margin-left:0;margin-right:3px;' . ($asc_active ? $on : $off) . '">&#9650;</a>'
                                . esc_html($label)
                                . '<a href="' . $desc_url . '" title="' . esc_attr__('Sort descending', 'bot-eraser') . '" style="' . $base . ($desc_active ? $on : $off) . '">&#9660;</a>'
                                . '</span>';
                        };
                        ?>
                        <thead>
                            <tr>
                                <th><?php _e('IP Address', 'bot-eraser'); ?></th>
                                <th><?php echo $sort_header('bot', __('Bot / User-Agent', 'bot-eraser')); ?></th>
                                <th><?php echo $sort_header('count', __('Count', 'bot-eraser')); ?></th>
                                <th><?php echo $sort_header('reason', __('Reason', 'bot-eraser')); ?></th>
                                <th><?php echo $sort_header('expires', __('Expires', 'bot-eraser')); ?></th>
                                <th><?php echo $sort_header('remaining', __('Time Remaining', 'bot-eraser')); ?></th>
                                <th><?php _e('Actions', 'bot-eraser'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($page_items as $data): ?>
                                <?php
                                $reason = $block_reasons[$data['ip']] ?? null;

                                // Bot / User-Agent name derived from the stored UA.
                                $row_ua   = is_array($reason) && !empty($reason['ua']) ? $reason['ua'] : '';
                                $bot_name = '';
                                if ($row_ua !== '') {
                                    if (function_exists('bot_eraser_extract_bot_name')) {
                                        $bot_name = bot_eraser_extract_bot_name($row_ua, $detection_config);
                                    }
                                    if ($bot_name === '' && function_exists('bot_eraser_detect_bot_name')) {
                                        $detected = bot_eraser_detect_bot_name($row_ua);
                                        $bot_name = ($detected === 'N/A') ? '' : $detected;
                                    }
                                }

                                // Hit count that triggered the block.
                                $row_count = is_array($reason) && isset($reason['count']) ? (int) $reason['count'] : 0;

                                if ($reason) {
                                    if ($reason['source'] === 'server') {
                                        $reason_html = '<span class="boteraser-status-badge warning " data-tooltip="Blocked by central server threat intelligence list">server list</span>';
                                    } else {
                                        $badges = '';
                                        $signal_labels = !empty($reason['signals']) ? $reason['signals'] : ['fingerprint'];
                                        foreach ($signal_labels as $label) {
                                            $tooltip = $signal_descriptions[$label] ?? $label;
                                            $badges .= '<span class="boteraser-status-badge error " data-tooltip="' . esc_attr($tooltip) . '" style="margin:1px 2px;">' . esc_html($label) . '</span>';
                                        }
                                        $reason_html = $badges;
                                    }
                                } else {
                                    $reason_html = '<span class="boteraser-status-badge" style="background:var(--be-gray-100);color:var(--be-gray-500);">—</span>';
                                }
                                ?>
                                <tr data-seconds="<?php echo esc_attr($data['sort_key']); ?>">
                                    <td>
                                        <span class="ip-address"><?php echo esc_html($data['ip']); ?></span>
                                    </td>
                                    <td>
                                        <?php if ($bot_name !== ''): ?>
                                            <span class="boteraser-status-badge" data-tooltip="<?php echo esc_attr($row_ua); ?>" style="background:var(--be-gray-100);color:var(--be-gray-700);"><?php echo esc_html($bot_name); ?></span>
                                        <?php else: ?>
                                            <span class="boteraser-status-badge"<?php echo $row_ua !== '' ? ' data-tooltip="' . esc_attr($row_ua) . '"' : ''; ?> style="background:var(--be-gray-100);color:var(--be-gray-500);">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span style="font-size: 12px; color: var(--be-gray-600);"><?php echo $row_count > 0 ? esc_html(number_format($row_count)) : '—'; ?></span>
                                    </td>
                                    <td><?php echo $reason_html; ?></td>
                                    <td>
                                        <span style="font-size: 12px; color: var(--be-gray-600);">
                                            <?php echo esc_html($data['expires']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php
                                        $remaining_class = 'success';
                                        if ($data['sort_key'] < 3600) $remaining_class = 'error';
                                        elseif ($data['sort_key'] < 7200) $remaining_class = 'warning';
                                        ?>
                                        <span class="boteraser-status-badge <?php echo esc_attr($remaining_class); ?>" style="font-size: 11px;">
                                            <?php echo bot_eraser_icon('clock'); ?>
                                            <?php echo esc_html($data['remaining']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button type="button"
                                                class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-unblock-btn"
                                                data-ip="<?php echo esc_attr($data['ip']); ?>"
                                                data-nonce="<?php echo esc_attr(wp_create_nonce('bot_eraser_unblock_ip')); ?>"
                                                data-confirm="<?php echo esc_js(sprintf(__('Are you sure you want to unblock %s?', 'bot-eraser'), $data['ip'])); ?>">
                                            <?php echo bot_eraser_icon('check'); ?>
                                            <?php _e('Unblock', 'bot-eraser'); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="boteraser-pagination">
                        <div class="boteraser-pagination-info">
                            <?php printf(
                                __('Showing %s - %s of %s entries', 'bot-eraser'),
                                number_format(($current_page - 1) * $per_page + 1),
                                number_format(min($current_page * $per_page, $total_items)),
                                number_format($total_items)
                            ); ?>
                        </div>
                        <div class="boteraser-pagination-links">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg(array('paged' => '%#%', 'per_page' => $per_page)),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ));
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php
    } catch (Throwable $e) {
        error_log('[BOTERASER_RENDER_CRASH] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
        echo '<div class="wrap boteraser-wrap"><p>A temporary error occurred.</p></div>';
    }
}

/**
 * Manually block a single IP address
 * 
 * @param string $ip IP address to block
 * @param int $duration Duration in hours (default 24)
 * @return bool True if IP was blocked, false if invalid
 */
function bot_eraser_manual_block_ip($ip, $duration = 24) {
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        error_log('Boteraser Error: Invalid IP address format');
        return false;
    }

    $cache_file = __DIR__ . '/blocked-ips.php';
    $blocked_ips = file_exists($cache_file) ? include $cache_file : [];
    $blocked_ips[$ip] = time() + ($duration * 3600);

    bot_eraser_write_ip_cache($cache_file, $blocked_ips);
    return true;
}

/**
 * Block multiple IP addresses at once
 * 
 * @param array $ips Array of IP addresses to block
 * @param int $duration Duration in hours (default 24)
 * @return array Results with status for each IP
 */
function bot_eraser_manual_block_multiple($ips, $duration = 24) {
    $results = [];
    foreach ($ips as $ip) {
        $results[$ip] = bot_eraser_manual_block_ip($ip, $duration);
    }
    return $results;
}

// Usage example:
// bot_eraser_manual_block_ip('192.168.1.1'); // Block for 24 hours

/**
 * Block IP immediately and end request
 * 
 * @param string $ip IP address being blocked
 */
function bot_eraser_force_block($ip) {
    if (!headers_sent()) {
        header('HTTP/1.1 403 Forbidden');
        header('Status: 403 Forbidden');
        header('Retry-After: 3600');
        nocache_headers();
    }
    
    error_log("Boteraser: Blocked access attempt from IP: " . $ip);
    die('<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body><h1>Access Denied</h1><p>Your IP address has been blocked.</p></body></html>');
}

/**
 * Check if current visitor IP is blocked
 */
function bot_eraser_check_ip() {
    if (is_admin() || wp_doing_ajax() || wp_doing_cron()) return;
    foreach ($_COOKIE as $name => $value) {
        if (strpos($name, 'wordpress_logged_in_') === 0) return;
    }

    $ip = bot_eraser_get_visitor_ip();

    if (bot_eraser_is_ip_blocked($ip)) {
        // Count the hit FIRST — the JA4 capture below exits, so anything after it
        // would be skipped on the first re-entry.
        bot_eraser_hit_incr($ip);

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0', true);
        header('Pragma: no-cache', true);

        // JA4 once then 403: first visit captures JA4, sets marker
        $ja4_key = 'bot_eraser_ja4_done_' . md5($ip);
        if (!get_transient($ja4_key)) {
            set_transient($ja4_key, 1, max(1, bot_eraser_block_remaining($ip)));
            $tok = bot_eraser_gen_token();
            bot_eraser_send_min_signal($ip, $tok); // JA4 pair (no orphan)
            bot_eraser_emit_analyze_capture($tok);
        }

        header('HTTP/1.1 403 Forbidden', true, 403);
        exit;
    }
}

// Single early hook for IP blocking check - immediate check in boteraser.php handles pre-WP blocking
add_action('plugins_loaded', 'bot_eraser_check_ip', 1);
