<?php
if (!defined('ABSPATH')) {
    exit;
}

function bot_eraser_block_ips($ips) {
    if (empty($ips) || !is_array($ips)) {
        error_log('Boteraser Error: Invalid IP array provided');
        return false;
    }

    $cache_file = __DIR__ . '/blocked-ips.php';
    $blocked_ips = file_exists($cache_file) ? include $cache_file : [];

    // Clean up expired IPs before adding new ones
    $current_time = time();
    $blocked_ips = array_filter($blocked_ips, function($expiry) use ($current_time) {
        return $expiry > $current_time;
    });

    foreach ($ips as $ip) {
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            $blocked_ips[$ip] = time() + 24 * 60 * 60; // Block for 24 hours
        }
    }

    file_put_contents($cache_file, '<?php return ' . var_export($blocked_ips, true) . ';');

    // Update WordPress transient if WordPress is loaded
    if (function_exists('set_transient')) {
        set_transient('bot_eraser_blocked_ips', $blocked_ips, 24 * 60 * 60);
    }

    return true;
}

function bot_eraser_is_ip_blocked($ip) {
    // Check file cache first
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
        if (isset($blocked_ips[$ip]) && time() < $blocked_ips[$ip]) {
            return true;
        }
    }
    
    // Check WordPress transient if available
    if (function_exists('get_transient')) {
        $blocked_ips = get_transient('bot_eraser_blocked_ips') ?: [];
        if (isset($blocked_ips[$ip]) && time() < $blocked_ips[$ip]) {
            return true;
        }
    }
    
    return false;
}

function bot_eraser_get_blocked_ips() {
    $blocked_ips = [];

    // Try file cache first
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (file_exists($cache_file)) {
        $blocked_ips = include $cache_file;
    }

    // Merge with WordPress transient if available
    if (function_exists('get_transient')) {
        $wp_blocked_ips = get_transient('bot_eraser_blocked_ips') ?: [];
        $blocked_ips = array_merge($blocked_ips, $wp_blocked_ips);
    }

    $current_time = time();
    $active_blocks = [];
    $expired_found = false;

    foreach ($blocked_ips as $ip => $expiry) {
        if ($current_time < $expiry) {
            $remaining_seconds = $expiry - $current_time;
            $remaining_hours = floor($remaining_seconds / 3600);
            $remaining_minutes = floor(($remaining_seconds % 3600) / 60);

            // Format as "3h 45m" or "45m" (if 0 hours) or "0m" (if less than 1 minute)
            if ($remaining_hours > 0) {
                $time_remaining = $remaining_hours . 'h ' . $remaining_minutes . 'm';
            } else {
                $time_remaining = max(1, $remaining_minutes) . 'm'; // Show at least 1m
            }

            $active_blocks[$ip] = [
                'ip' => $ip,
                'expires' => date('Y-m-d H:i:s', $expiry),
                'remaining' => $time_remaining,
                'sort_key' => $remaining_seconds // Sort by total seconds remaining
            ];
        } else {
            $expired_found = true;
        }
    }

    // If we found expired IPs, clean up the file
    if ($expired_found && file_exists($cache_file)) {
        $cleaned_ips = array_filter($blocked_ips, function($expiry) use ($current_time) {
            return $expiry > $current_time;
        });
        file_put_contents($cache_file, '<?php return ' . var_export($cleaned_ips, true) . ';');
    }

    // Sort by remaining hours in descending order
    uasort($active_blocks, function($a, $b) {
        return $b['sort_key'] - $a['sort_key'];
    });

    return $active_blocks;
}

/**
 * Clean up expired IP addresses from the blocked-ips.php file
 *
 * @return array ['removed' => count, 'remaining' => count]
 */
function bot_eraser_cleanup_expired_ips() {
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (!file_exists($cache_file)) {
        return ['removed' => 0, 'remaining' => 0];
    }

    $blocked_ips = include $cache_file;
    $current_time = time();
    $original_count = count($blocked_ips);

    // Filter out expired IPs
    $active_ips = array_filter($blocked_ips, function($expiry) use ($current_time) {
        return $expiry > $current_time;
    });

    $remaining_count = count($active_ips);
    $removed_count = $original_count - $remaining_count;

    // Update the file only if something was removed
    if ($removed_count > 0) {
        file_put_contents($cache_file, '<?php return ' . var_export($active_ips, true) . ';');

        // Also update WordPress transient if available
        if (function_exists('set_transient')) {
            set_transient('bot_eraser_blocked_ips', $active_ips, 24 * 60 * 60);
        }
    }

    return ['removed' => $removed_count, 'remaining' => $remaining_count];
}

// Add this new function near the other IP management functions
function bot_eraser_unblock_ip($ip) {
    $cache_file = __DIR__ . '/blocked-ips.php';
    if (!file_exists($cache_file)) {
        return false;
    }

    $blocked_ips = include $cache_file;
    if (isset($blocked_ips[$ip])) {
        unset($blocked_ips[$ip]);
        file_put_contents($cache_file, '<?php return ' . var_export($blocked_ips, true) . ';');

        // Also remove from WordPress transient if available
        if (function_exists('get_transient')) {
            $wp_blocked_ips = get_transient('bot_eraser_blocked_ips') ?: [];
            if (isset($wp_blocked_ips[$ip])) {
                unset($wp_blocked_ips[$ip]);
                set_transient('bot_eraser_blocked_ips', $wp_blocked_ips, 24 * 60 * 60);
            }
        }
        return true;
    }
    return false;
}

/**
 * Render the blocked IPs page with premium styling
 */
function bot_eraser_render_blocked_ips() {
    // Handle unblock action
    $ip_unblocked = false;
    $unblocked_ip = '';
    if (isset($_POST['action']) && $_POST['action'] === 'unblock_ip' &&
        isset($_POST['ip']) && isset($_POST['_wpnonce']) &&
        wp_verify_nonce($_POST['_wpnonce'], 'bot_eraser_unblock_ip')) {

        $ip = sanitize_text_field($_POST['ip']);
        if (bot_eraser_unblock_ip($ip)) {
            $ip_unblocked = true;
            $unblocked_ip = $ip;
        }
    }

    $blocked_ips = bot_eraser_get_blocked_ips();

    // Pagination setup
    $per_page = isset($_GET['per_page']) ? max(10, intval($_GET['per_page'])) : 10;
    $allowed_per_page = [10, 20, 50, 100];
    if (!in_array($per_page, $allowed_per_page)) {
        $per_page = 10;
    }
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $total_items = count($blocked_ips);
    $total_pages = max(1, ceil($total_items / $per_page));

    // Slice the array for current page
    $offset = ($current_page - 1) * $per_page;
    $page_items = array_slice($blocked_ips, $offset, $per_page, true);

    // Calculate stats
    $expiring_soon = 0;
    foreach ($blocked_ips as $data) {
        if ($data['sort_key'] < 3600) { // Less than 1 hour remaining
            $expiring_soon++;
        }
    }
    ?>

    <div class="wrap boteraser-wrap">
        <!-- Header -->
        <div class="boteraser-header">
            <img src="<?php echo esc_url(BOT_ERASER_PLUGIN_URL . 'assets/images/logo.svg'); ?>"
                 alt="Boteraser Logo"
                 class="boteraser-logo">
        </div>

        <!-- Notices -->
        <?php if ($ip_unblocked): ?>
            <div class="boteraser-notice success">
                <?php echo bot_eraser_icon('check-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title"><?php _e('IP Unblocked', 'bot-eraser'); ?></p>
                    <p class="boteraser-notice-message">
                        <?php printf(__('IP address %s has been successfully unblocked.', 'bot-eraser'), '<strong>' . esc_html($unblocked_ip) . '</strong>'); ?>
                    </p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="boteraser-stats-grid">
            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon danger">
                    <?php echo bot_eraser_icon('shield-x'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($total_items); ?>">
                        <?php echo number_format($total_items); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Total Blocked', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon warning">
                    <?php echo bot_eraser_icon('clock'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($expiring_soon); ?>">
                        <?php echo number_format($expiring_soon); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Expiring Soon', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon primary">
                    <?php echo bot_eraser_icon('shield'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value">24h</p>
                    <p class="boteraser-stat-label"><?php _e('Block Duration', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon success">
                    <?php echo bot_eraser_icon('check-circle'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value"><?php echo $total_items > 0 ? __('Active', 'bot-eraser') : __('Clear', 'bot-eraser'); ?></p>
                    <p class="boteraser-stat-label"><?php _e('Protection Status', 'bot-eraser'); ?></p>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="boteraser-card">
            <!-- Filter Bar -->
            <div class="boteraser-filter-bar">
                <div class="boteraser-filter-group">
                    <span class="boteraser-status-badge <?php echo $total_items > 0 ? 'error' : 'success'; ?>">
                        <?php echo $total_items > 0 ? bot_eraser_icon('shield-x') : bot_eraser_icon('check-circle'); ?>
                        <?php echo $total_items > 0
                            ? sprintf(_n('%d IP Blocked', '%d IPs Blocked', $total_items, 'bot-eraser'), $total_items)
                            : __('No Blocked IPs', 'bot-eraser'); ?>
                    </span>
                </div>

                <?php if ($total_items > 0): ?>
                <div class="boteraser-filter-group">
                    <span class="boteraser-filter-label">
                        <?php printf(
                            __('Showing %s-%s of %s', 'bot-eraser'),
                            number_format(min(($current_page - 1) * $per_page + 1, $total_items)),
                            number_format(min($current_page * $per_page, $total_items)),
                            number_format($total_items)
                        ); ?>
                    </span>

                    <form method="get" style="margin: 0; display: flex; align-items: center; gap: 8px;">
                        <?php foreach ($_GET as $key => $value): ?>
                            <?php if ($key !== 'per_page' && $key !== 'paged'): ?>
                                <input type="hidden" name="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>">
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <label for="per_page" class="boteraser-filter-label"><?php _e('Show:', 'bot-eraser'); ?></label>
                        <select name="per_page" id="per_page" class="boteraser-filter-select" onchange="this.form.submit()">
                            <option value="10" <?php selected($per_page, 10); ?>>10</option>
                            <option value="20" <?php selected($per_page, 20); ?>>20</option>
                            <option value="50" <?php selected($per_page, 50); ?>>50</option>
                            <option value="100" <?php selected($per_page, 100); ?>>100</option>
                        </select>
                    </form>
                </div>
                <?php endif; ?>
            </div>

            <!-- Blocked IPs Table -->
            <?php if (empty($blocked_ips)): ?>
                <div class="boteraser-empty-state">
                    <?php echo bot_eraser_icon('shield-check'); ?>
                    <p style="margin-top: 16px; font-size: 16px;"><?php _e('No IP addresses currently blocked', 'bot-eraser'); ?></p>
                    <p style="font-size: 14px;"><?php _e('Your site is protected. blacklisted IPs will appear here when detected.', 'bot-eraser'); ?></p>
                </div>
            <?php else: ?>
                <div class="boteraser-table-wrapper">
                    <table class="boteraser-table">
                        <thead>
                            <tr>
                                <th><?php _e('IP Address', 'bot-eraser'); ?></th>
                                <th><?php _e('Expires', 'bot-eraser'); ?></th>
                                <th><?php _e('Time Remaining', 'bot-eraser'); ?></th>
                                <th><?php _e('Actions', 'bot-eraser'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($page_items as $data): ?>
                                <tr>
                                    <td>
                                        <span class="ip-address"><?php echo esc_html($data['ip']); ?></span>
                                    </td>
                                    <td>
                                        <span style="font-size: 12px; color: var(--be-gray-600);">
                                            <?php echo esc_html($data['expires']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php
                                        $remaining_class = 'success';
                                        if ($data['sort_key'] < 3600) $remaining_class = 'error';
                                        elseif ($data['sort_key'] < 7200) $remaining_class = 'warning';
                                        ?>
                                        <span class="boteraser-status-badge <?php echo esc_attr($remaining_class); ?>" style="font-size: 11px;">
                                            <?php echo bot_eraser_icon('clock'); ?>
                                            <?php echo esc_html($data['remaining']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <form method="post" style="display: inline; margin: 0;">
                                            <?php wp_nonce_field('bot_eraser_unblock_ip'); ?>
                                            <input type="hidden" name="action" value="unblock_ip">
                                            <input type="hidden" name="ip" value="<?php echo esc_attr($data['ip']); ?>">
                                            <button type="submit" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm"
                                                    onclick="return confirm('<?php echo esc_js(sprintf(__('Are you sure you want to unblock %s?', 'bot-eraser'), $data['ip'])); ?>')">
                                                <?php echo bot_eraser_icon('check'); ?>
                                                <?php _e('Unblock', 'bot-eraser'); ?>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="boteraser-pagination">
                        <div class="boteraser-pagination-info">
                            <?php printf(
                                __('Showing %s - %s of %s entries', 'bot-eraser'),
                                number_format(($current_page - 1) * $per_page + 1),
                                number_format(min($current_page * $per_page, $total_items)),
                                number_format($total_items)
                            ); ?>
                        </div>
                        <div class="boteraser-pagination-links">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg(array('paged' => '%#%', 'per_page' => $per_page)),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ));
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

/**
 * Manually block a single IP address
 * 
 * @param string $ip IP address to block
 * @param int $duration Duration in hours (default 24)
 * @return bool True if IP was blocked, false if invalid
 */
function bot_eraser_manual_block_ip($ip, $duration = 24) {
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        error_log('Boteraser Error: Invalid IP address format');
        return false;
    }

    $cache_file = __DIR__ . '/blocked-ips.php';
    $blocked_ips = file_exists($cache_file) ? include $cache_file : [];
    $blocked_ips[$ip] = time() + ($duration * 3600);
    
    file_put_contents($cache_file, '<?php return ' . var_export($blocked_ips, true) . ';');
    return true;
}

/**
 * Block multiple IP addresses at once
 * 
 * @param array $ips Array of IP addresses to block
 * @param int $duration Duration in hours (default 24)
 * @return array Results with status for each IP
 */
function bot_eraser_manual_block_multiple($ips, $duration = 24) {
    $results = [];
    foreach ($ips as $ip) {
        $results[$ip] = bot_eraser_manual_block_ip($ip, $duration);
    }
    return $results;
}

// Usage example:
// bot_eraser_manual_block_ip('192.168.1.1'); // Block for 24 hours

/**
 * Block IP immediately and end request
 * 
 * @param string $ip IP address being blocked
 */
function bot_eraser_force_block($ip) {
    if (!headers_sent()) {
        header('HTTP/1.1 403 Forbidden');
        header('Status: 403 Forbidden');
        header('Retry-After: 3600');
        nocache_headers();
    }
    
    error_log("Boteraser: Blocked access attempt from IP: " . $ip);
    die('<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body><h1>Access Denied</h1><p>Your IP address has been blocked.</p></body></html>');
}

/**
 * Check if current visitor IP is blocked
 */
function bot_eraser_check_ip() {
    // Skip check for admin users
    if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
        return;
    }

    // Get real visitor IP
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? // Cloudflare
          $_SERVER['HTTP_TRUE_CLIENT_IP'] ?? // Akamai and others
          $_SERVER['HTTP_X_REAL_IP'] ?? // Nginx proxy
          $_SERVER['HTTP_X_FORWARDED_FOR'] ?? // Standard proxy header
          $_SERVER['HTTP_X_FORWARDED'] ?? // Some proxy variants
          $_SERVER['HTTP_FORWARDED_FOR'] ?? // RFC 7239
          $_SERVER['HTTP_FORWARDED'] ?? // RFC 7239
          $_SERVER['HTTP_VIA'] ?? // Via proxy
          $_SERVER['HTTP_CLIENT_IP'] ?? // Client IP
          $_SERVER['HTTP_X_CLIENT_IP'] ?? // Some CDNs
          $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'] ?? // Load balancers
          $_SERVER['REMOTE_ADDR'] ?? // Direct IP
          '0.0.0.0';
    
    $ip = explode(',', $ip)[0];
    $ip = filter_var(trim($ip), FILTER_VALIDATE_IP) ?: '0.0.0.0';

    if (bot_eraser_is_ip_blocked($ip)) {
        status_header(403);
        header('HTTP/1.1 403 Forbidden');
        header('Status: 403 Forbidden');
        header('Retry-After: 3600');
        nocache_headers();
        die('403 Forbidden - Access Denied');
    }
}

// Use multiple hooks to ensure blocking at different entry points
add_action('plugins_loaded', 'bot_eraser_check_ip', 1);
add_action('init', 'bot_eraser_check_ip', 1);
add_action('template_redirect', 'bot_eraser_check_ip', 1);

/**
 * Early IP blocking check
 */
function bot_eraser_early_block_check() {
    // Skip admin and AJAX only for logged-in administrators
    if (function_exists('current_user_can') && current_user_can('manage_options')) {
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }
    }

    // Get real visitor IP
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? // Cloudflare
          $_SERVER['HTTP_TRUE_CLIENT_IP'] ?? // Akamai and others
          $_SERVER['HTTP_X_REAL_IP'] ?? // Nginx proxy
          $_SERVER['HTTP_X_FORWARDED_FOR'] ?? // Standard proxy header
          $_SERVER['HTTP_X_FORWARDED'] ?? // Some proxy variants
          $_SERVER['HTTP_FORWARDED_FOR'] ?? // RFC 7239
          $_SERVER['HTTP_FORWARDED'] ?? // RFC 7239
          $_SERVER['HTTP_VIA'] ?? // Via proxy
          $_SERVER['HTTP_CLIENT_IP'] ?? // Client IP
          $_SERVER['HTTP_X_CLIENT_IP'] ?? // Some CDNs
          $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'] ?? // Load balancers
          $_SERVER['REMOTE_ADDR'] ?? // Direct IP
          '0.0.0.0';
    
    $ip = explode(',', $ip)[0];
    $ip = filter_var(trim($ip), FILTER_VALIDATE_IP) ?: '0.0.0.0';

    if (bot_eraser_is_ip_blocked($ip)) {
        error_log("Boteraser: Blocked access from IP: $ip");
        http_response_code(403);
        header('HTTP/1.1 403 Forbidden');
        header('Status: 403 Forbidden');
        header('Retry-After: 3600');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        die('403 Forbidden - Access Denied');
    }
}

// Hook into WordPress as early as possible
add_action('send_headers', 'bot_eraser_early_block_check', -9999);
add_action('parse_request', 'bot_eraser_early_block_check', -9999);
add_action('wp', 'bot_eraser_early_block_check', -9999);

// Also hook into template loading
add_action('template_redirect', 'bot_eraser_early_block_check', -9999);

// Catch other entry points
add_action('plugins_loaded', 'bot_eraser_early_block_check', -9999);
add_action('init', 'bot_eraser_early_block_check', -9999);
