<?php
if (!defined('ABSPATH')) {
    exit;
}

function bot_eraser_send_blocklist_to_server($type = 'cron') {
    if (!get_option('bot_eraser_privacy_notice_dismissed')) {
        return [
            'status'    => 'error',
            'message'   => 'Privacy notice must be accepted before sending data',
            'sent_data' => [],
            'response'  => ''
        ];
    }

    $result = [
        'status'    => 'error',
        'message'   => 'Initialization failed',
        'sent_data' => [],
        'response'  => ''
    ];

    try {
        global $wpdb;
        $api_key = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", 'bot_eraser_api_key'));
        $host_ip = get_option('bot_eraser_host_ip');
        $domain  = get_option('bot_eraser_domain');

        if (empty($api_key) || empty($host_ip) || empty($domain)) {
            throw new Exception('Required settings are missing. API key: ' . (empty($api_key) ? 'EMPTY' : 'OK') . ', Host IP: ' . (empty($host_ip) ? 'EMPTY' : 'OK') . ', Domain: ' . (empty($domain) ? 'EMPTY' : 'OK'));
        }

        $blocked_ips = bot_eraser_get_blocked_ips();
        $reasons     = get_option('bot_eraser_block_reasons', []);
        if (!is_array($reasons)) {
            $reasons = [];
        }

        $lines = [];
        foreach ($blocked_ips as $ip => $info) {
            if (!filter_var($ip, FILTER_VALIDATE_IP)) {
                continue;
            }
            $reason = (isset($reasons[$ip]) && is_array($reasons[$ip])) ? $reasons[$ip] : [];
            $count  = isset($reason['count']) ? (int) $reason['count'] : 1;
            $source = isset($reason['source']) ? $reason['source'] : 'local';
            $bot    = bot_eraser_detect_bot_name(isset($reason['ua']) ? $reason['ua'] : '');
            $lines[] = sprintf('%s %d %s %s', $ip, $count, $source, $bot);
        }

        $total_blocked = count($lines);

        if (defined('BOT_ERASER_SERVER_MAX_IPS')) {
            $lines = array_slice($lines, 0, BOT_ERASER_SERVER_MAX_IPS);
        }

        $whitelist_visits = get_option('bot_eraser_whitelist_visits', []);
        if (!is_array($whitelist_visits)) $whitelist_visits = [];
        $wl_ips = [];
        foreach ($whitelist_visits as $v) {
            $ip = $v['ip'] ?? '';
            if (!filter_var($ip, FILTER_VALIDATE_IP)) continue;
            if (!isset($wl_ips[$ip])) $wl_ips[$ip] = ['count' => 0, 'ua' => ''];
            $wl_ips[$ip]['count']++;
            if (!empty($v['ua']) && empty($wl_ips[$ip]['ua'])) $wl_ips[$ip]['ua'] = $v['ua'];
        }
        $wl_lines = [];
        foreach ($wl_ips as $ip => $info) {
            $wl_lines[] = sprintf('%s %d %s', $ip, $info['count'], $info['ua']);
        }
        delete_option('bot_eraser_whitelist_visits');

        $load       = function_exists('sys_getloadavg') ? sys_getloadavg() : [0, 0, 0];
        $srv_load   = number_format(isset($load[1]) ? $load[1] : 0, 2);
        $uptime_raw = @file_get_contents('/proc/uptime');
        $uptime     = $uptime_raw ? intval(explode(' ', $uptime_raw)[0]) : 0;

        $bf_data    = bot_eraser_bf_load_data();
        $bf_data    = bot_eraser_bf_cleanup($bf_data);
        $bf_max     = bot_eraser_bf_max_attempts();
        $bf_tracked = count($bf_data);
        $bf_blocked = count(array_filter($bf_data, function($e) use ($bf_max) {
            return $e['count'] >= $bf_max;
        }));

        $payload = [
            'api_key'     => $api_key,
            'type'        => 'blocklist',
            'host_ip'     => $host_ip,
            'domain'      => $domain,
            'total'       => $total_blocked,
            'blocklist'   => implode("\n", $lines),
            'whitelisted' => implode("\n", $wl_lines),
            'srv_load'    => $srv_load,
            'uptime'      => $uptime,
            'bf_tracked'  => $bf_tracked,
            'bf_blocked'  => $bf_blocked,
        ];

        $result['sent_data'] = $payload;

        $response = wp_remote_post(BOT_ERASER_BLOCKLIST_URL, [
            'body'      => $payload,
            'timeout'   => 10,
            'sslverify' => true
        ]);

        if (is_wp_error($response)) {
            $result['message'] = 'Blocklist server unreachable, local protection active';
            $result['status']  = 'warning';
            bot_eraser_debug_log('Blocklist server unreachable: ' . $response->get_error_message());
            return $result;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $result['response'] = $response_body;

        bot_eraser_debug_log('Blocklist server response code: ' . $response_code);

        if ($response_code >= 400) {
            throw new Exception($response_body ?: 'Blocklist server returned error code: ' . $response_code);
        }

        $result['status']  = 'success';
        $result['message'] = sprintf('Blocklist sent successfully. %d IP(s) reported.', count($lines));

    } catch (Exception $e) {
        $result['message'] = $e->getMessage();
        bot_eraser_debug_log('Blocklist sync exception: ' . $e->getMessage());
    }

    if (function_exists('bot_eraser_log_execution')) {
        bot_eraser_log_execution([
            'status'  => $result['status'],
            'message' => $result['message'],
            'type'    => $type
        ]);
    }

    return $result;
}
