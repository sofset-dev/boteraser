<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get the Brute Force max attempts threshold (default: 5).
 */
function bot_eraser_bf_max_attempts() {
    return (int) get_option('boteraser_bf_max_attempts', 5);
}

/**
 * Get the Brute Force time window in seconds (default: 900 = 15 minutes).
 */
function bot_eraser_bf_window_seconds() {
    return (int) get_option('boteraser_bf_window_minutes', 15) * 60;
}

/**
 * Get the Brute Force window in minutes for display (default: 15).
 */
function bot_eraser_bf_window_minutes() {
    return (int) get_option('boteraser_bf_window_minutes', 15);
}

/**
 * Get the soft-block duration in minutes (default: 15) — IP block duration
 * after threshold exceeded. Unlike "Time window": this is the PENALTY duration.
 */
function bot_eraser_bf_block_minutes() {
    return (int) get_option('boteraser_bf_block_minutes', 15);
}

function bot_eraser_bf_block_seconds() {
    return bot_eraser_bf_block_minutes() * 60;
}

/**
 * Check whether Brute Force protection is enabled (default: true).
 */
function bot_eraser_bf_is_enabled() {
    return (bool) get_option('boteraser_bf_enabled', true);
}

function bot_eraser_bf_get_ip() {
    return bot_eraser_get_visitor_ip();
}

function bot_eraser_bf_load_data() {
    $data = get_option('boteraser_bf_failures', array());
    return is_array($data) ? $data : array();
}

function bot_eraser_bf_save_data($data) {
    if (count($data) > BOT_ERASER_BF_MAX_ENTRIES) {
        $data = array_slice($data, -BOT_ERASER_BF_TRIM_TO, null, true);
    }
    update_option('boteraser_bf_failures', $data, false);
}

function bot_eraser_bf_cleanup($data) {
    $now = time();
    $window = bot_eraser_bf_window_seconds();
    foreach ($data as $ip => $entry) {
        // Keep active soft-block even after window expires (e.g. window 15min, block 24h).
        $blocked = !empty($entry['blocked_until']) && (int) $entry['blocked_until'] > $now;
        if (!$blocked && ($now - $entry['time']) > $window) {
            unset($data[$ip]);
        }
    }
    return $data;
}

function bot_eraser_bf_record_failure($username = '') {
    if (!bot_eraser_bf_is_enabled()) return;
    $ip = bot_eraser_bf_get_ip();
    if ($ip === '0.0.0.0') return;
    $data = bot_eraser_bf_load_data();
    $data = bot_eraser_bf_cleanup($data);
    $now = time();
    if (isset($data[$ip])) {
        $data[$ip]['count']++;
        $data[$ip]['time'] = $now;
        if (!empty($username)) $data[$ip]['username'] = $username;
    } else {
        $data[$ip] = array('count' => 1, 'time' => $now, 'username' => $username ?: 'unknown');
    }
    // Soft-block: lock IP for block_minutes when failures reach threshold.
    // Extend block on each attempt within window (sliding penalty).
    if ($data[$ip]['count'] >= bot_eraser_bf_max_attempts()) {
        $data[$ip]['blocked_until'] = $now + bot_eraser_bf_block_seconds();
    }
    bot_eraser_bf_save_data($data);
}

/**
 * Remaining soft-block seconds for IP (0 = not blocked).
 */
function bot_eraser_bf_blocked_remaining($ip) {
    if (!bot_eraser_bf_is_enabled()) return 0;
    $data = bot_eraser_bf_load_data();
    if (empty($data[$ip]['blocked_until'])) return 0;
    $remaining = (int) $data[$ip]['blocked_until'] - time();
    return $remaining > 0 ? $remaining : 0;
}

/**
 * Current failure count for IP in window (RAW data for module).
 */
function bot_eraser_bf_count_for_ip($ip) {
    if (!bot_eraser_bf_is_enabled()) return 0;
    $data = bot_eraser_bf_cleanup(bot_eraser_bf_load_data());
    return isset($data[$ip]) ? (int) $data[$ip]['count'] : 0;
}

function bot_eraser_bf_check_and_redirect() {
    if (!bot_eraser_bf_is_enabled()) return;
    if (is_user_logged_in()) return;
    if (!function_exists('bot_eraser_login_evaluate')) return;

    $ip = bot_eraser_bf_get_ip();
    if ($ip === '0.0.0.0') return;

    $count = bot_eraser_bf_count_for_ip($ip);
    if ($count === 0) return;

    // MODULE decides lockout. Admin setting acts as raw override.
    $config = bot_eraser_get_detection_config();
    $login  = bot_eraser_login_evaluate([
        'failed_count' => $count,
        'bf_max'       => bot_eraser_bf_max_attempts(),
    ], $config);

    if (empty($login['lockout'])) return;

    // BF = weak signal for module.
    // Queue + capture only when module confirms bot=true.
    // Queue + capture share
    // same token (no orphans). HUMAN (bot=false) not sent to cloud.
    // Evaluate once per window (deduped), redirect always with token.
    $window       = bot_eraser_bf_window_seconds();
    $reported_key = 'bot_eraser_bf_reported_' . md5($ip);
    $token_key    = 'bot_eraser_bf_token_' . md5($ip);

    if (!get_transient($reported_key) && function_exists('bot_eraser_build_server_context')) {
        set_transient($reported_key, 1, $window);
        $full   = bot_eraser_build_server_context($ip, ['failed_count' => $count, 'bf_max' => bot_eraser_bf_max_attempts()]);
        $result = bot_eraser_detect($full, $config);
        if (!empty($result['bot'])) {
            $token = bot_eraser_send_telemetry($result, ['ip' => $ip, 'ptr' => $full['ptr'] ?: '']);
            set_transient($token_key, $token, $window);
        }
    }

    // Redirect to analyze.php ONLY if token exists (bot=true).
    // No token (locked human / not bot) → no orphan capture.
    $token = (string) (get_transient($token_key) ?: '');
    if ($token !== '' && function_exists('bot_eraser_redirect_to_analyze')) {
        bot_eraser_redirect_to_analyze($token);
    }
}

function bot_eraser_bf_on_login_failed($username) {
    if (empty($username)) return;
    bot_eraser_bf_record_failure($username);
}
add_action('wp_login_failed', 'bot_eraser_bf_on_login_failed', 10, 1);

/**
 * Soft-block: reject login past threshold (WP_Error regardless of password).
 * Affects human + hidden brute-forcer (bot=false); loud bot reaches bot=true → cloud.
 * Priority > 20: runs AFTER wp_authenticate_username_password.
 */
function bot_eraser_bf_enforce_soft_block($user, $username = '', $password = '') {
    if (empty($username)) return $user;            // cookie/empty auth — ignore
    if (!bot_eraser_bf_is_enabled()) return $user;
    $ip = bot_eraser_bf_get_ip();
    if ($ip === '0.0.0.0') return $user;
    $remaining = bot_eraser_bf_blocked_remaining($ip);
    if ($remaining <= 0) return $user;
    $minutes = (int) ceil($remaining / 60);
    return new WP_Error('bot_eraser_locked', sprintf(
        /* translators: %d: minutes until the lockout expires */
        _n(
            'Too many failed login attempts. Please try again in %d minute.',
            'Too many failed login attempts. Please try again in %d minutes.',
            $minutes,
            'bot-eraser'
        ),
        $minutes
    ));
}
add_filter('authenticate', 'bot_eraser_bf_enforce_soft_block', 40, 3);

/**
 * Successful login clears failures for IP (resets sliding penalty).
 */
function bot_eraser_bf_clear_on_success($user_login, $user = null) {
    $ip = bot_eraser_bf_get_ip();
    if ($ip === '0.0.0.0') return;
    $data = bot_eraser_bf_load_data();
    if (isset($data[$ip])) {
        unset($data[$ip]);
        bot_eraser_bf_save_data($data);
    }
}
add_action('wp_login', 'bot_eraser_bf_clear_on_success', 10, 2);

function bot_eraser_bf_intercept_login_page() {
    bot_eraser_bf_check_and_redirect();
}
add_action('login_init', 'bot_eraser_bf_intercept_login_page', -9999);

add_action('init', function() {
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    if (strpos($request_uri, '/wp-login.php') !== false || strpos($request_uri, 'wp-login.php') !== false) {
        bot_eraser_bf_check_and_redirect();
    }
}, -9999);
