<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Server-side adapter — TANAK. I/O only: DNS, transient, $_SERVER, WBA crypto.
 * Fills raw context, passes to detection module. All thresholds in module.
 */

function bot_eraser_ts_is_enabled() {
    return (bool) get_option('boteraser_ts_enabled', true);
}

/**
 * Reverse DNS lookup, cached per IP. Returns raw host|false.
 */
function bot_eraser_ts_get_ptr($ip) {
    $key = 'bot_eraser_ts_ptr_' . md5($ip);
    $cached = get_transient($key);
    if ($cached !== false) return $cached === '0' ? false : $cached;

    $host = @gethostbyaddr($ip);
    $result = ($host && $host !== $ip) ? $host : false;
    set_transient($key, $result === false ? '0' : $result, 6 * HOUR_IN_SECONDS);
    return $result;
}

/**
 * Forward-confirmed reverse DNS. Returns raw bool.
 */
function bot_eraser_ts_fcrdns_ok($ip, $ptr_host) {
    $key = 'bot_eraser_ts_fcrdns_' . md5($ip);
    $cached = get_transient($key);
    if ($cached !== false) return $cached === '1';

    $forward = @gethostbyname($ptr_host);
    $ok = ($forward && $forward === $ip);
    set_transient($key, $ok ? '1' : '0', 6 * HOUR_IN_SECONDS);
    return $ok;
}

/**
 * Rate identity — per-session (first-party cookie), not per-IP.
 * Legit users behind shared IP get their own counter, no false high_rate.
 * Cookie-less HTTP bots (curl/scrapy) fall back to IP+UA.
 * Browser gets session cookie.
 */
function bot_eraser_ts_rate_id($ip, $ua) {
    $sid = $_COOKIE['be_sid'] ?? '';
    if (is_string($sid) && preg_match('/^[a-f0-9]{32}$/', $sid)) {
        return 'sid:' . $sid;
    }
    if (!headers_sent()) {
        $new    = bin2hex(random_bytes(16));
        $secure = (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off')
            || (($_SERVER['SERVER_PORT'] ?? '') == 443);
        setcookie('be_sid', $new, [
            'expires'  => 0, // session cookie
            'path'     => '/',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }
    return 'ip:' . $ip . '|' . substr((string) $ua, 0, 30);
}

/**
 * Rolling request counter per rate-identity (session or IP fallback).
 * Window from config.
 */
function bot_eraser_ts_track_request($rate_id, $window) {
    $key = 'bot_eraser_ts_cnt_' . md5($rate_id);
    $count = (int) get_transient($key);
    $count++;
    set_transient($key, $count, $window);
    return $count;
}

/**
 * First-seen timestamp per rate-identity (for js_missing grace).
 */
function bot_eraser_ts_get_first_seen($rate_id, $window) {
    $key = 'bot_eraser_ts_first_' . md5($rate_id);
    $first = get_transient($key);
    if ($first === false) {
        $first = time();
        set_transient($key, $first, $window);
    }
    return (int) $first;
}

/**
 * Build raw server context for module (no JS measures).
 * $overrides adds state from specific paths.
 * Shared between per-request and honeypot checks.
 */
function bot_eraser_build_server_context($ip, array $overrides = []) {
    $config = bot_eraser_get_detection_config();

    $ua      = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $window  = (int) ($config['rate_window'] ?? 300);
    $rate_id = bot_eraser_ts_rate_id($ip, $ua);
    $count   = bot_eraser_ts_track_request($rate_id, $window);
    $first   = bot_eraser_ts_get_first_seen($rate_id, $window);

    $ptr       = bot_eraser_ts_get_ptr($ip);
    $fcrdns_ok = $ptr !== false ? bot_eraser_ts_fcrdns_ok($ip, $ptr) : null;
    $wba       = function_exists('bot_eraser_wba_status') ? bot_eraser_wba_status() : 'none';

    $grace = (int) ($config['js_grace_seconds'] ?? 60);
    $js_missing = (time() - $first) >= $grace
        && function_exists('bot_eraser_check_js_signal_missing')
        && bot_eraser_check_js_signal_missing($ip);

    $uri  = $_SERVER['REQUEST_URI'] ?? '';

    $ctx = [
        'ua'            => $ua,
        'headers'       => bot_eraser_ts_raw_headers(),
        'ptr'           => $ptr,
        'fcrdns_ok'     => $fcrdns_ok,
        'request_count' => $count,
        // IP-aggregated counter (cookie-independent): catches bot rotating be_sid.
        // Weak signal only; does not trigger alone.
        'ip_request_count' => bot_eraser_ts_track_request('ipagg:' . $ip, $window),
        'wba_status'    => $wba,
        'js_missing'    => $js_missing,
        'request_path'  => parse_url($uri, PHP_URL_PATH) ?: '',
        'query_string'  => $_SERVER['QUERY_STRING'] ?? '',
        // WAF-scoped subjects (module scans each against CRS subset).
        'method'        => $_SERVER['REQUEST_METHOD'] ?? 'GET',
        'cookie_header' => $_SERVER['HTTP_COOKIE'] ?? '',
        'waf_headers'   => bot_eraser_ts_waf_headers(),
        'honeypot_url'  => (bool) get_query_var('boteraser_trap'),
        'failed_count'  => function_exists('bot_eraser_bf_count_for_ip') ? bot_eraser_bf_count_for_ip($ip) : 0,
        // Admin threshold override: lockout and weak signal share same count.
        'bf_max'        => function_exists('bot_eraser_bf_max_attempts') ? bot_eraser_bf_max_attempts() : 0,
        'ip'            => $ip,
        'is_self'       => bot_eraser_is_self_ip($ip),
    ];

    return array_merge($ctx, $overrides);
}

/**
 * Curated headers for WAF (KEY = lowercase CRS header name).
 * Only headers not freely set by URL content: Referer, Origin, body omitted.
 * New header = add one line here (allowlist, not blocklist).
 */
function bot_eraser_ts_waf_headers(): array {
    $map = [
        'user-agent'       => 'HTTP_USER_AGENT',
        'x-forwarded-for'  => 'HTTP_X_FORWARDED_FOR',
        'x-real-ip'        => 'HTTP_X_REAL_IP',
        'x-forwarded-host' => 'HTTP_X_FORWARDED_HOST',
        'true-client-ip'   => 'HTTP_TRUE_CLIENT_IP',
        'client-ip'        => 'HTTP_CLIENT_IP',
        'forwarded'        => 'HTTP_FORWARDED',
    ];
    $out = [];
    foreach ($map as $name => $sv) {
        if (!empty($_SERVER[$sv])) {
            $out[$name] = (string) $_SERVER[$sv];
        }
    }
    return $out;
}

/**
 * Raw header context (values, not signals) — module interprets.
 */
function bot_eraser_ts_raw_headers(): array {
    return [
        'accept'          => $_SERVER['HTTP_ACCEPT'] ?? '',
        'accept_language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
        'accept_encoding' => $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '',
        'connection'      => $_SERVER['HTTP_CONNECTION'] ?? '',
        'sec_fetch_site'  => $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '',
        'sec_fetch_mode'  => $_SERVER['HTTP_SEC_FETCH_MODE'] ?? '',
        'sec_fetch_dest'  => $_SERVER['HTTP_SEC_FETCH_DEST'] ?? '',
    ];
}

/**
 * Per-request entry point — collects raw context, runs module,
 * acts on result, sends telemetry if bot.
 */
function bot_eraser_ts_handle_request() {
    if (!bot_eraser_ts_is_enabled()) return;
    if (is_admin() || wp_doing_ajax() || wp_doing_cron()) return;

    foreach ($_COOKIE as $name => $value) {
        if (strpos($name, 'wordpress_logged_in_') === 0) return;
    }

    $ip = bot_eraser_get_visitor_ip();
    if ($ip === '0.0.0.0') return;
    if (current_user_can('manage_options')) return;

    if (function_exists('bot_eraser_is_ip_blocked') && bot_eraser_is_ip_blocked($ip)) return;

    $config = bot_eraser_get_detection_config();
    $ctx    = bot_eraser_build_server_context($ip);
    $result = bot_eraser_detect($ctx, $config);

    // bot=true: report to signal.php + capture JA4. Max coverage via IP toggle:
    //   even -> full page, footer <a> + <img>
    //   odd  -> standalone 302 (Location to data.boteraser.com)
    // Same token in signal and bait URLs -> analyze.php merges JA4 by token.
    if (!empty($result['bot'])) {
        $token = bot_eraser_gen_token();
        bot_eraser_send_telemetry($result, ['ip' => $ip, 'ptr' => $ctx['ptr'] ?: '', 'token' => $token]);
        $GLOBALS['bot_eraser_capture_token'] = $token;

        // Page carries signal-token — CF/cache must not cache (unique per bot).
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0', true);
            header('Pragma: no-cache', true);
        }

        // No body render -> always 302 (body carries bait).
        if (($result['path'] ?? '') === 'B' && function_exists('bot_eraser_emit_analyze_capture')) {
            bot_eraser_emit_analyze_capture($token, true); // exit
        }

        // Body render: even -> full page; odd -> 302.
        $key = 'bot_eraser_cap_toggle_' . md5($ip);
        $n   = (int) get_transient($key);
        set_transient($key, $n + 1, 300);
        if (($n % 2) === 1 && function_exists('bot_eraser_emit_analyze_capture')) {
            bot_eraser_emit_analyze_capture($token, true); // 302, exit; even releases page
        }
    }
}
add_action('template_redirect', 'bot_eraser_ts_handle_request', 2);

/**
 * Cover standalone bot-heavy endpoints (xmlrpc.php, /wp-json/*) not triggered
 * by template_redirect. Same guard: skip logged-in, admins, cron, blocked, 0.0.0.0.
 * Only acts on bot=true.
 */
function bot_eraser_ts_check_endpoint() {
    if (!bot_eraser_ts_is_enabled()) return;
    if (function_exists('wp_doing_cron') && wp_doing_cron()) return;
    foreach ($_COOKIE as $name => $value) {
        if (strpos($name, 'wordpress_logged_in_') === 0) return;
    }
    $ip = bot_eraser_get_visitor_ip();
    if ($ip === '0.0.0.0') return;
    if (function_exists('current_user_can') && current_user_can('manage_options')) return;
    if (function_exists('bot_eraser_is_ip_blocked') && bot_eraser_is_ip_blocked($ip)) return;

    $config = bot_eraser_get_detection_config();
    $ctx    = bot_eraser_build_server_context($ip);
    $result = bot_eraser_detect($ctx, $config);
    if (!empty($result['bot'])) {
        $token = bot_eraser_gen_token();
        bot_eraser_send_telemetry($result, ['ip' => $ip, 'ptr' => $ctx['ptr'] ?: '', 'token' => $token]);
        if (function_exists('bot_eraser_redirect_to_analyze')) {
            bot_eraser_redirect_to_analyze($token, ($result['path'] ?? '') === 'B');
        }
    }
}
add_action('xmlrpc_call', 'bot_eraser_ts_check_endpoint', 1);
add_filter('rest_pre_dispatch', function($result) {
    bot_eraser_ts_check_endpoint();
    return $result;
}, 1);
