<?php
if (!defined('ABSPATH')) {
    exit;
}

// Frontend adapter + shared helpers (config, telemetry, block).

// JS-seen marker (js_missing grace in threat-score)

function bot_eraser_check_js_signal_missing($ip): bool {
    $key = 'bot_eraser_js_seen_' . md5($ip);
    return get_transient($key) === false;
}

function bot_eraser_mark_js_seen($ip) {
    $key = 'bot_eraser_js_seen_' . md5($ip);
    set_transient($key, 1, 10 * MINUTE_IN_SECONDS);
}

// Module (single source of truth): load config + define functions

function bot_eraser_get_detection_config(): array {
    static $config = null;
    if ($config !== null) return $config;
    $config = require BOT_ERASER_PLUGIN_DIR . 'detection.php';

    // Override WAF with server ruleset if cache exists.
    // Premium gate: WAF enabled + valid API key.
    $waf_enabled  = (bool) get_option('boteraser_waf_enabled', false);
    $api_valid    = !empty(get_option('bot_eraser_api_validation_state', array())['is_valid']);
    if ($waf_enabled && $api_valid && function_exists('bot_eraser_waf_load_rules')) {
        $rules = bot_eraser_waf_load_rules();
        if (is_array($rules) && $rules) {
            $config['waf'] = array_merge($config['waf'], $rules);
        }
    }
    return $config;
}

// Telemetry (fire-and-forget)

function bot_eraser_send_telemetry(array $result, array $context = []) {
    // Token in signal queue + bait URL; analyze.php joins JA4 by token (not IP).
    // Return for bait. Generate if not provided.
    $token = !empty($context['token']) ? $context['token'] : bot_eraser_gen_token();

    // Skip if no API key (signal.php returns 403).
    $api_key = (string) get_option('bot_eraser_api_key', '');
    if ($api_key === '') return $token;

    $config = bot_eraser_get_detection_config();

    $ip          = $context['ip'] ?? bot_eraser_get_visitor_ip();
    $ptr         = !empty($context['ptr']) ? $context['ptr'] : '';
    $ua          = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $uri         = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
    $referer     = $_SERVER['HTTP_REFERER'] ?? '';
    $method      = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $accept_lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
    $fp_id       = $context['fp_id'] ?? '';

    $bot_name     = function_exists('bot_eraser_extract_bot_name') ? bot_eraser_extract_bot_name($ua, $config) : '';
    $timestamp    = time();
    $version      = $config['version'];
    $host         = $ptr;
    $path         = $result['path'] ?? '';
    $score        = $result['score'] ?? 0;
    $families_hit = implode('|', $result['families_hit'] ?? []);
    $strong_hard  = $result['strong_hard_hit'] ?? 0;
    $infra_hit    = $result['infra_hit'] ?? 0;
    $has_infra    = ($result['has_infra_hard'] ?? 0) ? 1 : 0;
    $signals      = implode('|', $result['reasons'] ?? []);

    // Canonical format (29 fields): signal.php fills domain, ja4..sni, srcPort, dstPort
    $ja4 = '';
    $fields = [
        $timestamp,    // 0: ts
        '',            // 1: domain (filled by signal.php)
        $version,      // 2: version
        $ip,           // 3: ip
        $ja4,          // 4: ja4 (empty)
        '',            // 5: ja4h
        '',            // 6: ja4t
        '',            // 7: ttl
        '',            // 8: connMin
        '',            // 9: timingMs
        '',            // 10: sni
        '',            // 11: srcPort (filled by signal.php)
        '',            // 12: dstPort (filled by signal.php)
        $host,         // 13: ptr
        $ua,           // 14: ua
        $bot_name,     // 15: bot_name
        $uri,          // 16: uri
        $referer,      // 17: ref
        $method,       // 18: method
        $accept_lang,  // 19: al
        $path,         // 20: path
        $score,        // 21: score
        $families_hit, // 22: fams
        $strong_hard,  // 23: strong
        $infra_hit,    // 24: infra
        $has_infra,    // 25: has_inf
        '',            // 26: fp_id slot (empty)
        $signals,      // 27: signals
        $token,        // 28: token
    ];

    $encoded = [];
    foreach ($fields as $f) {
        $s = (string) $f;
        if (strpbrk($s, ",\"\n\r") !== false || strpos($s, ' ') !== false) {
            $encoded[] = '"' . str_replace('"', '""', $s) . '"';
        } else {
            $encoded[] = $s;
        }
    }
    $csv = implode(',', $encoded) . "\n";

    wp_remote_post('https://data.boteraser.com/signal.php', [
        'body'     => $csv,
        'timeout'  => 1,
        'blocking' => false,
        'headers'  => [
            'Content-Type' => 'text/plain; charset=utf-8',
            'X-Api-Key'    => $api_key,
        ],
    ]);

    return $token;
}

// Redirect detected bot to analyze.php (JA4 capture).
// Bot connects directly -> server computes JA4, joins by TOKEN.
// Toggle 200/302 per IP: even=200 (harvester), odd=302.
function bot_eraser_redirect_to_analyze($token = '', $force_302 = false) {
    // No body render -> always 302.
    if ($force_302) {
        bot_eraser_emit_analyze_capture($token, true);
        return;
    }
    $key = 'bot_eraser_cap_toggle_' . md5(bot_eraser_get_visitor_ip());
    $n   = (int) get_transient($key);
    set_transient($key, $n + 1, 300);
    bot_eraser_emit_analyze_capture($token, ($n % 2) === 1);
}

// AJAX endpoint: raw JS measures -> module maps to signals

function bot_eraser_ajax_fingerprint() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bot_eraser_fp')) {
        wp_die('', '', ['response' => 403]);
    }

    $ip = bot_eraser_get_visitor_ip();

    $rate_key = 'bot_eraser_fp_rate_' . md5($ip);
    $rate_count = (int) get_transient($rate_key);
    if ($rate_count > BOT_ERASER_FP_RATE_LIMIT) {
        wp_send_json_error('Rate limited', 429);
    }
    set_transient($rate_key, $rate_count + 1, MINUTE_IN_SECONDS);

    if (current_user_can('manage_options')) {
        wp_send_json_success();
        return;
    }

    bot_eraser_mark_js_seen($ip);

    // Raw measures as JSON {webdriver:bool, fonts:int, canvas:str...}
    $measures = bot_eraser_sanitize_js_measures($_POST['measures'] ?? '');
    $fp_id    = isset($_POST['fp_id']) ? sanitize_text_field($_POST['fp_id']) : '';

    if (empty($measures)) {
        wp_send_json_success();
        return;
    }

    $config = bot_eraser_get_detection_config();
    $ctx = [
        'ua'      => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'headers' => function_exists('bot_eraser_ts_raw_headers') ? bot_eraser_ts_raw_headers() : [],
        'js'      => $measures,
        'ip'      => $ip,
        'is_self' => bot_eraser_is_self_ip($ip),
        // ptr omitted: no DNS on AJAX path.
    ];

    $result = bot_eraser_detect($ctx, $config);

    // bot=true: report via signal.php + redirect to analyze.php.
    if (!empty($result['bot'])) {
        // Same token in signal queue + bait URL -> JA4 join by token.
        $token = bot_eraser_gen_token();
        bot_eraser_send_telemetry($result, ['ip' => $ip, 'fp_id' => $fp_id, 'token' => $token]);
        $redirect_url = 'https://data.boteraser.com/' . chr(random_int(97, 122)) . '/' . $token;
        wp_send_json(['redirect' => $redirect_url]);
    }

    wp_send_json_success();
}
add_action('wp_ajax_nopriv_bot_eraser_fingerprint', 'bot_eraser_ajax_fingerprint');
add_action('wp_ajax_bot_eraser_fingerprint', 'bot_eraser_ajax_fingerprint');

/**
 * Sanitize raw JS measures into typed whitelist (values, not conclusions).
 * Unknown keys discarded; signal mapping is module-only.
 */
function bot_eraser_sanitize_js_measures($raw): array {
    if (!is_string($raw) || $raw === '') return [];
    $decoded = json_decode(stripslashes($raw), true);
    if (!is_array($decoded)) return [];

    $bool_keys = ['webdriver','phantom','nightmare','dom_automation','selenium','fxdriver',
                  'selenium_unwrapped','awesomium','is_mobile','mouse_moved','scrolled',
                  'page_tall','focus_had_mouse','perfect_order','honeypot_field','has_chrome','mouse_linear'];
    $int_keys  = ['plugins','languages','fonts','hardware','load_to_submit_ms'];
    $str_keys  = ['webgl','canvas','audio'];

    $out = [];
    foreach ($bool_keys as $k) {
        if (array_key_exists($k, $decoded)) $out[$k] = (bool) $decoded[$k];
    }
    foreach ($int_keys as $k) {
        if (array_key_exists($k, $decoded)) $out[$k] = (int) $decoded[$k];
    }
    foreach ($str_keys as $k) {
        if (array_key_exists($k, $decoded)) $out[$k] = substr(sanitize_text_field((string) $decoded[$k]), 0, 120);
    }
    return $out;
}

// Honeypot field: hidden from humans, autofill, screen-readers

function bot_eraser_honeypot_field_name(): string {
    return 'be_url'; // neutral name; not an autofill-magnet
}

/**
 * Hidden honeypot field. Multi-layer hidden from humans/AT:
 * off-screen CSS, aria-hidden, tabindex=-1, autocomplete=off.
 * Only populated by bots that fill all fields.
 */
function bot_eraser_render_honeypot_field() {
    $n = bot_eraser_honeypot_field_name();
    echo '<div style="position:absolute!important;left:-9999px!important;top:-9999px!important;height:1px;width:1px;overflow:hidden;" aria-hidden="true">';
    echo '<input type="text" name="' . esc_attr($n) . '" data-be-honeypot="1" value="" autocomplete="off" tabindex="-1" aria-hidden="true">';
    echo '</div>';
}
add_action('comment_form_after_fields', 'bot_eraser_render_honeypot_field');
add_action('comment_form_logged_in_after', 'bot_eraser_render_honeypot_field');
add_action('login_form', 'bot_eraser_render_honeypot_field');

/**
 * Server-side honeypot check on comment submit.
 * Filled field = raw honeypot_field signal for module.
 * Honeypot alone doesn't block (autofill/screen-reader FP).
 * Block only if module + independent signals => bot=true.
 */
function bot_eraser_honeypot_check_comment($commentdata) {
    $n = bot_eraser_honeypot_field_name();
    if (empty($_POST[$n])) return $commentdata;          // empty = human, let through
    if (current_user_can('manage_options')) return $commentdata;
    if (!function_exists('bot_eraser_build_server_context')) return $commentdata;

    $ip     = bot_eraser_get_visitor_ip();
    $config = bot_eraser_get_detection_config();
    $ctx    = bot_eraser_build_server_context($ip, ['honeypot_field' => true]);
    $result = bot_eraser_detect($ctx, $config);

    // bot=true: report + redirect to analyze.php (JA4 capture).
    if (!empty($result['bot'])) {
        $token = bot_eraser_gen_token();
        bot_eraser_send_telemetry($result, ['ip' => $ip, 'ptr' => $ctx['ptr'] ?: '', 'token' => $token]);
        bot_eraser_redirect_to_analyze($token, ($result['path'] ?? '') === 'B');
    }

    return $commentdata;
}
add_filter('preprocess_comment', 'bot_eraser_honeypot_check_comment', 1);

/**
 * Server-side honeypot check on login submit.
 * Same module, same invariant (honeypot alone doesn't block).
 * Covers sites with comments disabled.
 */
function bot_eraser_honeypot_check_login($user, $username = '', $password = '') {
    $n = bot_eraser_honeypot_field_name();
    if (empty($_POST[$n])) return $user;                 // empty = human, let through
    if (!function_exists('bot_eraser_build_server_context')) return $user;

    $ip     = bot_eraser_get_visitor_ip();
    $config = bot_eraser_get_detection_config();
    $ctx    = bot_eraser_build_server_context($ip, ['honeypot_field' => true]);
    $result = bot_eraser_detect($ctx, $config);

    // bot=true: report + redirect to analyze.php (JA4 capture).
    if (!empty($result['bot'])) {
        $token = bot_eraser_gen_token();
        bot_eraser_send_telemetry($result, ['ip' => $ip, 'ptr' => $ctx['ptr'] ?: '', 'token' => $token]);
        bot_eraser_redirect_to_analyze($token, ($result['path'] ?? '') === 'B');
    }

    return $user;
}
add_filter('authenticate', 'bot_eraser_honeypot_check_login', 30, 3);

// ---- Enqueue JS ----

function bot_eraser_enqueue_fp_script() {
    if (is_admin()) return;
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (empty($ua)) return;

    wp_enqueue_script(
        'bot-eraser-fp',
        BOT_ERASER_PLUGIN_URL . 'assets/js/bot-detector.js',
        [],
        BOT_ERASER_VERSION,
        true
    );
    wp_localize_script('bot-eraser-fp', 'botEraserFP', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('bot_eraser_fp'),
    ]);
}
add_action('wp_enqueue_scripts', 'bot_eraser_enqueue_fp_script');
