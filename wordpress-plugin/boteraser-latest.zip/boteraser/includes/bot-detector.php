<?php
if (!defined('ABSPATH')) {
    exit;
}


/**
 * PHP Headers Analysis
 * Returns array of triggered signals with their group
 */
function bot_eraser_analyze_headers() {
    $signals = [];

    $user_agent  = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $accept      = $_SERVER['HTTP_ACCEPT'] ?? '';
    $accept_lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
    $accept_enc  = $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '';
    $connection  = strtolower($_SERVER['HTTP_CONNECTION'] ?? '');
    $sec_fetch_site = $_SERVER['HTTP_SEC_FETCH_SITE'] ?? null;
    $sec_fetch_mode = $_SERVER['HTTP_SEC_FETCH_MODE'] ?? null;
    $sec_fetch_dest = $_SERVER['HTTP_SEC_FETCH_DEST'] ?? null;

    // Signal 18: Missing Sec-Fetch-*
    if ($sec_fetch_site === null && $sec_fetch_mode === null && $sec_fetch_dest === null) {
        $signals[] = ['id' => 18, 'group' => 'php_headers', 'label' => 'no_sec_fetch'];
    }

    // Signal 19: Missing Accept-Language
    if (empty($accept_lang)) {
        $signals[] = ['id' => 19, 'group' => 'php_headers', 'label' => 'no_accept_lang'];
    }

    // Signal 20: Missing Accept
    if (empty($accept)) {
        $signals[] = ['id' => 20, 'group' => 'php_headers', 'label' => 'no_accept'];
    }

    // Signal 21: Connection: close
    if ($connection === 'close') {
        $signals[] = ['id' => 21, 'group' => 'php_headers', 'label' => 'conn_close'];
    }

    // Signal 22: Missing Accept-Encoding
    if (empty($accept_enc)) {
        $signals[] = ['id' => 22, 'group' => 'php_headers', 'label' => 'no_accept_enc'];
    }

    return $signals;
}

/**
 * Signal 23: JS signals never arrived = bot that doesn't execute JS
 */
function bot_eraser_check_js_signal_missing($ip) {
    $key = 'bot_eraser_js_seen_' . md5($ip);
    return get_transient($key) === false;
}

function bot_eraser_mark_js_seen($ip) {
    $key = 'bot_eraser_js_seen_' . md5($ip);
    set_transient($key, 1, 10 * MINUTE_IN_SECONDS);
}

/**
 * Process signals received from JS (AJAX handler)
 */
function bot_eraser_process_signals($ip, $js_signals) {
    bot_eraser_mark_js_seen($ip);

    // Check for definitive JS signals
    $definitive_ids = [2, 3, 4, 5, 6, 7, 8, 9];
    $definitive = array_filter($js_signals, function($s) use ($definitive_ids) {
        return in_array($s['id'], $definitive_ids);
    });

    if (!empty($definitive)) {
        return true;
    }

    // Only combine JS behavioral with PHP headers — never evaluate PHP headers alone
    $behavioral = array_filter($js_signals, function($s) {
        return $s['group'] === 'js_behavioral';
    });

    // Only proceed with scoring if there are JS behavioral signals
    if (!empty($behavioral)) {
        $php_signals = bot_eraser_analyze_headers();
        $all_signals = array_merge(array_values($behavioral), $php_signals);
        return bot_eraser_evaluate_scoring($ip, $all_signals);
    }

    return false;
}

/**
 * Scoring logic
 * 1 signal = ignore, 2 = suspicious, 3+ from 2+ different groups = block
 */
function bot_eraser_evaluate_scoring($ip, $signals) {
    if (empty($signals)) return false;

    $count       = count($signals);
    $groups      = array_unique(array_column($signals, 'group'));
    $group_count = count($groups);

    if ($count >= 3 && $group_count >= 2) {
        bot_eraser_clear_suspicious($ip);
        return true;
    } elseif ($count === 2) {
        bot_eraser_add_suspicious($ip, $signals);
    }

    return false;
}

/**
 * Redirect detected bot to central analysis server
 */
function bot_eraser_block_detected_ip($ip, $signals) {
    if (!filter_var($ip, FILTER_VALIDATE_IP)) return;

    header('Location: https://data.boteraser.com/analyze.php', true, 302);
    exit;
}

/**
 * Add IP to suspicious list
 */
function bot_eraser_add_suspicious($ip, $signals) {
    $suspicious = get_option('bot_eraser_suspicious_ips', []);
    if (!is_array($suspicious)) $suspicious = [];

    $existing_signals = $suspicious[$ip]['signals'] ?? [];
    $existing_labels  = array_column($existing_signals, 'label');

    foreach ($signals as $s) {
        if (!in_array($s['label'], $existing_labels)) {
            $existing_signals[] = $s;
            $existing_labels[]  = $s['label'];
        }
    }

    $suspicious[$ip] = ['time' => time(), 'signals' => $existing_signals];
    update_option('bot_eraser_suspicious_ips', $suspicious);

    bot_eraser_evaluate_scoring($ip, $existing_signals);
}

/**
 * Remove IP from suspicious list
 */
function bot_eraser_clear_suspicious($ip) {
    $suspicious = get_option('bot_eraser_suspicious_ips', []);
    if (isset($suspicious[$ip])) {
        unset($suspicious[$ip]);
        update_option('bot_eraser_suspicious_ips', $suspicious);
    }
}

/**
 * Get and clear fingerprint blacklist queue (called from server-communication)
 */
function bot_eraser_get_and_clear_fp_queue() {
    $queue = get_option('bot_eraser_fp_blacklist_queue', []);
    if (!empty($queue)) {
        update_option('bot_eraser_fp_blacklist_queue', []);
    }
    return is_array($queue) ? $queue : [];
}

/**
 * AJAX endpoint — receives JS fingerprint signals
 */
function bot_eraser_ajax_fingerprint() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bot_eraser_fp')) {
        wp_die('', '', ['response' => 403]);
    }

    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ??
          $_SERVER['HTTP_TRUE_CLIENT_IP'] ??
          $_SERVER['HTTP_X_REAL_IP'] ??
          $_SERVER['HTTP_X_FORWARDED_FOR'] ??
          $_SERVER['REMOTE_ADDR'] ??
          '0.0.0.0';
    $ip = filter_var(trim(explode(',', $ip)[0]), FILTER_VALIDATE_IP) ?: '0.0.0.0';

    if (current_user_can('manage_options')) {
        wp_send_json_success();
        return;
    }

    $raw       = sanitize_text_field($_POST['signals'] ?? '');
    $js_signals = [];

    if (!empty($raw)) {
        $decoded = json_decode(stripslashes($raw), true);
        if (is_array($decoded)) {
            foreach ($decoded as $s) {
                if (isset($s['id'], $s['group'], $s['label'])) {
                    $js_signals[] = [
                        'id'    => intval($s['id']),
                        'group' => sanitize_key($s['group']),
                        'label' => sanitize_key($s['label']),
                    ];
                }
            }
        }
    }

    $redirect = bot_eraser_process_signals($ip, $js_signals);
    if ($redirect) {
        wp_send_json(['redirect' => 'https://data.boteraser.com/analyze.php']);
    }
    wp_send_json_success();
}
add_action('wp_ajax_nopriv_bot_eraser_fingerprint', 'bot_eraser_ajax_fingerprint');
add_action('wp_ajax_bot_eraser_fingerprint', 'bot_eraser_ajax_fingerprint');

/**
 * PHP-only request analysis — runs on every frontend request
 * Handles ONLY: UA empty (signal 1) and whitelist (signal 10)
 * PHP header signals are only evaluated when combined with JS signals (on form submit)
 */
function bot_eraser_php_request_check() {
    if (is_admin() || wp_doing_ajax() || wp_doing_cron() || wp_doing_ajax()) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_GET['page']) && strpos($_GET['page'], 'bot-eraser') !== false) return;
    if (isset($_POST['action']) && $_POST['action'] === 'unblock_ip') return;

    foreach ($_COOKIE as $name => $value) {
        if (strpos($name, 'wordpress_logged_in_') === 0) return;
    }

    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ??
          $_SERVER['HTTP_TRUE_CLIENT_IP'] ??
          $_SERVER['HTTP_X_REAL_IP'] ??
          $_SERVER['HTTP_X_FORWARDED_FOR'] ??
          $_SERVER['REMOTE_ADDR'] ??
          '0.0.0.0';
    $ip = filter_var(trim(explode(',', $ip)[0]), FILTER_VALIDATE_IP) ?: '0.0.0.0';

    if (current_user_can('manage_options')) return;

    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

    // Signal 1: Empty UA — block immediately
    if (empty($ua)) {
        bot_eraser_block_detected_ip($ip, [['id' => 1, 'group' => 'php_headers', 'label' => 'empty_ua']]);
        return;
    }

    // Level 2: UA claims to be a real browser but missing all three browser-only headers
    // Real browsers ALWAYS send Sec-Fetch-*, Accept-Language, and Accept together
    // curl/Python with a fake Chrome UA will never have all three
    $has_sec_fetch  = isset($_SERVER['HTTP_SEC_FETCH_SITE']) ||
                      isset($_SERVER['HTTP_SEC_FETCH_MODE']) ||
                      isset($_SERVER['HTTP_SEC_FETCH_DEST']);
    $has_accept_lang = !empty($_SERVER['HTTP_ACCEPT_LANGUAGE']);
    $has_accept      = !empty($_SERVER['HTTP_ACCEPT']);

    $looks_like_browser = preg_match('/(Chrome|Firefox|Safari|Edge|Opera|MSIE|Trident)/i', $ua);

}
add_action('init', 'bot_eraser_php_request_check', 1);

/**
 * Enqueue JS fingerprint collector on all frontend pages
 */
function bot_eraser_enqueue_fp_script() {
    if (is_admin()) return;
    wp_enqueue_script(
        'bot-eraser-fp',
        BOT_ERASER_PLUGIN_URL . 'assets/js/bot-detector.js',
        [],
        BOT_ERASER_VERSION,
        true
    );
    wp_localize_script('bot-eraser-fp', 'botEraserFP', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('bot_eraser_fp'),
    ]);
}
add_action('wp_enqueue_scripts', 'bot_eraser_enqueue_fp_script');
