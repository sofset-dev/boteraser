<?php
if (!defined('ABSPATH')) {
    exit;
}

// ----------------------------------------------------------------------------
// Periodically pull and cache threat lists from server.
// ----------------------------------------------------------------------------

/**
 * List names. Map fetched first; each has own ETag.
 */
function bot_eraser_list_names(): array {
    return [
        'map',
        'rate_limited_bots',
        'blacklist_ips',
        'blacklist_bots',
        'whitelist',
        'greylist',
        'blacklist',
    ];
}

/**
 * Compile list lines into lookup buckets by type.
 */
function bot_eraser_list_compile(string $body): array {
    $exact        = [];
    $v4           = [];
    $v6           = [];
    $bot_patterns = [];
    $count        = 0;

    foreach (preg_split('/\r\n|\r|\n/', $body) as $line) {
        $val = trim($line);
        if ($val === '' || $val[0] === '#') {
            continue;
        }
        // First CSV col is value; rest is metadata.
        if (strpos($val, ',') !== false) {
            $row = str_getcsv($val, ',', '"', '\\');
            $val = trim((string) $row[0]);
        }
        if ($val === '' || strcasecmp($val, 'ip') === 0) {
            continue; // skip empty / header row
        }

        // IPv4/IPv6 CIDR; otherwise bot regex.
        if (strpos($val, '/') !== false) {
            list($net, $prefix) = array_pad(explode('/', $val, 2), 2, '');
            if (ctype_digit($prefix) && filter_var($net, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $r = bot_eraser_cidr4_range($net, (int) $prefix);
                if ($r) { $v4[] = $r; $count++; }
                continue;
            }
            if (ctype_digit($prefix) && filter_var($net, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                $r = bot_eraser_cidr6_range($net, (int) $prefix);
                if ($r) { $v6[] = $r; $count++; }
                continue;
            }
        }

        if (filter_var($val, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $exact[$val] = 1; $count++;
        } elseif (filter_var($val, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $bin = @inet_pton($val);
            if ($bin !== false) { $v6[] = [$bin, $bin]; $count++; }
        } else {
            // Bot UA regex fragments.
            $bot_patterns[] = $val; $count++;
        }
    }

    return [
        'exact' => $exact,
        'v4'    => bot_eraser_merge_ranges($v4),
        'v6'    => $v6,
        'bots'  => bot_eraser_compile_bot_patterns($bot_patterns),
        'count' => $count,
    ];
}

/**
 * Combine UA patterns into chunks for fast matching.
 */
function bot_eraser_compile_bot_patterns(array $patterns): array {
    // Canary UAs: drop over-broad patterns matching these.
    $canaries = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0',
    ];

    $safe = [];
    foreach ($patterns as $p) {
        if ($p === '') {
            continue;
        }
        if (@preg_match('~' . $p . '~i', '') === false) {
            $p = preg_quote($p, '~');
        }
        $rx = '~' . $p . '~i';
        foreach ($canaries as $canary) {
            if (@preg_match($rx, $canary)) {
                continue 2; // over-broad — skip this pattern entirely
            }
        }
        $safe[] = $p;
    }
    if (empty($safe)) {
        return [];
    }

    $chunks = [];
    foreach (array_chunk($safe, 200) as $group) {
        $chunk = '~(?:' . implode('|', $group) . ')~i';
        if (@preg_match($chunk, '') === false) {
            $chunk = '~(?:' . implode('|', array_map(function ($p) {
                return preg_quote($p, '~');
            }, $group)) . ')~i';
        }
        $chunks[] = $chunk;
    }
    return $chunks;
}

/**
 * IPv4 CIDR -> [start, end] as unsigned 32-bit ints.
 */
function bot_eraser_cidr4_range(string $net, int $prefix) {
    if ($prefix < 0 || $prefix > 32) {
        return null;
    }
    $base = ip2long($net);
    if ($base === false) {
        return null;
    }
    $base = $base & 0xFFFFFFFF;
    $mask = $prefix === 0 ? 0 : ((0xFFFFFFFF << (32 - $prefix)) & 0xFFFFFFFF);
    $start = $base & $mask;
    $end   = $start | (~$mask & 0xFFFFFFFF);
    return [$start, $end];
}

/**
 * IPv6 CIDR -> [start, end] as 16-byte binary strings.
 */
function bot_eraser_cidr6_range(string $net, int $prefix) {
    if ($prefix < 0 || $prefix > 128) {
        return null;
    }
    $bin = @inet_pton($net);
    if ($bin === false || strlen($bin) !== 16) {
        return null;
    }
    $start = str_repeat("\0", 16);
    $end   = str_repeat("\0", 16);
    for ($i = 0; $i < 16; $i++) {
        $bits = $prefix - ($i * 8);
        if ($bits >= 8) {
            $mask = 0xFF;
        } elseif ($bits <= 0) {
            $mask = 0x00;
        } else {
            $mask = (0xFF << (8 - $bits)) & 0xFF;
        }
        $byte = ord($bin[$i]);
        $start[$i] = chr($byte & $mask);
        $end[$i]   = chr(($byte & $mask) | (~$mask & 0xFF));
    }
    return [$start, $end];
}

/**
 * Sort and merge overlapping IPv4 ranges.
 */
function bot_eraser_merge_ranges(array $ranges): array {
    if (empty($ranges)) {
        return [];
    }
    usort($ranges, function ($a, $b) {
        return $a[0] <=> $b[0];
    });
    $merged = [];
    $cur    = $ranges[0];
    $n      = count($ranges);
    for ($i = 1; $i < $n; $i++) {
        $r = $ranges[$i];
        if ($r[0] <= $cur[1] + 1) {
            if ($r[1] > $cur[1]) {
                $cur[1] = $r[1];
            }
        } else {
            $merged[] = $cur;
            $cur = $r;
        }
    }
    $merged[] = $cur;
    return $merged;
}

/**
 * Fetch list; 200=compile, 304=keep, error=log.
 */
function bot_eraser_list_sync_one(string $name, string $api_key): void {
    $response = wp_remote_post(BOT_ERASER_LIST_URL, [
        'body'    => ['api_key' => $api_key, 'list' => $name],
        'headers' => ['If-None-Match' => (string) get_option('bot_eraser_list_etag_' . $name, '')],
        'timeout' => 20,
    ]);

    if (is_wp_error($response)) {
        error_log('Boteraser list sync (' . $name . '): ' . $response->get_error_message());
        return;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    if ($code === 304) {
        return;
    }
    if ($code !== 200) {
        error_log('Boteraser list sync (' . $name . '): unexpected HTTP ' . $code);
        return;
    }

    $body = (string) wp_remote_retrieve_body($response);

    if ($name === 'map') {
        // Keep the raw server file verbatim for parity with the other lists
        // (and external tooling); the parsed option is derived from it.
        $dir = bot_eraser_list_dir();
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }
        $raw = $dir . 'map.txt';
        if (file_put_contents($raw, $body, LOCK_EX) === false) {
            error_log('Boteraser list sync (map): failed to write ' . $raw);
        }
        update_option('bot_eraser_list_etag_map', (string) wp_remote_retrieve_header($response, 'etag'), false);
        update_option('bot_eraser_list_synced_map', time(), false);
        return;
    }

    $compiled = bot_eraser_list_compile($body);
    $count    = (int) $compiled['count'];
    unset($compiled['count']);

    $dir = bot_eraser_list_dir();
    if (!is_dir($dir)) {
        wp_mkdir_p($dir);
    }
    $path   = $dir . $name . '.php';
    // Guard allows pre-WP prepend phase.
    $export = "<?php\nif (!defined('ABSPATH') && !defined('BOT_ERASER_PREPEND')) { exit; }\nreturn " . var_export($compiled, true) . ";\n";
    if (file_put_contents($path, $export, LOCK_EX) === false) {
        error_log('Boteraser list sync (' . $name . '): failed to write ' . $path);
        return;
    }
    if (function_exists('bot_eraser_invalidate_opcache')) {
        bot_eraser_invalidate_opcache($path);
    }

    update_option('bot_eraser_list_etag_' . $name, (string) wp_remote_retrieve_header($response, 'etag'), false);
    update_option('bot_eraser_list_synced_' . $name, time(), false);
    update_option('bot_eraser_list_count_' . $name, $count, false);
}

/**
 * Sync all lists (map first). Hooked on the hourly cron.
 */
function bot_eraser_list_sync(): void {
    $api_key = (string) get_option('bot_eraser_api_key', '');
    if ($api_key === '') {
        return;
    }
    foreach (bot_eraser_list_names() as $name) {
        bot_eraser_list_sync_one($name, $api_key);
    }
}
add_action('bot_eraser_list_sync', 'bot_eraser_list_sync');
add_action('bot_eraser_list_sync_once', 'bot_eraser_list_sync');

/**
 * Schedule hourly sync; bootstrap once if cache missing.
 */
function bot_eraser_list_schedule(): void {
    if (!wp_next_scheduled('bot_eraser_list_sync')) {
        wp_schedule_event(time(), 'boteraser_15min', 'bot_eraser_list_sync');
    }
    if (!is_file(bot_eraser_list_dir() . 'blacklist_ips.php')
        && (string) get_option('bot_eraser_api_key', '') !== ''
        && !wp_next_scheduled('bot_eraser_list_sync_once')) {
        wp_schedule_single_event(time(), 'bot_eraser_list_sync_once');
    }
}
add_action('init', 'bot_eraser_list_schedule');
