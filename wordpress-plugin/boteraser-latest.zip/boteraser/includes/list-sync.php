<?php
if (!defined('ABSPATH')) {
    exit;
}

// ----------------------------------------------------------------------------
// Periodically pull and cache threat lists from server.
// ----------------------------------------------------------------------------

/**
 * List names. Map fetched first; each has own ETag.
 */
function bot_eraser_list_names(): array {
    return [
        'map',
        'rate_limited_bots',
        'blacklist_ips',
        'blacklist_bots',
        'whitelist',
        'greylist',
        'blacklist',
    ];
}

/**
 * Compile list lines into lookup buckets by type.
 */
function bot_eraser_list_compile(string $body): array {
    $exact        = [];
    $v4           = [];
    $v6           = [];
    $bot_patterns = [];
    $count        = 0;

    foreach (preg_split('/\r\n|\r|\n/', $body) as $line) {
        $val = trim($line);
        if ($val === '' || $val[0] === '#') {
            continue;
        }
        // First CSV col is value; rest is metadata.
        if (strpos($val, ',') !== false) {
            $row = str_getcsv($val, ',', '"', '\\');
            $val = trim((string) $row[0]);
        }
        if ($val === '' || strcasecmp($val, 'ip') === 0) {
            continue; // skip empty / header row
        }

        // IPv4/IPv6 CIDR; otherwise bot regex.
        if (strpos($val, '/') !== false) {
            list($net, $prefix) = array_pad(explode('/', $val, 2), 2, '');
            if (ctype_digit($prefix) && filter_var($net, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $r = bot_eraser_cidr4_range($net, (int) $prefix);
                if ($r) { $v4[] = $r; $count++; }
                continue;
            }
            if (ctype_digit($prefix) && filter_var($net, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                $r = bot_eraser_cidr6_range($net, (int) $prefix);
                if ($r) { $v6[] = $r; $count++; }
                continue;
            }
        }

        if (filter_var($val, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $exact[$val] = 1; $count++;
        } elseif (filter_var($val, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $bin = @inet_pton($val);
            if ($bin !== false) { $v6[] = [$bin, $bin]; $count++; }
        } else {
            // Bot UA regex fragments.
            $bot_patterns[] = $val; $count++;
        }
    }

    return [
        'exact' => $exact,
        'v4'    => bot_eraser_merge_ranges($v4),
        'v6'    => $v6,
        'bots'  => bot_eraser_compile_bot_patterns($bot_patterns),
        'count' => $count,
    ];
}

/**
 * Combine UA patterns into chunks for fast matching.
 */
function bot_eraser_compile_bot_patterns(array $patterns): array {
    // Canary UAs: drop over-broad patterns matching these.
    $canaries = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0',
    ];

    $safe = [];
    foreach ($patterns as $p) {
        if ($p === '') {
            continue;
        }
        if (@preg_match('~' . $p . '~i', '') === false) {
            $p = preg_quote($p, '~');
        }
        $rx = '~' . $p . '~i';
        foreach ($canaries as $canary) {
            if (@preg_match($rx, $canary)) {
                continue 2; // over-broad — skip this pattern entirely
            }
        }
        $safe[] = $p;
    }
    if (empty($safe)) {
        return [];
    }

    $chunks = [];
    foreach (array_chunk($safe, 200) as $group) {
        $chunk = '~(?:' . implode('|', $group) . ')~i';
        if (@preg_match($chunk, '') === false) {
            $chunk = '~(?:' . implode('|', array_map(function ($p) {
                return preg_quote($p, '~');
            }, $group)) . ')~i';
        }
        $chunks[] = $chunk;
    }
    return $chunks;
}

/**
 * IPv4 CIDR -> [start, end] as unsigned 32-bit ints.
 */
function bot_eraser_cidr4_range(string $net, int $prefix) {
    if ($prefix < 0 || $prefix > 32) {
        return null;
    }
    $base = ip2long($net);
    if ($base === false) {
        return null;
    }
    $base = $base & 0xFFFFFFFF;
    $mask = $prefix === 0 ? 0 : ((0xFFFFFFFF << (32 - $prefix)) & 0xFFFFFFFF);
    $start = $base & $mask;
    $end   = $start | (~$mask & 0xFFFFFFFF);
    return [$start, $end];
}

/**
 * IPv6 CIDR -> [start, end] as 16-byte binary strings.
 */
function bot_eraser_cidr6_range(string $net, int $prefix) {
    if ($prefix < 0 || $prefix > 128) {
        return null;
    }
    $bin = @inet_pton($net);
    if ($bin === false || strlen($bin) !== 16) {
        return null;
    }
    $start = str_repeat("\0", 16);
    $end   = str_repeat("\0", 16);
    for ($i = 0; $i < 16; $i++) {
        $bits = $prefix - ($i * 8);
        if ($bits >= 8) {
            $mask = 0xFF;
        } elseif ($bits <= 0) {
            $mask = 0x00;
        } else {
            $mask = (0xFF << (8 - $bits)) & 0xFF;
        }
        $byte = ord($bin[$i]);
        $start[$i] = chr($byte & $mask);
        $end[$i]   = chr(($byte & $mask) | (~$mask & 0xFF));
    }
    return [$start, $end];
}

/**
 * Sort and merge overlapping IPv4 ranges.
 */
function bot_eraser_merge_ranges(array $ranges): array {
    if (empty($ranges)) {
        return [];
    }
    usort($ranges, function ($a, $b) {
        return $a[0] <=> $b[0];
    });
    $merged = [];
    $cur    = $ranges[0];
    $n      = count($ranges);
    for ($i = 1; $i < $n; $i++) {
        $r = $ranges[$i];
        if ($r[0] <= $cur[1] + 1) {
            if ($r[1] > $cur[1]) {
                $cur[1] = $r[1];
            }
        } else {
            $merged[] = $cur;
            $cur = $r;
        }
    }
    $merged[] = $cur;
    return $merged;
}

/**
 * Fetch list; 200=compile, 304=keep, error=log.
 * Returns true when the on-disk cache was rewritten.
 */
function bot_eraser_list_sync_one(string $name, string $api_key): bool {
    $response = wp_remote_post(BOT_ERASER_LIST_URL, [
        'body'    => ['api_key' => $api_key, 'list' => $name],
        'headers' => ['If-None-Match' => (string) get_option('bot_eraser_list_etag_' . $name, '')],
        'timeout' => 20,
    ]);

    if (is_wp_error($response)) {
        error_log('Boteraser list sync (' . $name . '): ' . $response->get_error_message());
        return false;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    if ($code === 304) {
        return false;
    }
    if ($code !== 200) {
        error_log('Boteraser list sync (' . $name . '): unexpected HTTP ' . $code);
        return false;
    }

    $body = (string) wp_remote_retrieve_body($response);

    if ($name === 'map') {
        // Keep the raw server file verbatim for parity with the other lists
        // (and external tooling); the parsed option is derived from it.
        $dir = bot_eraser_list_dir();
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }
        $raw = $dir . 'map.txt';
        if (file_put_contents($raw, $body, LOCK_EX) === false) {
            error_log('Boteraser list sync (map): failed to write ' . $raw);
        }
        update_option('bot_eraser_list_etag_map', (string) wp_remote_retrieve_header($response, 'etag'), false);
        update_option('bot_eraser_list_synced_map', time(), false);
        return true;
    }

    $compiled = bot_eraser_list_compile($body);
    $count    = (int) $compiled['count'];
    unset($compiled['count']);

    $dir = bot_eraser_list_dir();
    if (!is_dir($dir)) {
        wp_mkdir_p($dir);
    }
    $path   = $dir . $name . '.php';
    // Guard allows pre-WP prepend phase.
    $export = "<?php\nif (!defined('ABSPATH') && !defined('BOT_ERASER_PREPEND')) { exit; }\nreturn " . var_export($compiled, true) . ";\n";
    if (file_put_contents($path, $export, LOCK_EX) === false) {
        error_log('Boteraser list sync (' . $name . '): failed to write ' . $path);
        return false;
    }
    if (function_exists('bot_eraser_invalidate_opcache')) {
        bot_eraser_invalidate_opcache($path);
    }

    update_option('bot_eraser_list_etag_' . $name, (string) wp_remote_retrieve_header($response, 'etag'), false);
    update_option('bot_eraser_list_synced_' . $name, time(), false);
    update_option('bot_eraser_list_count_' . $name, $count, false);

    return true;
}

/**
 * Drop active list-sourced blocks that no longer match the refreshed lists.
 * Local detections (rate limiter, bot detector, brute force) are left alone —
 * only blocks written by bot_eraser_list_block() are reconciled. Runs after a
 * sync that rewrote at least one cache, so a removed feed entry no longer
 * outlives its cause by the remainder of its TTL.
 *
 * @return int Number of blocks released.
 */
function bot_eraser_list_reconcile_blocks(): int {
    $file = bot_eraser_list_blocked_path();
    if (!is_file($file)) {
        return 0;
    }
    if (function_exists('opcache_invalidate')) {
        opcache_invalidate($file, true);
    }
    $blocked = include $file;
    if (!is_array($blocked) || empty($blocked)) {
        return 0;
    }

    $reasons = get_option('bot_eraser_block_reasons', []);
    if (!is_array($reasons)) {
        $reasons = [];
    }

    // Sync defers opcache invalidation to shutdown; force it now so the
    // comparison runs against the caches just written, not the stale ones.
    if (function_exists('opcache_invalidate')) {
        foreach (bot_eraser_list_names() as $ln) {
            $lf = bot_eraser_list_dir() . $ln . '.php';
            if (is_file($lf)) {
                opcache_invalidate($lf, true);
            }
        }
    }

    // Lists that can produce a block, per bot_eraser_enforce_lists().
    $blocking = ['blacklist_ips', 'blacklist_bots', 'blacklist', 'rate_limited_bots', 'greylist'];
    // Reset: enforce_lists may have cached the pre-sync lists in this request.
    $whitelist = bot_eraser_list_load('whitelist', true);

    $now      = time();
    $released = [];

    foreach ($blocked as $ip => $expiry) {
        if ($expiry <= $now) {
            continue; // expired anyway; the write below drops it
        }
        if (!isset($reasons[$ip]) || !is_array($reasons[$ip])) {
            continue; // unknown provenance — leave untouched
        }

        $ua    = (string) ($reasons[$ip]['ua'] ?? '');
        $parts = array_filter(explode('|', (string) ($reasons[$ip]['source'] ?? '')));
        if (empty($parts)) {
            continue;
        }

        // Whitelist wins outright, whatever put the IP here.
        if ($whitelist
            && (bot_eraser_list_ip_match($whitelist, $ip) || bot_eraser_list_bot_match($whitelist, $ua))) {
            $released[] = $ip;
            continue;
        }

        // Every part must name a blocking list, else this is a local detection.
        $still_matches = false;
        $list_sourced  = true;
        foreach ($parts as $part) {
            list($name, $kind) = array_pad(explode(':', $part, 2), 2, '');
            if (!in_array($name, $blocking, true)) {
                $list_sourced = false;
                break;
            }
            $c = bot_eraser_list_load($name);
            if (!$c) {
                continue;
            }
            if ($kind === 'ua' ? bot_eraser_list_bot_match($c, $ua) : bot_eraser_list_ip_match($c, $ip)) {
                $still_matches = true;
                break;
            }
        }

        if ($list_sourced && !$still_matches) {
            $released[] = $ip;
        }
    }

    if (empty($released)) {
        return 0;
    }

    foreach ($released as $ip) {
        unset($blocked[$ip], $reasons[$ip]);
    }
    $blocked = array_filter($blocked, function ($expiry) use ($now) {
        return $expiry > $now;
    });

    bot_eraser_write_ip_cache($file, $blocked);
    update_option('bot_eraser_block_reasons', $reasons);
    set_transient('bot_eraser_blocked_ips', $blocked, DAY_IN_SECONDS);

    return count($released);
}

/**
 * Sync all lists (map first). Hooked on the hourly cron.
 */
function bot_eraser_list_sync(): void {
    $api_key = (string) get_option('bot_eraser_api_key', '');
    if ($api_key === '') {
        return;
    }
    $changed = false;
    foreach (bot_eraser_list_names() as $name) {
        if (bot_eraser_list_sync_one($name, $api_key)) {
            $changed = true;
        }
    }
    if ($changed) {
        bot_eraser_list_reconcile_blocks();
    }
}
add_action('bot_eraser_list_sync', 'bot_eraser_list_sync');
add_action('bot_eraser_list_sync_once', 'bot_eraser_list_sync');

/**
 * Schedule hourly sync; bootstrap once if cache missing.
 */
function bot_eraser_list_schedule(): void {
    if (!wp_next_scheduled('bot_eraser_list_sync')) {
        wp_schedule_event(time(), 'boteraser_15min', 'bot_eraser_list_sync');
    }
    if (!is_file(bot_eraser_list_dir() . 'blacklist_ips.php')
        && (string) get_option('bot_eraser_api_key', '') !== ''
        && !wp_next_scheduled('bot_eraser_list_sync_once')) {
        wp_schedule_single_event(time(), 'bot_eraser_list_sync_once');
    }
}
add_action('init', 'bot_eraser_list_schedule');
