<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('bot_eraser_request_verdict')) {

define('BOT_ERASER_VERDICT_URL', 'https://data.boteraser.com/verdict.php');
define('BOT_ERASER_VERDICT_CACHE_TTL', 900);

function bot_eraser_request_verdict(array $signals, array $ctx = []): array {
    $signals = array_values($signals);

    // No signals → not bot.
    if (empty($signals)) {
        return ['bot' => false, 'score' => 0, 'reasons' => []];
    }

    // Server decides; cache by sorted signals only (no IP).
    $sig_sorted = $signals;
    sort($sig_sorted);
    $cache_key = 'bot_eraser_v_' . md5(implode(',', $sig_sorted));
    $cached = get_transient($cache_key);
    if ($cached !== false && is_array($cached)) {
        return $cached;
    }

    $api_key = (string) get_option('bot_eraser_api_key', '');
    $response = wp_remote_post(BOT_ERASER_VERDICT_URL, [
        'body'     => [
            'signals'  => $signals,
            'site_key' => $api_key,
        ],
        'timeout'  => 2,
        'headers'  => ['X-Api-Key' => $api_key],
    ]);

    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (is_array($body) && isset($body['bot'])) {
            // Server returns only {bot}; merge local signals back.
            $verdict = [
                'bot'     => (bool) $body['bot'],
                'reasons' => $signals,
            ];
            set_transient($cache_key, $verdict, BOT_ERASER_VERDICT_CACHE_TTL);
            return $verdict;
        }
    }

    // Server unavailable → conservative fallback.
    return bot_eraser_fallback_verdict($signals);
}

function bot_eraser_fallback_verdict(array $signals): array {
    // Conservative: empty_ua + ≥2 infra = bot.
    $infra = ['empty_ua', 'no_sec_fetch', 'no_accept_lang', 'no_accept', 'no_accept_enc', 'conn_close', 'bad_ptr', 'fcrdns_fail', 'high_rate', 'crawler_unverified', 'header_mismatch'];
    $hits  = array_intersect($signals, $infra);
    if (in_array('empty_ua', $signals, true) && count($hits) >= 3) {
        return [
            'bot'     => true,
            'score'   => 10,
            'path'    => 'B',
            'reasons' => array_values($hits),
        ];
    }

    // Attack signal → bot.
    $attack = ['sqli_injection', 'xss_injection', 'lfi_attempt', 'path_traversal', 'rce_injection', 'rfi_attempt', 'php_injection', 'protocol_anomaly'];
    $a_hits = array_intersect($signals, $attack);
    if (!empty($a_hits)) {
        return [
            'bot'     => true,
            'score'   => 10,
            'path'    => 'A',
            'reasons' => array_values($a_hits),
        ];
    }

    // Otherwise → allow (lenient, 0 FP).
    return [
        'bot'    => false,
        'score'  => 0,
        'reasons' => [],
    ];
}

} // function_exists guard
