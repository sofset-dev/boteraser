<?php
/**
 * Risk Scoring Engine
 */

if (!defined('ABSPATH')) exit;

/**
 * Generic indicators frequently present in legitimate core/vendor code.
 * Token-only hits on these alone should not escalate to HIGH.
 */
function boteraser_generic_indicator_types() {
    return array(
        'eval_usage',
        'js_eval_usage',
        'base64_decode',
        'gzinflate',
        'gzuncompress',
        'str_rot13',
        'shell_exec',
        'exec_func',
        'system_func',
        'passthru',
        'popen_func',
        'proc_open',
        'create_function',
        'long_base64',
        'high_entropy',
        'packed_code',
        'file_get_url',
        'curl_remote',
        'iframe_inject',
        'script_inject',
        'document_write',
    );
}

/**
 * Shell/process execution patterns. Plugins legitimately use these for
 * media transcoding (ffmpeg), image optimization, backups, etc.
 *
 * Without other obfuscation indicators a shell-exec hit in third-party
 * plugin/theme code is more likely "legitimate utility" than malware.
 */
function boteraser_shell_exec_pattern_types() {
    return array(
        'shell_exec',
        'exec_func',
        'system_func',
        'passthru',
        'popen_func',
        'proc_open',
    );
}

/**
 * Returns true when every finding in the group belongs to the shell-exec
 * family. Used to decide whether to soften severity for plugin/theme
 * code hosting legitimate process invocations.
 */
function boteraser_findings_are_shell_exec_only($finding) {
    $shell_types = boteraser_shell_exec_pattern_types();
    if (empty($finding['findings'])) {
        return false;
    }
    foreach ($finding['findings'] as $item) {
        if (!in_array($item['type'] ?? '', $shell_types, true)) {
            return false;
        }
    }
    return true;
}

/**
 * Returns true when every finding is a bare curl_remote hit with no
 * obfuscation or webshell co-indicators. Plugins legitimately use direct
 * curl (image optimizers, payment gateways, API clients) — the dangerous
 * case requires additional indicators like eval or superglobal sinks.
 */
function boteraser_findings_are_curl_remote_only($finding) {
    if (empty($finding['findings'])) {
        return false;
    }
    foreach ($finding['findings'] as $item) {
        if (($item['type'] ?? '') !== 'curl_remote') {
            return false;
        }
    }
    return true;
}

/**
 * Returns true when the only finding in the group is a bare eval()
 * usage — no base64/gzinflate combo, no webshell sink, no preg_replace
 * /e modifier. Used to soften scoring for legitimate code-snippet
 * executors in plugin/theme code.
 */
function boteraser_findings_are_eval_only($finding) {
    if (empty($finding['findings'])) {
        return false;
    }
    foreach ($finding['findings'] as $item) {
        $type = $item['type'] ?? '';
        if ($type !== 'eval_usage' && $type !== 'js_eval_usage') {
            return false;
        }
    }
    return true;
}

/**
 * True if the file lives in a plugin/theme directory (not core, not
 * uploads). These locations frequently host legitimate utility code
 * that uses shell_exec/exec for non-malicious purposes.
 */
function boteraser_is_plugin_or_theme_path($rel_file) {
    return strpos($rel_file, 'wp-content/plugins/') === 0
        || strpos($rel_file, 'wp-content/themes/') === 0;
}

/**
 * Returns true when every finding in the group is a "generic" token hit
 * (no combined-pattern match like eval(base64_decode())).
 */
function boteraser_findings_are_generic_only($finding) {
    $generic_types = boteraser_generic_indicator_types();
    if (empty($finding['findings'])) {
        return false;
    }
    foreach ($finding['findings'] as $item) {
        if (!in_array($item['type'] ?? '', $generic_types, true)) {
            return false;
        }
    }
    return true;
}

/**
 * Returns true when the finding is a benign PHP placeholder inside
 * uploads: Boteraser's own workdir, or an index.php silence stub used
 * by legitimate plugins to block directory listing.
 */
function boteraser_is_benign_uploads_placeholder($finding) {
    $rel_file = str_replace('\\', '/', $finding['file'] ?? '');
    if ($rel_file === '' || basename($rel_file) !== 'index.php') {
        return false;
    }

    if (strpos($rel_file, 'wp-content/uploads/boteraser/scan/') === 0) {
        return true;
    }

    $full_path = ABSPATH . ltrim($rel_file, '/');
    if (!file_exists($full_path)) {
        return false;
    }

    return function_exists('boteraser_integrity_is_silence_stub')
        && boteraser_integrity_is_silence_stub($full_path);
}

/**
 * Hybrid trust signal:
 *   - 1.0  (full trust)  — checksum-verified core file
 *   - 0.35 (soft trust)  — known vendor JS / core path / minified vendor
 *   - 0.0  (no trust)
 *
 * Soft trust is applied as a score *reduction*, not a hard skip — if a
 * vendor file is actually modified to contain malware, combined-pattern
 * matches will still surface it as MEDIUM/LOW so the user can review.
 */
function boteraser_trust_factor($finding) {
    $rel_file = $finding['file'] ?? '';

    if (function_exists('boteraser_is_verified_core_file')
        && boteraser_is_verified_core_file($rel_file)) {
        return 1.0;
    }

    $is_core_path = function_exists('boteraser_is_core_path')
        && boteraser_is_core_path($rel_file);

    $is_vendor_js = function_exists('boteraser_is_known_vendor_js')
        && boteraser_is_known_vendor_js($rel_file);

    $is_minified_js = function_exists('boteraser_is_minified_js')
        && boteraser_is_minified_js($rel_file);

    if ($is_core_path || $is_vendor_js || $is_minified_js) {
        return 0.35;
    }

    return 0.0;
}

/**
 * Calculate risk score and severity for a finding group
 */
function boteraser_calculate_risk($finding) {
    $base_score = 0;
    $location_multiplier = 1.0;

    // Sum scores from all individual findings
    foreach ($finding['findings'] as $f) {
        $base_score += $f['score'] ?? 30;
    }

    // Average if multiple findings on same file
    if (count($finding['findings']) > 1) {
        $base_score = $base_score / count($finding['findings']);
        // Bonus for multiple hits on same file
        $base_score += 10 * (count($finding['findings']) - 1);
    }

    // Location risk multiplier
    $file = $finding['file'];
    $upload_dir = wp_upload_dir();
    $upload_rel = str_replace(ABSPATH, '', $upload_dir['basedir']);

    if (strpos($file, $upload_rel) !== false) {
        $location_multiplier = 1.4; // uploads folder = higher risk
    } elseif (strpos($file, 'wp-content/themes') !== false) {
        $location_multiplier = 1.1;
    } elseif (strpos($file, 'wp-content/plugins') !== false) {
        $location_multiplier = 1.0;
    } elseif (strpos($file, 'wp-admin') !== false || strpos($file, 'wp-includes') !== false) {
        $location_multiplier = 1.3; // Core modification = higher risk
    } elseif ($finding['ext'] === 'db') {
        $location_multiplier = 1.2;
    } elseif ($finding['ext'] === 'cron') {
        $location_multiplier = 1.3;
    }

    $final_score = min(100, round($base_score * $location_multiplier));

    // Hybrid trust adjustment.
    $trust  = boteraser_trust_factor($finding);
    $generic_only = boteraser_findings_are_generic_only($finding);

    if ($trust >= 1.0) {
        // Verified core file: token-only hits are documentation/legit
        // usage. Cap hard at 24 (= LOW).
        if ($generic_only) {
            $final_score = min($final_score, 24);
        }
    } elseif ($trust > 0.0 && $generic_only) {
        // Soft-trusted (path/vendor heuristic): reduce score by
        // ~65% so legitimate vendor matches degrade to LOW/MEDIUM
        // instead of HIGH, but combined-pattern hits still surface.
        $final_score = (int) round($final_score * (1 - $trust * 1.85));
        $final_score = max(0, $final_score);
    }

    // Plugin/theme code that ONLY hits shell-exec family patterns
    // (no obfuscation, no eval+base64 combos) is overwhelmingly
    // legitimate utility code: ffmpeg invocation, image optimizers,
    // backup tooling, system probes. Reduce by ~40% so it lands as
    // MEDIUM rather than HIGH. A real webshell would also trip the
    // webshell/eval/base64 patterns and bypass this path.
    // Shell-exec family (shell_exec, exec, system, passthru, popen,
    // proc_open) in plugin/theme code without any obfuscation is
    // overwhelmingly legitimate utility code: ffmpeg, image optimizers,
    // backup tools, system probes. Reduce to LOW.
    if (boteraser_is_plugin_or_theme_path($finding['file'] ?? '')
        && boteraser_findings_are_shell_exec_only($finding)) {
        $final_score = (int) round($final_score * 0.28);
        $final_score = max(0, $final_score);
    }

    // curl_remote in plugin/theme code without any obfuscation or webshell
    // co-indicators is overwhelmingly legitimate API usage (image optimizers,
    // payment gateways, etc.). Reduce to LOW.
    if (boteraser_is_plugin_or_theme_path($finding['file'] ?? '')
        && boteraser_findings_are_curl_remote_only($finding)) {
        $final_score = (int) round($final_score * 0.28);
        $final_score = max(0, $final_score);
    }

    // Standalone eval() in plugin/theme code without combined obfuscation
    // is most often a legitimate code-snippet executor (WPCode,
    // insert-headers-and-footers, Elementor dynamic tags, etc.).
    // Reduce to LOW. A malicious eval() almost always co-occurs with
    // base64_decode, gzinflate, or a $_POST sink — all matched
    // separately and not affected by this softening.
    if (boteraser_is_plugin_or_theme_path($finding['file'] ?? '')
        && boteraser_findings_are_eval_only($finding)) {
        $final_score = (int) round($final_score * 0.35);
        $final_score = max(0, $final_score);
    }

    // Severity thresholds
    if ($final_score >= 71) {
        $severity = 'HIGH';
    } elseif ($final_score >= 31) {
        $severity = 'MEDIUM';
    } else {
        $severity = 'LOW';
    }

    return array_merge($finding, array(
        'score'    => $final_score,
        'severity' => $severity,
    ));
}
