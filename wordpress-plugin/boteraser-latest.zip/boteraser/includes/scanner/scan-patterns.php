<?php
/**
 * Malware Pattern Detection + Obfuscation Analysis
 */

if (!defined('ABSPATH')) exit;

/**
 * Ignore obvious signature-definition or documentation matches.
 */
function boteraser_should_ignore_pattern_match($content, $offset, $file) {
    $line_start = strrpos(substr($content, 0, $offset), "\n");
    $line_start = ($line_start === false) ? 0 : $line_start + 1;
    $line_end = strpos($content, "\n", $offset);
    $line_end = ($line_end === false) ? strlen($content) : $line_end;
    $line = substr($content, $line_start, $line_end - $line_start);

    // Anything inside Boteraser's own scanner directory is a signature
    // definition or documentation match — never live malware.
    $normalized = str_replace('\\', '/', $file);
    if (strpos($normalized, '/plugins/boteraser/includes/scanner/') !== false
        || strpos($normalized, 'wp-content/plugins/boteraser/includes/scanner/') !== false) {
        return true;
    }

    if (preg_match('/example\s+\d+:/i', $line)) {
        return true;
    }

    return false;
}

/**
 * PHP-only malware signatures.
 * These functions and patterns only have meaning in PHP — running them
 * against JS files produces false positives (e.g. RegExp.prototype.exec).
 */
function boteraser_get_php_patterns() {
    return array(

        // --- Execution functions ---
        array(
            'id'      => 'eval_usage',
            'label'   => 'eval() usage',
            // Match the global eval() language construct. Exclude
            // identifiers that merely end with "eval" (myEval, preEval).
            // PHP doesn't have method-style eval but the lookbehind
            // is still useful against word-suffix collisions.
            'regex'   => '/(?<![A-Za-z0-9_])eval\s*\(/i',
            'score'   => 55,
            'context' => true,
        ),
        array(
            'id'      => 'base64_decode',
            'label'   => 'base64_decode()',
            // Standalone base64_decode() is heavily used by legitimate
            // plugins (settings imports, tracking parameter decoding,
            // file upload handling). The dangerous case is
            // eval(base64_decode(...)) which is matched separately by
            // the eval_base64 rule with a much higher score.
            'regex'   => '/\bbase64_decode\s*\(/i',
            'score'   => 25,
            'context' => true,
        ),
        array(
            'id'      => 'gzinflate',
            'label'   => 'gzinflate() — payload decompression',
            'regex'   => '/\bgzinflate\s*\(/i',
            'score'   => 50,
            'context' => true,
        ),
        array(
            'id'      => 'gzuncompress',
            'label'   => 'gzuncompress()',
            'regex'   => '/\bgzuncompress\s*\(/i',
            'score'   => 45,
            'context' => true,
        ),
        array(
            'id'      => 'str_rot13',
            'label'   => 'str_rot13() — obfuscation',
            'regex'   => '/\bstr_rot13\s*\(/i',
            'score'   => 40,
            'context' => true,
        ),

        // --- Shell execution ---
        array(
            'id'      => 'shell_exec',
            'label'   => 'shell_exec()',
            'regex'   => '/\bshell_exec\s*\(/i',
            'score'   => 80,
            'context' => true,
        ),
        array(
            'id'      => 'exec_func',
            'label'   => 'exec() function',
            'regex'   => '/\bexec\s*\(\s*[\'"]/',
            'score'   => 75,
            'context' => true,
        ),
        array(
            'id'      => 'system_func',
            'label'   => 'system() function',
            'regex'   => '/\bsystem\s*\(\s*[\'"]/',
            'score'   => 75,
            'context' => true,
        ),
        array(
            'id'      => 'passthru',
            'label'   => 'passthru()',
            'regex'   => '/\bpassthru\s*\(/i',
            'score'   => 75,
            'context' => true,
        ),
        array(
            'id'      => 'popen_func',
            'label'   => 'popen() — pipe to shell',
            'regex'   => '/\bpopen\s*\(/i',
            'score'   => 70,
            'context' => true,
        ),
        array(
            'id'      => 'proc_open',
            'label'   => 'proc_open() — process execution',
            'regex'   => '/\bproc_open\s*\(/i',
            'score'   => 70,
            'context' => true,
        ),

        // --- Remote file inclusion ---
        array(
            'id'      => 'file_get_url',
            'label'   => 'file_get_contents() with remote URL',
            'regex'   => '/file_get_contents\s*\(\s*[\'"]https?:\/\//i',
            'score'   => 50,
            'context' => true,
        ),
        array(
            'id'      => 'curl_remote',
            'label'   => 'CURL remote request in PHP file',
            'regex'   => '/curl_exec\s*\(.*curl_setopt.*CURLOPT_URL/is',
            'score'   => 35,
            'context' => false,
        ),

        // --- Webshell indicators ---
        //
        // Real webshells execute superglobals, e.g. eval($_POST['x']),
        // system($_GET['cmd']), assert($_REQUEST['a']). The naive
        // pattern of matching ANY $_GET/POST/REQUEST access produces
        // hundreds of false positives across legitimate WordPress
        // plugins (every plugin reads $_GET['page'] and similar).
        //
        // We anchor on "dangerous-sink-function( ... $_SUPERGLOBAL ... )"
        // — same pattern Wordfence and Sucuri use. The dotall (s) flag
        // and bounded {0,200} prevent catastrophic backtracking.
        array(
            'id'      => 'webshell_get',
            'label'   => 'Webshell — superglobal passed to code-execution sink',
            // Same-statement match: dangerous sink + superglobal must
            // appear on the same line (no newlines between them).
            // Without this anchor the regex chains across the file
            // and matches any sink that has a superglobal somewhere
            // later — every WordPress plugin trips this.
            //
            // preg_replace is intentionally NOT in this list — bare
            // preg_replace($pattern, $replacement, $_POST['x']) is a
            // legitimate sanitization pattern. The dangerous variant
            // is preg_replace with the /e modifier, matched by the
            // separate "preg_replace_e" rule.
            'regex'   => '/(?:^|[\s;{}(=,&|!])(?:eval|assert|system|exec|passthru|shell_exec|proc_open|popen|create_function)\s*\(\s*[^);{}\r\n]{0,150}\$_(?:GET|POST|REQUEST|COOKIE|SERVER)\b/i',
            'score'   => 90,
            'context' => true,
        ),
        array(
            'id'      => 'webshell_include',
            'label'   => 'Dynamic include/require with user input',
            // Single-line match: include/require directly followed by
            // a superglobal in the same statement (no semicolons,
            // braces, or newlines between them). Trailing \b prevents
            // matching identifiers that merely start with "require"
            // such as `required` or `requires_something`.
            // Anchor on statement-start whitespace/punctuation so we
            // don't match the literal string "include" appearing as an
            // array key or method name (e.g. $_REQUEST["include"]).
            'regex'   => '/(?:^|[\s;{}(])(?:include|include_once|require|require_once)\b\s*\(?\s*[^;{}\r\n]{0,120}\$_(?:GET|POST|REQUEST|COOKIE)\b/i',
            'score'   => 88,
            'context' => true,
        ),
        array(
            'id'      => 'assert_input',
            'label'   => 'assert() with user input',
            'regex'   => '/\bassert\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)/i',
            'score'   => 90,
            'context' => true,
        ),
        array(
            'id'      => 'preg_replace_e',
            'label'   => 'preg_replace with /e modifier',
            'regex'   => '/preg_replace\s*\(\s*[\'"].*\/e[\'"]/i',
            'score'   => 85,
            'context' => true,
        ),

        // --- Obfuscation combined patterns ---
        array(
            'id'      => 'eval_base64',
            'label'   => 'eval(base64_decode()) — classic obfuscation',
            'regex'   => '/eval\s*\(\s*base64_decode\s*\(/i',
            'score'   => 95,
            'context' => true,
        ),
        array(
            'id'      => 'eval_gzip',
            'label'   => 'eval(gzinflate()) — compressed payload',
            'regex'   => '/eval\s*\(\s*gzinflate\s*\(/i',
            'score'   => 95,
            'context' => true,
        ),
        array(
            'id'      => 'create_function',
            'label'   => 'create_function() — dynamic code',
            'regex'   => '/\bcreate_function\s*\(/i',
            'score'   => 60,
            'context' => true,
        ),
        array(
            'id'      => 'variable_function',
            'label'   => 'Variable function call $func()',
            'regex'   => '/\$\w+\s*=\s*[\'"](\beval\b|\bbase64_decode\b|\bsystem\b|\bexec\b)[\'"]/',
            'score'   => 70,
            'context' => true,
        ),

        // --- Content injection ---
        //
        // Plain `<iframe src="https://...">` is overwhelmingly legit
        // (YouTube embeds, GTM, Google Maps, vendor analytics). Real
        // iframe injection malware is hidden — zero size, off-screen,
        // visibility:hidden, or uses data:/javascript: URLs. We anchor
        // on those signals.
        array(
            'id'      => 'iframe_inject',
            'label'   => 'Hidden / off-screen iframe (possible injection)',
            // Word boundary on the attribute name avoids matching
            // marginwidth/marginheight as if they were width/height.
            // `style` patterns require the suspicious property anywhere
            // in the inline style value.
            'regex'   => '/<iframe[^>]*(?:\b(?:width|height)\s*=\s*[\'"]?0(?![\d.])|\bstyle\s*=\s*[\'"][^\'"]*(?:display\s*:\s*none|visibility\s*:\s*hidden|position\s*:\s*absolute[^\'"]*(?:left|top)\s*:\s*-\d{2,})|\bsrc\s*=\s*[\'"](?:data:|javascript:))/i',
            'score'   => 75,
            'context' => true,
        ),
    );
}

/**
 * JavaScript-only malware signatures.
 * eval() is legitimate in many libraries (jQuery JSON parsing, smartmenus,
 * etc.) so it scores lower here than in PHP. Shell-execution patterns are
 * intentionally absent — they have no meaning in browser JavaScript.
 */
function boteraser_get_js_patterns() {
    return array(
        array(
            'id'      => 'js_eval_usage',
            'label'   => 'eval() usage',
            // Match the global eval() function call only.
            //
            // Excluded false positives:
            //   - method calls: obj.eval(x), this.eval(x)
            //   - word suffixes: myEval(x), preEval(x)
            //   - method definitions inside ES6 classes:
            //       class Foo { eval(a,b) { ... } }
            //     where "eval" is a valid (non-reserved) method name.
            //
            // Lookbehind blocks word/dot/$ characters before "eval".
            // Lookahead after the closing ) blocks "{" which would
            // indicate a function/method body — a real eval() call is
            // never followed by an opening brace.
            'regex'   => '/(?<![A-Za-z0-9_.$])eval\s*\([^)]*\)\s*(?!\{)/i',
            'score'   => 35,
            'context' => true,
        ),
        array(
            'id'      => 'js_function_constructor',
            'label'   => 'Function() constructor with dynamic body',
            'regex'   => '/new\s+Function\s*\(\s*[\'"][^\'"]*\$\{/i',
            'score'   => 50,
            'context' => true,
        ),
        array(
            'id'      => 'iframe_inject',
            'label'   => 'iframe injection',
            'regex'   => '/<iframe[^>]+src\s*=\s*[\'"]https?:\/\//i',
            'score'   => 60,
            'context' => true,
        ),
        array(
            'id'      => 'script_inject',
            'label'   => 'Suspicious script tag with external URL',
            'regex'   => '/<script[^>]+src\s*=\s*[\'"]https?:\/\/(?!(?:ajax\.googleapis\.com|cdn\.jsdelivr\.net|cdnjs\.cloudflare\.com))/i',
            'score'   => 50,
            'context' => true,
        ),
        array(
            'id'      => 'document_write',
            'label'   => 'document.write() with embedded code',
            'regex'   => '/document\.write\s*\(\s*unescape\s*\(/i',
            'score'   => 65,
            'context' => true,
        ),
    );
}

/**
 * Backwards-compatible aggregator (PHP signatures only, for callers that
 * still expect the legacy single-list shape).
 */
function boteraser_get_patterns() {
    return boteraser_get_php_patterns();
}

/**
 * Check whether an iframe tag (the substring from "<iframe" to ">")
 * targets a well-known analytics / tag-manager / video provider.
 * These services routinely use display:none + 0×0 noscript iframes
 * — exactly the structural signal that flags a hidden iframe — but
 * are not malware. Whitelisting them prevents the GTM/Facebook
 * noscript snippet from being reported as injection.
 */
function boteraser_iframe_is_known_tracker($iframe_tag) {
    $known_hosts = array(
        // Tag managers / analytics
        'googletagmanager.com',
        'google-analytics.com',
        'metrics.10web.site',
        'connect.facebook.net',
        'facebook.com/tr',
        'analytics.tiktok.com',
        'bat.bing.com',
        'static.hotjar.com',
        'snap.licdn.com',
        // Tunnel iframes used by mailing/forms plugins
        'tnp-tunnel',
    );

    $tag = strtolower($iframe_tag);
    foreach ($known_hosts as $host) {
        if (strpos($tag, $host) !== false) {
            return true;
        }
    }
    return false;
}

/**
 * Check file content against all patterns.
 *
 * @param string $content File contents.
 * @param string $file    Absolute file path (used for path-based filters).
 * @param string $ext     Lowercase extension ("php" or "js"). Defaults to
 *                        "php" so legacy callers keep their behavior.
 */
function boteraser_check_patterns($content, $file, $ext = 'php') {
    $findings = array();

    $rel_file = str_replace(ABSPATH, '', $file);
    $is_js    = ($ext === 'js');
    $is_minified_js = $is_js
        && function_exists('boteraser_is_minified_js')
        && boteraser_is_minified_js($rel_file, $content);
    $is_known_vendor_js = $is_js
        && function_exists('boteraser_is_known_vendor_js')
        && boteraser_is_known_vendor_js($rel_file);

    $patterns = $is_js
        ? boteraser_get_js_patterns()
        : boteraser_get_php_patterns();

    foreach ($patterns as $pattern) {
        if (preg_match($pattern['regex'], $content, $matches, PREG_OFFSET_CAPTURE)) {
            $offset = $matches[0][1];

            if (boteraser_should_ignore_pattern_match($content, $offset, $file)) {
                continue;
            }

            // Iframe pattern: skip if the matched element points at a
            // well-known analytics/tag-manager domain. GTM, Facebook
            // Pixel and similar legitimately use width=0/display:none
            // for their noscript fallback iframes.
            if ($pattern['id'] === 'iframe_inject') {
                $tag_end = strpos($content, '>', $offset);
                $tag = $tag_end !== false ? substr($content, $offset, $tag_end - $offset) : substr($content, $offset, 400);
                if (boteraser_iframe_is_known_tracker($tag)) {
                    continue;
                }
            }

            $finding = array(
                'type'    => $pattern['id'],
                'label'   => $pattern['label'],
                'score'   => $pattern['score'],
                'details' => '',
            );

            if ($pattern['context']) {
                $snippet = substr($content, max(0, $offset - 30), 120);
                $snippet = preg_replace('/\s+/', ' ', trim($snippet));
                $finding['details'] = $snippet;
            }

            $findings[] = $finding;
        }
    }

    // Entropy / long-base64 / packed-code heuristics produce false
    // positives on minified vendor JS and on data/template JSON files
    // that use .js extension (e.g. template.json.js from page builders).
    // These files legitimately contain base64-encoded images or fonts.
    // WP 6.5+ .l10n.php translation files are data-only files generated
    // by WordPress.org and are excluded for the same reason.
    $is_json_js = (bool) preg_match('/\.json\.js$/i', $rel_file);
    $is_l10n_php = (bool) preg_match('/\.l10n\.php$/i', $rel_file);
    if ($is_minified_js || $is_known_vendor_js || $is_json_js || $is_l10n_php) {
        return $findings;
    }

    // Skip obfuscation heuristics when the file is mostly human-language
    // text: multibyte UTF-8 (CJK, Cyrillic, Arabic translations) pushes
    // byte entropy into the 5.8+ zone tuned for obfuscated ASCII payloads.
    // Real packed/encoded malware is almost entirely ASCII, so a high
    // non-ASCII share is a reliable "not obfuscation" signal. Signature
    // pattern matches above are unaffected.
    if (boteraser_non_ascii_ratio($content) > 0.25) {
        return $findings;
    }

    // Obfuscation: long base64 string detection
    if (preg_match('/[\'"][A-Za-z0-9+\/]{200,}={0,2}[\'"]/', $content)) {
        $findings[] = array(
            'type'    => 'long_base64',
            'label'   => 'Long base64 string (possible payload)',
            'score'   => 50,
            'details' => 'Base64 string > 200 characters',
        );
    }

    // Entropy analysis — high entropy = likely obfuscated.
    // Threshold tuned to match Wordfence/Sucuri: HTML/CSS/JSON-heavy
    // PHP templates can hit 5.2-5.4, but real packed/obfuscated
    // malware sits at 5.8-6.5+. Anything below 5.7 produces false
    // positives on legitimate WordPress block templates.
    $entropy = boteraser_entropy($content);
    if ($entropy > 5.7 && strlen($content) > 500) {
        $findings[] = array(
            'type'    => 'high_entropy',
            'label'   => 'High entropy content (' . round($entropy, 2) . ') — possible obfuscation',
            'score'   => 40,
            'details' => 'Entropy: ' . round($entropy, 2) . '/8.0',
        );
    }

    // Packed/minified malicious code — very long single line with a real
    // eval() call. Match the call syntax (eval + optional whitespace + "(")
    // rather than the bare substring "eval": legitimate WAF/signature files
    // and minifiers embed the word "eval" inside regexes and identifiers
    // without ever invoking it, which the substring check mis-flagged.
    $lines = explode("\n", $content);
    foreach ($lines as $line) {
        if (strlen($line) > 5000 && preg_match('/\beval\s*\(/i', $line)) {
            $findings[] = array(
                'type'    => 'packed_code',
                'label'   => 'Minified/packed code with eval()',
                'score'   => 80,
                'details' => 'Line ' . strlen($line) . ' characters with eval()',
            );
            break;
        }
    }

    return $findings;
}

/**
 * Shannon entropy calculation.
 *
 * Memory-safe: avoids str_split() (which on a 5 MB file would allocate
 * ~250 MB worth of single-byte PHP strings). Uses count_chars() instead
 * which returns a 256-element frequency table built in C — constant
 * memory regardless of input size.
 */
function boteraser_entropy($string) {
    $len = strlen($string);
    if ($len === 0) return 0;

    $freq = count_chars($string, 1);
    $entropy = 0.0;

    foreach ($freq as $count) {
        $p = $count / $len;
        $entropy -= $p * log($p, 2);
    }

    return $entropy;
}

/**
 * Share of non-ASCII bytes (>= 0x80) in a string. Used to recognise
 * multibyte human-language text (translations) that legitimately has
 * high byte entropy.
 */
function boteraser_non_ascii_ratio($string) {
    $len = strlen($string);
    if ($len === 0) return 0.0;
    $non_ascii = 0;
    foreach (count_chars($string, 1) as $byte => $count) {
        if ($byte >= 0x80) $non_ascii += $count;
    }
    return $non_ascii / $len;
}

/**
 * Incremental Shannon entropy state.
 *
 * Used by the chunked scanner to compute entropy without holding the
 * whole file in memory. Caller updates the state with each chunk and
 * finalizes once at the end.
 */
function boteraser_entropy_state_init() {
    return array(
        'freq'  => array_fill(0, 256, 0),
        'total' => 0,
    );
}

function boteraser_entropy_state_update(&$state, $chunk) {
    $len = strlen($chunk);
    if ($len === 0) return;

    $chunk_freq = count_chars($chunk, 1); // byte => count for present bytes
    foreach ($chunk_freq as $byte => $count) {
        $state['freq'][$byte] += $count;
    }
    $state['total'] += $len;
}

function boteraser_entropy_state_finalize($state) {
    if ($state['total'] === 0) return 0.0;

    $entropy = 0.0;
    $total = $state['total'];
    foreach ($state['freq'] as $count) {
        if ($count === 0) continue;
        $p = $count / $total;
        $entropy -= $p * log($p, 2);
    }
    return $entropy;
}

/**
 * Run pattern detection over a file.
 *
 * Picks between whole-file and chunked scanning based on file size, so
 * memory stays bounded even on 5 MB+ files. Returns the same structure
 * as boteraser_check_patterns() — an array of finding records.
 */
function boteraser_check_file_patterns($file, $ext) {
    $size = @filesize($file);
    if ($size === false) {
        return array();
    }

    if ($size <= BOTERASER_LARGE_FILE_THRESHOLD) {
        $content = @file_get_contents($file);
        if ($content === false) return array();
        $findings = boteraser_check_patterns($content, $file, $ext);
        unset($content);
        return $findings;
    }

    return boteraser_check_patterns_chunked($file, $ext);
}

/**
 * Chunked variant of pattern detection. Processes the file in fixed
 * 256 KB windows with 1 KB overlap so signatures spanning a boundary
 * still match.
 *
 * Heuristics that operate on the whole file (entropy, longest line)
 * are computed incrementally; long-base64 detection runs per-chunk
 * (1 KB overlap is enough to catch boundary cases since the regex
 * threshold is 200 chars).
 */
function boteraser_check_patterns_chunked($file, $ext) {
    $findings = array();
    $rel_file = str_replace(ABSPATH, '', $file);

    $is_js              = ($ext === 'js');
    $is_known_vendor_js = $is_js
        && function_exists('boteraser_is_known_vendor_js')
        && boteraser_is_known_vendor_js($rel_file);

    // Initial minified detection by path/filename. Will be re-checked
    // against the first chunk of content below if not already true.
    $is_minified_js     = $is_js
        && function_exists('boteraser_is_minified_js')
        && boteraser_is_minified_js($rel_file);

    // Template/data JSON files with .js extension contain base64-encoded
    // assets by design — skip all heuristics for them. Same for WP 6.5+
    // .l10n.php translation data files generated by WordPress.org.
    $is_json_js = (bool) preg_match('/\.json\.js$/i', $rel_file);
    $is_l10n_php = (bool) preg_match('/\.l10n\.php$/i', $rel_file);
    if ($is_json_js || $is_l10n_php) {
        return array();
    }

    $patterns = $is_js
        ? boteraser_get_js_patterns()
        : boteraser_get_php_patterns();

    // Track which pattern types we've already recorded so we don't
    // emit a finding for every chunk that contains the same hit.
    $seen_pattern_types  = array();
    $found_long_base64   = false;
    $longest_line_with_eval = 0;
    $current_line_len    = 0;
    $entropy_state       = boteraser_entropy_state_init();
    $total_bytes_seen    = 0;

    $chunks = boteraser_read_file_chunks($file);
    if ($chunks === null) {
        return array();
    }

    // Content-based minified detection on the first chunk for JS files
    // that didn't trip path-based detection (e.g. modern Webpack bundles
    // without ".min.js" in the name).
    if ($is_js && !$is_minified_js && !empty($chunks)
        && function_exists('boteraser_is_minified_js')
        && boteraser_is_minified_js($rel_file, $chunks[0])) {
        $is_minified_js = true;
    }

    foreach ($chunks as $chunk) {
        boteraser_entropy_state_update($entropy_state, $chunk);
        $total_bytes_seen += strlen($chunk);

        // Pattern matching per chunk
        foreach ($patterns as $pattern) {
            if (isset($seen_pattern_types[$pattern['id']])) continue;

            if (preg_match($pattern['regex'], $chunk, $matches, PREG_OFFSET_CAPTURE)) {
                $offset = $matches[0][1];
                if (boteraser_should_ignore_pattern_match($chunk, $offset, $file)) {
                    continue;
                }

                if ($pattern['id'] === 'iframe_inject') {
                    $tag_end = strpos($chunk, '>', $offset);
                    $tag = $tag_end !== false ? substr($chunk, $offset, $tag_end - $offset) : substr($chunk, $offset, 400);
                    if (boteraser_iframe_is_known_tracker($tag)) {
                        continue;
                    }
                }

                $finding = array(
                    'type'    => $pattern['id'],
                    'label'   => $pattern['label'],
                    'score'   => $pattern['score'],
                    'details' => '',
                );

                if ($pattern['context']) {
                    $snippet = substr($chunk, max(0, $offset - 30), 120);
                    $snippet = preg_replace('/\s+/', ' ', trim($snippet));
                    $finding['details'] = $snippet;
                }

                $findings[] = $finding;
                $seen_pattern_types[$pattern['id']] = true;
            }
        }

        // Skip noisy heuristics on minified vendor JS
        if ($is_minified_js || $is_known_vendor_js) {
            continue;
        }

        // Long base64 detection — per-chunk, recorded once
        if (!$found_long_base64
            && preg_match('/[\'"][A-Za-z0-9+\/]{200,}={0,2}[\'"]/', $chunk)) {
            $findings[] = array(
                'type'    => 'long_base64',
                'label'   => 'Long base64 string (possible payload)',
                'score'   => 50,
                'details' => 'Base64 string > 200 characters',
            );
            $found_long_base64 = true;
        }

        // Track longest line that contains "eval" — accounts for
        // chunk boundaries by carrying current_line_len across.
        $offset = 0;
        $len    = strlen($chunk);
        while ($offset < $len) {
            $nl = strpos($chunk, "\n", $offset);
            if ($nl === false) {
                $current_line_len += ($len - $offset);
                break;
            }
            $current_line_len += ($nl - $offset);
            // We only care once the line exceeds threshold
            if ($current_line_len > 5000) {
                $line_segment = substr($chunk, $offset, $nl - $offset);
                if (strpos($line_segment, 'eval') !== false
                    && $current_line_len > $longest_line_with_eval) {
                    $longest_line_with_eval = $current_line_len;
                }
            }
            $current_line_len = 0;
            $offset = $nl + 1;
        }
    }

    // Free chunk buffer immediately
    unset($chunks);

    if (!$is_minified_js && !$is_known_vendor_js) {
        // Non-ASCII share straight from the entropy freq table — mostly
        // multibyte text (translations) is not obfuscation; see the
        // non-chunked variant for rationale.
        $non_ascii = 0;
        for ($b = 0x80; $b < 256; $b++) {
            $non_ascii += $entropy_state['freq'][$b];
        }
        $mostly_multibyte = $total_bytes_seen > 0
            && ($non_ascii / $total_bytes_seen) > 0.25;

        // Entropy heuristic — see threshold rationale in the
        // non-chunked variant above.
        $entropy = boteraser_entropy_state_finalize($entropy_state);
        if (!$mostly_multibyte && $entropy > 5.7 && $total_bytes_seen > 500) {
            $findings[] = array(
                'type'    => 'high_entropy',
                'label'   => 'High entropy content (' . round($entropy, 2) . ') — possible obfuscation',
                'score'   => 40,
                'details' => 'Entropy: ' . round($entropy, 2) . '/8.0',
            );
        }

        if ($longest_line_with_eval > 5000) {
            $findings[] = array(
                'type'    => 'packed_code',
                'label'   => 'Minified/packed code with eval()',
                'score'   => 80,
                'details' => 'Line ' . $longest_line_with_eval . ' characters with eval()',
            );
        }
    }

    return $findings;
}
