<?php
/**
 * Boteraser Scanner Engine
 * Orchestrates all scan modules with chunked processing
 */

if (!defined('ABSPATH')) exit;

define('BOTERASER_SCAN_VERSION', '1.0');
define('BOTERASER_SCAN_CHUNK_SIZE', 50);
define('BOTERASER_SCAN_CORE_CHUNK_SIZE', 200);
define('BOTERASER_SCAN_TRANSIENT', 'boteraser_scan_state');
define('BOTERASER_SCAN_RESULTS', 'boteraser_scan_results');
define('BOTERASER_SCAN_WHITELIST', 'boteraser_scan_whitelist');

/**
 * Working directory for scan-in-progress data: the file queue and the
 * findings stream. Living on disk instead of inside the WP transient
 * (= wp_options row) keeps the per-AJAX-chunk overhead constant
 * regardless of how many files the site has or how many findings have
 * accumulated. With ~10k files in the queue and a few thousand
 * findings, the transient approach was costing 5-15 seconds per chunk
 * just on serialize/unserialize and DB I/O.
 */
function boteraser_scan_workdir() {
    $upload = wp_upload_dir();
    $dir = trailingslashit($upload['basedir']) . 'boteraser/scan';
    if (!is_dir($dir)) {
        wp_mkdir_p($dir);
        @file_put_contents($dir . '/.htaccess', "Order allow,deny\nDeny from all\n");
        @file_put_contents($dir . '/index.php', "<?php // silence\n");
    }
    return $dir;
}

function boteraser_scan_queue_path()    { return boteraser_scan_workdir() . '/queue.txt'; }
function boteraser_scan_core_path()     { return boteraser_scan_workdir() . '/core.txt'; }
function boteraser_scan_findings_path() { return boteraser_scan_workdir() . '/findings.jsonl'; }

/**
 * Persist scan state to both the transient and a wp_options backup.
 * The backup survives object-cache eviction (Redis/Memcached under memory
 * pressure) which can silently wipe transients and freeze the scan.
 */
function boteraser_scan_set_state($state, $ttl = HOUR_IN_SECONDS) {
    set_transient(BOTERASER_SCAN_TRANSIENT, $state, $ttl);
    update_option('boteraser_scan_state_backup', $state, false);
}

/**
 * Reset / cleanup workdir at the start of a new scan.
 */
function boteraser_scan_reset_workdir() {
    foreach (array(
        boteraser_scan_queue_path(),
        boteraser_scan_core_path(),
        boteraser_scan_findings_path(),
    ) as $f) {
        if (file_exists($f)) @unlink($f);
    }
}

/**
 * Append a single finding (associative array) to the findings stream.
 */
function boteraser_scan_append_finding($finding) {
    $path = boteraser_scan_findings_path();
    @file_put_contents(
        $path,
        wp_json_encode($finding) . "\n",
        FILE_APPEND | LOCK_EX
    );
}

/**
 * Load every finding back into memory at the end of the scan. Only
 * called once when computing the final summary.
 */
function boteraser_scan_load_findings() {
    $path = boteraser_scan_findings_path();
    if (!file_exists($path)) return array();
    $findings = array();
    $fp = @fopen($path, 'r');
    if (!$fp) return array();
    while (($line = fgets($fp)) !== false) {
        $line = trim($line);
        if ($line === '') continue;
        $row = json_decode($line, true);
        if (is_array($row)) {
            $findings[] = $row;
        }
    }
    fclose($fp);
    return $findings;
}

require_once __DIR__ . '/scan-patterns.php';
require_once __DIR__ . '/scan-files.php';
require_once __DIR__ . '/scan-database.php';
require_once __DIR__ . '/scan-cron.php';
require_once __DIR__ . '/scan-risk-score.php';
require_once __DIR__ . '/scan-integrity.php';
require_once __DIR__ . '/scan-malware-api.php';

/**
 * Initialize a new scan session
 */
function boteraser_scan_init($modules = array()) {
    // Free-tier defaults: hash-based integrity verification only.
    //
    // - core / plugins / themes: compare against WordPress.org upstream
    // - filenames / uploads:     known malware names + PHP-in-uploads
    // - database / cron:         lightweight checks for backdoors
    //
    // Pattern matching (eval, base64_decode, shell_exec, etc.) is OFF
    // by default — those generate false positives across legitimate
    // plugins and are not what Wordfence Free / MalCare Free use.
    // Users can opt in via the "Deep code scan" checkbox if they
    // explicitly want pattern-based heuristics.
    $default_modules = array(
        'core'        => true,
        'plugins'     => true,
        'themes'      => true,
        'filenames'   => true,
        'uploads'     => true,
        'htaccess'    => true,
        'database'    => true,
        'cron'        => true,
        // Opt-in only — generates false positives on legitimate plugins
        'patterns'    => false,
        'files'       => true,
        'permissions' => true,
        // Cloud malware signature lookup — requires valid API key
        'malware_api' => false,
    );

    $modules = wp_parse_args($modules, $default_modules);

    // Wipe any previous scan's working files so we don't mix queues
    // or accidentally append to a stale findings stream.
    boteraser_scan_reset_workdir();

    // Collect files to scan and stream them straight to disk. Holding
    // the full path list in memory and then serializing it into the
    // transient was the dominant per-chunk cost on large sites.
    $queue_path = boteraser_scan_queue_path();
    $fp = @fopen($queue_path, 'w');
    $total_files = 0;
    if ($fp) {
        $files = boteraser_collect_files($modules);
        foreach ($files as $f) {
            fwrite($fp, $f . "\n");
            $total_files++;
        }
        fclose($fp);
        unset($files);
    }

    // Prefetch the WordPress.org checksums during init so the slow API
    // call (up to ~15s) happens while the UI shows "Preparing scan..."
    // instead of stalling mid-scan in the core integrity phase. The
    // result is cached for 12 hours so subsequent scans skip the API
    // call entirely.
    //
    // Scope: only wp-admin/ and wp-includes/ are considered "core".
    // Bundled default themes under wp-content/ are excluded — they are
    // user-customizable and not part of the standard "core integrity"
    // surface (same scope as Wordfence/Sucuri/MalCare).
    $core_total = 0;
    if (!empty($modules['core'])) {
        $checksums = boteraser_get_core_checksums();
        if (is_array($checksums) && !empty($checksums)) {
            $core_path = boteraser_scan_core_path();
            $cf = @fopen($core_path, 'w');
            if ($cf) {
                foreach ($checksums as $rel_file => $hash) {
                    if (strpos($rel_file, 'wp-admin/') === 0
                        || strpos($rel_file, 'wp-includes/') === 0) {
                        fwrite($cf, $rel_file . "\n");
                        $core_total++;
                    }
                }
                fclose($cf);
            }
        }
    }

    // Enumerate plugins / themes that need integrity verification.
    // Each record is a compact array (slug, version, abs path, rel
    // path) — the full list lives in $state since it's small.
    $plugin_records = !empty($modules['plugins'])
        ? boteraser_integrity_enumerate_plugins() : array();
    $theme_records = !empty($modules['themes'])
        ? boteraser_integrity_enumerate_themes() : array();

    // Decide the starting phase based on which modules are enabled.
    // malware_api runs LAST — by then all local findings are collected
    // and can be sent to the server together with hashes for a complete
    // scan record and cross-referenced analysis.
    $first_phase = 'done';
    if (!empty($modules['files']))         $first_phase = 'files';
    elseif (!empty($modules['core']))      $first_phase = 'core';
    elseif (!empty($modules['plugins']))   $first_phase = 'plugins';
    elseif (!empty($modules['themes']))    $first_phase = 'themes';
    elseif (!empty($modules['filenames'])) $first_phase = 'filenames';
    elseif (!empty($modules['uploads']))   $first_phase = 'uploads';
    elseif (!empty($modules['htaccess']))  $first_phase = 'htaccess';
    elseif (!empty($modules['database']))  $first_phase = 'database';
    elseif (!empty($modules['cron']))      $first_phase = 'cron';
    elseif (!empty($modules['malware_api'])) $first_phase = 'malware_api';

    // The transient now holds only metadata / counters — < 1 KB. The
    // heavy queues live on disk (queue.txt, core.txt, findings.jsonl).
    $state = array(
        'status'           => 'running',
        'modules'          => $modules,
        'total_files'      => $total_files,
        'scanned_files'    => 0,
        'queue_offset'     => 0,
        'core_total'       => $core_total,
        'core_scanned'     => 0,
        'core_offset'      => 0,
        'plugin_records'   => $plugin_records,
        'plugin_index'     => 0,
        'plugins_total'    => count($plugin_records),
        'plugins_scanned'  => 0,
        'theme_records'    => $theme_records,
        'theme_index'      => 0,
        'themes_total'     => count($theme_records),
        'themes_scanned'   => 0,
        'unverified_packages' => array(),
        'current_file'     => '',
        'phase'            => $first_phase,
        'phases_done'      => array(),
        'started_at'       => time(),
        'findings_count'   => 0,
    );

    boteraser_scan_set_state($state);
    return $state;
}

/**
 * Determine the next active phase given the current one + which
 * modules are enabled. Phases without their module are skipped.
 */
function boteraser_scan_next_phase($current, $modules) {
    $order = array('files', 'core', 'plugins', 'themes', 'filenames', 'uploads', 'htaccess', 'database', 'cron', 'malware_api', 'done');
    $module_for_phase = array(
        'files'       => 'files',
        'core'        => 'core',
        'plugins'     => 'plugins',
        'themes'      => 'themes',
        'filenames'   => 'filenames',
        'uploads'     => 'uploads',
        'htaccess'    => 'htaccess',
        'database'    => 'database',
        'cron'        => 'cron',
        'malware_api' => 'malware_api',
        'done'        => null,
    );

    $idx = array_search($current, $order, true);
    if ($idx === false) return 'done';

    for ($i = $idx + 1; $i < count($order); $i++) {
        $phase = $order[$i];
        $mod = $module_for_phase[$phase];
        if ($mod === null) return $phase;
        if (!empty($modules[$mod])) return $phase;
    }
    return 'done';
}

/**
 * Read the next $count entries from a line-oriented queue file
 * starting at $offset bytes. Returns array(items, new_offset).
 */
function boteraser_scan_read_queue($path, $offset, $count) {
    if (!file_exists($path)) {
        return array(array(), $offset);
    }
    $fp = @fopen($path, 'r');
    if (!$fp) {
        return array(array(), $offset);
    }
    if ($offset > 0) {
        @fseek($fp, $offset);
    }
    $items = array();
    while (count($items) < $count && ($line = fgets($fp)) !== false) {
        $line = rtrim($line, "\r\n");
        if ($line !== '') {
            $items[] = $line;
        }
    }
    $new_offset = ftell($fp);
    fclose($fp);
    return array($items, $new_offset);
}

/**
 * Process one chunk — called repeatedly via AJAX
 */
function boteraser_scan_chunk() {
    $state = get_transient(BOTERASER_SCAN_TRANSIENT);

    // Fallback: transient may have been evicted from object cache (Redis/Memcached
    // under memory pressure). Recover from the wp_options backup written each chunk.
    if (!$state || $state['status'] !== 'running') {
        $backup = get_option('boteraser_scan_state_backup', false);
        if ($backup && isset($backup['status']) && $backup['status'] === 'running') {
            $state = $backup;
            // Restore transient from backup so subsequent reads are fast again.
            set_transient(BOTERASER_SCAN_TRANSIENT, $state, 4 * HOUR_IN_SECONDS);
        }
    }

    if (!$state || $state['status'] !== 'running') {
        delete_option('boteraser_scan_state_backup');
        return array('status' => 'error', 'message' => 'No active scan session.');
    }

    // Give this chunk a fresh time budget so a slow chunk does not
    // inherit any time already spent earlier in the request lifecycle.
    if (function_exists('set_time_limit')) {
        @set_time_limit(60);
    }

    $chunk_size = BOTERASER_SCAN_CHUNK_SIZE;

    // Per-chunk safety budgets — break out cleanly before PHP kills us.
    $start_time   = microtime(true);
    $time_budget  = 25.0; // seconds; AJAX request ceiling is typically 30s
    $memory_limit = boteraser_memory_limit_bytes();
    $memory_ceiling = $memory_limit > 0
        ? (int) ($memory_limit * 0.80)
        : 0;

    // Phase: malware API hash lookup — runs LAST, after all local
    // phases have completed. Sends file hashes to the cloud server
    // for signature verification. The complete set of local findings
    // is available at this point for cross-referencing.
    if ($state['phase'] === 'malware_api') {
        if (empty($state['modules']['malware_api'])) {
            $state['phases_done'][] = 'malware_api';
            $state['phase']         = boteraser_scan_next_phase('malware_api', $state['modules']);
            boteraser_scan_set_state($state);
            return boteraser_scan_progress($state);
        }

        $malware_offset = isset($state['malware_api_offset']) ? $state['malware_api_offset'] : 0;

        $queue_path = boteraser_scan_queue_path();
        list($batch, $next_offset) = boteraser_scan_read_queue(
            $queue_path,
            $malware_offset,
            BOTERASER_HASH_BATCH_SIZE
        );

        if (empty($batch)) {
            $state['phases_done'][] = 'malware_api';
            $state['phase']         = boteraser_scan_next_phase('malware_api', $state['modules']);
            boteraser_scan_set_state($state);
            return boteraser_scan_progress($state);
        }

        // Send batch of file hashes to the malware signature server
        $findings = boteraser_malware_scan_batch($batch);
        foreach ($findings as $f) {
            boteraser_scan_append_finding($f);
            $state['findings_count']++;
        }

        $state['malware_api_offset'] = $next_offset;
        $state['malware_api_scanned'] = ($state['malware_api_scanned'] ?? 0) + count($batch);

        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: file scanning — pull next batch from disk queue
    if ($state['phase'] === 'files') {
        $queue_path = boteraser_scan_queue_path();
        list($batch, $next_offset) = boteraser_scan_read_queue(
            $queue_path,
            $state['queue_offset'],
            $chunk_size
        );

        if (empty($batch)) {
            $state['phases_done'][] = 'files';
            $state['phase'] = boteraser_scan_next_phase('files', $state['modules']);
            boteraser_scan_set_state($state);
            return boteraser_scan_progress($state);
        }

        $processed = 0;
        foreach ($batch as $file) {
            // Always process at least one file per chunk to guarantee
            // forward progress. Without this guard, a single slow file
            // (large pattern scan) would make queue_offset never advance,
            // locking the scan in an infinite loop on the same file.
            $over_budget = (microtime(true) - $start_time) > $time_budget;
            $over_memory = $memory_ceiling > 0 && memory_get_usage(true) > $memory_ceiling;
            if ($processed > 0 && ($over_budget || $over_memory)) break;

            $state['current_file'] = str_replace(ABSPATH, '', $file);
            $result = boteraser_scan_single_file($file, $state['modules']);
            if ($result) {
                boteraser_scan_append_finding($result);
                $state['findings_count']++;
            }
            $state['scanned_files']++;
            $processed++;

            if (($processed & 0x0F) === 0 && function_exists('gc_collect_cycles')) {
                gc_collect_cycles();
            }
        }

        // Advance the offset only by the bytes we actually processed.
        if ($processed === count($batch)) {
            $state['queue_offset'] = $next_offset;
        } else {
            $bytes_consumed = 0;
            for ($i = 0; $i < $processed; $i++) {
                $bytes_consumed += strlen($batch[$i]) + 1; // +1 for "\n"
            }
            $state['queue_offset'] += $bytes_consumed;
        }

        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: WordPress core integrity (chunked, file-queue backed)
    if ($state['phase'] === 'core') {
        if (empty($state['modules']['core']) || $state['core_total'] === 0) {
            $state['phases_done'][] = 'core';
            $state['phase']         = boteraser_scan_next_phase('core', $state['modules']);
            boteraser_scan_set_state($state);
            return boteraser_scan_progress($state);
        }

        // boteraser_get_core_checksums() caches in a transient so repeated
        // calls within the same scan are fast, but the first call per PHP
        // process still hits the transient backend. Use a static cache so
        // we pay that cost at most once per AJAX request.
        static $cached_checksums = null;
        if ($cached_checksums === null) {
            $cached_checksums = boteraser_get_core_checksums();
        }
        $checksums = $cached_checksums;

        if (empty($checksums)) {
            $state['phases_done'][] = 'core';
            $state['phase']         = boteraser_scan_next_phase('core', $state['modules']);
            boteraser_scan_set_state($state);
            return boteraser_scan_progress($state);
        }

        list($batch, $next_offset) = boteraser_scan_read_queue(
            boteraser_scan_core_path(),
            $state['core_offset'],
            BOTERASER_SCAN_CORE_CHUNK_SIZE
        );

        if (empty($batch)) {
            $state['phases_done'][] = 'core';
            $state['phase']         = boteraser_scan_next_phase('core', $state['modules']);
            boteraser_scan_set_state($state);
            return boteraser_scan_progress($state);
        }

        $processed = 0;
        foreach ($batch as $rel_file) {
            $over_budget = (microtime(true) - $start_time) > $time_budget;
            $over_memory = $memory_ceiling > 0 && memory_get_usage(true) > $memory_ceiling;
            if ($processed > 0 && ($over_budget || $over_memory)) break;

            $expected_hash = $checksums[$rel_file] ?? null;
            if (!$expected_hash) {
                $state['core_scanned']++;
                $processed++;
                continue;
            }

            $state['current_file'] = $rel_file;
            $full_path = ABSPATH . $rel_file;
            $file_ext  = strtolower(pathinfo($rel_file, PATHINFO_EXTENSION));
            $is_executable = in_array($file_ext, array('php', 'phtml', 'phar'), true);

            if (!file_exists($full_path)) {
                boteraser_scan_append_finding(array(
                    'file'     => $rel_file,
                    'findings' => array(array(
                        'type'    => 'core_missing',
                        'label'   => $is_executable
                            ? 'Missing WordPress core file'
                            : 'Missing WordPress core asset (non-executable)',
                        'score'   => $is_executable ? 70 : 18,
                        'details' => $rel_file,
                    )),
                    'ext'  => $file_ext,
                    'size' => 0,
                ));
                $state['findings_count']++;
            } else {
                $actual_hash = md5_file($full_path);
                if ($actual_hash !== $expected_hash) {
                    boteraser_scan_append_finding(array(
                        'file'     => $rel_file,
                        'findings' => array(array(
                            'type'    => 'core_modified',
                            'label'   => $is_executable
                                ? 'Modified WordPress core file'
                                : 'Modified WordPress core asset (non-executable)',
                            'score'   => $is_executable ? 85 : 22,
                            'details' => "Expected hash: {$expected_hash}, actual: {$actual_hash}",
                        )),
                        'ext'  => $file_ext,
                        'size' => filesize($full_path),
                    ));
                    $state['findings_count']++;
                }
            }

            $state['core_scanned']++;
            $processed++;
        }

        if ($processed === count($batch)) {
            $state['core_offset'] = $next_offset;
        } else {
            $bytes_consumed = 0;
            for ($i = 0; $i < $processed; $i++) {
                $bytes_consumed += strlen($batch[$i]) + 1;
            }
            $state['core_offset'] += $bytes_consumed;
        }

        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: plugin integrity (one plugin per chunk — downloading +
    // hashing the upstream ZIP can take several seconds).
    if ($state['phase'] === 'plugins') {
        if (empty($state['plugin_records']) || $state['plugin_index'] >= count($state['plugin_records'])) {
            $state['phases_done'][] = 'plugins';
            $state['phase']         = boteraser_scan_next_phase('plugins', $state['modules']);
            boteraser_scan_set_state($state);
            return boteraser_scan_progress($state);
        }

        $record = $state['plugin_records'][$state['plugin_index']];
        $state['current_file'] = $record['rel'];

        // Give this chunk extra time for ZIP download (up to 90s).
        // Without this, a large plugin ZIP download on a slow host
        // causes a PHP timeout mid-chunk — the AJAX request dies,
        // JS sees a network failure, and after 3 retries the scan aborts.
        if (function_exists('set_time_limit')) {
            @set_time_limit(120);
        }

        $result = boteraser_integrity_verify_package($record, 'plugin');

        if ($result['status'] === 'unverified') {
            $state['unverified_packages'][] = array(
                'kind' => 'plugin',
                'slug' => $record['slug'],
                'rel'  => $record['rel'],
            );
        }

        foreach ($result['findings'] as $f) {
            boteraser_scan_append_finding($f);
            $state['findings_count']++;
        }

        $state['plugin_index']++;
        $state['plugins_scanned']++;

        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: theme integrity
    if ($state['phase'] === 'themes') {
        if (empty($state['theme_records']) || $state['theme_index'] >= count($state['theme_records'])) {
            $state['phases_done'][] = 'themes';
            $state['phase']         = boteraser_scan_next_phase('themes', $state['modules']);
            boteraser_scan_set_state($state);
            return boteraser_scan_progress($state);
        }

        $record = $state['theme_records'][$state['theme_index']];
        $state['current_file'] = $record['rel'];

        if (function_exists('set_time_limit')) {
            @set_time_limit(120);
        }

        $result = boteraser_integrity_verify_package($record, 'theme');

        if ($result['status'] === 'unverified') {
            $state['unverified_packages'][] = array(
                'kind' => 'theme',
                'slug' => $record['slug'],
                'rel'  => $record['rel'],
            );
        }

        foreach ($result['findings'] as $f) {
            boteraser_scan_append_finding($f);
            $state['findings_count']++;
        }

        $state['theme_index']++;
        $state['themes_scanned']++;

        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: filename blacklist — scan unverified packages for known
    // malware filenames + suspicious naming patterns.
    if ($state['phase'] === 'filenames') {
        if (!empty($state['modules']['filenames'])) {
            // Walk every plugin/theme directory once and check each
            // file's basename. Cheap (no content read).
            $roots = array();
            if (is_dir(WP_PLUGIN_DIR))         $roots[] = WP_PLUGIN_DIR;
            if (is_dir(WP_CONTENT_DIR . '/themes')) $roots[] = WP_CONTENT_DIR . '/themes';
            if (is_dir(WP_CONTENT_DIR . '/mu-plugins')) $roots[] = WP_CONTENT_DIR . '/mu-plugins';

            foreach ($roots as $root) {
                $stack = array($root);
                while ($stack) {
                    if ((microtime(true) - $start_time) > $time_budget) break 2;
                    $dir = array_pop($stack);
                    $dh = @opendir($dir);
                    if (!$dh) continue;
                    while (($entry = readdir($dh)) !== false) {
                        if ($entry === '.' || $entry === '..') continue;
                        $full = $dir . '/' . $entry;
                        if (is_dir($full)) {
                            // Skip vendor/build dirs (same as main traversal)
                            if (boteraser_should_skip_dir($full)) continue;
                            $stack[] = $full;
                            continue;
                        }
                        if (!is_file($full)) continue;
                        $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
                        if (!in_array($ext, array('php', 'phtml', 'phar'), true)) continue;

                        $rel = str_replace(ABSPATH, '', $full);
                        $hit = boteraser_integrity_check_filename($rel);
                        if ($hit) {
                            boteraser_scan_append_finding(array(
                                'file'     => $rel,
                                'findings' => array($hit),
                                'ext'      => $ext,
                                'size'     => filesize($full),
                            ));
                            $state['findings_count']++;
                        }
                    }
                    closedir($dh);
                }
            }
        }
        $state['phases_done'][] = 'filenames';
        $state['phase']         = boteraser_scan_next_phase('filenames', $state['modules']);
        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: uploads PHP scan — PHP files in wp-content/uploads are
    // almost always malware (uploads is for media, not code).
    if ($state['phase'] === 'uploads') {
        if (!empty($state['modules']['uploads'])) {
            if (function_exists('set_time_limit')) @set_time_limit(60);
            $uploads_findings = boteraser_integrity_scan_uploads_php();
            foreach ($uploads_findings as $f) {
                boteraser_scan_append_finding($f);
                $state['findings_count']++;
            }
        }
        $state['phases_done'][] = 'uploads';
        $state['phase']         = boteraser_scan_next_phase('uploads', $state['modules']);
        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: .htaccess in uploads scan
    if ($state['phase'] === 'htaccess') {
        if (!empty($state['modules']['htaccess'])) {
            if (function_exists('set_time_limit')) @set_time_limit(30);
            $htaccess_findings = boteraser_integrity_scan_uploads_htaccess();
            foreach ($htaccess_findings as $f) {
                boteraser_scan_append_finding($f);
                $state['findings_count']++;
            }
        }
        $state['phases_done'][] = 'htaccess';
        $state['phase']         = boteraser_scan_next_phase('htaccess', $state['modules']);
        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: database scan
    if ($state['phase'] === 'database') {
        if (!empty($state['modules']['database'])) {
            if (function_exists('set_time_limit')) @set_time_limit(60);
            $db_findings = boteraser_scan_database();
            foreach ($db_findings as $f) {
                boteraser_scan_append_finding($f);
                $state['findings_count']++;
            }
        }
        $state['phases_done'][] = 'database';
        $state['phase']         = boteraser_scan_next_phase('database', $state['modules']);
        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: cron scan
    if ($state['phase'] === 'cron') {
        if (!empty($state['modules']['cron'])) {
            $cron_findings = boteraser_scan_cron_jobs();
            foreach ($cron_findings as $f) {
                boteraser_scan_append_finding($f);
                $state['findings_count']++;
            }
        }
        $state['phases_done'][] = 'cron';
        $state['phase']         = boteraser_scan_next_phase('cron', $state['modules']);
        boteraser_scan_set_state($state);
        return boteraser_scan_progress($state);
    }

    // Phase: done — load all findings, score, sort, persist results
    if ($state['phase'] === 'done') {
        $raw_findings = boteraser_scan_load_findings();
        $scored = array();
        foreach ($raw_findings as $finding) {
            $scored[] = boteraser_calculate_risk($finding);
        }
        unset($raw_findings);

        usort($scored, function($a, $b) {
            return $b['score'] - $a['score'];
        });

        $summary = boteraser_scan_summary($scored, $state);

        $results = array(
            'findings'     => $scored,
            'summary'      => $summary,
            'completed_at' => time(),
            'duration'     => time() - $state['started_at'],
            'modules'      => $state['modules'],
        );

        update_option('boteraser_last_scan_results', $results, false);
        update_option('boteraser_last_scan_time', time(), false);

        // Append to scan history for sparkline trends (keep last 30 entries)
        $scan_history = get_option('boteraser_scan_history', array());
        $scan_history[] = array(
            'time'  => time(),
            'score' => $summary['score'],
            'high'  => $summary['high'],
            'medium'=> $summary['medium'],
            'low'   => $summary['low'],
            'total' => $summary['total'],
        );
        if (count($scan_history) > 30) {
            $scan_history = array_slice($scan_history, -30);
        }
        update_option('boteraser_scan_history', $scan_history, false);

        // Auto-quarantine confirmed malware signature findings (Premium + option enabled).
        $aq_validation = get_option('bot_eraser_api_validation_state', array());
        if (get_option('boteraser_auto_quarantine') && !empty($aq_validation['is_valid']) && function_exists('boteraser_quarantine_move')) {
            $abspath = rtrim(ABSPATH, '/');
            foreach ($scored as &$finding) {
                $has_sig = false;
                foreach ($finding['findings'] as $item) {
                    if (($item['type'] ?? '') === 'malware_signature') {
                        $has_sig = true;
                        break;
                    }
                }
                if (!$has_sig) continue;

                $full_path = $abspath . '/' . ltrim($finding['file'], '/');
                if (!file_exists($full_path)) continue;

                $result = boteraser_quarantine_move($full_path, $finding['file'], $finding['severity'] ?? 'HIGH');
                if (!is_wp_error($result)) {
                    $finding['auto_quarantined'] = true;
                }
            }
            unset($finding);

            // Refresh summary with updated findings (auto_quarantined flag).
            $summary = boteraser_scan_summary($scored, $state);
            update_option('boteraser_last_scan_results', array_merge($results, array(
                'findings' => $scored,
                'summary'  => $summary,
            )), false);
        }

        // Send scan report to server — non-blocking (fire-and-forget
        // with short timeout), only when malware_api module was active.
        if (!empty($state['modules']['malware_api'])) {
            boteraser_send_scan_report($state, $summary, $scored);
        }

        delete_transient(BOTERASER_SCAN_TRANSIENT);
        delete_option('boteraser_scan_state_backup');
        boteraser_scan_reset_workdir();

        return array(
            'status'   => 'complete',
            'progress' => 100,
            'summary'  => $summary,
            'findings' => $scored,
        );
    }

    return boteraser_scan_progress($state);
}

/**
 * Build progress response.
 *
 * Each phase gets a fixed slice of the 0-99% range. Phases that are
 * disabled contribute zero, so a free-tier scan (no file walk, no
 * pattern matching) still reaches ~99% naturally.
 */
function boteraser_scan_progress($state) {
    $modules = $state['modules'];

    // Per-phase weights. Sum can be < 99 because some phases may be
    // disabled — we normalize at the end.
    $weights = array(
        'malware_api' => !empty($modules['malware_api']) ? 5 : 0,
        'files'       => !empty($modules['files'])     ? 30 : 0,
        'core'        => !empty($modules['core'])      ? 15 : 0,
        'plugins'     => !empty($modules['plugins'])   ? 25 : 0,
        'themes'      => !empty($modules['themes'])    ? 10 : 0,
        'filenames'   => !empty($modules['filenames']) ?  5 : 0,
        'uploads'     => !empty($modules['uploads'])   ?  5 : 0,
        'htaccess'    => !empty($modules['htaccess'])  ?  2 : 0,
        'database'    => !empty($modules['database'])  ?  5 : 0,
        'cron'        => !empty($modules['cron'])      ?  4 : 0,
    );
    $total_weight = max(1, array_sum($weights));
    $scale = 99 / $total_weight;

    $progress = 0;
    foreach ($weights as $phase => $w) {
        if ($w === 0) continue;
        if (in_array($phase, $state['phases_done'], true)) {
            $progress += $w * $scale;
            continue;
        }
        if ($state['phase'] === $phase) {
            // Partial credit for the active phase based on per-phase counter.
            $pct = 0;
            switch ($phase) {
                case 'malware_api':
                    $pct = $state['total_files'] > 0
                        ? ($state['malware_api_scanned'] ?? 0) / $state['total_files'] : 0;
                    break;
                case 'files':
                    $pct = $state['total_files'] > 0
                        ? $state['scanned_files'] / $state['total_files'] : 0;
                    break;
                case 'core':
                    $pct = $state['core_total'] > 0
                        ? $state['core_scanned'] / $state['core_total'] : 0;
                    break;
                case 'plugins':
                    $pct = $state['plugins_total'] > 0
                        ? $state['plugins_scanned'] / $state['plugins_total'] : 0;
                    break;
                case 'themes':
                    $pct = $state['themes_total'] > 0
                        ? $state['themes_scanned'] / $state['themes_total'] : 0;
                    break;
            }
            $progress += $w * $scale * min(1.0, $pct);
        }
    }

    $progress = min(99, max(0, round($progress)));

    $phase_labels = array(
        'malware_api' => 'Verifying signatures via cloud',
        'files'       => 'Scanning files',
        'core'        => 'Verifying WordPress core',
        'plugins'     => 'Verifying plugins against WordPress.org',
        'themes'      => 'Verifying themes against WordPress.org',
        'filenames'   => 'Checking for known malware filenames',
        'uploads'     => 'Scanning uploads folder',
        'htaccess'    => 'Checking .htaccess in uploads',
        'database'    => 'Scanning database',
        'cron'        => 'Checking cron jobs',
        'done'        => 'Finishing analysis',
    );

    return array(
        'status'           => 'running',
        'progress'         => $progress,
        'scanned'          => $state['scanned_files'],
        'total'            => $state['total_files'],
        'core_scanned'     => $state['core_scanned'] ?? 0,
        'core_total'       => $state['core_total'] ?? 0,
        'plugins_scanned'  => $state['plugins_scanned'] ?? 0,
        'plugins_total'    => $state['plugins_total'] ?? 0,
        'themes_scanned'   => $state['themes_scanned'] ?? 0,
        'themes_total'     => $state['themes_total'] ?? 0,
        'current_file'     => $state['current_file'],
        'phase'            => $state['phase'],
        'phase_label'      => $phase_labels[$state['phase']] ?? $state['phase'],
        'findings_count'   => $state['findings_count'] ?? 0,
    );
}

/**
 * Parse php.ini memory_limit (e.g. "256M") into bytes. Returns 0 if no
 * limit is set.
 */
function boteraser_memory_limit_bytes() {
    $raw = trim((string) ini_get('memory_limit'));
    if ($raw === '' || $raw === '-1') return 0;

    $unit  = strtolower(substr($raw, -1));
    $value = (int) $raw;

    switch ($unit) {
        case 'g': return $value * 1024 * 1024 * 1024;
        case 'm': return $value * 1024 * 1024;
        case 'k': return $value * 1024;
        default:  return $value;
    }
}

/**
 * Directory names we never recurse into. These are package manager /
 * build / cache trees that contain thousands of generated files and
 * never legitimately host malware reachable by the web — scanning them
 * just inflates the file list and wastes memory.
 */
function boteraser_skip_dir_names() {
    return array(
        // VCS metadata
        '.git', '.svn', '.hg',

        // Package managers
        'node_modules', 'bower_components',
        'vendor', 'vendor_prefixed', 'vendor-prefixed',
        'third-party', 'third_party',

        // Build artifacts
        'dist', 'build', '_build',
        '.next', '.nuxt', '.parcel-cache',

        // Caches / temp
        '.cache', 'cache',
        '.tmp', 'tmp',
        'backup', 'backups',
        '.wp-cli',
    );
}

/**
 * Returns true if this directory should be skipped during traversal.
 */
function boteraser_should_skip_dir($path) {
    static $skip = null;
    if ($skip === null) {
        $skip = array_flip(boteraser_skip_dir_names());
    }
    $name = basename($path);
    return isset($skip[$name]);
}

/**
 * Collect all files to scan.
 *
 * Uses a manual stack-based traversal instead of RecursiveIteratorIterator
 * so we can prune entire subtrees (node_modules, vendor, .git, caches)
 * before they expand into thousands of leaf entries.
 */
function boteraser_collect_files($modules) {
    $files = array();
    $valid_ext = array_flip(array('php', 'js', 'html', 'htm', 'ico', 'jpg', 'jpeg', 'png', 'gif'));

    $roots = array(
        ABSPATH . 'wp-admin',
        ABSPATH . WPINC,
        WP_CONTENT_DIR,
    );

    foreach ($roots as $root) {
        if (!is_dir($root)) continue;

        $stack = array($root);
        while ($stack) {
            $dir = array_pop($stack);
            $dh = @opendir($dir);
            if (!$dh) continue;

            while (($entry = readdir($dh)) !== false) {
                if ($entry === '.' || $entry === '..') continue;
                $path = $dir . DIRECTORY_SEPARATOR . $entry;

                if (is_dir($path)) {
                    if (boteraser_should_skip_dir($path)) continue;
                    $stack[] = $path;
                    continue;
                }

                if (!is_file($path)) continue;

                $dot = strrpos($entry, '.');
                if ($dot === false) continue;
                $ext = strtolower(substr($entry, $dot + 1));
                if (!isset($valid_ext[$ext])) continue;

                $files[] = $path;
            }
            closedir($dh);
        }
    }

    return $files;
}

/**
 * Scan a single file
 */
function boteraser_scan_single_file($file, $modules) {
    if (!is_readable($file)) return null;

    // Check whitelist
    $whitelist = get_option(BOTERASER_SCAN_WHITELIST, array());
    $rel_path  = str_replace(ABSPATH, '', $file);
    if (in_array($rel_path, $whitelist)) return null;

    $findings = array();
    $ext      = strtolower(pathinfo($file, PATHINFO_EXTENSION));

    // Skip Boteraser's own scanner code — its signature definitions
    // would otherwise match every pattern in the catalog.
    if (boteraser_is_self_plugin_path($rel_path)) {
        return null;
    }

    // Malware pattern detection (PHP/JS files). Uses the size-aware
    // file scanner: small files load whole, large files stream in
    // 256 KB chunks so memory stays bounded.
    if (!empty($modules['patterns']) && in_array($ext, array('php', 'js'))) {
        $pattern_hits = boteraser_check_file_patterns($file, $ext);
        $findings = array_merge($findings, $pattern_hits);
    }

    // PHP files in uploads folder
    if (!empty($modules['files'])) {
        $upload_dir = wp_upload_dir();
        if ($ext === 'php' && strpos($file, $upload_dir['basedir']) !== false) {
            $own_workdir = realpath($upload_dir['basedir'] . '/boteraser/scan') ?: '';
            $real_file   = realpath($file) ?: $file;
            $in_own_workdir = $own_workdir && strpos($real_file, $own_workdir) === 0;
            $is_stub = filesize($file) < 512 && function_exists('boteraser_integrity_is_silence_stub')
                       && boteraser_integrity_is_silence_stub($file);
            $is_known_plugin_dir = function_exists('boteraser_is_known_plugin_uploads_dir')
                                   && boteraser_is_known_plugin_uploads_dir($rel_path);
            if (!$in_own_workdir && !$is_stub && !$is_known_plugin_dir) {
                $findings[] = array(
                    'type'    => 'php_in_uploads',
                    'label'   => 'PHP file in uploads folder',
                    'details' => $rel_path,
                );
            }
        }

        // Suspicious double extensions
        $basename = basename($file);
        if (preg_match('/\.(php\.(jpg|jpeg|png|gif|ico)|ico\.php|shell\.php)$/i', $basename)) {
            $findings[] = array(
                'type'    => 'suspicious_extension',
                'label'   => 'Suspicious double extension',
                'details' => $basename,
            );
        }

        // Permissions check
        if (!empty($modules['permissions'])) {
            $perms = fileperms($file) & 0777;
            if ($perms === 0777 || $perms === 0775) {
                $findings[] = array(
                    'type'    => 'bad_permissions',
                    'label'   => 'Overly permissive file permissions (' . decoct($perms) . ')',
                    'details' => $rel_path,
                );
            }
        }
    }

    if (empty($findings)) return null;

    return array(
        'file'     => $rel_path,
        'findings' => $findings,
        'ext'      => $ext,
        'size'     => filesize($file),
    );
}

/**
 * Build scan summary with security score
 */
function boteraser_scan_summary($scored_findings, $state) {
    $high   = 0;
    $medium = 0;
    $low    = 0;

    foreach ($scored_findings as $f) {
        if ($f['severity'] === 'HIGH')        $high++;
        elseif ($f['severity'] === 'MEDIUM')  $medium++;
        elseif ($f['severity'] === 'LOW')     $low++;
    }

    // Security score — Wordfence-style:
    // worst severity dominates (a single HIGH should already drop the score
    // below 50), with a small "count tier" penalty so that 5×HIGH is
    // visibly worse than 1×HIGH. LOW findings barely move the needle —
    // a noisy LOW count must not panic the user into thinking the site
    // is compromised.
    $severity_penalty = 0;
    if ($high > 0) {
        $severity_penalty = 50;
    } elseif ($medium > 0) {
        $severity_penalty = 25;
    } elseif ($low > 0) {
        $severity_penalty = 5;
    }

    $count_penalty = 0;
    if ($high > 0) {
        $count_penalty += min(20, ($high - 1) * 5);
    }
    if ($medium > 0) {
        $count_penalty += min(10, ($medium - 1) * 2);
    }
    if ($low > 0) {
        $count_penalty += min(5, intval($low / 5));
    }

    $score = max(0, min(100, 100 - $severity_penalty - $count_penalty));

    $grade = 'EXCELLENT';
    if ($score < 40)      $grade = 'CRITICAL';
    elseif ($score < 60)  $grade = 'POOR';
    elseif ($score < 75)  $grade = 'WARNING';
    elseif ($score < 90)  $grade = 'GOOD';

    return array(
        'score'        => $score,
        'grade'        => $grade,
        'high'         => $high,
        'medium'       => $medium,
        'low'          => $low,
        'total'        => count($scored_findings),
        'files_scanned'=> $state['scanned_files'],
        'duration'     => time() - $state['started_at'],
    );
}

/**
 * Cancel active scan
 */
function boteraser_scan_cancel() {
    delete_transient(BOTERASER_SCAN_TRANSIENT);
    delete_option('boteraser_scan_state_backup');
    boteraser_scan_reset_workdir();
}

/**
 * Get last scan results
 */
function boteraser_get_last_scan() {
    return get_option('boteraser_last_scan_results', null);
}

/**
 * Add file to whitelist
 */
function boteraser_whitelist_add($rel_path) {
    $whitelist   = get_option(BOTERASER_SCAN_WHITELIST, array());
    $whitelist[] = $rel_path;
    update_option(BOTERASER_SCAN_WHITELIST, array_unique($whitelist));
}

/**
 * Remove file from whitelist
 */
function boteraser_whitelist_remove($rel_path) {
    $whitelist = get_option(BOTERASER_SCAN_WHITELIST, array());
    $whitelist = array_filter($whitelist, fn($f) => $f !== $rel_path);
    update_option(BOTERASER_SCAN_WHITELIST, array_values($whitelist));
}
