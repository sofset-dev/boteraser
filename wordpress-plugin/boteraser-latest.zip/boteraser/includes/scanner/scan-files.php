<?php
/**
 * File System Scan + WordPress Core Integrity Check
 */

if (!defined('ABSPATH')) exit;

/**
 * Fetch and cache WordPress core checksums.
 */
function boteraser_get_core_checksums() {
    global $wp_version;

    $locale = get_locale();
    $cache_key = 'boteraser_core_checksums_' . md5($wp_version . '|' . $locale);
    $cached = get_transient($cache_key);

    if (is_array($cached)) {
        return $cached;
    }

    $api_url  = "https://api.wordpress.org/core/checksums/1.0/?version={$wp_version}&locale={$locale}";
    $response = wp_remote_get($api_url, array('timeout' => 15));

    if (is_wp_error($response)) {
        return array();
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    $checksums = is_array($data['checksums'] ?? null) ? $data['checksums'] : array();

    if (!empty($checksums)) {
        set_transient($cache_key, $checksums, 12 * HOUR_IN_SECONDS);
    }

    return $checksums;
}

/**
 * Check whether a core file matches the official WordPress checksum.
 */
function boteraser_is_verified_core_file($rel_file) {
    if (strpos($rel_file, 'wp-admin/') !== 0 && strpos($rel_file, 'wp-includes/') !== 0) {
        return false;
    }

    $checksums = boteraser_get_core_checksums();
    if (empty($checksums[$rel_file])) {
        return false;
    }

    $full_path = ABSPATH . $rel_file;
    return file_exists($full_path) && md5_file($full_path) === $checksums[$rel_file];
}

/**
 * Path-based heuristic: file lives in a known WordPress core path.
 * Used as a soft trust signal when checksum API is unavailable.
 */
function boteraser_is_core_path($rel_file) {
    return strpos($rel_file, 'wp-admin/') === 0
        || strpos($rel_file, 'wp-includes/') === 0;
}

/**
 * Detect well-known vendor JavaScript libraries that ship with WordPress
 * core or popular plugins. Hits on these files are almost always false
 * positives (minified code, regex .exec(), eval() fallbacks, base64 in
 * source maps, etc.).
 */
function boteraser_is_known_vendor_js($rel_file) {
    $rel_file = strtolower($rel_file);

    if (substr($rel_file, -3) !== '.js') {
        return false;
    }

    $vendor_path_fragments = array(
        'wp-includes/js/',
        'wp-includes/blocks/',
        'wp-admin/js/',
        '/node_modules/',
        '/vendor/',
        '/assets/vendor/',
        '/assets/lib/',
        '/dist/vendor/',
    );

    foreach ($vendor_path_fragments as $fragment) {
        if (strpos($rel_file, $fragment) !== false) {
            return true;
        }
    }

    $vendor_name_patterns = array(
        'jquery', 'underscore', 'lodash', 'react', 'react-dom',
        'react-refresh', 'react-jsx-runtime', 'codemirror', 'tinymce',
        'moxie', 'plupload', 'backbone', 'mediaelement', 'thickbox',
        'hoverintent', 'imgareaselect', 'masonry', 'json2',
        'wp-tinymce', 'latex-to-mathml', 'interactivity',
    );

    $basename = basename($rel_file);
    foreach ($vendor_name_patterns as $pat) {
        if (strpos($basename, $pat) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Detect minified / bundled JavaScript. Minified code naturally has
 * high entropy and long single lines — these signals are not reliable
 * for malware detection in such files.
 *
 * Detection layers (any one wins):
 *   1. Filename contains ".min.js"
 *   2. Path contains a build-output segment (/dist/, /build/, /assets/)
 *   3. Content fingerprint: long average line length, low whitespace
 *      ratio, or the leading webpack/vite/rollup bundle prefix.
 *
 * Layer 3 catches Webpack/Vite output that doesn't include ".min" in
 * its filename (vendor.js, outline.js, editor-one-top-bar.js, etc.)
 * — exactly the kind of file that triggered false positive entropy
 * alerts on this site.
 */
function boteraser_is_minified_js($rel_file, $content = null) {
    $rel_file = strtolower($rel_file);

    if (substr($rel_file, -3) !== '.js') {
        return false;
    }

    if (strpos($rel_file, '.min.js') !== false) {
        return true;
    }

    if (strpos($rel_file, '/dist/') !== false
        || strpos($rel_file, '/build/') !== false
        || strpos($rel_file, '/assets/') !== false) {
        return true;
    }

    // If we have content, look at structural fingerprints. This is
    // how Wordfence and Sucuri identify bundled output regardless of
    // filename: minifiers strip whitespace and emit very long lines.
    if ($content !== null && strlen($content) > 1000) {
        $len = strlen($content);

        // 1) Average line length > 200 chars is a strong minify signal.
        $line_count = substr_count($content, "\n") + 1;
        $avg_line = $len / max(1, $line_count);
        if ($avg_line > 200) {
            return true;
        }

        // 2) Whitespace ratio < 8% on a sizeable sample = minified.
        // Hand-written code typically runs 15-25% whitespace.
        $sample = substr($content, 0, 65536);
        $ws = preg_match_all('/\s/', $sample);
        if ($ws !== false && strlen($sample) > 1000) {
            $ratio = $ws / strlen($sample);
            if ($ratio < 0.08) {
                return true;
            }
        }

        // 3) Webpack/Vite/Rollup bundle prefixes near the top.
        $prefix = substr($content, 0, 4096);
        if (preg_match('/^[\s\S]{0,200}(?:\(self\.webpackChunk|__webpack_require__|var\s+__webpack_modules__|System\.register|var\s+_typeof|\(()\(\s*function\s*\([a-z],[a-z]\)|!function\s*\([a-z]\)\s*\{)/i', $prefix)) {
            return true;
        }
    }

    return false;
}

/**
 * Returns true if the given path belongs to the Boteraser plugin itself.
 * Hits inside our own scanner code are signature definitions, never live
 * malware — never escalate them.
 *
 * Covers both the plugin directory and the plugin's own generated data
 * folder under uploads (WAF rules, scan workdir, etc.). This mirrors how
 * Wordfence excludes its plugin dir and its wp-content/wflogs/ data store:
 * a scanner must never flag the files it generates itself. Our WAF ruleset
 * (uploads/boteraser/waf-rules.php) legitimately embeds signature strings
 * like "eval" inside detection regexes and would otherwise self-detect.
 */
function boteraser_is_self_plugin_path($rel_file) {
    return strpos($rel_file, 'wp-content/plugins/boteraser/') !== false
        || strpos($rel_file, 'wp-content/uploads/boteraser/') !== false;
}

/**
 * Recognise a PHP file inside wp-content/uploads/<plugin-slug>/ that
 * belongs to a legitimate, active plugin.  Many plugins (easy-table-of-
 * contents, wp-time-capsule, WPForms, Elementor, WooCommerce etc.) create
 * a subdirectory named after themselves inside the uploads folder and
 * place PHP files there for caching, templating or dynamic CSS/JS
 * generation.  Flagging those as malware is a false positive — the
 * subdirectory name gives away the real owner.
 *
 * Returns the plugin slug if the file lives in a recognised plugin
 * subdirectory, or false otherwise.
 */
function boteraser_is_known_plugin_uploads_dir($rel_file) {
    if (strpos($rel_file, 'wp-content/uploads/') !== 0) {
        return false;
    }

    // Strip the uploads base so we can look at the first directory.
    $upload_rel = substr($rel_file, strlen('wp-content/uploads/'));
    $slash = strpos($upload_rel, '/');
    $first_dir = ($slash !== false) ? substr($upload_rel, 0, $slash) : '';

    if ($first_dir === '') return false;
    // Year-month directories (2024/05, etc.) are WordPress's own
    // media organisation — a PHP file there is genuinely suspicious.
    if (preg_match('/^\d{4}$/', $first_dir)) return false;

    // Build a quick lookup of active plugin slugs (cached as static).
    static $plugin_slugs = null;
    if ($plugin_slugs === null) {
        $plugin_slugs = array();
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all = get_plugins();
        foreach ($all as $plugin_file => $data) {
            $slug = dirname($plugin_file);
            if ($slug !== '' && $slug !== '.') {
                $plugin_slugs[$slug] = true;
            }
        }
        // Also check active themes.
        $theme = wp_get_theme();
        if ($theme->exists()) {
            $plugin_slugs[$theme->get_stylesheet()] = true;
        }
    }

    if (isset($plugin_slugs[$first_dir])) {
        return $first_dir;
    }

    return false;
}

/**
 * Threshold above which a file is read in fixed-size chunks instead of
 * being slurped whole into memory. Below this, the simpler whole-file
 * code path is used.
 */
if (!defined('BOTERASER_LARGE_FILE_THRESHOLD')) {
    define('BOTERASER_LARGE_FILE_THRESHOLD', 1024 * 1024); // 1 MB
}

if (!defined('BOTERASER_CHUNK_BYTES')) {
    define('BOTERASER_CHUNK_BYTES', 262144);  // 256 KB
}

if (!defined('BOTERASER_CHUNK_OVERLAP')) {
    define('BOTERASER_CHUNK_OVERLAP', 1024);  // 1 KB
}

/**
 * Hard ceiling on total bytes scanned per file. Above this we stop
 * reading even in chunked mode — anything larger than 20 MB is almost
 * certainly a generated bundle, sourcemap, or media blob and not
 * something where reading the tail would surface real malware.
 */
if (!defined('BOTERASER_MAX_SCAN_BYTES')) {
    define('BOTERASER_MAX_SCAN_BYTES', 20 * 1024 * 1024); // 20 MB
}

/**
 * Yield successive chunks of a file with overlap between chunks so that
 * pattern matches that straddle a chunk boundary are still detected.
 *
 * Returns null if the file cannot be opened. Otherwise returns an array
 * of chunks; callers should treat each chunk as an independent scan
 * surface.
 *
 * Memory profile: O(BOTERASER_CHUNK_BYTES) — constant, regardless of
 * file size.
 */
function boteraser_read_file_chunks($file) {
    $fp = @fopen($file, 'rb');
    if (!$fp) {
        return null;
    }

    $chunks       = array();
    $tail         = '';
    $bytes_read   = 0;
    $chunk_size   = BOTERASER_CHUNK_BYTES;
    $overlap_size = BOTERASER_CHUNK_OVERLAP;
    $max_bytes    = BOTERASER_MAX_SCAN_BYTES;

    while (!feof($fp) && $bytes_read < $max_bytes) {
        $remaining = $max_bytes - $bytes_read;
        $read_size = min($chunk_size, $remaining);
        $buf = fread($fp, $read_size);
        if ($buf === false || $buf === '') {
            break;
        }
        $bytes_read += strlen($buf);

        $chunks[] = $tail . $buf;

        // Keep last $overlap_size bytes as the prefix of the next chunk
        // so that signatures spanning the boundary are not missed.
        $tail = (strlen($buf) >= $overlap_size)
            ? substr($buf, -$overlap_size)
            : $buf;
    }

    fclose($fp);
    return $chunks;
}

/**
 * WordPress Core integrity check via WordPress.org checksum API
 */
function boteraser_check_core_integrity() {
    $findings = array();
    $checksums = boteraser_get_core_checksums();

    if (empty($checksums)) {
        return array();
    }

    foreach ($checksums as $rel_file => $expected_hash) {
        $full_path = ABSPATH . $rel_file;

        if (!file_exists($full_path)) {
            // Nedostaje core fajl
            $findings[] = array(
                'file'     => $rel_file,
                'findings' => array(array(
                    'type'    => 'core_missing',
                    'label'   => 'Missing WordPress core file',
                    'score'   => 70,
                    'details' => $rel_file,
                )),
                'ext'  => pathinfo($rel_file, PATHINFO_EXTENSION),
                'size' => 0,
            );
            continue;
        }

        $actual_hash = md5_file($full_path);

        if ($actual_hash !== $expected_hash) {
            $findings[] = array(
                'file'     => $rel_file,
                'findings' => array(array(
                    'type'    => 'core_modified',
                    'label'   => 'Modified WordPress core file',
                    'score'   => 85,
                    'details' => "Očekivani hash: {$expected_hash}, stvarni: {$actual_hash}",
                )),
                'ext'  => pathinfo($rel_file, PATHINFO_EXTENSION),
                'size' => filesize($full_path),
            );
        }
    }

    return $findings;
}

/**
 * Check recently modified files (last 7 days) — file integrity monitoring
 */
function boteraser_check_recently_modified() {
    $findings  = array();
    $threshold = time() - (7 * DAY_IN_SECONDS);

    $baseline = get_option('boteraser_file_baseline', array());
    if (empty($baseline)) {
        return array(); // No baseline, skipping
    }

    foreach ($baseline as $rel_path => $saved_hash) {
        $full_path = ABSPATH . $rel_path;

        if (!file_exists($full_path)) {
            $findings[] = array(
                'file'     => $rel_path,
                'findings' => array(array(
                    'type'    => 'file_deleted',
                    'label'   => 'File deleted since last baseline',
                    'score'   => 50,
                    'details' => $rel_path,
                )),
                'ext'  => pathinfo($rel_path, PATHINFO_EXTENSION),
                'size' => 0,
            );
            continue;
        }

        $current_hash = md5_file($full_path);
        if ($current_hash !== $saved_hash) {
            $mtime = filemtime($full_path);
            $findings[] = array(
                'file'     => $rel_path,
                'findings' => array(array(
                    'type'    => 'file_modified',
                    'label'   => 'File modified since last baseline',
                    'score'   => 45,
                    'details' => 'Modified: ' . date('d.m.Y H:i', $mtime),
                )),
                'ext'  => pathinfo($rel_path, PATHINFO_EXTENSION),
                'size' => filesize($full_path),
            );
        }
    }

    return $findings;
}

/**
 * Automatically reset the baseline after any WordPress upgrade so that
 * core file changes from the upgrade do not appear as false positives
 * in the File Integrity monitor.
 *
 * Fires on upgrader_process_complete for core updates only. Plugin and
 * theme updates do not touch wp-admin/wp-includes so they don't affect
 * the baseline.
 */
function boteraser_auto_reset_baseline_after_upgrade($upgrader, $hook_extra) {
    if (empty($hook_extra['action']) || $hook_extra['action'] !== 'update') {
        return;
    }
    if (empty($hook_extra['type']) || $hook_extra['type'] !== 'core') {
        return;
    }
    boteraser_save_baseline();
}
add_action('upgrader_process_complete', 'boteraser_auto_reset_baseline_after_upgrade', 10, 2);

/**
 * Save current file state as baseline
 */
function boteraser_save_baseline() {
    $dirs = array(
        ABSPATH . 'wp-admin',
        ABSPATH . WPINC,
    );

    $baseline = array();

    foreach ($dirs as $dir) {
        if (!is_dir($dir)) continue;
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if (!$file->isFile()) continue;
            if ($file->getExtension() !== 'php') continue;
            $rel = str_replace(ABSPATH, '', $file->getRealPath());
            $baseline[$rel] = md5_file($file->getRealPath());
        }
    }

    update_option('boteraser_file_baseline', $baseline);
    update_option('boteraser_baseline_time', time());

    return count($baseline);
}
