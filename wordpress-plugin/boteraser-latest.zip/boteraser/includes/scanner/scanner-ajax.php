<?php
/**
 * Scanner AJAX Handlers
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/scan-engine.php';
require_once __DIR__ . '/scan-files.php';

/**
 * Normalize posted scanner module settings.
 *
 * @return array<string, bool>
 */
function boteraser_normalize_scanner_module_settings() {
    $keys = array(
        'mod_core',
        'mod_plugins',
        'mod_themes',
        'mod_filenames',
        'mod_uploads',
        'mod_htaccess',
        'mod_files',
        'mod_permissions',
        'mod_database',
        'mod_cron',
        'mod_patterns',
        'mod_malware_api',
    );
    $settings = array();
    foreach ($keys as $key) {
        $settings[$key] = !empty($_POST[$key]);
    }

    return $settings;
}

/**
 * Start scan
 */
function boteraser_ajax_scan_start() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    $validation_state = get_option('bot_eraser_api_validation_state', array());
    $premium_enabled = !empty($validation_state['is_valid']);

    // Init may need to call api.wordpress.org for checksums (up to 15s)
    // and walk the entire wp-content tree to enumerate files. Give the
    // request enough headroom so it cannot be killed by a stale
    // max_execution_time inherited from the previous request.
    if (function_exists('set_time_limit')) {
        @set_time_limit(60);
    }

    // If the form sent zero module flags, fall through to the
    // free-tier defaults defined in boteraser_scan_init().
    $any_sent = false;
    foreach (array('mod_core','mod_plugins','mod_themes','mod_filenames','mod_uploads','mod_htaccess',
                   'mod_database','mod_cron','mod_patterns','mod_files','mod_permissions',
                   'mod_malware_api') as $k) {
        if (isset($_POST[$k])) { $any_sent = true; break; }
    }

    if ($any_sent) {
        update_option('boteraser_scanner_module_settings', boteraser_normalize_scanner_module_settings(), false);
        wp_cache_delete('boteraser_scanner_module_settings', 'options');
        wp_cache_delete('alloptions', 'options');

        $modules = array(
            'core'        => !empty($_POST['mod_core']),
            'plugins'     => !empty($_POST['mod_plugins']),
            'themes'      => !empty($_POST['mod_themes']),
            'filenames'   => !empty($_POST['mod_filenames']),
            'uploads'     => !empty($_POST['mod_uploads']),
            'htaccess'    => !empty($_POST['mod_htaccess']),
            'database'    => !empty($_POST['mod_database']),
            'cron'        => !empty($_POST['mod_cron']),
            // Deep / opt-in
            'patterns'    => $premium_enabled && !empty($_POST['mod_patterns']),
            'files'       => ($premium_enabled && !empty($_POST['mod_patterns'])) || !empty($_POST['mod_files']),
            'permissions' => !empty($_POST['mod_permissions']),
            // Cloud malware signature lookup — premium only
            'malware_api' => $premium_enabled && !empty($_POST['mod_malware_api']),
        );
    } else {
        $modules = array(); // engine fills in free-tier defaults
    }

    $state = boteraser_scan_init($modules);

    wp_send_json_success(array(
        'status'      => 'running',
        'progress'    => 0,
        'total_files' => $state['total_files'],
        'core_total'  => $state['core_total'],
        'phase_label' => 'Preparing scan...',
    ));
}
add_action('wp_ajax_boteraser_scan_start', 'boteraser_ajax_scan_start');

/**
 * Save scanner module preferences.
 */
function boteraser_ajax_save_scanner_modules() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $settings = boteraser_normalize_scanner_module_settings();
    update_option('boteraser_scanner_module_settings', $settings, false);
    wp_cache_delete('boteraser_scanner_module_settings', 'options');
    wp_cache_delete('alloptions', 'options');
    wp_send_json_success(array('saved' => true, 'settings' => $settings));
}
add_action('wp_ajax_boteraser_save_scanner_modules', 'boteraser_ajax_save_scanner_modules');

/**
 * Process next chunk
 */
function boteraser_ajax_scan_chunk() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $result = boteraser_scan_chunk();

    if (isset($result['status']) && $result['status'] === 'error') {
        wp_send_json_error(isset($result['message']) ? $result['message'] : 'Scan error.');
    }

    if (isset($result['status']) && $result['status'] === 'complete'
        && get_option('boteraser_notify_enabled', false)
        && !empty(get_option('bot_eraser_api_validation_state', array())['is_valid'])) {
        // Send via a one-off cron event instead of inline. A hanging SMTP
        // connection here would block the final AJAX response past the
        // browser's timeout, leaving the UI frozen at ~100% even though
        // the scan already finished and its state was cleaned up.
        wp_schedule_single_event(time(), 'boteraser_scan_notify_event');
    }

    wp_send_json_success($result);
}
add_action('wp_ajax_boteraser_scan_chunk', 'boteraser_ajax_scan_chunk');

/**
 * Cancel scan
 */
function boteraser_ajax_scan_cancel() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    boteraser_scan_cancel();
    wp_send_json_success(array('status' => 'cancelled'));
}
add_action('wp_ajax_boteraser_scan_cancel', 'boteraser_ajax_scan_cancel');

/**
 * Get last scan results
 */
function boteraser_ajax_scan_results() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $results = boteraser_get_last_scan();
    if (!$results) {
        wp_send_json_error(array('message' => 'No scan results found.'));
    }

    wp_send_json_success($results);
}
add_action('wp_ajax_boteraser_scan_results', 'boteraser_ajax_scan_results');

/**
 * Whitelist a file
 */
function boteraser_ajax_whitelist_add() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $path = sanitize_text_field($_POST['file'] ?? '');
    if (!$path) wp_send_json_error('Invalid path');

    boteraser_whitelist_add($path);
    wp_send_json_success(array('whitelisted' => $path));
}
add_action('wp_ajax_boteraser_whitelist_add', 'boteraser_ajax_whitelist_add');

/**
 * Remove from whitelist
 */
function boteraser_ajax_whitelist_remove() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $path = sanitize_text_field($_POST['file'] ?? '');
    if (!$path) wp_send_json_error('Invalid path');

    boteraser_whitelist_remove($path);
    wp_send_json_success(array('removed' => $path));
}
add_action('wp_ajax_boteraser_whitelist_remove', 'boteraser_ajax_whitelist_remove');

/**
 * Save baseline
 */
function boteraser_ajax_save_baseline() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $count = boteraser_save_baseline();
    wp_send_json_success(array(
        'count'   => $count,
        'message' => "Baseline saved: {$count} files.",
    ));
}
add_action('wp_ajax_boteraser_save_baseline', 'boteraser_ajax_save_baseline');

/**
 * Persist Automatic Scan settings and (re)schedule the cron hook.
 */
function boteraser_ajax_save_auto_scan() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $validation_state = get_option('bot_eraser_api_validation_state', array());
    $premium_enabled  = !empty($validation_state['is_valid']);

    $enabled  = $premium_enabled && !empty($_POST['enabled']) && $_POST['enabled'] !== '0';
    $interval = bot_eraser_auto_scan_interval_slug(sanitize_text_field($_POST['interval'] ?? ''));

    update_option('boteraser_auto_scan_enabled', $enabled, false);
    update_option('boteraser_auto_scan_interval', $interval, false);
    wp_cache_delete('boteraser_auto_scan_enabled', 'options');
    wp_cache_delete('boteraser_auto_scan_interval', 'options');
    wp_cache_delete('alloptions', 'options');
    bot_eraser_reschedule_auto_scan();

    $next = wp_next_scheduled('boteraser_auto_scan_hook');
    wp_send_json_success(array(
        'enabled'   => $enabled,
        'interval'  => $interval,
        'next_run'  => $next ? (int) $next : 0,
    ));
}
add_action('wp_ajax_boteraser_save_auto_scan', 'boteraser_ajax_save_auto_scan');

/**
 * Save email notification setting.
 */
function boteraser_ajax_save_notify() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $validation_state = get_option('bot_eraser_api_validation_state', array());
    if (empty($validation_state['is_valid'])) wp_send_json_error('Premium required');

    $enabled = !empty($_POST['enabled']) && $_POST['enabled'] !== '0';
    update_option('boteraser_notify_enabled', $enabled, false);

    // Save custom notification email address(es) — comma-separated list supported
    if (isset($_POST['email'])) {
        $raw   = trim(wp_unslash($_POST['email']));
        $email = '';
        if ($raw !== '') {
            $parts = array_map('trim', explode(',', $raw));
            $valid = array();
            foreach ($parts as $addr) {
                if ($addr === '') continue;
                $cleaned = sanitize_email($addr);
                if (!is_email($cleaned)) {
                    /* translators: %s: invalid email address */
                    wp_send_json_error(sprintf(__('Invalid email address: %s', 'bot-eraser'), $addr));
                }
                $valid[] = $cleaned;
            }
            $email = implode(', ', $valid);
        }
        // Fall back to admin_email when the field is cleared
        update_option('boteraser_notify_email', $email ?: get_option('admin_email'), false);
    }

    wp_cache_delete('boteraser_notify_enabled', 'options');
    wp_cache_delete('boteraser_notify_email', 'options');
    wp_cache_delete('alloptions', 'options');

    wp_send_json_success(array(
        'enabled' => $enabled,
        'email'   => get_option('boteraser_notify_email', get_option('admin_email')),
    ));
}
add_action('wp_ajax_boteraser_save_notify', 'boteraser_ajax_save_notify');

/**
 * Save auto scan files/themes/plugins toggle.
 */
function boteraser_ajax_save_auto_scan_files_themes_plugins() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $validation_state = get_option('bot_eraser_api_validation_state', array());
    if (empty($validation_state['is_valid'])) wp_send_json_error('Premium required');

    $enabled = !empty($_POST['enabled']) && $_POST['enabled'] !== '0';
    update_option('boteraser_auto_scan_files_themes_plugins', $enabled, false);
    wp_cache_delete('boteraser_auto_scan_files_themes_plugins', 'options');
    wp_cache_delete('alloptions', 'options');
    wp_send_json_success(array('enabled' => $enabled));
}
add_action('wp_ajax_boteraser_save_auto_scan_files_themes_plugins', 'boteraser_ajax_save_auto_scan_files_themes_plugins');

/**
 * Save auto-quarantine toggle.
 */
function boteraser_ajax_save_auto_quarantine() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $validation_state = get_option('bot_eraser_api_validation_state', array());
    if (empty($validation_state['is_valid'])) wp_send_json_error('Premium required');

    $enabled = !empty($_POST['enabled']) && $_POST['enabled'] !== '0';
    update_option('boteraser_auto_quarantine', $enabled, false);
    wp_cache_delete('boteraser_auto_quarantine', 'options');
    wp_cache_delete('alloptions', 'options');
    wp_send_json_success(array('enabled' => $enabled));
}
add_action('wp_ajax_boteraser_save_auto_quarantine', 'boteraser_ajax_save_auto_quarantine');

/**
 * Save WAF ruleset (OWASP CRS) toggle. Premium — requires a valid API key.
 */
function boteraser_ajax_save_waf_ruleset() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $validation_state = get_option('bot_eraser_api_validation_state', array());
    if (empty($validation_state['is_valid'])) wp_send_json_error('Premium required');

    $enabled = !empty($_POST['enabled']) && $_POST['enabled'] !== '0';
    update_option('boteraser_waf_enabled', $enabled, false);
    wp_cache_delete('boteraser_waf_enabled', 'options');
    wp_cache_delete('alloptions', 'options');

    // Pull the ruleset immediately on first enable so protection is active at once.
    if ($enabled && function_exists('bot_eraser_waf_sync') && !is_file(bot_eraser_waf_cache_path())) {
        bot_eraser_waf_sync();
    }

    wp_send_json_success(array('enabled' => $enabled));
}
add_action('wp_ajax_boteraser_save_waf_ruleset', 'boteraser_ajax_save_waf_ruleset');

/**
 * Save upload & plugin protection toggles.
 */
function boteraser_ajax_save_upload_protection() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $option_map = array(
        'block_php_uploads'       => 'boteraser_block_php_uploads',
        'block_dangerous_ext'     => 'boteraser_block_dangerous_ext',
        'auto_quarantine_uploads' => 'boteraser_auto_quarantine_uploads',
        'scan_before_activation'  => 'boteraser_scan_before_activation',
        'auto_deactivate_plugins' => 'boteraser_auto_deactivate_plugins',
        'rollback_on_update'      => 'boteraser_rollback_on_update',
        'realtime_cloud_scan'     => 'boteraser_realtime_cloud_scan',
        'whitelist_safe_plugins'  => 'boteraser_whitelist_safe_plugins',
    );
    $premium_fields = array('auto_quarantine_uploads', 'auto_deactivate_plugins', 'realtime_cloud_scan');

    $field = isset($_POST['field']) ? sanitize_key($_POST['field']) : '';
    if (!isset($option_map[$field])) wp_send_json_error('Invalid field');

    if (in_array($field, $premium_fields, true)) {
        $validation_state = get_option('bot_eraser_api_validation_state', array());
        if (empty($validation_state['is_valid'])) wp_send_json_error('Premium required');
    }

    $option_name = $option_map[$field];
    $enabled     = !empty($_POST['enabled']) && $_POST['enabled'] !== '0';
    update_option($option_name, $enabled, false);
    wp_cache_delete($option_name, 'options');
    wp_cache_delete('alloptions', 'options');
    wp_send_json_success(array('field' => $field, 'enabled' => $enabled));
}
add_action('wp_ajax_boteraser_save_upload_protection', 'boteraser_ajax_save_upload_protection');

/**
 * Quarantine file — move outside web root
 */
/**
 * Detects the main plugin file from a relative path inside wp-content/plugins/.
 * Returns plugin file like 'google-site-kit/google-site-kit.php' or null.
 */
function boteraser_detect_plugin_from_path($rel_path) {
    if (!preg_match('#^wp-content/plugins/([^/]+)/#', $rel_path, $m)) {
        return null;
    }
    $slug = $m[1];
    if (!function_exists('get_plugins')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    foreach (array_keys(get_plugins()) as $plugin_file) {
        if (strpos($plugin_file, $slug . '/') === 0) {
            return $plugin_file;
        }
    }
    return null;
}

function boteraser_ajax_quarantine_file() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $rel_path = sanitize_text_field($_POST['file'] ?? '');
    if (!$rel_path) wp_send_json_error('Invalid path');

    $full_path = ABSPATH . ltrim($rel_path, '/');

    // Security: only allow files inside ABSPATH
    $real_path = realpath($full_path);
    $real_abspath = realpath(ABSPATH);
    if (!$real_path || !$real_abspath || strpos($real_path, $real_abspath) !== 0) {
        wp_send_json_error('Path traversal detected.');
    }

    if (!file_exists($full_path)) {
        wp_send_json_error('File does not exist.');
    }

    // Deactivate plugin if file belongs to an active plugin
    $deactivated_plugin = null;
    $plugin_file = boteraser_detect_plugin_from_path($rel_path);
    if ($plugin_file) {
        $active_plugins = get_option('active_plugins', []);
        if (in_array($plugin_file, $active_plugins, true)) {
            if (!function_exists('deactivate_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            deactivate_plugins($plugin_file);
            $deactivated_plugin = $plugin_file;
        }
    }

    require_once BOT_ERASER_PLUGIN_DIR . 'includes/quarantine.php';
    $severity = isset($_POST['severity']) ? sanitize_text_field($_POST['severity']) : '';

    $result = boteraser_quarantine_move($full_path, $rel_path, $severity, $deactivated_plugin);
    if (is_wp_error($result)) {
        if ($deactivated_plugin) {
            if (!function_exists('activate_plugin')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            activate_plugin($deactivated_plugin);
        }
        wp_send_json_error($result->get_error_message());
    }

    wp_send_json_success(array(
        'message'            => 'File moved to quarantine: ' . $result['stored_name'],
        'deactivated_plugin' => $deactivated_plugin,
    ));
}
add_action('wp_ajax_boteraser_quarantine_file', 'boteraser_ajax_quarantine_file');

/**
 * Get diff data — original vs current file content
 */
function boteraser_ajax_get_file_diff() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $rel_path = sanitize_text_field($_POST['file'] ?? '');
    if (!$rel_path) wp_send_json_error('Invalid path');

    require_once __DIR__ . '/file-restorer.php';

    $data = boteraser_restorer_get_diff_data($rel_path);
    if (is_wp_error($data)) {
        wp_send_json_error($data->get_error_message());
    }

    // Limit file size sent to browser (max 512 KB per side)
    $max = 524288;
    if (strlen($data['original']) > $max) {
        $data['original'] = substr($data['original'], 0, $max) . "\n\n[...truncated — file exceeds 512 KB...]";
    }
    if (strlen($data['current']) > $max) {
        $data['current'] = substr($data['current'], 0, $max) . "\n\n[...truncated — file exceeds 512 KB...]";
    }

    wp_send_json_success($data);
}
add_action('wp_ajax_boteraser_get_file_diff', 'boteraser_ajax_get_file_diff');

/**
 * Restore file from WordPress.org original
 */
function boteraser_ajax_restore_file() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $rel_path = sanitize_text_field($_POST['file'] ?? '');
    if (!$rel_path) wp_send_json_error('Invalid path');

    require_once __DIR__ . '/file-restorer.php';

    $result = boteraser_restorer_restore($rel_path);
    if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
    }

    wp_send_json_success(array(
        'message'       => 'File restored successfully from ' . $result['restored_from'],
        'backup_path'   => $result['backup_path'],
        'restored_from' => $result['restored_from'],
    ));
}
add_action('wp_ajax_boteraser_restore_file', 'boteraser_ajax_restore_file');

/**
 * Delete file permanently
 */
function boteraser_ajax_delete_file() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $rel_path = sanitize_text_field($_POST['file'] ?? '');
    if (!$rel_path) wp_send_json_error('Invalid path');

    $full_path = ABSPATH . ltrim($rel_path, '/');

    if (strpos(realpath($full_path), realpath(ABSPATH)) !== 0) {
        wp_send_json_error('Path traversal detected.');
    }

    if (!file_exists($full_path)) {
        wp_send_json_error('File does not exist.');
    }

    if (unlink($full_path)) {
        wp_send_json_success(array('message' => 'File deleted: ' . basename($full_path)));
    } else {
        wp_send_json_error('Could not delete file.');
    }
}
add_action('wp_ajax_boteraser_delete_file', 'boteraser_ajax_delete_file');
