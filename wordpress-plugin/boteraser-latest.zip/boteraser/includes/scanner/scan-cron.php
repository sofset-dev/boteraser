<?php
/**
 * WP-Cron Backdoor Detection — definitive signals only.
 *
 * Zero-FP policy: we flag a cron entry only when the HOOK NAME itself
 * looks unambiguously malicious. Matching against event $args is
 * intentionally NOT done — many legitimate plugins pass URLs, IDs,
 * and serialized arrays as cron arguments, and matching tokens like
 * "http://" or "$_POST" inside an args blob produces false positives.
 *
 * Real malware cron entries almost always either:
 *   1. name the hook with eval / base64 / shell / system / passthru, or
 *   2. use a long hex/random string as the hook name (because the
 *      malware was auto-generated)
 *
 * Both are unambiguous; both are what Wordfence/Sucuri flag.
 */

if (!defined('ABSPATH')) exit;

function boteraser_scan_cron_jobs() {
    $findings = array();

    if (!function_exists('_get_cron_array')) return $findings;
    $cron = _get_cron_array();
    if (!is_array($cron)) return $findings;

    // Hook names that contain any of these tokens are almost always
    // backdoors. No legitimate plugin / theme registers a cron hook
    // with these substrings in the name.
    $malicious_tokens = array(
        'eval', 'base64', 'shell_exec', 'shellexec',
        'passthru', 'proc_open', 'system_exec',
    );

    foreach ($cron as $timestamp => $hooks) {
        if (!is_array($hooks)) continue;

        foreach ($hooks as $hook => $events) {
            $hook_lc = strtolower($hook);
            $is_malicious_name = false;

            foreach ($malicious_tokens as $tok) {
                if (strpos($hook_lc, $tok) !== false) {
                    $is_malicious_name = true;
                    break;
                }
            }

            // Long hex-only hook names (16+ hex chars) — auto-generated
            // malware signature. Real plugin hooks use human-readable
            // names with underscores/slashes.
            if (!$is_malicious_name && preg_match('/^[a-f0-9]{16,}$/i', $hook)) {
                $is_malicious_name = true;
            }

            if ($is_malicious_name) {
                $findings[] = array(
                    'file'     => 'WP-Cron',
                    'findings' => array(array(
                        'type'    => 'cron_suspicious_hook',
                        'label'   => 'Suspicious WP-Cron hook',
                        'score'   => 90,
                        'details' => "Hook: {$hook}, next run: " . date('Y-m-d H:i', (int) $timestamp),
                    )),
                    'ext'  => 'cron',
                    'size' => 0,
                );
            }
        }
    }

    return $findings;
}
