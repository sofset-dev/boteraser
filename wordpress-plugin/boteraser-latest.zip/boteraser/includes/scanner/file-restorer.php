<?php
/**
 * File Restorer — fetch original file from WordPress.org and replace compromised copy.
 *
 * Supports: WordPress core, plugins, and themes hosted on WordPress.org.
 * Always creates a timestamped backup before overwriting.
 */

if (!defined('ABSPATH')) exit;

/**
 * Resolve which "source" a given relative file path belongs to.
 *
 * Returns array with keys:
 *   type         => 'core' | 'plugin' | 'theme'
 *   slug         => plugin/theme slug (empty for core)
 *   rel_in_pkg   => path inside the ZIP (e.g. "includes/functions.php")
 *   wp_version   => WP version string (core only)
 *
 * Returns null when the file cannot be resolved to a known source.
 */
function boteraser_restorer_resolve_source($rel_path) {
    $rel_path = ltrim($rel_path, '/');

    // ── Core ──────────────────────────────────────────────────────────────────
    // Core files live in ABSPATH but outside wp-content.
    // rel_path examples: "wp-includes/functions.php", "wp-login.php",
    //                    "wp-admin/edit.php"
    $core_prefixes = array('wp-includes/', 'wp-admin/');
    $is_core_root  = !preg_match('#^wp-content/#', $rel_path) && !strpos($rel_path, '/');

    foreach ($core_prefixes as $pfx) {
        if (strpos($rel_path, $pfx) === 0) {
            return array(
                'type'       => 'core',
                'slug'       => '',
                'rel_in_pkg' => $rel_path,
                'wp_version' => get_bloginfo('version'),
            );
        }
    }
    // Single root-level core files (wp-login.php, wp-cron.php, xmlrpc.php …)
    if ($is_core_root && substr($rel_path, -4) === '.php') {
        return array(
            'type'       => 'core',
            'slug'       => '',
            'rel_in_pkg' => $rel_path,
            'wp_version' => get_bloginfo('version'),
        );
    }

    // ── Plugin ────────────────────────────────────────────────────────────────
    // rel_path: "wp-content/plugins/akismet/akismet.php"
    if (preg_match('#^wp-content/plugins/([^/]+)/(.+)$#', $rel_path, $m)) {
        return array(
            'type'       => 'plugin',
            'slug'       => $m[1],
            'rel_in_pkg' => $m[2],
            'wp_version' => '',
        );
    }

    // ── Theme ─────────────────────────────────────────────────────────────────
    // rel_path: "wp-content/themes/twentytwentythree/functions.php"
    if (preg_match('#^wp-content/themes/([^/]+)/(.+)$#', $rel_path, $m)) {
        return array(
            'type'       => 'theme',
            'slug'       => $m[1],
            'rel_in_pkg' => $m[2],
            'wp_version' => '',
        );
    }

    return null;
}

/**
 * Fetch the original content of a file from WordPress.org.
 *
 * @param array $source  Return value of boteraser_restorer_resolve_source().
 * @return string|WP_Error  File content on success, WP_Error on failure.
 */
function boteraser_restorer_fetch_original($source) {
    if ($source['type'] === 'core') {
        return boteraser_restorer_fetch_core_file($source['rel_in_pkg'], $source['wp_version']);
    }

    require_once __DIR__ . '/scan-integrity.php';

    if ($source['type'] === 'plugin') {
        $info = boteraser_integrity_plugin_info($source['slug']);
    } else {
        $info = boteraser_integrity_theme_info($source['slug']);
    }

    if (!$info) {
        return new WP_Error('not_on_wporg',
            sprintf('"%s" is not available on WordPress.org — cannot fetch original.', $source['slug'])
        );
    }

    return boteraser_restorer_fetch_from_zip($info['download_link'], $source['slug'], $source['rel_in_pkg']);
}

/**
 * Download a single core file from WordPress.org download server.
 */
function boteraser_restorer_fetch_core_file($rel_path, $wp_version) {
    // Use the official checksums endpoint first to verify the file is a known
    // core file, then build the download URL.
    $checksums_url = 'https://api.wordpress.org/core/checksums/1.0/?version=' . rawurlencode($wp_version) . '&locale=en_US';
    $resp = wp_remote_get($checksums_url, array('timeout' => 15));

    if (is_wp_error($resp)) return $resp;
    if (wp_remote_retrieve_response_code($resp) !== 200) {
        return new WP_Error('api_error', 'WordPress.org checksums API returned non-200.');
    }

    $body = json_decode(wp_remote_retrieve_body($resp), true);
    $checksums = $body['checksums'] ?? null;

    if (!is_array($checksums)) {
        return new WP_Error('parse_error', 'Could not parse WordPress.org checksums response.');
    }

    if (!isset($checksums[$rel_path])) {
        return new WP_Error('not_core_file', sprintf('"%s" is not a known WordPress core file.', $rel_path));
    }

    // Build the direct download URL for the core ZIP and extract the single file.
    $zip_url = 'https://downloads.wordpress.org/release/wordpress-' . rawurlencode($wp_version) . '-no-content.zip';
    $content = boteraser_restorer_fetch_from_zip($zip_url, 'wordpress', $rel_path, 'wordpress/');

    if (!is_wp_error($content)) {
        return $content;
    }

    // Fallback: full core ZIP
    $zip_url_full = 'https://downloads.wordpress.org/release/wordpress-' . rawurlencode($wp_version) . '.zip';
    return boteraser_restorer_fetch_from_zip($zip_url_full, 'wordpress', $rel_path, 'wordpress/');
}

/**
 * Download a ZIP and extract one file's content from it.
 *
 * @param string $zip_url     Full URL to the ZIP archive.
 * @param string $slug        Top-level folder name inside the ZIP.
 * @param string $rel_in_pkg  Path to the file inside the ZIP (without slug prefix).
 * @param string $prefix_override  Optional override for the ZIP prefix (e.g. "wordpress/").
 * @return string|WP_Error
 */
function boteraser_restorer_fetch_from_zip($zip_url, $slug, $rel_in_pkg, $prefix_override = '') {
    if (!class_exists('ZipArchive')) {
        return new WP_Error('no_zip', 'ZipArchive PHP extension is not available.');
    }

    require_once __DIR__ . '/scan-integrity.php';
    $cache_dir = boteraser_integrity_cache_dir();
    $tmp_zip   = $cache_dir . '/restore-' . $slug . '-' . wp_generate_password(8, false) . '.zip';

    $resp = wp_remote_get($zip_url, array(
        'timeout'  => 60,
        'stream'   => true,
        'filename' => $tmp_zip,
    ));

    if (is_wp_error($resp)) {
        @unlink($tmp_zip);
        return $resp;
    }
    if (wp_remote_retrieve_response_code($resp) !== 200) {
        @unlink($tmp_zip);
        return new WP_Error('download_failed', 'Failed to download ZIP from WordPress.org.');
    }

    $zip = new ZipArchive();
    if ($zip->open($tmp_zip) !== true) {
        @unlink($tmp_zip);
        return new WP_Error('zip_open_failed', 'Could not open downloaded ZIP.');
    }

    // Try both with slug prefix and without.
    $prefix = $prefix_override !== '' ? $prefix_override : ($slug . '/');
    $candidates = array(
        $prefix . $rel_in_pkg,
        $rel_in_pkg,
    );

    $content = false;
    foreach ($candidates as $path_in_zip) {
        $content = $zip->getFromName($path_in_zip);
        if ($content !== false) break;
    }

    $zip->close();
    @unlink($tmp_zip);

    if ($content === false) {
        return new WP_Error('file_not_in_zip',
            sprintf('File "%s" not found inside the downloaded ZIP.', $rel_in_pkg)
        );
    }

    return $content;
}

/**
 * Back up a file to wp-content/boteraser-backups/YYYY-MM-DD/.
 *
 * @param string $full_path  Absolute path to the file.
 * @param string $rel_path   Relative path (used to build backup filename).
 * @return string|WP_Error   Path to the backup file on success.
 */
function boteraser_restorer_backup($full_path, $rel_path) {
    $backup_base = WP_CONTENT_DIR . '/boteraser-backups/' . gmdate('Y-m-d');
    if (!wp_mkdir_p($backup_base)) {
        return new WP_Error('mkdir_failed', 'Could not create backup directory.');
    }

    // Protect backup dir from direct web access.
    $htaccess = dirname($backup_base) . '/.htaccess';
    if (!file_exists($htaccess)) {
        @file_put_contents($htaccess, "Order allow,deny\nDeny from all\n");
    }
    $index = dirname($backup_base) . '/index.php';
    if (!file_exists($index)) {
        @file_put_contents($index, "<?php // silence\n");
    }

    $safe_name  = str_replace(array('/', '\\', ':'), '_', ltrim($rel_path, '/'));
    $backup_path = $backup_base . '/' . $safe_name . '.' . gmdate('His') . '.bak';

    if (!@copy($full_path, $backup_path)) {
        return new WP_Error('backup_failed', 'Could not write backup file.');
    }

    return $backup_path;
}

/**
 * Replace a compromised file with the original from WordPress.org.
 *
 * Steps:
 *   1. Validate the path is inside ABSPATH.
 *   2. Resolve to a known source (core / plugin / theme).
 *   3. Fetch original content.
 *   4. Back up the current file.
 *   5. Write the original content.
 *
 * @param string $rel_path  Path relative to ABSPATH (e.g. "wp-content/plugins/slug/file.php").
 * @return array|WP_Error   Array with 'backup_path' and 'restored_from' on success.
 */
function boteraser_restorer_restore($rel_path) {
    $rel_path  = ltrim(sanitize_text_field($rel_path), '/');
    $full_path = ABSPATH . $rel_path;
    $real_path = realpath($full_path);

    // Path traversal guard.
    if (!$real_path || strpos($real_path, realpath(ABSPATH)) !== 0) {
        return new WP_Error('path_traversal', 'Invalid file path.');
    }

    if (!is_file($real_path)) {
        return new WP_Error('not_found', 'File does not exist: ' . $rel_path);
    }

    $source = boteraser_restorer_resolve_source($rel_path);
    if (!$source) {
        return new WP_Error('unresolvable',
            'Cannot determine source for this file — it may be a custom/premium file not on WordPress.org.'
        );
    }

    $original = boteraser_restorer_fetch_original($source);
    if (is_wp_error($original)) {
        return $original;
    }

    $backup = boteraser_restorer_backup($real_path, $rel_path);
    if (is_wp_error($backup)) {
        return $backup;
    }

    // Write original content.
    $written = @file_put_contents($real_path, $original);
    if ($written === false) {
        return new WP_Error('write_failed', 'Could not write restored file. Check file permissions.');
    }

    // Log the action.
    $log_msg = sprintf(
        '[%s] Restored: %s (type=%s, slug=%s) — backup at %s — user=%s',
        gmdate('Y-m-d H:i:s'),
        $rel_path,
        $source['type'],
        $source['slug'] ?: 'core',
        $backup,
        wp_get_current_user()->user_login
    );
    $log_file = WP_CONTENT_DIR . '/boteraser-backups/restore.log';
    @file_put_contents($log_file, $log_msg . PHP_EOL, FILE_APPEND | LOCK_EX);

    return array(
        'backup_path'    => $backup,
        'restored_from'  => $source['type'] === 'core'
            ? 'WordPress core v' . $source['wp_version']
            : 'WordPress.org (' . $source['type'] . ': ' . $source['slug'] . ')',
    );
}

/**
 * Return the content of the original (clean) file and the current (possibly
 * compromised) file for side-by-side display.
 *
 * @param string $rel_path  Path relative to ABSPATH.
 * @return array|WP_Error   Array with 'original', 'current', 'source_label', 'file_name'.
 */
function boteraser_restorer_get_diff_data($rel_path) {
    $rel_path  = ltrim(sanitize_text_field($rel_path), '/');
    $full_path = ABSPATH . $rel_path;
    $real_path = realpath($full_path);

    if (!$real_path || strpos($real_path, realpath(ABSPATH)) !== 0) {
        return new WP_Error('path_traversal', 'Invalid file path.');
    }

    if (!is_file($real_path)) {
        return new WP_Error('not_found', 'File does not exist.');
    }

    $source = boteraser_restorer_resolve_source($rel_path);
    if (!$source) {
        return new WP_Error('unresolvable', 'File source cannot be determined.');
    }

    $original = boteraser_restorer_fetch_original($source);
    if (is_wp_error($original)) {
        return $original;
    }

    $current = @file_get_contents($real_path);
    if ($current === false) {
        return new WP_Error('read_failed', 'Cannot read current file.');
    }

    if ($source['type'] === 'core') {
        $source_label = 'WordPress core v' . $source['wp_version'];
    } else {
        $source_label = ucfirst($source['type']) . ': ' . $source['slug'];
    }

    return array(
        'original'     => $original,
        'current'      => $current,
        'source_label' => $source_label,
        'file_name'    => basename($rel_path),
        'rel_path'     => $rel_path,
        'source_type'  => $source['type'],
    );
}
