<?php
/**
 * Database Scan — definitive backdoor detection only.
 *
 * Zero-false-positive policy: every check below targets a state that
 * is unambiguously malicious. Generic patterns (base64 strings, script
 * tags, eval() in option values) are NOT used here — legitimate plugins
 * routinely store such content (license keys, cached HTML, settings
 * imports). They belong behind the opt-in "Deep Code Scan" tier.
 */

if (!defined('ABSPATH')) exit;

function boteraser_scan_database() {
    global $wpdb;
    $findings = array();

    // --- Check 1: Suspicious admin user accounts ---
    //
    // The classic post-compromise persistence technique: attacker
    // creates a hidden admin user with a short username and recent
    // registration, often with display_name matching user_login so
    // the account blends into the user list.
    //
    // Conservative criteria — must satisfy ALL of:
    //   - has administrator capability
    //   - registered within the last 7 days
    //   - has zero published posts and zero session tokens (never
    //     actually logged in via the WP UI)
    //   - username < 4 chars OR matches malware-typical patterns
    //
    // A real new admin (legit hire) will almost always log in within
    // 7 days, generating session tokens.
    $cap_key = $wpdb->prefix . 'capabilities';
    $admin_users = $wpdb->get_results($wpdb->prepare(
        "SELECT u.ID, u.user_login, u.user_email, u.user_registered
         FROM {$wpdb->users} u
         INNER JOIN {$wpdb->usermeta} m
                 ON m.user_id = u.ID AND m.meta_key = %s
         WHERE m.meta_value LIKE %s
           AND u.user_registered > DATE_SUB(NOW(), INTERVAL 7 DAY)",
        $cap_key,
        '%administrator%'
    ));

    if (is_array($admin_users)) {
        foreach ($admin_users as $u) {
            $sessions = get_user_meta($u->ID, 'session_tokens', true);
            $has_session = !empty($sessions);
            $post_count = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts}
                 WHERE post_author = %d AND post_status = 'publish'",
                $u->ID
            ));

            $login = $u->user_login;
            $is_short  = (strlen($login) < 4);
            $is_typical_malware_name = (bool) preg_match(
                '/^(adm|wpadm|wp_user|backup|root|test|user[0-9]+|wpsupport|support[0-9]+)$/i',
                $login
            );

            if (!$has_session && $post_count === 0 && ($is_short || $is_typical_malware_name)) {
                $findings[] = array(
                    'file'     => 'wp_users: ' . $login,
                    'findings' => array(array(
                        'type'    => 'db_suspicious_admin',
                        'label'   => 'Recently created administrator with no activity',
                        'score'   => 90,
                        'details' => "Login: {$login}, registered: {$u->user_registered}, no logins, no posts",
                    )),
                    'ext'  => 'db',
                    'size' => 0,
                );
            }
        }
    }

    // --- Check 2: Mismatched siteurl / home option ---
    //
    // Attackers frequently change siteurl/home to redirect SEO traffic
    // to malware domains. We flag only when the option does not match
    // the current request host AND points at a different domain.
    //
    // Skipped during WP-CLI / cron / when SERVER_NAME is missing — we
    // can't reliably detect "current" host without a real request.
    $server_name = isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : '';
    if ($server_name && !defined('WP_CLI')) {
        $current_host = strtolower(preg_replace('/^www\./', '', $server_name));

        foreach (array('siteurl', 'home') as $opt) {
            $val = get_option($opt);
            if (!$val) continue;
            $host = parse_url($val, PHP_URL_HOST);
            if (!$host) continue;
            $host = strtolower(preg_replace('/^www\./', '', $host));
            if ($host !== $current_host && $host !== 'localhost') {
                // Only flag if the host looks unrelated (different TLD
                // or completely different domain). This protects sites
                // with reverse-proxy setups where SERVER_NAME differs.
                $cur_parts = explode('.', $current_host);
                $opt_parts = explode('.', $host);
                $cur_root  = count($cur_parts) >= 2 ? $cur_parts[count($cur_parts)-2] : $current_host;
                $opt_root  = count($opt_parts) >= 2 ? $opt_parts[count($opt_parts)-2] : $host;

                if ($cur_root !== $opt_root) {
                    $findings[] = array(
                        'file'     => 'wp_options: ' . $opt,
                        'findings' => array(array(
                            'type'    => 'db_url_mismatch',
                            'label'   => 'Site URL points to a different domain than the current request',
                            'score'   => 85,
                            'details' => "{$opt} = {$val}, request host = {$server_name}",
                        )),
                        'ext'  => 'db',
                        'size' => 0,
                    );
                }
            }
        }
    }

    return $findings;
}
