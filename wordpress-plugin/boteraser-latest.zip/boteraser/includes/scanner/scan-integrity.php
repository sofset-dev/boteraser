<?php
/**
 * WordPress.org Plugin & Theme Integrity Verification
 *
 * Free-tier integrity scanning that mirrors how Wordfence Free and
 * MalCare Free operate: download the upstream ZIP from WordPress.org
 * for any installed plugin/theme that lives in the public repository,
 * compare every file's hash against the upstream copy, and surface
 * any mismatch as a finding.
 *
 * Pattern matching (eval, base64_decode, shell_exec, etc.) is NOT
 * what the free tiers of established scanners use — those signatures
 * sit behind paid cloud APIs. The free tier is hash-based: signal is
 * "this file does not match the upstream copy", which produces zero
 * false positives on legitimate, unmodified plugin/theme code.
 */

if (!defined('ABSPATH')) exit;

if (!defined('BOTERASER_INTEGRITY_BATCH')) {
    define('BOTERASER_INTEGRITY_BATCH', 25); // files per AJAX chunk
}

if (!defined('BOTERASER_ZIP_CACHE_TTL')) {
    define('BOTERASER_ZIP_CACHE_TTL', DAY_IN_SECONDS);
}

/**
 * Workdir for downloaded reference ZIPs and extracted hash maps.
 */
function boteraser_integrity_cache_dir() {
    $upload = wp_upload_dir();
    $dir = trailingslashit($upload['basedir']) . 'boteraser/scan/integrity-cache';
    if (!is_dir($dir)) {
        wp_mkdir_p($dir);
        @file_put_contents($dir . '/.htaccess', "Order allow,deny\nDeny from all\n");
        @file_put_contents($dir . '/index.php', "<?php // silence\n");
    }
    return $dir;
}

/**
 * Read the Plugin slug + version from a plugin's main file header.
 * Returns null if header cannot be parsed.
 */
function boteraser_integrity_plugin_meta($plugin_dir) {
    if (!is_dir($plugin_dir)) return null;
    $slug = basename($plugin_dir);

    // Find a candidate main PHP file with a Plugin Name header.
    $candidates = array($plugin_dir . '/' . $slug . '.php');
    $iter = @scandir($plugin_dir);
    if (is_array($iter)) {
        foreach ($iter as $entry) {
            if (substr($entry, -4) === '.php') {
                $candidates[] = $plugin_dir . '/' . $entry;
            }
        }
    }

    foreach (array_unique($candidates) as $file) {
        if (!is_file($file)) continue;
        $head = @file_get_contents($file, false, null, 0, 8192);
        if ($head === false) continue;
        if (!preg_match('/^[ \t\/*#@]*Plugin Name:\s*(.+)$/mi', $head)) continue;

        $version = '';
        if (preg_match('/^[ \t\/*#@]*Version:\s*([^\r\n]+)/mi', $head, $m)) {
            $version = trim($m[1]);
        }
        return array(
            'slug'    => $slug,
            'version' => $version,
            'file'    => $file,
        );
    }
    return null;
}

/**
 * Read style.css for theme metadata. Returns null if missing.
 */
function boteraser_integrity_theme_meta($theme_dir) {
    $style = $theme_dir . '/style.css';
    if (!is_file($style)) return null;
    $head = @file_get_contents($style, false, null, 0, 8192);
    if ($head === false) return null;

    $slug = basename($theme_dir);
    $version = '';
    if (preg_match('/^[ \t\/*#@]*Version:\s*([^\r\n]+)/mi', $head, $m)) {
        $version = trim($m[1]);
    }
    if (!preg_match('/^[ \t\/*#@]*Theme Name:\s*(.+)$/mi', $head)) {
        return null;
    }
    return array(
        'slug'    => $slug,
        'version' => $version,
    );
}

/**
 * Probe the WordPress.org plugins API for a slug + specific version.
 *
 * We always request the exact locally-installed version so that
 * boteraser_integrity_build_hashmap() downloads the matching ZIP and
 * computes hashes against the right release — not the latest one. This
 * eliminates the false-positive flood that occurs immediately after a
 * plugin update when the installed files differ from the previously-
 * cached "latest" hashmap.
 *
 * @param string $slug    Plugin slug (directory name).
 * @param string $version Locally installed version string (from plugin header).
 * @return array|null     {slug, version, download_link} or null if not on .org.
 */
function boteraser_integrity_plugin_info($slug, $version = '') {
    $cache_key = 'boteraser_plugin_info_' . md5($slug . '|' . $version);
    $cached = get_transient($cache_key);
    if ($cached !== false) {
        return $cached === 'NOT_FOUND' ? null : $cached;
    }

    $url = 'https://api.wordpress.org/plugins/info/1.2/?action=plugin_information&slug=' . rawurlencode($slug);
    $response = wp_remote_get($url, array('timeout' => 15));

    if (is_wp_error($response)) {
        set_transient($cache_key, 'NOT_FOUND', HOUR_IN_SECONDS);
        return null;
    }

    $code = wp_remote_retrieve_response_code($response);
    if ($code !== 200) {
        set_transient($cache_key, 'NOT_FOUND', HOUR_IN_SECONDS);
        return null;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    if (!is_array($data) || empty($data['download_link']) || empty($data['version'])) {
        set_transient($cache_key, 'NOT_FOUND', HOUR_IN_SECONDS);
        return null;
    }

    // If the caller specified a version and the API reports a different
    // latest version, try to construct the version-specific download URL.
    // WordPress.org stores every release at a predictable path:
    //   https://downloads.wordpress.org/plugin/<slug>.<version>.zip
    // This avoids comparing locally-installed v3.x files against a
    // hashmap built from the v4.x ZIP (or vice-versa).
    $api_version   = $data['version'];
    $target_version = ($version !== '' && $version !== $api_version) ? $version : $api_version;

    if ($target_version === $api_version) {
        $download_link = $data['download_link'];
    } else {
        // Version-specific URL. WordPress.org uses this scheme for all
        // plugins in the public repository; premium plugins that do NOT
        // live on .org will have returned null from the API already.
        $download_link = 'https://downloads.wordpress.org/plugin/'
            . rawurlencode($slug) . '.' . rawurlencode($target_version) . '.zip';
    }

    $info = array(
        'slug'          => $slug,
        'version'       => $target_version,
        'download_link' => $download_link,
    );
    set_transient($cache_key, $info, BOTERASER_ZIP_CACHE_TTL);
    return $info;
}

/**
 * Probe the WordPress.org themes API for a slug + specific version.
 *
 * Same version-pinning rationale as boteraser_integrity_plugin_info().
 *
 * @param string $slug    Theme slug (directory name).
 * @param string $version Locally installed version string.
 * @return array|null     {slug, version, download_link} or null if not on .org.
 */
function boteraser_integrity_theme_info($slug, $version = '') {
    $cache_key = 'boteraser_theme_info_' . md5($slug . '|' . $version);
    $cached = get_transient($cache_key);
    if ($cached !== false) {
        return $cached === 'NOT_FOUND' ? null : $cached;
    }

    $url = 'https://api.wordpress.org/themes/info/1.2/?action=theme_information&slug=' . rawurlencode($slug);
    $response = wp_remote_get($url, array('timeout' => 15));

    if (is_wp_error($response)) {
        set_transient($cache_key, 'NOT_FOUND', HOUR_IN_SECONDS);
        return null;
    }

    $code = wp_remote_retrieve_response_code($response);
    if ($code !== 200) {
        set_transient($cache_key, 'NOT_FOUND', HOUR_IN_SECONDS);
        return null;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    if (!is_array($data) || empty($data['download_link']) || empty($data['version'])) {
        set_transient($cache_key, 'NOT_FOUND', HOUR_IN_SECONDS);
        return null;
    }

    $api_version    = $data['version'];
    $target_version = ($version !== '' && $version !== $api_version) ? $version : $api_version;

    if ($target_version === $api_version) {
        $download_link = $data['download_link'];
    } else {
        $download_link = 'https://downloads.wordpress.org/theme/'
            . rawurlencode($slug) . '.' . rawurlencode($target_version) . '.zip';
    }

    $info = array(
        'slug'          => $slug,
        'version'       => $target_version,
        'download_link' => $download_link,
    );
    set_transient($cache_key, $info, BOTERASER_ZIP_CACHE_TTL);
    return $info;
}

/**
 * Build a hash map of every file inside a downloaded ZIP, keyed by
 * the path inside the archive (with the top-level slug folder
 * stripped). Result is cached on disk so subsequent scans skip the
 * network round-trip.
 */
function boteraser_integrity_build_hashmap($info, $kind /* 'plugin' | 'theme' */) {
    $cache_dir = boteraser_integrity_cache_dir();
    $cache_file = $cache_dir . '/' . $kind . '-' . $info['slug'] . '-' . md5($info['version']) . '.json';

    if (file_exists($cache_file)) {
        $cached = @file_get_contents($cache_file);
        if ($cached !== false) {
            $decoded = json_decode($cached, true);
            if (is_array($decoded)) return $decoded;
        }
    }

    // Download the ZIP to a temp file
    $tmp_zip = $cache_dir . '/tmp-' . $info['slug'] . '-' . wp_generate_password(8, false) . '.zip';
    $response = wp_remote_get($info['download_link'], array(
        'timeout'  => 30,
        'stream'   => true,
        'filename' => $tmp_zip,
    ));

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        @unlink($tmp_zip);
        return null;
    }

    if (!file_exists($tmp_zip) || filesize($tmp_zip) < 100) {
        @unlink($tmp_zip);
        return null;
    }

    if (!class_exists('ZipArchive')) {
        @unlink($tmp_zip);
        return null;
    }

    $zip = new ZipArchive();
    if ($zip->open($tmp_zip) !== true) {
        @unlink($tmp_zip);
        return null;
    }

    $hashmap = array();
    $slug = $info['slug'];
    $prefix = $slug . '/';
    $prefix_len = strlen($prefix);

    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        if (!$stat) continue;
        $name = $stat['name'];
        // Skip directories
        if (substr($name, -1) === '/') continue;
        // Strip the top-level slug folder
        if (strpos($name, $prefix) === 0) {
            $rel = substr($name, $prefix_len);
        } else {
            $rel = $name;
        }
        // Skip junk
        if ($rel === '' || strpos($rel, '..') !== false) continue;

        $contents = $zip->getFromIndex($i);
        if ($contents === false) continue;
        $hashmap[$rel] = md5($contents);
    }

    $zip->close();
    @unlink($tmp_zip);

    @file_put_contents($cache_file, wp_json_encode($hashmap));
    return $hashmap;
}

/**
 * Filenames that are almost always malware. Drawn from public webshell
 * collections (Wordfence threat feed samples, Sucuri research, the
 * "TennC/webshell" repository on GitHub). Match is case-insensitive
 * basename only — never matches plugin slug or directory.
 *
 * Conservative list: filenames removed if they appear in any popular
 * legitimate plugin (e.g. "command.php" is used by Elementor's WP-CLI
 * commands, "wp-content.php" appears in Elementor's import-export).
 */
function boteraser_integrity_known_malware_basenames() {
    return array(
        // Classic webshells (very specific names — no legitimate use)
        'wso.php', 'wso2.php', 'wso25.php', 'wsoyanz.php',
        'c99.php', 'c100.php', 'c999.php',
        'r57.php', 'r58.php',
        'b374k.php', 'b374k-3.2.3.php',
        'gel4y.php', 'gel4y_mini.php',
        'mini-shell.php', 'p0wny.php', 'p0wny-shell.php',
        'phpspy.php',
        'wp-conflg.php', 'wp-includ3s.php', 'wp-confg.php',
        'wp-load1.php', 'wp-cron1.php',
        'alfa.php', 'alfashell.php', 'alfa-shell.php',
        'foxshell.php',
        'indoxploit.php',
    );
}

/**
 * Suspicious filename pattern matchers (regex) for filenames that
 * are not in the static blacklist but exhibit malware-typical naming.
 *
 * These are deliberately conservative — false positives here erode
 * user trust faster than false negatives.
 */
function boteraser_integrity_filename_is_suspicious($basename) {
    // Double extension: anything.php.jpg / .php.gif / .php.png / .php.suspected
    // This is one of the most reliable malware naming signals; a real
    // .php file should never have a second image/text extension.
    if (preg_match('/\.php\.(jpg|jpeg|png|gif|ico|svg|txt|bak|suspected|hide|hidden)$/i', $basename)) {
        return 'Double extension (PHP disguised as another type)';
    }

    // Hex-only filenames of suspicious length (16-64 hex chars).
    // No legitimate WordPress plugin names files with bare hex IDs.
    if (preg_match('/^[a-f0-9]{16,64}\.php$/i', $basename)) {
        return 'Hex-encoded PHP filename';
    }

    return null;
}

/**
 * Check a single file path against malware naming heuristics.
 * Returns array(label, score) or null.
 */
function boteraser_integrity_check_filename($rel_path) {
    $basename = strtolower(basename($rel_path));
    $blacklist = array_flip(array_map('strtolower', boteraser_integrity_known_malware_basenames()));

    if (isset($blacklist[$basename])) {
        return array(
            'type'  => 'malware_filename',
            'label' => 'Known malware filename: ' . $basename,
            'score' => 95,
            'details' => $rel_path,
        );
    }

    $reason = boteraser_integrity_filename_is_suspicious(basename($rel_path));
    if ($reason !== null) {
        return array(
            'type'  => 'suspicious_filename',
            'label' => $reason,
            'score' => 80,
            'details' => $rel_path,
        );
    }

    return null;
}

/**
 * Enumerate plugins to be integrity-checked. Returns an array of
 * { slug, plugin_dir_abs, plugin_dir_rel } records — one per plugin
 * directory. Plugins not on WordPress.org are skipped here (the
 * caller will then mark them as "unverified").
 */
function boteraser_integrity_enumerate_plugins() {
    $plugins_root = WP_PLUGIN_DIR;
    if (!is_dir($plugins_root)) return array();

    $records = array();
    $dh = @opendir($plugins_root);
    if (!$dh) return $records;

    while (($entry = readdir($dh)) !== false) {
        if ($entry === '.' || $entry === '..') continue;
        $full = $plugins_root . '/' . $entry;
        if (!is_dir($full)) continue;

        $meta = boteraser_integrity_plugin_meta($full);
        if (!$meta) continue;

        $records[] = array(
            'slug'    => $meta['slug'],
            'version' => $meta['version'],
            'abs'     => $full,
            'rel'     => 'wp-content/plugins/' . $meta['slug'],
        );
    }
    closedir($dh);
    return $records;
}

/**
 * Same shape as plugins, for themes.
 */
function boteraser_integrity_enumerate_themes() {
    $themes_root = WP_CONTENT_DIR . '/themes';
    if (!is_dir($themes_root)) return array();

    $records = array();
    $dh = @opendir($themes_root);
    if (!$dh) return $records;

    while (($entry = readdir($dh)) !== false) {
        if ($entry === '.' || $entry === '..') continue;
        $full = $themes_root . '/' . $entry;
        if (!is_dir($full)) continue;

        $meta = boteraser_integrity_theme_meta($full);
        if (!$meta) continue;

        $records[] = array(
            'slug'    => $meta['slug'],
            'version' => $meta['version'],
            'abs'     => $full,
            'rel'     => 'wp-content/themes/' . $meta['slug'],
        );
    }
    closedir($dh);
    return $records;
}

/**
 * Returns true when a path inside a plugin/theme package is a known
 * runtime-generated file that will never appear in the upstream ZIP.
 *
 * Popular plugins write generated CSS, font cache, and data files at
 * runtime into their own directory. These are not malware — flagging
 * them as "unknown_file" produces false positives after every update
 * because the upstream ZIP for that version naturally doesn't include
 * dynamically generated content.
 *
 * Match is done against the relative-within-package path (e.g.
 * "css/custom-9abc1234.min.css") so the check is both precise and
 * plugin-agnostic.
 *
 * @param string $rel_in_pkg  Path relative to the plugin/theme root.
 * @param string $slug        Plugin/theme slug (for slug-specific patterns).
 * @return bool
 */
function boteraser_integrity_is_runtime_generated($rel_in_pkg, $slug) {
    // Normalize to forward-slash for consistent matching.
    $p = str_replace('\\', '/', $rel_in_pkg);

    // Generic: known runtime-generated subdirectory names. Plugins commonly
    // write cache, generated assets, logs, and feature-specific files into
    // these directories at runtime — they are never present in the upstream
    // ZIP and are not a meaningful malware surface (attackers target the
    // plugin root or wp-content/uploads, not internal cache dirs).
    static $runtime_dirs = null;
    if ($runtime_dirs === null) {
        $runtime_dirs = array_flip(array(
            'css', 'fonts', 'uploads',
            'cache', 'caches', 'tmp', 'temp',
            'logs', 'log',
            'generated', 'generate',
            'data', 'gtg',
        ));
    }
    $top_dir = strtolower(strtok($p, '/'));
    if (isset($runtime_dirs[$top_dir])) {
        return true;
    }

    // Generic: Composer-generated autoload artifacts. These carry a
    // random suffix that changes on every `composer dump-autoload` run.
    if (preg_match('#(?:^|/)autoload_real\.php$#i', $p)) {
        return true;
    }

    return false;
}

/**
 * Compare every PHP/JS/CSS file inside a plugin/theme installation
 * against the WordPress.org reference hashmap and emit findings.
 *
 * @param array  $record    {slug, version, abs, rel}
 * @param string $kind      'plugin' or 'theme'
 * @return array            findings array (engine-shaped)
 */
function boteraser_integrity_verify_package($record, $kind) {
    $local_version = $record['version'] ?? '';
    $info = ($kind === 'plugin')
        ? boteraser_integrity_plugin_info($record['slug'], $local_version)
        : boteraser_integrity_theme_info($record['slug'], $local_version);

    if (!$info) {
        // Premium / custom — caller marks unverified
        return array('status' => 'unverified', 'findings' => array());
    }

    $hashmap = boteraser_integrity_build_hashmap($info, $kind);
    if ($hashmap === null) {
        return array('status' => 'unverified', 'findings' => array());
    }

    $findings = array();

    // Walk the local directory and compare
    $stack = array($record['abs']);
    $base_len = strlen($record['abs']) + 1;

    // Subdirectories we never verify against the upstream ZIP.
    //
    // Composer / NPM / build trees regenerate hashes on every release
    // build (autoload_real.php numbers, sourcemap timestamps, etc.) so
    // local hashes legitimately differ from upstream — that's a build
    // artifact, not malware. Wordfence and MalCare both skip these
    // directories during integrity verification.
    $skip_subdirs = array(
        'vendor', 'node_modules',
        'dist', 'build', '_build',
        '.next', '.nuxt', '.parcel-cache',
        'cache', '.cache', 'tmp', '.tmp',
    );
    $skip_lookup = array_flip($skip_subdirs);

    // Theme content the user routinely customizes. Hash mismatches
    // on these files almost always reflect legitimate user edits
    // (custom CSS, child theme JSON tweaks). PHP files in themes are
    // still verified because modifications there are dangerous.
    $theme_user_editable_ext = array('css', 'json', 'pot', 'po', 'mo', 'txt', 'md');

    while ($stack) {
        $dir = array_pop($stack);
        $dh = @opendir($dir);
        if (!$dh) continue;
        while (($entry = readdir($dh)) !== false) {
            if ($entry === '.' || $entry === '..') continue;
            $full = $dir . '/' . $entry;
            if (is_dir($full)) {
                if (isset($skip_lookup[strtolower($entry)])) continue;
                $stack[] = $full;
                continue;
            }
            if (!is_file($full)) continue;

            $rel_in_pkg = substr($full, $base_len);
            $rel_full   = $record['rel'] . '/' . $rel_in_pkg;
            $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));

            // Only verify executable / asset files. Generated caches,
            // logs, or user uploads inside the plugin directory are
            // ignored.
            if (!in_array($ext, array('php', 'js', 'css', 'html', 'htm'), true)) {
                continue;
            }

            // Themes: user-editable file types (CSS, translation
            // files, JSON theme tweaks) are skipped — modifications
            // there are routine customization, not malware.
            if ($kind === 'theme' && in_array($ext, $theme_user_editable_ext, true)) {
                continue;
            }

            $expected = $hashmap[$rel_in_pkg] ?? null;
            $actual   = md5_file($full);

            if ($expected === null) {
                // File exists locally but not in upstream ZIP.
                // Real malware almost always shows up this way —
                // BUT only PHP files are dangerous. JS/CSS extras
                // are usually leftover from updates, beta builds,
                // or pro add-ons; we score them as LOW.

                // Skip files in known runtime-generated subdirectories.
                // Popular plugins (Elementor, WooCommerce, WP Rocket, etc.)
                // write generated CSS, font cache, and data files at
                // runtime — these never exist in the upstream ZIP and
                // are not malware. We match on the relative path inside
                // the package so we don't accidentally skip legitimately
                // dangerous PHP files in unrelated directories.
                if (boteraser_integrity_is_runtime_generated($rel_in_pkg, $record['slug'])) {
                    continue;
                }

                $is_php = in_array($ext, array('php', 'phtml', 'phar'), true);
                $findings[] = array(
                    'file'     => $rel_full,
                    'findings' => array(array(
                        'type'    => 'unknown_file',
                        'label'   => $is_php
                            ? 'PHP file not present in upstream ' . $kind . ' (' . $record['slug'] . ' v' . $info['version'] . ')'
                            : 'Extra asset not present in upstream ' . $kind,
                        'score'   => $is_php ? 80 : 20,
                        'details' => 'Local file has no upstream counterpart',
                    )),
                    'ext'  => $ext,
                    'size' => filesize($full),
                );
                continue;
            }

            if ($actual !== $expected) {
                $is_executable = in_array($ext, array('php'), true);
                $findings[] = array(
                    'file'      => $rel_full,
                    'findings'  => array(array(
                        'type'    => 'modified_file',
                        'label'   => $is_executable
                            ? 'Modified file (does not match upstream)'
                            : 'Modified asset (does not match upstream)',
                        'score'   => $is_executable ? 85 : 25,
                        'details' => "Expected hash: {$expected}, actual: {$actual}",
                    )),
                    'ext'       => $ext,
                    'size'      => filesize($full),
                    'restorable' => true,
                );
            }
        }
        closedir($dh);
    }

    return array('status' => 'verified', 'findings' => $findings);
}

/**
 * Returns true if the given small PHP file is a "silence stub" — a
 * placeholder dropped by plugins (WPForms, Elementor, WooCommerce,
 * Rank Math, Yoast, Loco Translate, etc.) to prevent directory
 * listing or direct script access.
 *
 * Stubs share these traits, all of which we verify before skipping:
 *   - file body is short (< 512 bytes — checked by caller)
 *   - body contains nothing besides PHP open tag, comments, and a
 *     small set of harmless stmts (exit / die / header / return)
 *   - NO function definitions, NO eval/base64/include/require, NO
 *     superglobal access, NO loops, NO file operations
 *
 * If any of those traits are violated, we treat the file as
 * unverified PHP and let the surrounding "PHP in uploads" rule
 * flag it.
 */
function boteraser_integrity_is_silence_stub($full_path) {
    $body = @file_get_contents($full_path, false, null, 0, 512);
    if ($body === false) return false;

    // Strip PHP open tag, all comments, and whitespace, then check
    // what code (if any) is left.
    $stripped = preg_replace('/^\s*<\?php\b/i', '', $body, 1);
    if ($stripped === null) return false;
    // Remove // and # line comments and /* ... */ block comments
    $stripped = preg_replace('/\/\*[\s\S]*?\*\//', '', $stripped);
    $stripped = preg_replace('/(\/\/|#)[^\r\n]*/', '', $stripped);
    $stripped = trim($stripped);

    // Empty after stripping = pure comment file (the classic "Silence
    // is golden" stub). A bare PHP close tag alone is also fine.
    if ($stripped === '' || $stripped === '?' . '>') return true;

    // Hard reject: if any clearly dangerous token appears, this is
    // not a silence stub regardless of how it looks structurally.
    if (preg_match('/\b(?:eval|assert|base64_decode|gzinflate|gzuncompress|str_rot13|create_function|shell_exec|system|exec|passthru|popen|proc_open|include|include_once|require|require_once|file_get_contents|file_put_contents|fopen|curl_exec|preg_replace_callback)\b/i', $stripped)) {
        return false;
    }
    // Reject superglobals that are user-controlled. $_SERVER is
    // allowed because legitimate stubs (e.g. WPForms 404 fallback)
    // read $_SERVER['SERVER_PROTOCOL'] for the response status line.
    if (preg_match('/\$_(?:GET|POST|REQUEST|COOKIE|FILES)\b/', $stripped)) {
        return false;
    }
    if (preg_match('/\b(?:function|class|trait|interface)\s+[A-Za-z_]/', $stripped)) {
        return false;
    }

    // Allowed tokens for a silence stub: header(), status_header(),
    // exit, die, return, defined('ABSPATH') guard, simple echo of
    // a string literal. Anything outside this whitelist means the
    // file does real work — caller will flag it.
    // Whitelist of harmless statements a silence stub may contain.
    // Each alternative is anchored so it only matches a complete
    // statement; unknown tokens cause the overall match to fail.
    // The "if(!defined(ABSPATH)) exit;" guard needs special handling
    // because of the nested parens.
    $allowed_pattern = '/^(?:'
        . 'header\s*\([^)]*\)\s*;?'
        . '|status_header\s*\(\s*\d+\s*\)\s*;?'
        . '|http_response_code\s*\(\s*\d+\s*\)\s*;?'
        . '|exit\s*\(?[^()]*\)?\s*;?'
        . '|die\s*\(?[^()]*\)?\s*;?'
        . '|return\s*[^;]*;?'
        . '|echo\s+[\'"][^\'"]*[\'"]\s*;?'
        . '|defined\s*\(\s*[\'"]ABSPATH[\'"]\s*\)\s*(?:\|\|\s*(?:exit|die)\s*\(?[^()]*\)?\s*;?|or\s+(?:exit|die)\s*\(?[^()]*\)?\s*;?)?'
        . '|if\s*\(\s*!\s*defined\s*\(\s*[\'"]ABSPATH[\'"]\s*\)\s*\)\s*(?:exit|die)\s*\(?[^()]*\)?\s*;?'
        . '|\$_SERVER\s*\[[^\]]*\]\s*;?'
        . '|[;\s]|\?' . '>'
        . ')*$/i';

    return (bool) preg_match($allowed_pattern, $stripped);
}

/**
 * PHP file inside wp-content/uploads is one of the most reliable
 * malware signals — uploads is for media, never for executable code.
 * Same rule used by Wordfence Free and MalCare.
 */
/**
 * Scan wp-content/uploads for .htaccess files that enable PHP execution
 * or redirect to external domains — a high-confidence malware signal.
 */
function boteraser_integrity_scan_uploads_htaccess() {
    $upload = wp_upload_dir();
    $base = $upload['basedir'];
    if (!is_dir($base)) return array();

    $findings = array();
    $htaccess_path = $base . '/.htaccess';
    if (is_file($htaccess_path)) {
        $size = filesize($htaccess_path);
        if ($size !== false && $size < 65536) {
            $body = @file_get_contents($htaccess_path);
            if ($body !== false) {
                $is_hardening      = (bool) preg_match('/(deny\s+from\s+all|<Files[^>]*\.(?:php|phtml|phar))/i', $body);
                $enables_php       = (bool) preg_match('/(AddHandler|AddType|SetHandler|application\/x-httpd-php)/i', $body);
                $external_redirect = (bool) preg_match('/RewriteRule\s+.*\s+https?:\/\/(?!' . preg_quote($_SERVER['SERVER_NAME'] ?? '', '/') . ')/i', $body);

                if (!$is_hardening && ($enables_php || $external_redirect)) {
                    $findings[] = array(
                        'file'     => str_replace(ABSPATH, '', $htaccess_path),
                        'findings' => array(array(
                            'type'    => 'htaccess_in_uploads',
                            'label'   => '.htaccess in uploads enabling PHP execution or external redirect',
                            'score'   => 95,
                            'details' => $enables_php
                                ? 'Enables PHP execution in uploads folder'
                                : 'Contains rewrite to external domain',
                        )),
                        'ext'  => 'htaccess',
                        'size' => $size,
                    );
                }
            }
        }
    }
    return $findings;
}

function boteraser_integrity_scan_uploads_php() {
    $upload = wp_upload_dir();
    $base = $upload['basedir'];
    if (!is_dir($base)) return array();

    // Skip our own working directory (silence stub) and any other
    // index.php silence files that legitimate plugins drop into
    // upload subdirectories. Real malware never names itself
    // "index.php" with the standard one-line silence body.
    $own_workdir = realpath($base . '/boteraser/scan') ?: '';

    $findings = array();
    $stack = array($base);

    // Bound traversal — uploads can be huge. Cap at 50k entries.
    $max_entries = 50000;
    $seen = 0;

    while ($stack && $seen < $max_entries) {
        $dir = array_pop($stack);
        $real_dir = realpath($dir) ?: $dir;
        if ($own_workdir && strpos($real_dir, $own_workdir) === 0) continue;

        $dh = @opendir($dir);
        if (!$dh) continue;
        while (($entry = readdir($dh)) !== false) {
            if ($entry === '.' || $entry === '..') continue;
            $full = $dir . '/' . $entry;
            $seen++;
            if (is_dir($full)) {
                $stack[] = $full;
                continue;
            }
            if (!is_file($full)) continue;
            $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
            if ($ext !== 'php' && $ext !== 'phtml' && $ext !== 'phar') continue;

            // Skip silence stubs — short PHP files that legitimate
            // plugins (WPForms, Elementor, WooCommerce, etc.) drop
            // into upload subdirectories to block direct access.
            // These are NEVER malware drops: real malware is too long
            // to fit, and pretending to be a silence stub defeats
            // the purpose of dropping malware in the first place.
            //
            // Recognized patterns (all under ~500 bytes):
            //   - PHP open tag with empty body or comments only
            //   - PHP open tag plus exit; / die();
            //   - PHP open tag plus header(404) / status_header()
            //   - PHP open tag plus defined(ABSPATH) || exit;
            //   - "Silence is golden." style stubs
            $size = filesize($full);
            if ($size !== false && $size < 512 && boteraser_integrity_is_silence_stub($full)) {
                continue;
            }

            $rel = str_replace(ABSPATH, '', $full);

            // Skip PHP files that live in a subdirectory named after
            // an active plugin (e.g. wp-content/uploads/easy-table-of-
            // contents/).  These are legitimate plugin-generated files,
            // not malware — the subdirectory name guarantees the owner.
            if (function_exists('boteraser_is_known_plugin_uploads_dir')
                && boteraser_is_known_plugin_uploads_dir($rel)) {
                continue;
            }

            $findings[] = array(
                'file'     => $rel,
                'findings' => array(array(
                    'type'    => 'php_in_uploads',
                    'label'   => 'PHP file in uploads folder',
                    'score'   => 95,
                    'details' => 'Uploads is for media — executable code here is almost always malware',
                )),
                'ext'  => $ext,
                'size' => $size ?: 0,
            );
        }
        closedir($dh);
    }
    return $findings;
}
