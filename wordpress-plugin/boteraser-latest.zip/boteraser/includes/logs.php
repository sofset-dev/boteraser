<?php
/**
 * Boteraser Logs Page
 *
 * @package Boteraser
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render the logs page with premium styling
 */
function bot_eraser_render_logs_page() {
    if (!current_user_can('manage_options')) return;

    // Handle log clearing
    $logs_cleared = false;
    if (isset($_POST['clear_logs']) && check_admin_referer('bot_eraser_clear_logs')) {
        $log_file = BOT_ERASER_LOG_PATH;
        if (file_exists($log_file)) {
            file_put_contents($log_file, '');
            $logs_cleared = true;
        }
    }

    // Get log data
    $log_file = BOT_ERASER_LOG_PATH;
    $logs = [];
    $total_lines = 0;
    $per_page = 10;
    $current_page = 1;
    $total_pages = 1;

    if (file_exists($log_file)) {
        $total_lines = count(file($log_file));

        // Pagination setup
        $per_page = isset($_GET['per_page']) ? max(10, intval($_GET['per_page'])) : 10;
        $allowed_per_page = [10, 20, 50, 100];
        if (!in_array($per_page, $allowed_per_page)) {
            $per_page = 10;
        }
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $total_pages = ceil($total_lines / $per_page);

        // Read logs in reverse order (newest first)
        $lines = file($log_file);
        $lines = array_reverse($lines);

        // Get lines for current page
        $offset = ($current_page - 1) * $per_page;
        $page_lines = array_slice($lines, $offset, $per_page);

        // Parse log lines
        foreach ($page_lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;

            // Parse Apache/Combined log format: IP - - [timestamp] "request" status - "referer" "user-agent"
            if (preg_match('/^(\S+) \S+ \S+ \[([^\]]+)\] "([^"]*)" (\d+) \S+ "([^"]*)" "([^"]*)"/', $line, $matches)) {
                $logs[] = [
                    'ip' => $matches[1],
                    'timestamp' => $matches[2],
                    'request' => $matches[3],
                    'status' => $matches[4],
                    'referer' => $matches[5],
                    'user_agent' => $matches[6]
                ];
            } else {
                $logs[] = [
                    'ip' => 'Unknown',
                    'timestamp' => 'Unknown',
                    'request' => $line,
                    'status' => '000',
                    'referer' => '-',
                    'user_agent' => 'Raw log line'
                ];
            }
        }
    }

    // Calculate stats
    $status_counts = ['2xx' => 0, '3xx' => 0, '4xx' => 0, '5xx' => 0];
    foreach ($logs as $log) {
        $status = intval($log['status']);
        if ($status >= 200 && $status < 300) $status_counts['2xx']++;
        elseif ($status >= 300 && $status < 400) $status_counts['3xx']++;
        elseif ($status >= 400 && $status < 500) $status_counts['4xx']++;
        elseif ($status >= 500) $status_counts['5xx']++;
    }

    // Hero KPI data
    $log_size_bytes = file_exists($log_file) ? filesize($log_file) : 0;
    if ($log_size_bytes >= 1048576) {
        $log_size_label = number_format($log_size_bytes / 1048576, 1) . ' MB';
    } elseif ($log_size_bytes >= 1024) {
        $log_size_label = number_format($log_size_bytes / 1024, 0) . ' KB';
    } else {
        $log_size_label = $log_size_bytes . ' B';
    }

    $last_write_label = '—';
    if (file_exists($log_file)) {
        $mtime = filemtime($log_file);
        $diff  = time() - $mtime;
        if ($diff < 60) {
            $last_write_label = $diff . ' ' . __('seconds ago', 'bot-eraser');
        } elseif ($diff < 3600) {
            $last_write_label = round($diff / 60) . ' ' . __('min ago', 'bot-eraser');
        } elseif ($diff < 86400) {
            $last_write_label = round($diff / 3600) . ' ' . __('hrs ago', 'bot-eraser');
        } else {
            $last_write_label = date_i18n(get_option('date_format'), $mtime);
        }
    }

    $log_healthy   = file_exists($log_file) && is_writable($log_file);
    $status_label  = $log_healthy ? __('Healthy', 'bot-eraser') : __('Unavailable', 'bot-eraser');
    $status_tone   = $log_healthy ? 'good' : 'critical';

    $hero_metrics = array(
        array(
            'label'   => __('Size', 'bot-eraser'),
            'value'   => $log_size_label,
            'context' => __('Log file on disk', 'bot-eraser'),
            'tone'    => 'neutral',
        ),
        array(
            'label'   => __('Entries', 'bot-eraser'),
            'value'   => number_format_i18n($total_lines),
            'context' => __('Total log lines', 'bot-eraser'),
            'tone'    => 'neutral',
        ),
        array(
            'label'   => __('Last write', 'bot-eraser'),
            'value'   => $last_write_label,
            'context' => __('Most recent activity', 'bot-eraser'),
            'tone'    => 'neutral',
        ),
        array(
            'label'   => __('Status', 'bot-eraser'),
            'value'   => $status_label,
            'context' => __('Log file health', 'bot-eraser'),
            'tone'    => $status_tone,
        ),
    );
    ?>

    <?php
    $latest_event_label = '';
    if (!empty($logs)) {
        $latest_event_label = $logs[0]['timestamp'] !== 'Unknown' ? $logs[0]['timestamp'] : '';
    }
    $aside_rows = '';
    foreach (array(
        '2xx' => __('Success', 'bot-eraser'),
        '3xx' => __('Redirects', 'bot-eraser'),
        '4xx' => __('Client errors', 'bot-eraser'),
        '5xx' => __('Server errors', 'bot-eraser'),
    ) as $bucket => $label) {
        $aside_rows .= sprintf(
            '<li class="boteraser-hero-aside-item"><span class="boteraser-hero-aside-item-key">%s</span><span class="boteraser-hero-aside-item-val">%s</span></li>',
            esc_html($label),
            esc_html(number_format_i18n($status_counts[$bucket]))
        );
    }
    $logs_aside = sprintf(
        '<div class="boteraser-hero-aside boteraser-hero-aside-list"><p class="boteraser-hero-aside-eyebrow">%s</p><h3 class="boteraser-hero-aside-title">%s</h3><ul class="boteraser-hero-aside-items">%s</ul><p class="boteraser-hero-aside-foot %s">%s</p></div>',
        esc_html__('Status mix on this page', 'bot-eraser'),
        esc_html(sprintf(_n('%s log entry total', '%s log entries total', $total_lines, 'bot-eraser'), number_format_i18n($total_lines))),
        $aside_rows,
        $latest_event_label ? '' : 'is-placeholder',
        $latest_event_label
            ? esc_html(sprintf(__('Latest: %s', 'bot-eraser'), $latest_event_label))
            : '·'
    );
    ?>
    <div class="wrap boteraser-wrap">
        <?php bot_eraser_render_page_header(array(
            'variant'  => 'standard',
            'title'    => __('Security Logs', 'bot-eraser'),
            'subtitle' => __('Inspect request activity, status patterns, and recent events from one consistent audit view.', 'bot-eraser'),
            'metrics'  => $hero_metrics,
            'aside'    => $logs_aside,
        )); ?>

        <!-- Notices -->
        <?php if ($logs_cleared): ?>
            <div class="boteraser-notice success">
                <?php echo bot_eraser_icon('check-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title"><?php _e('Logs Cleared', 'bot-eraser'); ?></p>
                    <p class="boteraser-notice-message"><?php _e('All log entries have been successfully cleared.', 'bot-eraser'); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="boteraser-stats-grid">
            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon primary">
                    <?php echo bot_eraser_icon('file-text'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($total_lines); ?>">
                        <?php echo number_format($total_lines); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Total Entries', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon success">
                    <?php echo bot_eraser_icon('check-circle'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($status_counts['2xx']); ?>">
                        <?php echo number_format($status_counts['2xx']); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Success (2xx)', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon warning">
                    <?php echo bot_eraser_icon('alert-circle'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($status_counts['4xx']); ?>">
                        <?php echo number_format($status_counts['4xx']); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Client Errors (4xx)', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon danger">
                    <?php echo bot_eraser_icon('x-circle'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($status_counts['5xx']); ?>">
                        <?php echo number_format($status_counts['5xx']); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Server Errors (5xx)', 'bot-eraser'); ?></p>
                </div>
            </div>
        </div>

        <div class="boteraser-card be-live-bar-card">
            <div class="boteraser-card-header"><h2 class="boteraser-card-title"><?php echo bot_eraser_icon('activity'); ?> <?php _e('Traffic Flow', 'bot-eraser'); ?></h2><div class="be-live-bar-actions"><span id="be-live-status" class="be-live-status offline">● <?php _e('Offline', 'bot-eraser'); ?></span><button type="button" id="be-live-toggle" class="boteraser-btn boteraser-btn-primary boteraser-btn-sm"><?php echo bot_eraser_icon('play'); ?> <?php _e('Go Live', 'bot-eraser'); ?></button></div></div>
            <p class="boteraser-card-intro" style="margin:0 0 12px;font-size:12px;color:#6b7280;"><?php _e('Each bar = 5 seconds.', 'bot-eraser'); ?></p>
            <canvas id="be-live-canvas" width="880" height="80" style="width:100%;height:80px;display:block;background:#f9fafb;border-radius:6px 6px 0 0;"></canvas>
            <div class="be-live-legend" style="display:flex;gap:16px;padding:6px 12px;background:#f9fafb;border-radius:0 0 6px 6px;font-size:11px;color:#6b7280;justify-content:center;"><span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#10b981;margin-right:4px;"></span> OK (200)</span><span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#ef4444;margin-right:4px;"></span> Errors 4xx/5xx</span><span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#d1d5db;margin-right:4px;"></span> Idle</span></div>
            <div id="be-live-latest" style="display:none;margin-top:8px;font-size:11px;color:#9ca3af;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;"></div>
        </div>

        <!-- Main Content -->
        <div class="boteraser-card">
            <!-- Filter Bar -->
            <div class="boteraser-filter-bar">
                <div class="boteraser-filter-group">
                    <form method="post" style="margin: 0;">
                        <?php wp_nonce_field('bot_eraser_clear_logs'); ?>
                        <input type="hidden" name="clear_logs" value="1">
                        <button type="submit" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm"
                                onclick="return confirm('<?php echo esc_js(__('Are you sure you want to clear all logs? This action cannot be undone.', 'bot-eraser')); ?>')">
                            <?php echo bot_eraser_icon('trash'); ?>
                            <?php _e('Clear Logs', 'bot-eraser'); ?>
                        </button>
                    </form>

                    <span class="boteraser-status-badge <?php echo file_exists($log_file) ? 'success' : 'error'; ?>">
                        <?php echo file_exists($log_file) ? bot_eraser_icon('check-circle') : bot_eraser_icon('x-circle'); ?>
                        <?php echo file_exists($log_file) ? __('Log File Active', 'bot-eraser') : __('Log File Missing', 'bot-eraser'); ?>
                    </span>
                </div>

                <div class="boteraser-filter-group">
                    <span class="boteraser-filter-label">
                        <?php printf(
                            __('Showing %s-%s of %s', 'bot-eraser'),
                            number_format(min(($current_page - 1) * $per_page + 1, $total_lines)),
                            number_format(min($current_page * $per_page, $total_lines)),
                            number_format($total_lines)
                        ); ?>
                    </span>

                    <form method="get" style="margin: 0; display: flex; align-items: center; gap: 8px;">
                        <?php foreach ($_GET as $key => $value): ?>
                            <?php if ($key !== 'per_page' && $key !== 'paged'): ?>
                                <input type="hidden" name="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>">
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <label for="per_page" class="boteraser-filter-label"><?php _e('Show:', 'bot-eraser'); ?></label>
                        <select name="per_page" id="per_page" class="boteraser-filter-select" onchange="this.form.submit()">
                            <option value="10" <?php selected($per_page, 10); ?>>10</option>
                            <option value="20" <?php selected($per_page, 20); ?>>20</option>
                            <option value="50" <?php selected($per_page, 50); ?>>50</option>
                            <option value="100" <?php selected($per_page, 100); ?>>100</option>
                        </select>
                    </form>
                </div>
            </div>

            <!-- Logs Table -->
            <?php if (empty($logs)): ?>
                <div style="text-align: center; padding: 60px 20px; color: var(--be-gray-500);">
                    <div style="width: 64px; height: 64px; margin: 0 auto;">
                        <?php echo bot_eraser_icon('file-text'); ?>
                    </div>
                    <p style="margin-top: 16px; font-size: 16px;"><?php _e('No log entries found', 'bot-eraser'); ?></p>
                    <p style="font-size: 14px;"><?php _e('Logs will appear here once visitors access your site.', 'bot-eraser'); ?></p>
                </div>
            <?php else: ?>
                <div class="boteraser-table-wrapper">
                    <table class="boteraser-table">
                        <thead>
                            <tr>
                                <th><?php _e('IP Address', 'bot-eraser'); ?></th>
                                <th><?php _e('Timestamp', 'bot-eraser'); ?></th>
                                <th><?php _e('Request', 'bot-eraser'); ?></th>
                                <th><?php _e('Status', 'bot-eraser'); ?></th>
                                <th><?php _e('User Agent', 'bot-eraser'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td>
                                        <span class="ip-address"><?php echo esc_html($log['ip']); ?></span>
                                    </td>
                                    <td>
                                        <span style="font-size: 12px; color: var(--be-gray-600);">
                                            <?php echo esc_html($log['timestamp']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="request-path"><?php echo esc_html($log['request']); ?></span>
                                    </td>
                                    <td>
                                        <?php
                                        $status = intval($log['status']);
                                        $status_class = 'status-2xx';
                                        if ($status >= 300 && $status < 400) $status_class = 'status-3xx';
                                        elseif ($status >= 400 && $status < 500) $status_class = 'status-4xx';
                                        elseif ($status >= 500) $status_class = 'status-5xx';
                                        ?>
                                        <span class="status-badge <?php echo esc_attr($status_class); ?>">
                                            <?php echo esc_html($log['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="user-agent" title="<?php echo esc_attr($log['user_agent']); ?>">
                                            <?php echo esc_html($log['user_agent']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="boteraser-pagination">
                        <div class="boteraser-pagination-info">
                            <?php printf(
                                __('Showing %s - %s of %s entries', 'bot-eraser'),
                                number_format(($current_page - 1) * $per_page + 1),
                                number_format(min($current_page * $per_page, $total_lines)),
                                number_format($total_lines)
                            ); ?>
                        </div>
                        <div class="boteraser-pagination-links">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg(array('paged' => '%#%', 'per_page' => $per_page)),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ));
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php wp_localize_script('boteraser-admin', 'boteraser_live', array('ajaxUrl' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('boteraser_live_traffic'))); ?>
    <script>(function(){var c=document.getElementById('be-live-canvas'),t=document.getElementById('be-live-toggle'),s=document.getElementById('be-live-status'),l=document.getElementById('be-live-latest');if(!c||!t)return;var x=c.getContext('2d'),W,H,bw,g=false,d=null,h=-1,p=new Array(60).fill(0),ti=null;function rs(){W=c.clientWidth;H=c.clientHeight;c.width=W;c.height=H;bw=W/60}rs();window.addEventListener('resize',function(){rs();if(d)dr()});function dr(){if(!d)return;var b=d.buckets||[];x.clearRect(0,0,W,H);var m=1;for(var i=0;i<60;i++){if(!b[i])continue;m=Math.max(m,b[i][0]+b[i][1]+b[i][2])}var hm=H-10;for(var i=0;i<60;i++){var total=0,errs=0;if(b[i]){total=b[i][0]+b[i][1]+b[i][2];errs=(b[i][3]||0)+(b[i][4]||0)}var tg=total>0?Math.max(3,(total/m)*hm):0;p[i]+=(tg-p[i])*0.3;var xp=i*bw+1,hv=Math.max(0,p[i]),yp=H-hv-2;if(hv<0.5)continue;if(errs>0&&errs>=total*0.3)x.fillStyle='#ef4444';else if(total>=1)x.fillStyle='#10b981';else x.fillStyle='#d1d5db';x.beginPath();x.roundRect(xp,yp,bw-1,hv,2);x.fill();if(h===i){x.fillStyle='rgba(0,0,0,0.08)';x.beginPath();x.roundRect(xp,yp,bw-1,hv,2);x.fill()}}x.strokeStyle='#9ca3af';x.lineWidth=1;x.setLineDash([3,3]);x.beginPath();x.moveTo(W-1,2);x.lineTo(W-1,H-2);x.stroke();x.setLineDash([]);x.fillStyle='#6b7280';x.font='9px sans-serif';x.fillText('now',W-24,H-4);if(d.latest&&d.latest.length){l.style.display='block';l.innerHTML=d.latest.map(function(e){var c=e.code>=500?'#ef4444':e.code>=400?'#f59e0b':e.code>=300?'#3b82f6':'#10b981';return'<span style="color:'+c+';font-weight:600">'+e.code+'</span> <span style="color:#6b7280">'+e.ip+'</span> '+e.path}).join(' &nbsp;|&nbsp; ')}if(h>=0&&h<60&&b[h]){var bk=b[h],sa=(60-h)*5,txt=sa<60?sa+'s ago':Math.ceil(sa/60)+'m ago';if(bk[5]&&bk[5].length)txt+=' \u2014 '+bk[5].slice(0,5).join(', ')+(bk[5].length>5?' +'+(bk[5].length-5):'');x.font='11px sans-serif';var tw=x.measureText(txt).width+20,tx=Math.min(W-tw/2-6,Math.max(tw/2+6,h*bw+bw/2));x.fillStyle='rgba(0,0,0,0.82)';x.beginPath();x.roundRect(tx-tw/2,22,tw,22,4);x.fill();x.fillStyle='#fff';x.textAlign='center';x.fillText(txt,tx,37);x.textAlign='start'}}c.addEventListener('mousemove',function(e){var mx=e.clientX-c.getBoundingClientRect().left;h=Math.min(59,Math.max(0,Math.floor(mx/bw)));if(d)dr()});c.addEventListener('mouseleave',function(){h=-1;if(d)dr()});function pl(){if(!g)return;var f=new FormData();f.append('action','boteraser_live_traffic');f.append('nonce',boteraser_live.nonce);fetch(boteraser_live.ajaxUrl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){if(r.success){d=r.data;dr()}});ti=setTimeout(pl,2000)}t.addEventListener('click',function(){g=!g;if(g){t.innerHTML='<?php echo bot_eraser_icon("pause"); ?> <?php _e("Pause", "bot-eraser"); ?>';t.classList.add('boteraser-btn-secondary');t.classList.remove('boteraser-btn-primary');s.className='be-live-status live';s.innerHTML='● <?php _e("Live", "bot-eraser"); ?>';pl()}else{t.innerHTML='<?php echo bot_eraser_icon("play"); ?> <?php _e("Go Live", "bot-eraser"); ?>';t.classList.add('boteraser-btn-primary');t.classList.remove('boteraser-btn-secondary');s.className='be-live-status offline';s.innerHTML='● <?php _e("Offline", "bot-eraser"); ?>';clearTimeout(ti)}})})();</script>
    <?php
}
