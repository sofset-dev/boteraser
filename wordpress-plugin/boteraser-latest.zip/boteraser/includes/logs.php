<?php
if (!defined('ABSPATH')) {
    exit;
}

function bot_eraser_render_logs_page() {
    if (!current_user_can('manage_options')) return;

    // Styling for full visibility of all content
    echo '<style>
        .wp-list-table {
            table-layout: auto !important;
            width: 100% !important;
        }
        
        .wp-list-table th,
        .wp-list-table td {
            word-wrap: break-word !important;
            white-space: normal !important;
            padding: 8px 12px !important;
            vertical-align: top !important;
        }
        
        /* Remove any width restrictions to allow natural content sizing */
        .wp-list-table th:nth-child(1),  /* IP Address */
        .wp-list-table td:nth-child(1) {
            min-width: 120px;
        }
        
        .wp-list-table th:nth-child(2),  /* Timestamp */
        .wp-list-table td:nth-child(2) {
            min-width: 150px;
        }
        
        .wp-list-table th:nth-child(3),  /* Request */
        .wp-list-table td:nth-child(3) {
            min-width: 200px;
        }
        
        .wp-list-table th:nth-child(4),  /* Status */
        .wp-list-table td:nth-child(4) {
            min-width: 60px;
            text-align: center;
        }
        
        .wp-list-table th:nth-child(5),  /* User Agent */
        .wp-list-table td:nth-child(5) {
            min-width: 200px;
        }
        
        .tablenav-pages .pagination-links {
            font-size: 16px;
        }
        .tablenav-pages .pagination-links a,
        .tablenav-pages .pagination-links span.current {
            font-size: 16px;
            min-width: 30px;
            height: 30px;
            line-height: 28px;
            text-decoration: none;
        }
    </style>';
    // Remove all custom CSS to match blocked IPs page exactly
    // Blocked IPs page uses no custom width/positioning CSS

    // Handle log clearing
    if (isset($_POST['clear_logs']) && check_admin_referer('bot_eraser_clear_logs')) {
        $log_file = BOT_ERASER_LOG_PATH;
        if (file_exists($log_file)) {
            file_put_contents($log_file, '');
            echo '<div class="notice notice-success"><p>Logs cleared successfully.</p></div>';
        }
    }

    // Get log data
    $log_file = BOT_ERASER_LOG_PATH;
    $logs = [];
    $total_lines = 0;
    
    if (file_exists($log_file)) {
        $total_lines = count(file($log_file));
        
        // Pagination setup
        $per_page = isset($_GET['per_page']) ? max(10, intval($_GET['per_page'])) : 10;
        // Ensure per_page is one of the allowed values
        $allowed_per_page = [10, 20, 50, 100];
        if (!in_array($per_page, $allowed_per_page)) {
            $per_page = 10;
        }
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $total_pages = ceil($total_lines / $per_page);
        
        // Read logs in reverse order (newest first)
        $lines = file($log_file);
        $lines = array_reverse($lines);
        
        // Get lines for current page
        $offset = ($current_page - 1) * $per_page;
        $page_lines = array_slice($lines, $offset, $per_page);
        
        // Parse log lines
        foreach ($page_lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            
            // Parse Apache log format with double brackets: IP - - [[timestamp]] "METHOD /path HTTP/1.1" status size "referer" "user-agent"
            if (preg_match('/^(\S+) \S+ \S+ \[\[([^\]]+)\]\] "([^"]*)" (\d+) \S+ "([^"]*)" "([^"]*)"/', $line, $matches)) {
                $logs[] = [
                    'ip' => $matches[1],
                    'timestamp' => $matches[2],
                    'request' => $matches[3],
                    'status' => $matches[4],
                    'referer' => $matches[5],
                    'user_agent' => $matches[6]
                ];
            } else {
                // If regex doesn't match, add the raw line for debugging
                $logs[] = [
                    'ip' => 'Unknown',
                    'timestamp' => 'Unknown',
                    'request' => $line,
                    'status' => '000',
                    'referer' => '-',
                    'user_agent' => 'Raw log line'
                ];
            }
        }
    }    ?>
    <div class="wrap">
        <div class="boteraser-header">
            <img src="<?php echo esc_url(BOT_ERASER_PLUGIN_URL . 'logo.svg'); ?>" 
                 alt="Boteraser Logo" 
                 class="boteraser-logo">
        </div>
        <h2><?php echo sprintf(__('Access Logs: last <span style="color: red;">%d</span> entries', 'bot-eraser'), $total_lines); ?></h2>
        
        <?php if ($total_lines > 0): ?>
        <div style="margin-bottom: 15px; display: flex; align-items: center; justify-content: space-between; gap: 15px; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 15px;">
                <form method="post" style="display: inline; margin: 0;">
                    <?php wp_nonce_field('bot_eraser_clear_logs'); ?>
                    <input type="hidden" name="clear_logs" value="1">
                    <button type="submit" class="button button-secondary" 
                            onclick="return confirm('Are you sure you want to clear all logs? This action cannot be undone.')">
                        <span class="dashicons dashicons-trash"></span>
                        Clear Logs
                    </button>
                </form>
                
                <span style="vertical-align: middle;">
                    <?php echo file_exists($log_file) ? 
                        '<span style="color: #46b450; font-weight: 500; background: #f0f8f0; padding: 4px 8px; border-radius: 3px; font-size: 13px;">
                            <span class="dashicons dashicons-yes-alt" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle;"></span> 
                            access.log Found
                        </span>' : 
                        '<span style="color: #dc3232; font-weight: 500; background: #fdf0f0; padding: 4px 8px; border-radius: 3px; font-size: 13px;">
                            <span class="dashicons dashicons-dismiss" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle;"></span> 
                            access.log Not Found
                        </span>'; ?>
                </span>
            </div>
            
            <div style="display: flex; align-items: center; gap: 15px;">
                <span style="color: #666; font-size: 13px;">
                    Showing <?php echo number_format(($current_page - 1) * $per_page + 1); ?>-<?php echo number_format(min($current_page * $per_page, $total_lines)); ?> of <?php echo number_format($total_lines); ?> entries
                </span>
                
                <form method="get" style="display: inline; margin: 0;">
                    <?php foreach ($_GET as $key => $value): ?>
                        <?php if ($key !== 'per_page' && $key !== 'paged'): ?>
                            <input type="hidden" name="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>">
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <label for="per_page" style="margin-right: 5px;">Show:</label>
                    <select name="per_page" id="per_page" onchange="this.form.submit()" style="margin-right: 5px;">
                        <option value="10" <?php selected($per_page, 10); ?>>10</option>
                        <option value="20" <?php selected($per_page, 20); ?>>20</option>
                        <option value="50" <?php selected($per_page, 50); ?>>50</option>
                        <option value="100" <?php selected($per_page, 100); ?>>100</option>
                    </select>
                    <span>entries per page</span>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <?php if (empty($logs)): ?>
            <p><?php _e('No log entries found', 'bot-eraser'); ?></p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('IP Address', 'bot-eraser'); ?></th>
                        <th><?php _e('Timestamp', 'bot-eraser'); ?></th>
                        <th><?php _e('Request', 'bot-eraser'); ?></th>
                        <th><?php _e('Status', 'bot-eraser'); ?></th>
                        <th><?php _e('User Agent', 'bot-eraser'); ?></th>
                    </tr>
                </thead>
                <tbody>
                                    <?php foreach ($logs as $log): ?>
                                        <tr>
                                            <td>
                                                <code style="background: #f0f0f0; padding: 2px 4px; border-radius: 2px;">
                                                    <?php echo esc_html($log['ip']); ?>
                                                </code>
                                            </td>
                                            <td>
                                                <small><?php echo esc_html($log['timestamp']); ?></small>
                                            </td>
                                            <td>
                                                <code style="font-size: 11px; word-break: break-all;">
                                                    <?php echo esc_html($log['request']); ?>
                                                </code>
                                            </td>
                                            <td>
                                                <span class="status-badge status-<?php echo esc_attr($log['status']); ?>" 
                                                      style="display: inline-block; padding: 2px 6px; border-radius: 3px; font-size: 11px; font-weight: bold; 
                                                             <?php
                                                             if ($log['status'] >= 200 && $log['status'] < 300) {
                                                                 echo 'background: #d4edda; color: #155724;';
                                                             } elseif ($log['status'] >= 300 && $log['status'] < 400) {
                                                                 echo 'background: #fff3cd; color: #856404;';
                                                             } elseif ($log['status'] >= 400) {
                                                                 echo 'background: #f8d7da; color: #721c24;';
                                                             } else {
                                                                 echo 'background: #d1ecf1; color: #0c5460;';
                                                             }
                                                             ?>">
                                                    <?php echo esc_html($log['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <small style="word-break: break-all;">
                                                    <?php echo esc_html($log['user_agent']); ?>
                                                </small>
                                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if ($total_pages > 1): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <span class="displaying-num">
                        Showing <?php echo number_format(($current_page - 1) * $per_page + 1); ?> - 
                        <?php echo number_format(min($current_page * $per_page, $total_lines)); ?> of 
                        <?php echo number_format($total_lines); ?> entries
                    </span>
                    <span class="pagination-links">
                        <?php
                        $pagination_args = array(
                            'base' => add_query_arg(array('paged' => '%#%', 'per_page' => $per_page)),
                            'format' => '',
                            'prev_text' => __('&laquo;'),
                            'next_text' => __('&raquo;'),
                            'total' => $total_pages,
                            'current' => $current_page
                        );
                        echo paginate_links($pagination_args);
                        ?>
                    </span>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
}