<?php
/**
 * Boteraser Logs Page
 *
 * @package Boteraser
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render the logs page with premium styling
 */
function bot_eraser_render_logs_page() {
    if (!current_user_can('manage_options')) return;

    // Handle log clearing
    $logs_cleared = false;
    if (isset($_POST['clear_logs']) && check_admin_referer('bot_eraser_clear_logs')) {
        $log_file = BOT_ERASER_LOG_PATH;
        if (file_exists($log_file)) {
            file_put_contents($log_file, '');
            $logs_cleared = true;
        }
    }

    // Get log data
    $log_file = BOT_ERASER_LOG_PATH;
    $logs = [];
    $total_lines = 0;
    $per_page = 10;
    $current_page = 1;
    $total_pages = 1;

    if (file_exists($log_file)) {
        $total_lines = count(file($log_file));

        // Pagination setup
        $per_page = isset($_GET['per_page']) ? max(10, intval($_GET['per_page'])) : 10;
        $allowed_per_page = [10, 20, 50, 100];
        if (!in_array($per_page, $allowed_per_page)) {
            $per_page = 10;
        }
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $total_pages = ceil($total_lines / $per_page);

        // Read logs in reverse order (newest first)
        $lines = file($log_file);
        $lines = array_reverse($lines);

        // Get lines for current page
        $offset = ($current_page - 1) * $per_page;
        $page_lines = array_slice($lines, $offset, $per_page);

        // Parse log lines
        foreach ($page_lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;

            // Parse Apache/Combined log format: IP - - [timestamp] "request" status - "referer" "user-agent"
            if (preg_match('/^(\S+) \S+ \S+ \[([^\]]+)\] "([^"]*)" (\d+) \S+ "([^"]*)" "([^"]*)"/', $line, $matches)) {
                $logs[] = [
                    'ip' => $matches[1],
                    'timestamp' => $matches[2],
                    'request' => $matches[3],
                    'status' => $matches[4],
                    'referer' => $matches[5],
                    'user_agent' => $matches[6]
                ];
            } else {
                $logs[] = [
                    'ip' => 'Unknown',
                    'timestamp' => 'Unknown',
                    'request' => $line,
                    'status' => '000',
                    'referer' => '-',
                    'user_agent' => 'Raw log line'
                ];
            }
        }
    }

    // Calculate stats
    $status_counts = ['2xx' => 0, '3xx' => 0, '4xx' => 0, '5xx' => 0];
    foreach ($logs as $log) {
        $status = intval($log['status']);
        if ($status >= 200 && $status < 300) $status_counts['2xx']++;
        elseif ($status >= 300 && $status < 400) $status_counts['3xx']++;
        elseif ($status >= 400 && $status < 500) $status_counts['4xx']++;
        elseif ($status >= 500) $status_counts['5xx']++;
    }
    ?>

    <div class="wrap boteraser-wrap">
        <!-- Header -->
        <div class="boteraser-header">
            <img src="<?php echo esc_url(BOT_ERASER_PLUGIN_URL . 'logo.svg'); ?>"
                 alt="Boteraser Logo"
                 class="boteraser-logo">
        </div>

        <!-- Notices -->
        <?php if ($logs_cleared): ?>
            <div class="boteraser-notice success">
                <?php echo bot_eraser_icon('check-circle'); ?>
                <div class="boteraser-notice-content">
                    <p class="boteraser-notice-title"><?php _e('Logs Cleared', 'bot-eraser'); ?></p>
                    <p class="boteraser-notice-message"><?php _e('All log entries have been successfully cleared.', 'bot-eraser'); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="boteraser-stats-grid">
            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon primary">
                    <?php echo bot_eraser_icon('file-text'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($total_lines); ?>">
                        <?php echo number_format($total_lines); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Total Entries', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon success">
                    <?php echo bot_eraser_icon('check-circle'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($status_counts['2xx']); ?>">
                        <?php echo number_format($status_counts['2xx']); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Success (2xx)', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon warning">
                    <?php echo bot_eraser_icon('alert-circle'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($status_counts['4xx']); ?>">
                        <?php echo number_format($status_counts['4xx']); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Client Errors (4xx)', 'bot-eraser'); ?></p>
                </div>
            </div>

            <div class="boteraser-stat-card">
                <div class="boteraser-stat-icon danger">
                    <?php echo bot_eraser_icon('x-circle'); ?>
                </div>
                <div class="boteraser-stat-content">
                    <p class="boteraser-stat-value" data-count="<?php echo esc_attr($status_counts['5xx']); ?>">
                        <?php echo number_format($status_counts['5xx']); ?>
                    </p>
                    <p class="boteraser-stat-label"><?php _e('Server Errors (5xx)', 'bot-eraser'); ?></p>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="boteraser-card">
            <!-- Filter Bar -->
            <div class="boteraser-filter-bar">
                <div class="boteraser-filter-group">
                    <form method="post" style="margin: 0;">
                        <?php wp_nonce_field('bot_eraser_clear_logs'); ?>
                        <input type="hidden" name="clear_logs" value="1">
                        <button type="submit" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm"
                                onclick="return confirm('<?php echo esc_js(__('Are you sure you want to clear all logs? This action cannot be undone.', 'bot-eraser')); ?>')">
                            <?php echo bot_eraser_icon('trash'); ?>
                            <?php _e('Clear Logs', 'bot-eraser'); ?>
                        </button>
                    </form>

                    <span class="boteraser-status-badge <?php echo file_exists($log_file) ? 'success' : 'error'; ?>">
                        <?php echo file_exists($log_file) ? bot_eraser_icon('check-circle') : bot_eraser_icon('x-circle'); ?>
                        <?php echo file_exists($log_file) ? __('Log File Active', 'bot-eraser') : __('Log File Missing', 'bot-eraser'); ?>
                    </span>
                </div>

                <div class="boteraser-filter-group">
                    <span class="boteraser-filter-label">
                        <?php printf(
                            __('Showing %s-%s of %s', 'bot-eraser'),
                            number_format(min(($current_page - 1) * $per_page + 1, $total_lines)),
                            number_format(min($current_page * $per_page, $total_lines)),
                            number_format($total_lines)
                        ); ?>
                    </span>

                    <form method="get" style="margin: 0; display: flex; align-items: center; gap: 8px;">
                        <?php foreach ($_GET as $key => $value): ?>
                            <?php if ($key !== 'per_page' && $key !== 'paged'): ?>
                                <input type="hidden" name="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>">
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <label for="per_page" class="boteraser-filter-label"><?php _e('Show:', 'bot-eraser'); ?></label>
                        <select name="per_page" id="per_page" class="boteraser-filter-select" onchange="this.form.submit()">
                            <option value="10" <?php selected($per_page, 10); ?>>10</option>
                            <option value="20" <?php selected($per_page, 20); ?>>20</option>
                            <option value="50" <?php selected($per_page, 50); ?>>50</option>
                            <option value="100" <?php selected($per_page, 100); ?>>100</option>
                        </select>
                    </form>
                </div>
            </div>

            <!-- Logs Table -->
            <?php if (empty($logs)): ?>
                <div style="text-align: center; padding: 60px 20px; color: var(--be-gray-500);">
                    <div style="width: 64px; height: 64px; margin: 0 auto;">
                        <?php echo bot_eraser_icon('file-text'); ?>
                    </div>
                    <p style="margin-top: 16px; font-size: 16px;"><?php _e('No log entries found', 'bot-eraser'); ?></p>
                    <p style="font-size: 14px;"><?php _e('Logs will appear here once visitors access your site.', 'bot-eraser'); ?></p>
                </div>
            <?php else: ?>
                <div class="boteraser-table-wrapper">
                    <table class="boteraser-table">
                        <thead>
                            <tr>
                                <th><?php _e('IP Address', 'bot-eraser'); ?></th>
                                <th><?php _e('Timestamp', 'bot-eraser'); ?></th>
                                <th><?php _e('Request', 'bot-eraser'); ?></th>
                                <th><?php _e('Status', 'bot-eraser'); ?></th>
                                <th><?php _e('User Agent', 'bot-eraser'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td>
                                        <span class="ip-address"><?php echo esc_html($log['ip']); ?></span>
                                    </td>
                                    <td>
                                        <span style="font-size: 12px; color: var(--be-gray-600);">
                                            <?php echo esc_html($log['timestamp']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="request-path"><?php echo esc_html($log['request']); ?></span>
                                    </td>
                                    <td>
                                        <?php
                                        $status = intval($log['status']);
                                        $status_class = 'status-2xx';
                                        if ($status >= 300 && $status < 400) $status_class = 'status-3xx';
                                        elseif ($status >= 400 && $status < 500) $status_class = 'status-4xx';
                                        elseif ($status >= 500) $status_class = 'status-5xx';
                                        ?>
                                        <span class="status-badge <?php echo esc_attr($status_class); ?>">
                                            <?php echo esc_html($log['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="user-agent" title="<?php echo esc_attr($log['user_agent']); ?>">
                                            <?php echo esc_html($log['user_agent']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="boteraser-pagination">
                        <div class="boteraser-pagination-info">
                            <?php printf(
                                __('Showing %s - %s of %s entries', 'bot-eraser'),
                                number_format(($current_page - 1) * $per_page + 1),
                                number_format(min($current_page * $per_page, $total_lines)),
                                number_format($total_lines)
                            ); ?>
                        </div>
                        <div class="boteraser-pagination-links">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg(array('paged' => '%#%', 'per_page' => $per_page)),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ));
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
