<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('bot_eraser_build_signals')) {

function bot_eraser_extract_bot_name(string $ua, array $config): string {
    $ua = trim($ua);
    if ($ua === '') return '';
    foreach (['ua_claims_bot', 'ua_fake'] as $key) {
        if (!empty($config['patterns'][$key]) && preg_match($config['patterns'][$key], $ua, $m)) {
            return trim($m[0], " \t/");
        }
    }
    if (!empty($config['waf']['scanner']) && is_string($config['waf']['scanner'])
        && preg_match($config['waf']['scanner'], $ua, $m)) {
        return trim($m[0]);
    }
    if (preg_match('/([A-Za-z][A-Za-z0-9._\-]*(?:bot|crawler|spider|scraper|agent))(?=[\/ ;)]|$)/i', $ua, $m)) {
        return $m[1];
    }
    return '';
}

function bot_eraser_build_signals(array $ctx, array $config): array {
    $t  = [];
    $ua = trim((string) ($ctx['ua'] ?? ''));

    if (!empty($ctx['is_self'])) {
        return [];
    }

    switch ($ctx['wba_status'] ?? 'none') {
        case 'verified':
            return [];
        case 'forged':
            $t[] = 'forged_signature';
            break;
        case 'unverifiable':
            $t[] = 'invalid_signature';
            break;
    }

    $claims_bot = $ua !== '' && (bool) preg_match($config['patterns']['ua_claims_bot'], $ua);
    $ptr_known = array_key_exists('ptr', $ctx);

    if ($claims_bot) {
        $ptr = $ctx['ptr'] ?? false;
        if ($ptr_known && $ptr !== false && !empty($ctx['fcrdns_ok'])) {
            return [];
        }
        $t[] = 'crawler_unverified';
        if ($ptr_known) {
            $t[] = ($ptr === false) ? 'bad_ptr' : 'fcrdns_fail';
        }
    } else {
        if ($ua === '-') {
            $t[] = 'fake_ua';
        } elseif ($ua !== '' && preg_match($config['patterns']['ua_fake'], $ua)) {
            $t[] = 'fake_ua';
        }
    }

    $h = $ctx['headers'] ?? [];
    if (empty($h['sec_fetch_site']) && empty($h['sec_fetch_mode']) && empty($h['sec_fetch_dest'])) {
        $t[] = 'no_sec_fetch';
    }
    if (empty($h['accept_language']))            $t[] = 'no_accept_lang';
    if (empty($h['accept']))                     $t[] = 'no_accept';
    if (strtolower($h['connection'] ?? '') === 'close') $t[] = 'conn_close';
    if (empty($h['accept_encoding']))            $t[] = 'no_accept_enc';
    if ($ua === '')                              $t[] = 'empty_ua';

    $omitted = count(array_intersect(
        ['no_sec_fetch', 'no_accept_lang', 'no_accept', 'no_accept_enc', 'conn_close'],
        $t
    ));
    if ($omitted >= $config['header_mismatch_min']) {
        $t[] = 'header_mismatch';
    }

    if ((int) ($ctx['request_count'] ?? 0) > $config['rate_limit']) {
        $t[] = 'high_rate';
    }

    if (!$claims_bot && !empty($ctx['js_missing'])) {
        $t[] = 'js_missing';
    }

    $failed_signal_min = (int) ($ctx['bf_max'] ?? $config['bf']['signal_min']);
    if ($failed_signal_min > 0 && (int) ($ctx['failed_count'] ?? 0) >= $failed_signal_min) {
        $t[] = 'failed_logins';
    }

    if (!$claims_bot && !empty($t) && $ptr_known) {
        $ptr = $ctx['ptr'];
        if ($ptr === false) {
            $t[] = 'bad_ptr';
        } elseif (isset($ctx['fcrdns_ok']) && $ctx['fcrdns_ok'] === false) {
            $t[] = 'fcrdns_fail';
        }
    }

    $t = array_merge($t, bot_eraser_waf_signals($ctx, $config));

    if (!empty($ctx['honeypot_url']))   $t[] = 'honeypot_url';
    if (!empty($ctx['honeypot_field'])) $t[] = 'honeypot';

    if (!empty($ctx['js']) && is_array($ctx['js'])) {
        $t = array_merge($t, bot_eraser_js_signals($ctx['js'], $ua, $config));
    }

    return array_values(array_unique($t));
}

function bot_eraser_waf_signals(array $ctx, array $config): array {
    $t   = [];
    $waf = $config['waf'];
    $ua  = (string) ($ctx['ua'] ?? '');

    if ($ua !== '' && !empty($waf['scanner']) && bot_eraser_waf_match($waf['scanner'], $ua)) {
        $t[] = 'scanner_detected';
    }

    $path  = (string) ($ctx['request_path'] ?? '');
    $query = (string) ($ctx['query_string'] ?? '');

    $target = rawurldecode($path);
    if (!empty($waf['scan_query']) && $query !== '') {
        $target .= ' ' . rawurldecode($query);
    }

    $checks = [
        'path_traversal' => 'path_traversal',
        'lfi'            => 'lfi_attempt',
        'sqli'           => 'sqli_injection',
        'xss'            => 'xss_injection',
        'rce'            => 'rce_injection',
        'rfi'            => 'rfi_attempt',
        'php'            => 'php_injection',
        'ssti'           => 'ssti_injection',
        'protocol'       => 'protocol_anomaly',
    ];
    $sig_map = $checks + ['scanner' => 'scanner_detected'];

    $crs_hits = [];
    if ($target !== '') {
        foreach ($checks as $cat => $signal) {
            if (empty($waf[$cat]) || !bot_eraser_waf_match($waf[$cat], $target)) {
                continue;
            }
            if (is_array($waf[$cat])) {
                $crs_hits[] = $signal;
            } else {
                $t[] = $signal;
            }
        }
    }

    $scoped = $waf['_scoped'] ?? null;
    if (is_array($scoped)) {
        $method = strtoupper(trim((string) ($ctx['method'] ?? '')));
        if ($method !== '' && !empty($scoped['method'])) {
            foreach ($scoped['method'] as $cat => $pats) {
                if (bot_eraser_waf_match($pats, $method)) {
                    $crs_hits[] = $sig_map[$cat] ?? $cat;
                }
            }
        }

        $cookie = (string) ($ctx['cookie_header'] ?? '');
        if ($cookie !== '' && !empty($scoped['cookies'])) {
            foreach ($scoped['cookies'] as $cat => $pats) {
                if (bot_eraser_waf_match($pats, $cookie)) {
                    $crs_hits[] = $sig_map[$cat] ?? $cat;
                }
            }
        }

        $hv = $ctx['waf_headers'] ?? [];
        if (!empty($scoped['headers']) && is_array($hv) && $hv) {
            foreach ($scoped['headers'] as $hname => $cats) {
                if ($hname === '*') {
                    $subject = implode(' ', array_map('strval', $hv));
                } elseif (isset($hv[$hname]) && $hv[$hname] !== '') {
                    $subject = (string) $hv[$hname];
                } else {
                    continue;
                }
                if ($subject === '') {
                    continue;
                }
                foreach ($cats as $cat => $pats) {
                    if (bot_eraser_waf_match($pats, $subject)) {
                        $crs_hits[] = $sig_map[$cat] ?? $cat;
                    }
                }
            }
        }
    }

    $crs_hits = array_values(array_unique($crs_hits));
    if (count($crs_hits) >= (int) ($waf['crs_min'] ?? 2)) {
        $t = array_merge($t, $crs_hits);
    }

    return $t;
}

function bot_eraser_waf_match($patterns, string $subject): bool {
    if (is_string($patterns)) {
        return $patterns !== '' && @preg_match($patterns, $subject) === 1;
    }
    if (is_array($patterns)) {
        foreach ($patterns as $p) {
            if ($p !== '' && @preg_match($p, $subject) === 1) {
                return true;
            }
        }
    }
    return false;
}

function bot_eraser_js_signals(array $js, string $ua, array $config): array {
    $t = [];
    $has = function ($k) use ($js) { return array_key_exists($k, $js); };

    if (!empty($js['webdriver']))          $t[] = 'webdriver';
    if (!empty($js['phantom']))            $t[] = 'phantom';
    if (!empty($js['nightmare']))          $t[] = 'nightmare';
    if (!empty($js['dom_automation']))     $t[] = 'dom_automation';
    if (!empty($js['selenium']))           $t[] = 'selenium';
    if (!empty($js['fxdriver']))           $t[] = 'fxdriver';
    if (!empty($js['selenium_unwrapped'])) $t[] = 'selenium_unwrapped';
    if (!empty($js['awesomium']))          $t[] = 'awesomium';

    $is_mobile = !empty($js['is_mobile']);

    if ($has('webgl') && $js['webgl'] !== '' && preg_match($config['patterns']['webgl_headless'], (string) $js['webgl'])) {
        $t[] = 'headless_webgl';
    }
    if ($has('canvas') && $js['canvas'] === '') {
        $t[] = 'headless_canvas';
    }
    if ($has('fonts') && (int) $js['fonts'] !== -1 && (int) $js['fonts'] < $config['min_fonts']) {
        $t[] = 'no_fonts';
    }
    if ($has('audio') && $js['audio'] === '') {
        $t[] = 'no_audio';
    }
    if (!$is_mobile && $has('hardware') && (int) $js['hardware'] > 0 && (int) $js['hardware'] <= $config['min_hardware']) {
        $t[] = 'no_hardware';
    }
    if (!$is_mobile && $has('plugins') && (int) $js['plugins'] === 0) {
        $t[] = 'no_plugins';
    }

    if ($has('mouse_moved') && empty($js['mouse_moved']))   $t[] = 'no_mouse';
    if ($has('load_to_submit_ms') && (int) $js['load_to_submit_ms'] > 0
        && (int) $js['load_to_submit_ms'] < $config['fast_submit_ms']) {
        $t[] = 'fast_submit';
    }
    if ($has('page_tall') && !empty($js['page_tall']) && empty($js['scrolled'])) $t[] = 'no_scroll';
    if ($has('focus_had_mouse') && empty($js['focus_had_mouse']) && empty($js['mouse_moved'])) $t[] = 'focus_no_mouse';
    if (!empty($js['perfect_order']))                       $t[] = 'perfect_order';
    if ($has('languages') && (int) $js['languages'] === 0)  $t[] = 'no_languages';
    if (!empty($js['mouse_linear']))                         $t[] = 'mouse_trajectory';

    if (!empty($js['honeypot_field'])) $t[] = 'honeypot';

    return $t;
}

function bot_eraser_login_evaluate(array $ctx, array $config): array {
    $max   = (int) ($ctx['bf_max'] ?? $config['bf']['max_attempts']);
    $count = (int) ($ctx['failed_count'] ?? 0);
    return [
        'lockout'   => $max > 0 && $count >= $max,
        'count'     => $count,
        'threshold' => $max,
    ];
}

} // function_exists guard
