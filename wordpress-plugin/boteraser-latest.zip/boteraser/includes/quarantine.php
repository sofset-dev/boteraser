<?php
/**
 * Boteraser Quarantine
 *
 * Manages files moved to wp-content/uploads/boteraser/quarantine/ with a JSON
 * manifest so users can list, restore, download or delete them later.
 */

if (!defined('ABSPATH')) exit;

/**
 * Absolute path to the quarantine directory (with trailing slash).
 */
function boteraser_quarantine_dir() {
    return WP_CONTENT_DIR . '/uploads/boteraser/quarantine/';
}

/**
 * Absolute path to the manifest file.
 */
function boteraser_quarantine_manifest_path() {
    return boteraser_quarantine_dir() . 'manifest.json';
}

/**
 * Ensure the quarantine directory exists with the protective files.
 */
function boteraser_quarantine_ensure_dir() {
    $dir = boteraser_quarantine_dir();
    if (!is_dir($dir)) {
        wp_mkdir_p($dir);
        file_put_contents($dir . '.htaccess', "deny from all\n");
        file_put_contents($dir . 'index.php', "<?php // silence\n");
        file_put_contents($dir . 'web.config', "<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n");
    }
    return $dir;
}

/**
 * Load the manifest array.
 */
function boteraser_quarantine_load_manifest() {
    $path = boteraser_quarantine_manifest_path();
    if (!file_exists($path)) return array();
    $raw = file_get_contents($path);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : array();
}

/**
 * Save the manifest array atomically.
 */
function boteraser_quarantine_save_manifest($manifest) {
    $path = boteraser_quarantine_manifest_path();
    $tmp  = $path . '.tmp';
    file_put_contents($tmp, wp_json_encode(array_values($manifest), JSON_PRETTY_PRINT));
    @rename($tmp, $path);
}

/**
 * Move a file into quarantine and append a manifest entry.
 *
 * @param string $full_path Absolute path of the source file.
 * @param string $rel_path  Path relative to ABSPATH (used for restore).
 * @param string $severity  Optional severity label captured at quarantine time.
 * @return array|WP_Error   On success returns entry, on failure WP_Error.
 */
function boteraser_quarantine_move($full_path, $rel_path, $severity = '', $deactivated_plugin = null) {
    $dir = boteraser_quarantine_ensure_dir();

    $size = file_exists($full_path) ? filesize($full_path) : 0;
    $hash = file_exists($full_path) ? @md5_file($full_path) : '';

    $stored_name = date('Ymd-His') . '-' . wp_unique_filename($dir, basename($full_path));
    $dest        = $dir . $stored_name;

    if (!@rename($full_path, $dest)) {
        return new WP_Error('quarantine_move_failed', 'Could not move file. Check permissions.');
    }

    $manifest = boteraser_quarantine_load_manifest();
    $entry = array(
        'id'                 => uniqid('q_', true),
        'stored_name'        => $stored_name,
        'original_path'      => ltrim($rel_path, '/'),
        'severity'           => strtoupper($severity),
        'size'               => (int) $size,
        'hash'               => $hash,
        'quarantined_at'     => time(),
        'deactivated_plugin' => $deactivated_plugin,
    );
    $manifest[] = $entry;
    boteraser_quarantine_save_manifest($manifest);

    boteraser_send_quarantine_report($entry);

    return $entry;
}

/**
 * List quarantine entries, with on-disk reconciliation.
 * Removes manifest rows whose file no longer exists.
 */
function boteraser_quarantine_list() {
    $manifest = boteraser_quarantine_load_manifest();
    $dir = boteraser_quarantine_dir();
    $changed = false;

    $alive = array();
    foreach ($manifest as $entry) {
        $stored = $entry['stored_name'] ?? '';
        if (!$stored) { $changed = true; continue; }
        if (!file_exists($dir . $stored)) { $changed = true; continue; }
        $alive[] = $entry;
    }

    if ($changed) {
        boteraser_quarantine_save_manifest($alive);
    }

    usort($alive, function($a, $b) {
        return ($b['quarantined_at'] ?? 0) <=> ($a['quarantined_at'] ?? 0);
    });

    return $alive;
}

/**
 * Find a single entry by stored_name.
 */
function boteraser_quarantine_find($stored_name) {
    $manifest = boteraser_quarantine_load_manifest();
    foreach ($manifest as $entry) {
        if (($entry['stored_name'] ?? '') === $stored_name) return $entry;
    }
    return null;
}

/**
 * Restore a file from quarantine to its original path.
 */
function boteraser_quarantine_restore($stored_name) {
    $entry = boteraser_quarantine_find($stored_name);
    if (!$entry) return new WP_Error('quarantine_not_found', 'Entry not found in manifest.');

    $src  = boteraser_quarantine_dir() . $entry['stored_name'];
    if (!file_exists($src)) return new WP_Error('quarantine_missing', 'Quarantined file is missing on disk.');

    $original_rel = ltrim($entry['original_path'] ?? '', '/');
    if (!$original_rel) return new WP_Error('quarantine_no_origin', 'Original path is unknown.');

    $dest = ABSPATH . $original_rel;

    $real_dest_dir = realpath(dirname($dest));
    $real_abspath = realpath(ABSPATH);
    if (!$real_dest_dir || !$real_abspath || strpos($real_dest_dir, $real_abspath) !== 0) {
        return new WP_Error('quarantine_path_traversal', 'Path traversal detected.');
    }

    if (file_exists($dest)) {
        return new WP_Error('quarantine_dest_exists', 'A file already exists at the original location. Resolve manually first.');
    }

    $parent = dirname($dest);
    if (!is_dir($parent)) {
        if (!wp_mkdir_p($parent)) {
            return new WP_Error('quarantine_mkdir_failed', 'Could not create the destination directory.');
        }
    }

    if (!@rename($src, $dest)) {
        return new WP_Error('quarantine_restore_failed', 'Could not move file. Check permissions.');
    }

    $manifest = boteraser_quarantine_load_manifest();
    $manifest = array_values(array_filter($manifest, function($e) use ($stored_name) {
        return ($e['stored_name'] ?? '') !== $stored_name;
    }));
    boteraser_quarantine_save_manifest($manifest);

    if (!empty($entry['deactivated_plugin'])) {
        if (!function_exists('activate_plugin')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        activate_plugin($entry['deactivated_plugin']);
    }

    boteraser_send_quarantine_update($entry['original_path'] ?? '', 'restored');

    return $entry;
}

/**
 * Permanently delete a quarantined file.
 */
function boteraser_quarantine_delete($stored_name) {
    $entry = boteraser_quarantine_find($stored_name);
    if (!$entry) return new WP_Error('quarantine_not_found', 'Entry not found in manifest.');

    $path = boteraser_quarantine_dir() . $entry['stored_name'];
    if (file_exists($path) && !@unlink($path)) {
        return new WP_Error('quarantine_delete_failed', 'Could not delete file.');
    }

    $manifest = boteraser_quarantine_load_manifest();
    $manifest = array_values(array_filter($manifest, function($e) use ($stored_name) {
        return ($e['stored_name'] ?? '') !== $stored_name;
    }));
    boteraser_quarantine_save_manifest($manifest);

    boteraser_send_quarantine_update($entry['original_path'] ?? '', 'deleted');

    return $entry;
}

/* ---------------------------------------------------------------------
 * Server reporting
 * --------------------------------------------------------------------- */

/**
 * Notify the hash server that a quarantined file was restored or deleted.
 */
function boteraser_send_quarantine_update(string $original_path, string $status): void
{
    if (!defined('BOT_ERASER_HASH_SERVER_URL')) return;

    global $wpdb;
    $api_key = $wpdb->get_var($wpdb->prepare(
        "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
        'bot_eraser_api_key'
    ));
    if (empty($api_key)) return;

    $domain = get_option('bot_eraser_domain');
    if (empty($domain)) {
        $domain = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '';
        $domain = preg_replace('/^www\./', '', $domain);
    }

    wp_remote_post(BOT_ERASER_HASH_SERVER_URL, array(
        'body' => array(
            'api_key'       => $api_key,
            'domain'        => $domain,
            'action'        => 'quarantine_update',
            'original_path' => $original_path,
            'status'        => $status,
        ),
        'timeout'   => 8,
        'sslverify' => true,
        'blocking'  => false,
    ));
}

/**
 * Send a single quarantine entry to the hash server (fire-and-forget).
 * Format: severity|hash|size|original_path|quarantined_at
 */
function boteraser_send_quarantine_report(array $entry) {
    if (!defined('BOT_ERASER_HASH_SERVER_URL')) return;

    global $wpdb;
    $api_key = $wpdb->get_var($wpdb->prepare(
        "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
        'bot_eraser_api_key'
    ));
    if (empty($api_key)) return;

    $domain = get_option('bot_eraser_domain');
    if (empty($domain)) {
        $domain = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '';
        $domain = preg_replace('/^www\./', '', $domain);
    }

    $line = implode('|', array(
        $entry['severity']       ?? '',
        $entry['size']           ?? 0,
        $entry['original_path']  ?? '',
        $entry['quarantined_at'] ?? time(),
    ));

    wp_remote_post(BOT_ERASER_HASH_SERVER_URL, array(
        'body' => array(
            'api_key' => $api_key,
            'domain'  => $domain,
            'action'  => 'quarantine_report',
            'entries' => $line,
            'count'   => 1,
        ),
        'timeout'   => 8,
        'sslverify' => true,
        'blocking'  => false,
    ));
}

/* ---------------------------------------------------------------------
 * AJAX handlers
 * --------------------------------------------------------------------- */

function boteraser_ajax_quarantine_list() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    wp_send_json_success(array('items' => boteraser_quarantine_list()));
}
add_action('wp_ajax_boteraser_quarantine_list', 'boteraser_ajax_quarantine_list');

function boteraser_ajax_quarantine_restore() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $stored_name = sanitize_file_name($_POST['stored_name'] ?? '');
    if (!$stored_name) wp_send_json_error('Invalid request.');

    $result = boteraser_quarantine_restore($stored_name);
    if (is_wp_error($result)) wp_send_json_error($result->get_error_message());

    wp_send_json_success(array('message' => 'File restored: ' . $result['original_path']));
}
add_action('wp_ajax_boteraser_quarantine_restore', 'boteraser_ajax_quarantine_restore');

function boteraser_ajax_quarantine_delete_entry() {
    check_ajax_referer('boteraser_scan_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $stored_name = sanitize_file_name($_POST['stored_name'] ?? '');
    if (!$stored_name) wp_send_json_error('Invalid request.');

    $result = boteraser_quarantine_delete($stored_name);
    if (is_wp_error($result)) wp_send_json_error($result->get_error_message());

    wp_send_json_success(array('message' => 'File permanently deleted.'));
}
add_action('wp_ajax_boteraser_quarantine_delete_entry', 'boteraser_ajax_quarantine_delete_entry');

/**
 * Stream a quarantined file as a download. Uses admin-post.php since
 * we need to send file bytes and headers, not JSON.
 */
function boteraser_quarantine_download_handler() {
    if (!current_user_can('manage_options')) wp_die('Unauthorized', 403);
    check_admin_referer('boteraser_quarantine_download');

    $stored_name = sanitize_file_name($_GET['stored_name'] ?? '');
    if (!$stored_name) wp_die('Invalid request.', 400);

    $entry = boteraser_quarantine_find($stored_name);
    if (!$entry) wp_die('Entry not found.', 404);

    $path = boteraser_quarantine_dir() . $entry['stored_name'];
    if (!file_exists($path)) wp_die('File missing on disk.', 404);

    nocache_headers();
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($path) . '.bin"');
    header('Content-Length: ' . filesize($path));
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}
add_action('admin_post_boteraser_quarantine_download', 'boteraser_quarantine_download_handler');
