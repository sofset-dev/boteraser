<?php
if (!defined('ABSPATH')) {
    exit;
}

function bot_eraser_create_log_file()
{
    $log_dir = dirname(BOT_ERASER_LOG_PATH);

    try {
        if (!file_exists($log_dir)) {
            if (!mkdir($log_dir, 0755, true)) {
                throw new Exception("Failed to create directory: {$log_dir}");
            }
        }

        if (!file_exists(BOT_ERASER_LOG_PATH)) {
            if (!touch(BOT_ERASER_LOG_PATH)) {
                throw new Exception("Failed to create file: " . BOT_ERASER_LOG_PATH);
            }
            chmod(BOT_ERASER_LOG_PATH, 0644);
        }

        return true;
    } catch (Exception $e) {
        error_log('Boteraser File Error: ' . $e->getMessage());
        return false;
    }
}

function bot_eraser_log_visitor()
{
    if (is_admin() || wp_doing_ajax()) return;

    try {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? // Cloudflare
            $_SERVER['HTTP_TRUE_CLIENT_IP'] ?? // Akamai and others
            $_SERVER['HTTP_X_REAL_IP'] ?? // Nginx proxy
            $_SERVER['HTTP_X_FORWARDED_FOR'] ?? // Standard proxy header
            $_SERVER['HTTP_X_FORWARDED'] ?? // Some proxy variants
            $_SERVER['HTTP_FORWARDED_FOR'] ?? // RFC 7239
            $_SERVER['HTTP_FORWARDED'] ?? // RFC 7239
            $_SERVER['HTTP_VIA'] ?? // Via proxy
            $_SERVER['HTTP_CLIENT_IP'] ?? // Client IP
            $_SERVER['HTTP_X_CLIENT_IP'] ?? // Some CDNs
            $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'] ?? // Load balancers
            $_SERVER['REMOTE_ADDR'] ?? // Direct IP
            '0.0.0.0';

        $ip = explode(',', $ip)[0];
        $ip = filter_var(trim($ip), FILTER_VALIDATE_IP) ?: '0.0.0.0';

        $log_entry = sprintf(
            '%s - - [%s] "%s %s %s" %d - "%s" "%s"',
            $ip,
            date('d/M/Y:H:i:s O'),
            $_SERVER['REQUEST_METHOD'] ?? '-',
            $_SERVER['REQUEST_URI'] ?? '-',
            $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.1',
            http_response_code() ?: 200,
            $_SERVER['HTTP_REFERER'] ?? '-',
            $_SERVER['HTTP_USER_AGENT'] ?? '-'
        );

        bot_eraser_write_log($log_entry);
    } catch (Exception $e) {
        error_log('Boteraser Visitor Log Error: ' . $e->getMessage());
    }
}

function bot_eraser_write_log($entry)
{
    try {
        if (!file_exists(BOT_ERASER_LOG_PATH) && !bot_eraser_create_log_file()) {
            return;
        }

        $log_entries = file(BOT_ERASER_LOG_PATH, FILE_IGNORE_NEW_LINES) ?: [];

        // Cleanup entries older than 30 days (fail-safe)
        $thirty_days_ago = time() - (30 * 24 * 60 * 60);
        $log_entries = array_filter($log_entries, function($line) use ($thirty_days_ago) {
            if (preg_match('/\[(\d{2}\/\w{3}\/\d{4}):(\d{2}:\d{2}:\d{2})/', $line, $matches)) {
                // Convert Apache log date format to timestamp
                // Format: 14/Jan/2026:19:09:04 -> 2026-01-14 19:09:04
                $log_timestamp = strtotime(str_replace('/', ' ', $matches[1]) . ' ' . $matches[2]);
                return $log_timestamp !== false && $log_timestamp > $thirty_days_ago;
            }
            return true; // Keep entries without valid timestamp
        });

        // Limit to 10000 entries
        if (count($log_entries) >= 10000) {
            $log_entries = array_slice($log_entries, -9999);
        }
        $log_entries[] = $entry;

        file_put_contents(BOT_ERASER_LOG_PATH, implode("\n", $log_entries) . "\n", LOCK_EX);
    } catch (Exception $e) {
        error_log('Boteraser Write Error: ' . $e->getMessage());
    }
}

function bot_eraser_parse_log()
{
    $result = [
        'data' => '',
        'srv_load' => 0,
        'uptime' => 0,
        'error' => ''
    ];

    try {
        $load = sys_getloadavg();
        $result['srv_load'] = number_format($load[1], 2);
        $uptime = @file_get_contents('/proc/uptime');
        $result['uptime'] = $uptime ? intval(explode(' ', $uptime)[0]) : 0;

        $log_entries = file(BOT_ERASER_LOG_PATH, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $ip_bot_counts = [];

        foreach ($log_entries as $entry) {
            if (preg_match('/^(\S+).*"(.*?)"$/', $entry, $matches)) {
                $ip = $matches[1];
                $user_agent = $matches[2];

                $bot_name = bot_eraser_detect_bot_name($user_agent);
                $key = "{$ip}|{$bot_name}";
                $ip_bot_counts[$key] = ($ip_bot_counts[$key] ?? 0) + 1;
            }
        }

        $lines = [];
        foreach ($ip_bot_counts as $key => $count) {
            list($ip, $bot) = explode('|', $key);
            $lines[] = sprintf("%d %s %s", $count, $ip, $bot);
        }
        arsort($lines);
        $lines = array_slice($lines, 0, 30); // Keep only top 30 results
        $result['data'] = implode("\n", $lines);
    } catch (Exception $e) {
        $result['error'] = $e->getMessage();
    }

    return $result;
}

function bot_eraser_detect_bot_name($user_agent)
{
    // First check for "compatible; BOT_NAME" pattern
    if (preg_match('/compatible; ([^\/;]+)/i', $user_agent, $matches)) {
        $bot = explode('/', trim($matches[1]))[0];
        return preg_replace('/[^a-zA-Z0-9]/', '', $bot);
    }

    // Then check general bot patterns
    if (preg_match('/(bot|spider|crawl|slurp)[\/\s]?([a-z0-9]+)?/i', $user_agent, $matches)) {
        $bot = !empty($matches[2]) ? $matches[2] : $matches[1];
        return preg_replace('/[^a-zA-Z0-9]/', '', $bot);
    }

    return 'no_bot_name';
}

/**
 * Log a plugin execution (manual or cron)
 * 
 * @param array $entry {
 *     @type string $status success|error|warning
 *     @type string $message The execution message
 *     @type string $type manual|cron
 * }
 */
function bot_eraser_log_execution($entry) {
    $history = get_option('bot_eraser_execution_history', []);
    if (!is_array($history)) {
        $history = [];
    }

    $new_entry = [
        'timestamp' => current_time('mysql'),
        'status' => $entry['status'] ?? 'info',
        'message' => $entry['message'] ?? '',
        'type' => $entry['type'] ?? 'unknown'
    ];

    // Add to beginning of array
    array_unshift($history, $new_entry);

    // Keep only last 10 entries
    $history = array_slice($history, 0, 10);

    update_option('bot_eraser_execution_history', $history);
}

/**
 * Get recent execution history
 * 
 * @return array
 */
function bot_eraser_get_execution_history() {
    return get_option('bot_eraser_execution_history', []);
}
