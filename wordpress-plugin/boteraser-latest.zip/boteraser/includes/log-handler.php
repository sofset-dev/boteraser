<?php
if (!defined('ABSPATH')) {
    exit;
}

function bot_eraser_create_log_file()
{
    $log_dir = dirname(BOT_ERASER_LOG_PATH);

    try {
        if (!file_exists($log_dir)) {
            if (!mkdir($log_dir, 0755, true)) {
                throw new Exception("Failed to create directory: {$log_dir}");
            }
        }

        if (!file_exists(BOT_ERASER_LOG_PATH)) {
            if (!touch(BOT_ERASER_LOG_PATH)) {
                throw new Exception("Failed to create file: " . BOT_ERASER_LOG_PATH);
            }
            chmod(BOT_ERASER_LOG_PATH, 0644);
        }

        return true;
    } catch (Exception $e) {
        error_log('Boteraser File Error: ' . $e->getMessage());
        return false;
    }
}

function bot_eraser_log_visitor()
{
    if (is_admin() || wp_doing_ajax()) return;

    try {
        $ip = bot_eraser_get_visitor_ip();

        $log_entry = sprintf(
            '%s - - [%s] "%s %s %s" %d - "%s" "%s"',
            $ip,
            date('d/M/Y:H:i:s O'),
            $_SERVER['REQUEST_METHOD'] ?? '-',
            $_SERVER['REQUEST_URI'] ?? '-',
            $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.1',
            http_response_code() ?: 200,
            $_SERVER['HTTP_REFERER'] ?? '-',
            $_SERVER['HTTP_USER_AGENT'] ?? '-'
        );

        bot_eraser_write_log($log_entry);
    } catch (Exception $e) {
        error_log('Boteraser Visitor Log Error: ' . $e->getMessage());
    }
}

function bot_eraser_write_log($entry)
{
    try {
        if (!file_exists(BOT_ERASER_LOG_PATH) && !bot_eraser_create_log_file()) {
            return;
        }

        $handle = fopen(BOT_ERASER_LOG_PATH, 'a');
        if (!$handle) {
            return;
        }
        for ($attempt = 0; $attempt < 4; $attempt++) {
            if (flock($handle, LOCK_EX | LOCK_NB)) {
                fwrite($handle, $entry . "\n");
                flock($handle, LOCK_UN);
                break;
            }
            usleep(20000);
        }
        fclose($handle);
    } catch (Exception $e) {
        error_log('Boteraser Write Error: ' . $e->getMessage());
    }
}

/**
 * Cleanup log file - called by cron job only (bot_eraser_cron_hook, every 5 min)
 * Removes entries older than 30 days and limits to 10000 entries
 */
function bot_eraser_cleanup_log_file()
{
    $handle = null;
    try {
        if (!file_exists(BOT_ERASER_LOG_PATH)) {
            return;
        }

        // Read and rewrite under one exclusive lock on the same inode, so a
        // concurrent append can never observe or write back a partial file.
        $handle = fopen(BOT_ERASER_LOG_PATH, 'c+');
        if (!$handle || !flock($handle, LOCK_EX)) {
            if ($handle) {
                fclose($handle);
            }
            return;
        }

        $contents = stream_get_contents($handle);
        if ($contents === false || $contents === '') {
            flock($handle, LOCK_UN);
            fclose($handle);
            return;
        }
        $log_entries = explode("\n", rtrim($contents, "\n"));

        // Cleanup entries older than retention period, and drop lines that are
        // not a complete log record (leftovers from earlier torn rewrites).
        $retention_ago = time() - (BOT_ERASER_LOG_RETENTION_DAYS * 24 * 60 * 60);
        $log_entries = array_filter($log_entries, function($line) use ($retention_ago) {
            if (!preg_match('/^\S+ - - \[[^\]]+\] ".*" \d+ - ".*" ".*"$/', $line)) {
                return false;
            }
            if (preg_match('/\[(\d{2}\/\w{3}\/\d{4}):(\d{2}:\d{2}:\d{2})/', $line, $matches)) {
                $log_timestamp = strtotime(str_replace('/', ' ', $matches[1]) . ' ' . $matches[2]);
                return $log_timestamp !== false && $log_timestamp > $retention_ago;
            }
            return true;
        });

        // Limit to max entries
        if (count($log_entries) > BOT_ERASER_LOG_MAX_ENTRIES) {
            $log_entries = array_slice($log_entries, -BOT_ERASER_LOG_MAX_ENTRIES);
        }

        $payload = $log_entries ? implode("\n", $log_entries) . "\n" : '';
        ftruncate($handle, 0);
        rewind($handle);
        fwrite($handle, $payload);
        fflush($handle);
        flock($handle, LOCK_UN);
        fclose($handle);
        $handle = null;
    } catch (Exception $e) {
        if ($handle) {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
        error_log('Boteraser Log Cleanup Error: ' . $e->getMessage());
    }
}

function bot_eraser_parse_log()
{
    $result = [
        'data' => '',
        'srv_load' => 0,
        'uptime' => 0,
        'error' => ''
    ];

    try {
        $load = sys_getloadavg();
        $result['srv_load'] = number_format($load[1], 2);
        $uptime = @file_get_contents('/proc/uptime');
        $result['uptime'] = $uptime ? intval(explode(' ', $uptime)[0]) : 0;

        $log_entries = file(BOT_ERASER_LOG_PATH, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        $counts = [];

        foreach ($log_entries as $entry) {
            if (!preg_match('/^(\S+).*\[(\d{2}\/\w{3}\/\d{4}):(\d{2}:\d{2}:\d{2})\s[^\]]*\].*"(.*?)"$/', $entry, $matches)) {
                continue;
            }
            $ip = $matches[1];
            $log_timestamp = strtotime(str_replace('/', ' ', $matches[2]) . ' ' . $matches[3]);
            $user_agent = $matches[4];

            if ($log_timestamp === false) {
                continue;
            }

            $bot_name = bot_eraser_detect_bot_name($user_agent);
            $key = "{$ip}|{$bot_name}";

            if (!isset($counts[$key])) {
                $counts[$key] = 0;
            }
            $counts[$key]++;
        }

        $lines = [];
        foreach ($counts as $key => $count) {
            list($ip, $bot) = explode('|', $key);
            $lines[] = sprintf("%d %s %s", $count, $ip, $bot);
        }
        arsort($lines);
        $lines = array_slice($lines, 0, 30); // Keep only top 30 results
        $result['data'] = implode("\n", $lines);
    } catch (Exception $e) {
        $result['error'] = $e->getMessage();
    }

    return $result;
}

function bot_eraser_detect_bot_name($user_agent)
{
    // First check for "compatible; BOT_NAME" pattern
    if (preg_match('/compatible; ([^\/;]+)/i', $user_agent, $matches)) {
        $bot = explode('/', trim($matches[1]))[0];
        return preg_replace('/[^a-zA-Z0-9]/', '', $bot);
    }

    // Specific check for Boteraser (own service, not a third-party bot)
    if (stripos($user_agent, 'Boteraser') !== false) {
        return 'Boteraser';
    }

    // Then check general bot patterns
    if (preg_match('/(bot|spider|crawl|slurp)[\/\s]?([a-z0-9]+)?/i', $user_agent, $matches)) {
        $bot = !empty($matches[2]) ? $matches[2] : $matches[1];
        return preg_replace('/[^a-zA-Z0-9]/', '', $bot);
    }

    return 'N/A';
}

/**
 * Log a plugin execution (manual or cron)
 * 
 * @param array $entry {
 *     @type string $status success|error|warning
 *     @type string $message The execution message
 *     @type string $type manual|cron
 * }
 */
function bot_eraser_log_execution($entry) {
    $history = get_option('bot_eraser_execution_history', []);
    if (!is_array($history)) {
        $history = [];
    }

    $new_entry = [
        'timestamp' => current_time('mysql'),
        'status' => $entry['status'] ?? 'info',
        'message' => $entry['message'] ?? '',
        'type' => $entry['type'] ?? 'unknown'
    ];

    // Add to beginning of array
    array_unshift($history, $new_entry);

    // Keep only last 10 entries
    $history = array_slice($history, 0, 10);

    update_option('bot_eraser_execution_history', $history);
}

/**
 * Get recent execution history
 * 
 * @return array
 */
function bot_eraser_get_execution_history() {
    return get_option('bot_eraser_execution_history', []);
}

function bot_eraser_ajax_live_traffic_data() {
    if (!current_user_can('manage_options')) { wp_send_json_error('Permission denied', 403); }
    $log_file = BOT_ERASER_LOG_PATH;
    if (!file_exists($log_file)) { wp_send_json_success(array('buckets' => array(), 'latest' => array())); }
    $all = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $all = array_slice($all, -200);
    $now = time(); $window = 300;
    $buckets = array_fill(0, 60, array(0, 0, 0, 0, 0, array()));
    $latest_entries = array();
    foreach ($all as $line) {
        if (preg_match('/\[(\d{2}\/[A-Z][a-z]{2}\/\d{4}:\d{2}:\d{2}:\d{2})\s[+\-]\d{4}\]/', $line, $m)) {
            $ts = strtotime(str_replace('/', ' ', preg_replace('/^(\d{2})\/(\w{3})\/(\d{4}):/', '$1 $2 $3 ', $m[1])));
            if (!$ts) { try { $ts = (new DateTimeImmutable($m[1]))->getTimestamp(); } catch (\Exception $e) { continue; } }
            $age = $now - $ts;
            if ($age >= 0 && $age < $window) {
                $bucket = (int) (($window - $age) / ($window / 60));
                if ($bucket < 0) $bucket = 0; if ($bucket > 59) $bucket = 59;
                if (preg_match('/^(\S+)/', $line, $ipm)) { $buckets[$bucket][5][] = $ipm[1]; }
                if (preg_match('/"(\S+)\s/', $line, $req)) { $method = $req[1]; if ($method === 'GET') $buckets[$bucket][0]++; elseif ($method === 'POST') $buckets[$bucket][1]++; else $buckets[$bucket][2]++; } else { $buckets[$bucket][2]++; }
                if (preg_match('/" \d{3} /', $line, $sm)) { $code = (int) substr($sm[0], 2, 3); if ($code >= 500) $buckets[$bucket][3]++; elseif ($code >= 400) $buckets[$bucket][4]++; }
            }
        }
    }
    $last = array_slice($all, -6);
    foreach ($last as $l) { if (preg_match('/^(\S+).*"([^"]*)" (\d{3})/', $l, $lm)) { $latest_entries[] = array('ip' => $lm[1], 'path' => $lm[2], 'code' => (int) $lm[3]); } }
    wp_send_json_success(array('buckets' => $buckets, 'latest' => $latest_entries, 'now' => time()));
}
add_action('wp_ajax_boteraser_live_traffic', 'bot_eraser_ajax_live_traffic_data');

function bot_eraser_count_recent_log_entries($seconds = 3600) {
    $file = BOT_ERASER_LOG_PATH;
    if (!file_exists($file)) return 0;

    $handle = fopen($file, 'r');
    if (!$handle) return 0;

    fseek($handle, 0, SEEK_END);
    $pos = ftell($handle);
    $count = 0;
    $cutoff = time() - $seconds;
    $buffer = '';

    while ($pos > 0) {
        $read = min(4096, $pos);
        $pos -= $read;
        fseek($handle, $pos);
        $buffer = fread($handle, $read) . $buffer;
        $lines = explode("\n", $buffer);
        $buffer = array_shift($lines);

        foreach (array_reverse($lines) as $line) {
            if (empty($line)) continue;
            $ts = bot_eraser_parse_log_timestamp($line);
            if ($ts === false) continue;
            if ($ts < $cutoff) {
                fclose($handle);
                return $count;
            }
            $count++;
        }
    }

    fclose($handle);
    return $count;
}
