<?php
/**
 * Boteraser Upload Scanner
 * Automatically scans uploaded files, plugins, and themes for malware.
 * Sends email alert and shows admin popup warning if threats are detected.
 */

if (!defined('ABSPATH')) exit;

// Pull in scanner helpers so the upload scanner uses the same
// vendor-JS / minified-JS / trust-factor / softening logic that
// the main scanner already applies — without this, every plugin
// update triggers false-positive popups for legitimate plugins.
require_once __DIR__ . '/scanner/scan-files.php';
require_once __DIR__ . '/scanner/scan-risk-score.php';

/**
 * Scan a single file for malware indicators.
 * Returns array of findings, or empty array if clean.
 */
function boteraser_upload_scan_file($file_path, $rel_path = '') {
    if (!is_readable($file_path)) return array();

    $findings = array();
    $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    $basename = basename($file_path);

    // --- Pre-scan skip: known vendor & minified JS are false-positive
    //     factories. The main scanner already trusts them; do the same
    //     in the upload path so Elementor/React/Vite bundles don't
    //     fire a malware popup on every update.
    if ($ext === 'js') {
        if (function_exists('boteraser_is_known_vendor_js')
            && boteraser_is_known_vendor_js($rel_path)) {
            return array();
        }
        $size = filesize($file_path);
        if ($size > 0 && $size < 5 * 1024 * 1024) {
            $content = @file_get_contents($file_path);
            if ($content !== false
                && function_exists('boteraser_is_minified_js')
                && boteraser_is_minified_js($rel_path, $content)) {
                return array();
            }
            // JS-only checks: eval() in an inline <script> or
            // document.write(unescape(…)) — real XSS patterns, not
            // legitimate RegExp.exec / require('eval') etc.
            if (preg_match('/<script[^>]*>\s*function\s/', $content)) {
                // Heuristic: file looks like inline HTML+JS (rare in
                // plugins). Only then run the JS-specific patterns.
                if (preg_match('/<script[^>]*>[^<]*\beval\s*\(/i', $content)) {
                    $findings[] = array(
                        'type'    => 'js_eval',
                        'label'   => 'JavaScript eval in script tag',
                        'score'   => 70,
                        'details' => $rel_path ?: $basename,
                    );
                }
                if (preg_match('/document\.write\s*\(\s*unescape\s*\(/i', $content)) {
                    $findings[] = array(
                        'type'    => 'js_unescape',
                        'label'   => 'JS document.write+unescape',
                        'score'   => 75,
                        'details' => $rel_path ?: $basename,
                    );
                }
            }
        }
        return $findings;
    }

    // --- PHP-only checks below this line. JS files are already handled
    //     above, so PHP patterns never match .js RegExp.prototype.exec
    //     or require('eval') or other legitimate JS code.

    // PHP files in uploads = almost always malware
    // Only flag if the file is actually inside the uploads directory,
    // not in plugins/themes (which legitimately contain PHP files).
    if ($ext === 'php' || $ext === 'phtml' || $ext === 'phar') {
        $upload_dir   = wp_upload_dir();
        $in_uploads   = !empty($upload_dir['basedir'])
                        && strpos(realpath($file_path) ?: $file_path, $upload_dir['basedir']) === 0;
        if ($in_uploads) {
            // Skip silence stubs (<512 byte index.php placeholders)
            // that legitimate plugins drop to block direct browsing.
            $size_now = @filesize($file_path);
            if ($size_now !== false && $size_now < 512
                && function_exists('boteraser_integrity_is_silence_stub')
                && boteraser_integrity_is_silence_stub($file_path)) {
                // no-op — skip this file
            } elseif (function_exists('boteraser_is_known_plugin_uploads_dir')
                      && boteraser_is_known_plugin_uploads_dir($rel_path ?: (str_replace(ABSPATH, '', $file_path)))) {
                // PHP file belongs to a legitimate plugin's uploads
                // subdirectory — skip.
            } else {
                $findings[] = array(
                    'type'    => 'php_in_uploads',
                    'label'   => 'PHP file uploaded to media library',
                    'score'   => 90,
                    'details' => $rel_path ?: $basename,
                );
            }
        }
    }

    // Suspicious double extensions: file.php.jpg, file.ico.php etc.
    if (preg_match('/\.(php\.(jpg|jpeg|png|gif|ico)|ico\.php|shell\.php|jpg\.php|png\.php)$/i', $basename)) {
        $findings[] = array(
            'type'    => 'suspicious_extension',
            'label'   => 'Suspicious double extension',
            'score'   => 85,
            'details' => $basename,
        );
    }

    // Pattern scan for PHP files only (JS was handled above).
    // Patterns that are PHP-only (shell_exec, system, passthru,
    // base64_decode, gzinflate, etc.) must NOT run against JS files
    // — they produce massive false positives on minified bundles.
    if (in_array($ext, array('php', 'phtml', 'phar'), true)) {
        $size = filesize($file_path);
        if ($size > 0 && $size < 5 * 1024 * 1024) {
            $content = @file_get_contents($file_path);
            if ($content !== false) {
                $patterns = array(
                    '/eval\s*\(\s*base64_decode\s*\(/i'           => array('type' => 'eval_base64',       'label' => 'Obfuscated eval/base64 code',     'score' => 95),
                    '/eval\s*\(\s*gzinflate\s*\(/i'               => array('type' => 'eval_gzinflate',    'label' => 'Obfuscated eval/gzinflate code',  'score' => 95),
                    '/eval\s*\(\s*str_rot13\s*\(/i'               => array('type' => 'eval_rot13',        'label' => 'Obfuscated eval/rot13 code',      'score' => 90),
                    '/shell_exec\s*\(/i'                           => array('type' => 'shell_exec',        'label' => 'shell_exec() call detected',      'score' => 85),
                    '/system\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)/i'=> array('type' => 'system_input',     'label' => 'system() with user input',        'score' => 95),
                    '/passthru\s*\(/i'                             => array('type' => 'passthru',          'label' => 'passthru() call detected',        'score' => 80),
                    '/preg_replace\s*\(.*\/e[\'\"]/i'             => array('type' => 'preg_replace_e',   'label' => 'preg_replace /e modifier (RCE)',  'score' => 95),
                    '/\$_(GET|POST|REQUEST|COOKIE)\s*\[.*\]\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)/i'
                                                                   => array('type' => 'variable_func',    'label' => 'Variable function call from input','score' => 90),
                    '/assert\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)/i'=> array('type' => 'assert_input',     'label' => 'assert() with user input',        'score' => 90),
                );
                foreach ($patterns as $regex => $info) {
                    if (preg_match($regex, $content)) {
                        $findings[] = $info + array('details' => $rel_path ?: $basename);
                        break; // one critical finding per file is enough
                    }
                }
            }
        }
    }

    return $findings;
}

/**
 * Determine severity label from highest finding score.
 * Mirrors the main scanner thresholds (scan-risk-score.php).
 */
function boteraser_upload_scan_severity($findings) {
    $max = 0;
    foreach ($findings as $f) {
        $max = max($max, (int) ($f['score'] ?? 0));
    }
    // Same thresholds as scan-risk-score.php: >=71 HIGH, >=31 MEDIUM
    if ($max >= 71) return 'HIGH';
    if ($max >= 31) return 'MEDIUM';
    return 'LOW';
}

/**
 * Persist a malware alert so the admin popup can display it.
 */
function boteraser_upload_store_alert($type, $name, $findings, $severity) {
    $alerts   = get_option('boteraser_upload_alerts', array());
    $alerts[] = array(
        'type'     => $type,   // 'file', 'plugin', 'theme'
        'name'     => $name,
        'severity' => $severity,
        'findings' => $findings,
        'time'     => time(),
    );
    if (count($alerts) > 20) {
        $alerts = array_slice($alerts, -20);
    }
    update_option('boteraser_upload_alerts', $alerts, false);

    // Reset popup dismissed list so new alerts force the popup to reappear
    $dismissed = get_option('boteraser_upload_popup_dismissed', array());
    if (!empty($dismissed)) {
        delete_option('boteraser_upload_popup_dismissed');
    }
}

/**
 * Send upload malware alert to the hash server immediately upon detection.
 * Fire-and-forget — never blocks the upload flow.
 * Stores the alert in scan_statistics (same table as full scans) with
 * scan_type='upload' so all malware data lives in one place.
 */
function boteraser_upload_notify_server($type, $name, $findings, $severity) {
    if (!defined('BOT_ERASER_HASH_SERVER_URL')) return;

    global $wpdb;
    $api_key = $wpdb->get_var($wpdb->prepare(
        "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
        'bot_eraser_api_key'
    ));
    if (empty($api_key)) return;

    $domain = get_option('bot_eraser_domain');
    if (empty($domain)) {
        $domain = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '';
        $domain = preg_replace('/^www\./', '', $domain);
    }

    // Build pipe-delimited findings: type|label|score|details
    $finding_lines = array();
    foreach ($findings as $f) {
        $finding_lines[] = implode('|', array(
            $f['type']    ?? 'unknown',
            $f['label']   ?? '',
            $f['score']   ?? 0,
            $f['details'] ?? '',
        ));
    }

    wp_remote_post(BOT_ERASER_HASH_SERVER_URL, array(
        'body' => array(
            'api_key'     => $api_key,
            'domain'      => $domain,
            'action'      => 'upload_alert',
            'alert_type'  => $type,
            'alert_name'  => $name,
            'severity'    => $severity,
            'findings'    => implode("\n", $finding_lines),
            'detected_at' => time(),
            'wp_version'  => get_bloginfo('version'),
            'php_version' => phpversion(),
        ),
        'timeout'   => 8,
        'sslverify' => true,
        'blocking'  => false,
    ));
}

/**
 * Send malware alert email to site admin.
 */
function boteraser_upload_send_alert_email($type, $name, $findings, $severity) {
    $to        = get_option('boteraser_notify_email', get_option('admin_email'));
    $site      = get_bloginfo('name') ?: get_bloginfo('url');
    $logo_url  = 'https://boteraser.com/wp-content/plugins/boteraser/assets/images/logo-email.png';
    $panel_url = admin_url('admin.php?page=bot-eraser-scanner');
    $scan_time = date_i18n('d.m.Y H:i', time());

    $type_labels = array(
        'file'   => __('Uploaded File', 'bot-eraser'),
        'plugin' => __('Plugin', 'bot-eraser'),
        'theme'  => __('Theme', 'bot-eraser'),
    );
    $type_label = $type_labels[$type] ?? ucfirst($type);

    $subject = sprintf('[%s] ⚠️ Boteraser — Malware detected in uploaded %s', $site, strtolower($type_label));

    $severity_colors = array(
        'HIGH'   => array('bg' => '#fef2f2', 'border' => '#b91c1c33', 'text' => '#b91c1c'),
        'MEDIUM' => array('bg' => '#fffbeb', 'border' => '#b4530933', 'text' => '#b45309'),
        'LOW'    => array('bg' => '#f0fdf4', 'border' => '#16653433', 'text' => '#166534'),
    );
    $sc = $severity_colors[$severity] ?? $severity_colors['HIGH'];

    $findings_rows = '';
    foreach ($findings as $idx => $f) {
        $bg = $idx % 2 === 0 ? '#ffffff' : '#fafbfc';
        $findings_rows .= '<tr style="background:' . $bg . ';">'
            . '<td style="padding:10px 16px;font-size:13px;color:#1e293b;border-bottom:1px solid #f1f5f9;">' . esc_html($f['label'] ?? $f['type']) . '</td>'
            . '<td style="padding:10px 16px;font-size:12px;color:#64748b;border-bottom:1px solid #f1f5f9;">' . esc_html($f['details'] ?? '') . '</td>'
            . '</tr>';
    }

    $body = '<!doctype html><html lang="en"><head>'
        . '<meta charset="' . esc_attr(get_bloginfo('charset')) . '">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1">'
        . '</head>'
        . '<body style="margin:0;padding:0;background:#f5f7fa;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Arial,sans-serif;color:#1e293b;">'
        . '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f5f7fa;padding:36px 16px;">'
        . '<tr><td align="center">'
        . '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:620px;margin:0 auto;background:#ffffff;border-radius:16px;border:1px solid #e8edf2;overflow:hidden;">'

        // Header
        . '<tr><td style="border-top:4px solid #ef4444;padding:32px 36px 24px;text-align:left;">'
        . '<img src="' . esc_url($logo_url) . '" alt="Boteraser" style="display:block;width:130px;height:auto;margin-bottom:20px;">'
        . '<p style="margin:0 0 4px;font-size:11px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#94a3b8;">Security Alert</p>'
        . '<h1 style="margin:0 0 6px;font-size:22px;font-weight:700;color:#0f172a;">Malware Detected</h1>'
        . '<p style="margin:0;font-size:13px;color:#94a3b8;">' . esc_html($site) . ' &nbsp;&middot;&nbsp; ' . esc_html($scan_time) . '</p>'
        . '</td></tr>'

        // Alert banner
        . '<tr><td style="padding:0 36px 24px;">'
        . '<div style="padding:14px 18px;border-radius:10px;background:' . $sc['bg'] . ';border:1px solid ' . $sc['border'] . ';">'
        . '<span style="font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:' . $sc['text'] . ';">&#9888;&nbsp;&nbsp;' . esc_html($severity) . ' Severity</span>'
        . '<p style="margin:4px 0 0;font-size:13px;line-height:1.6;color:#475569;">'
        . sprintf(
            __('A <strong>%s</strong> named <strong>%s</strong> was uploaded and contains suspicious code. Immediate action is recommended.', 'bot-eraser'),
            esc_html($type_label),
            esc_html($name)
          )
        . '</p>'
        . '</div>'
        . '</td></tr>'

        // Findings table
        . '<tr><td style="padding:0 36px 24px;">'
        . '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #e8edf2;border-radius:10px;overflow:hidden;">'
        . '<tr style="background:#f8fafc;"><td colspan="2" style="padding:10px 16px;font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#64748b;border-bottom:1px solid #e8edf2;">Detected Threats</td></tr>'
        . $findings_rows
        . '</table>'
        . '</td></tr>'

        // CTA
        . '<tr><td style="padding:0 36px 32px;">'
        . '<a href="' . esc_url($panel_url) . '" style="display:inline-block;padding:12px 28px;border-radius:8px;background:#ef4444;color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;">View Scanner &amp; Take Action</a>'
        . '</td></tr>'

        // Footer
        . '<tr><td style="padding:20px 36px;border-top:1px solid #f1f5f9;background:#fafbfc;text-align:center;">'
        . '<p style="margin:0;font-size:12px;color:#94a3b8;">Powered by <strong style="color:#64748b;">Boteraser</strong> &nbsp;&middot;&nbsp; <a href="' . esc_url(home_url()) . '" style="color:#94a3b8;text-decoration:none;">' . esc_html(home_url()) . '</a></p>'
        . '</td></tr>'

        . '</table></td></tr></table>'
        . '</body></html>';

    $headers = array('Content-Type: text/html; charset=' . get_bloginfo('charset'));
    wp_mail($to, $subject, $body, $headers);
}

/**
 * Hook: scan every file uploaded via the media uploader.
 * Fires on wp_handle_upload after the file is saved to disk.
 */
function boteraser_is_premium_active() {
    $state = get_option('bot_eraser_api_validation_state', array());
    return !empty($state['is_valid']);
}

function boteraser_on_media_upload($upload, $context = 'upload') {
    if (!boteraser_is_premium_active()) return $upload;
    if (empty($upload['file']) || !empty($upload['error'])) {
        return $upload;
    }

    $file_path = $upload['file'];
    $rel_path  = str_replace(ABSPATH, '', $file_path);
    $name      = basename($file_path);

    $findings = boteraser_upload_scan_file($file_path, $rel_path);

    if (!empty($findings)) {
        $severity = boteraser_upload_scan_severity($findings);

        // Auto-quarantine uploaded file if enabled and severity is HIGH/MEDIUM
        $quarantined = array();
        if ($severity !== 'LOW') {
            $auto_q_enabled = (bool) get_option('boteraser_auto_quarantine_uploads', false);
            if ($auto_q_enabled && function_exists('boteraser_quarantine_move')) {
                require_once BOT_ERASER_PLUGIN_DIR . 'includes/quarantine.php';
                $result = boteraser_quarantine_move($file_path, $rel_path, $severity, null);
                if (!is_wp_error($result)) {
                    $quarantined[] = array(
                        'rel_path'    => $rel_path,
                        'stored_name' => $result['stored_name'],
                        'severity'    => $severity,
                    );
                }
            }
        }

        if (!empty($quarantined)) {
            foreach ($findings as &$f) {
                $f['_quarantined'] = true;
                $f['_quarantined_files'] = $quarantined;
            }
            unset($f);
        }

        boteraser_upload_store_alert('file', $name, $findings, $severity);
        boteraser_upload_send_alert_email('file', $name, $findings, $severity);
        boteraser_upload_notify_server('file', $name, $findings, $severity);
    }

    return $upload;
}
add_filter('wp_handle_upload', 'boteraser_on_media_upload', 10, 2);
add_filter('wp_handle_sideload', 'boteraser_on_media_upload', 10, 2);

/**
 * Hook: scan plugin after it is fully installed (before activation).
 * Fires on upgrader_process_complete for plugin installs/updates.
 */
function boteraser_on_upgrader_complete($upgrader, $hook_extra) {
    if (!boteraser_is_premium_active()) return;
    $type   = $hook_extra['type']   ?? '';
    $action = $hook_extra['action'] ?? '';

    if (!in_array($type, array('plugin', 'theme'), true)) return;
    if (!in_array($action, array('install', 'update'), true)) return;

    // Determine the installed path
    if ($type === 'plugin') {
        $destination = $upgrader->skin->result['destination'] ?? '';
        if (!$destination || !is_dir($destination)) return;
        $slug = basename($destination);
        boteraser_scan_installed_package('plugin', $slug, $destination);
    }

    if ($type === 'theme') {
        $destination = $upgrader->skin->result['destination'] ?? '';
        if (!$destination || !is_dir($destination)) return;
        $slug = basename($destination);
        boteraser_scan_installed_package('theme', $slug, $destination);
    }
}
add_action('upgrader_process_complete', 'boteraser_on_upgrader_complete', 10, 2);

/**
 * Recursively scan all PHP/JS files in an installed package directory.
 *
 * Applies the same vendor-JS / minified-JS / trust-factor / softening
 * logic that the main scanner uses, so legitimate plugin updates (like
 * Elementor) don't trigger false-positive malware popups.
 */
function boteraser_scan_installed_package($type, $slug, $dir) {
    if (!is_dir($dir)) return;

    $grouped = array();
    $stack   = array($dir);

    // More comprehensive skip list: these directories contain vendored
    // third-party code that should never be flagged as malware.
    $skip_dirs = array(
        'node_modules', 'vendor', '.git', 'dist', 'build',
        'assets/vendor', 'assets/lib', 'lib', 'libraries',
        'bower_components', 'packages',
    );

    while ($stack) {
        $current = array_pop($stack);
        $dh = @opendir($current);
        if (!$dh) continue;
        while (($entry = readdir($dh)) !== false) {
            if ($entry === '.' || $entry === '..') continue;
            $full = $current . '/' . $entry;
            $rel  = str_replace(ABSPATH, '', $full);
            if (is_dir($full)) {
                $skip = false;
                foreach ($skip_dirs as $skip_candidate) {
                    if ($entry === $skip_candidate
                        || strpos($rel, '/' . $skip_candidate . '/') !== false
                        || strpos($rel, '/' . $skip_candidate) === strlen($rel) - strlen('/' . $skip_candidate)) {
                        $skip = true;
                        break;
                    }
                }
                if (!$skip) {
                    $stack[] = $full;
                }
                continue;
            }
            if (!is_file($full)) continue;
            $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
            if (!in_array($ext, array('php', 'phtml', 'phar', 'js'), true)) continue;

            $hits = boteraser_upload_scan_file($full, $rel);

            // Group hits by file and apply risk scoring with trust
            // factor — same softening that the main scanner applies.
            foreach ($hits as $hit) {
                // Build a per-file finding group for risk calculation
                $file_key = $rel;
                if (!isset($grouped[$file_key])) {
                    $grouped[$file_key] = array(
                        'file'     => $rel,
                        'ext'      => $ext,
                        'findings' => array(),
                    );
                }
                $grouped[$file_key]['findings'][] = $hit;
            }

            // Stop after first 50 ungrouped raw hits to keep the scan fast
            $raw_count = 0;
            foreach ($grouped as $g) {
                $raw_count += count($g['findings']);
            }
            if ($raw_count >= 50) break 2;
        }
        closedir($dh);
    }

    if (empty($grouped)) return;

    // --- Apply risk scoring (same logic as main scanner) ---
    // Only keep findings that score HIGH or MEDIUM after trust/
    // softening adjustments. LOW findings from legitimate plugin
    // code are false positives 99% of the time.
    $filtered = array();
    foreach ($grouped as $file_key => $finding) {
        if (!function_exists('boteraser_calculate_risk')) {
            // Fallback: keep everything if risk calc not available
            foreach ($finding['findings'] as $f) {
                $filtered[] = $f;
            }
            continue;
        }

        $scored = boteraser_calculate_risk($finding);
        $severity = $scored['severity'] ?? 'LOW';

        if ($severity === 'HIGH' || $severity === 'MEDIUM') {
            // Merge scored details back into each finding so the
            // alert modal shows the real severity
            foreach ($finding['findings'] as $f) {
                $f['_severity'] = $severity;
                $f['_score']    = $scored['score'] ?? 0;
                $filtered[] = $f;
            }
        }
    }

    if (!empty($filtered)) {
        $overall_severity = boteraser_upload_scan_severity($filtered);

        // --- Auto-Quarantine ---
        // If auto_quarantine_uploads is enabled, move infected plugin/theme
        // files to the quarantine directory so the malware cannot execute.
        $quarantined = array();
        $deactivated_plugin_file = null;
        $auto_q_enabled = (bool) get_option('boteraser_auto_quarantine_uploads', false);

        if ($auto_q_enabled && function_exists('boteraser_quarantine_move')) {
            require_once BOT_ERASER_PLUGIN_DIR . 'includes/quarantine.php';

            // Collect unique infected files from scored results
            $infected_files = array();
            foreach ($grouped as $file_key => $finding) {
                $scored = boteraser_calculate_risk($finding);
                $sev = $scored['severity'] ?? 'LOW';
                if ($sev === 'HIGH' || $sev === 'MEDIUM') {
                    $infected_files[$file_key] = $sev;
                }
            }

            // Quarantine each infected file
            foreach ($infected_files as $rel_path => $severity) {
                $abs_path = ABSPATH . ltrim($rel_path, '/');
                if (!file_exists($abs_path)) continue;

                $result = boteraser_quarantine_move($abs_path, $rel_path, $severity, null);
                if (!is_wp_error($result)) {
                    $quarantined[] = array(
                        'rel_path'    => $rel_path,
                        'stored_name' => $result['stored_name'],
                        'severity'    => $severity,
                    );
                }
            }

            // Deactivate plugin if infected and was automatically activated
            if ($type === 'plugin' && !empty($quarantined)) {
                if (!function_exists('get_plugins')) {
                    require_once ABSPATH . 'wp-admin/includes/plugin.php';
                }
                foreach (array_keys(get_plugins()) as $plugin_file) {
                    if (strpos($plugin_file, $slug . '/') === 0) {
                        $active_plugins = get_option('active_plugins', array());
                        if (in_array($plugin_file, $active_plugins, true)) {
                            deactivate_plugins($plugin_file);
                            $deactivated_plugin_file = $plugin_file;
                        }
                        break;
                    }
                }
            }
        }

        // Attach quarantine info to alert findings
        if (!empty($quarantined)) {
            foreach ($filtered as &$f) {
                $f['_quarantined'] = true;
                $f['_quarantined_files'] = $quarantined;
                $f['_deactivated_plugin'] = $deactivated_plugin_file;
            }
            unset($f);
        }

        boteraser_upload_store_alert($type, $slug, $filtered, $overall_severity);
        boteraser_upload_send_alert_email($type, $slug, $filtered, $overall_severity);
        boteraser_upload_notify_server($type, $slug, $filtered, $overall_severity);
    }
}

/**
 * AJAX: dismiss one upload alert from the UPLOAD ALERTS TAB (permanent).
 */
function boteraser_ajax_dismiss_upload_alert() {
    check_ajax_referer('boteraser_upload_alert_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $idx    = (int) ($_POST['idx'] ?? -1);
    $alerts = get_option('boteraser_upload_alerts', array());

    if (isset($alerts[$idx])) {
        $removed_time = $alerts[$idx]['time'] ?? 0;
        array_splice($alerts, $idx, 1);
        update_option('boteraser_upload_alerts', array_values($alerts), false);

        // Also remove from popup dismissed tracking since the alert is gone
        $dismissed = get_option('boteraser_upload_popup_dismissed', array());
        if (in_array($removed_time, $dismissed, true)) {
            $dismissed = array_values(array_diff($dismissed, array($removed_time)));
            update_option('boteraser_upload_popup_dismissed', $dismissed, false);
        }
    }

    wp_send_json_success(array('remaining' => count($alerts)));
}
add_action('wp_ajax_boteraser_dismiss_upload_alert', 'boteraser_ajax_dismiss_upload_alert');

/**
 * AJAX: dismiss ALL upload alerts from the UPLOAD ALERTS TAB (permanent).
 */
function boteraser_ajax_dismiss_all_upload_alerts() {
    check_ajax_referer('boteraser_upload_alert_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    delete_option('boteraser_upload_alerts');
    delete_option('boteraser_upload_popup_dismissed');
    wp_send_json_success();
}
add_action('wp_ajax_boteraser_dismiss_all_upload_alerts', 'boteraser_ajax_dismiss_all_upload_alerts');

/**
 * AJAX: hide one alert from POPUP only (keeps it in Upload Alerts tab).
 */
function boteraser_ajax_hide_popup_alert() {
    check_ajax_referer('boteraser_upload_alert_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $alert_time = (int) ($_POST['alert_time'] ?? 0);
    if ($alert_time <= 0) wp_send_json_error('Invalid alert time');

    $dismissed = get_option('boteraser_upload_popup_dismissed', array());
    if (!in_array($alert_time, $dismissed, true)) {
        $dismissed[] = $alert_time;
        update_option('boteraser_upload_popup_dismissed', $dismissed, false);
    }

    wp_send_json_success();
}
add_action('wp_ajax_boteraser_hide_popup_alert', 'boteraser_ajax_hide_popup_alert');

/**
 * AJAX: hide ALL alerts from POPUP only (keeps all in Upload Alerts tab).
 */
function boteraser_ajax_hide_all_popup_alerts() {
    check_ajax_referer('boteraser_upload_alert_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

    $alerts    = get_option('boteraser_upload_alerts', array());
    $dismissed = array();
    foreach ($alerts as $a) {
        $dismissed[] = $a['time'] ?? 0;
    }
    update_option('boteraser_upload_popup_dismissed', $dismissed, false);

    wp_send_json_success();
}
add_action('wp_ajax_boteraser_hide_all_popup_alerts', 'boteraser_ajax_hide_all_popup_alerts');

/**
 * Inject the malware warning popup in wp-admin whenever undismissed alerts exist.
 * Popup "Dismiss" only hides the popup — full history stays in Upload Alerts tab.
 */
function boteraser_render_upload_alert_popup() {
    if (!current_user_can('manage_options')) return;
    if (!boteraser_is_premium_active()) return;

    $all_alerts    = get_option('boteraser_upload_alerts', array());
    $popup_dismissed = get_option('boteraser_upload_popup_dismissed', array());

    // Filter out alerts already dismissed from popup
    $alerts = array();
    foreach ($all_alerts as $a) {
        if (!in_array($a['time'] ?? 0, $popup_dismissed, true)) {
            $alerts[] = $a;
        }
    }
    if (empty($alerts)) return;

    $nonce       = wp_create_nonce('boteraser_upload_alert_nonce');
    $scanner_url = esc_url(admin_url('admin.php?page=bot-eraser-scanner'));
    $count       = count($all_alerts);

    // Build alerts JSON for JS
    $alerts_json = wp_json_encode(array_values($alerts));
    // Build mapping: popup index → original alert time (for AJAX dismiss)
    $alert_times = array();
    foreach ($alerts as $a) {
        $alert_times[] = $a['time'] ?? 0;
    }
    ?>
    <div id="boteraser-upload-alert-overlay" style="
        position:fixed;top:0;left:0;width:100%;height:100%;
        background:rgba(0,0,0,0.55);z-index:999999;
        display:flex;align-items:center;justify-content:center;
        font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
      <div id="boteraser-upload-alert-modal" style="
          background:#fff;border-radius:16px;max-width:560px;width:calc(100% - 40px);
          box-shadow:0 25px 60px rgba(0,0,0,0.3);overflow:hidden;max-height:90vh;
          display:flex;flex-direction:column;">

        <!-- Modal header -->
        <?php
        $has_quarantined = false;
        foreach ($alerts as $a) {
            $qf = $a['findings'][0]['_quarantined'] ?? false;
            if ($qf) { $has_quarantined = true; break; }
        }
        ?>
        <div style="background:linear-gradient(135deg,#dc2626,#b91c1c);padding:24px 28px;flex-shrink:0;">
          <div style="display:flex;align-items:center;gap:12px;">
            <div style="width:44px;height:44px;background:rgba(255,255,255,0.2);border-radius:50%;
                        display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:22px;">
              &#9888;
            </div>
            <div>
              <p style="margin:0 0 2px;font-size:11px;font-weight:600;letter-spacing:.12em;
                        text-transform:uppercase;color:rgba(255,255,255,0.75);">
                <?php _e('Security Alert', 'bot-eraser'); ?>
              </p>
              <h2 style="margin:0;font-size:20px;font-weight:700;color:#fff;">
                <?php printf(
                    _n('Malware detected in %d upload', 'Malware detected in %d uploads', $count, 'bot-eraser'),
                    $count
                ); ?>
              </h2>
              <?php if ($has_quarantined): ?>
                <p style="margin:4px 0 0;font-size:12px;color:rgba(255,255,255,0.8);">
                  &#128274; <?php _e('Infected files auto-quarantined', 'bot-eraser'); ?>
                </p>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <!-- Scrollable alert list -->
        <div id="boteraser-alert-list" style="overflow-y:auto;flex:1;padding:20px 28px;">
          <?php foreach ($alerts as $idx => $alert) :
            $sev_colors = array(
                'HIGH'   => array('bg' => '#fef2f2', 'border' => '#fecaca', 'text' => '#dc2626', 'badge_bg' => '#dc2626'),
                'MEDIUM' => array('bg' => '#fffbeb', 'border' => '#fde68a', 'text' => '#d97706', 'badge_bg' => '#d97706'),
                'LOW'    => array('bg' => '#f0fdf4', 'border' => '#bbf7d0', 'text' => '#16a34a', 'badge_bg' => '#16a34a'),
            );
            $sc = $sev_colors[$alert['severity']] ?? $sev_colors['HIGH'];
            $type_icon = $alert['type'] === 'plugin' ? '🔌' : ($alert['type'] === 'theme' ? '🎨' : '📄');
          ?>
          <div class="boteraser-alert-item" data-idx="<?php echo (int) $idx; ?>" style="
              background:<?php echo $sc['bg']; ?>;border:1px solid <?php echo $sc['border']; ?>;
              border-radius:10px;padding:14px 16px;margin-bottom:12px;position:relative;">

            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;">
              <div style="flex:1;min-width:0;">
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;">
                  <span style="font-size:16px;"><?php echo $type_icon; ?></span>
                  <span style="font-size:13px;font-weight:700;color:#0f172a;word-break:break-all;">
                    <?php echo esc_html($alert['name']); ?>
                  </span>
                  <span style="font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
                               padding:2px 8px;border-radius:4px;background:<?php echo $sc['badge_bg']; ?>;color:#fff;">
                    <?php echo esc_html($alert['severity']); ?>
                  </span>
                  <?php if ($alert['findings'][0]['_quarantined'] ?? false): ?>
                    <span style="font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
                                 padding:2px 8px;border-radius:4px;background:#0f766e;color:#fff;">
                      &#128274; <?php _e('Quarantined', 'bot-eraser'); ?>
                    </span>
                  <?php endif; ?>
                </div>
                <ul style="margin:0;padding:0 0 0 16px;font-size:12px;color:#475569;line-height:1.7;">
                  <?php foreach (array_slice($alert['findings'], 0, 5) as $f) : ?>
                    <li><?php echo esc_html($f['label'] ?? $f['type']); ?></li>
                  <?php endforeach; ?>
                  <?php if (count($alert['findings']) > 5) : ?>
                    <li style="color:#94a3b8;">
                      <?php printf(
                          __('+ %d more finding(s)', 'bot-eraser'),
                          count($alert['findings']) - 5
                      ); ?>
                    </li>
                  <?php endif; ?>
                </ul>
              </div>
              <button class="boteraser-dismiss-one" data-idx="<?php echo (int) $idx; ?>"
                  style="background:none;border:none;cursor:pointer;font-size:18px;color:#94a3b8;
                         line-height:1;padding:0;flex-shrink:0;" title="<?php esc_attr_e('Hide from popup', 'bot-eraser'); ?>">
                &times;
              </button>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Footer actions -->
        <div style="padding:16px 28px;border-top:1px solid #f1f5f9;background:#fafbfc;
                    display:flex;gap:10px;flex-shrink:0;flex-wrap:wrap;">
          <button id="boteraser-go-scanner"
             style="flex:1;min-width:140px;text-align:center;padding:10px 20px;border-radius:8px;border:none;
                    background:#dc2626;color:#fff;cursor:pointer;font-size:14px;font-weight:600;">
            <?php _e('Open Scanner', 'bot-eraser'); ?>
          </button>
          <?php if ($has_quarantined): ?>
            <button id="boteraser-go-quarantine"
               style="flex:1;min-width:140px;text-align:center;padding:10px 20px;border-radius:8px;border:none;
                      background:#0f766e;color:#fff;cursor:pointer;font-size:14px;font-weight:600;">
              &#128274; <?php _e('View Quarantine', 'bot-eraser'); ?>
            </button>
          <?php endif; ?>
          <button id="boteraser-dismiss-all-alerts"
              style="flex:1;min-width:120px;padding:10px 20px;border-radius:8px;border:1px solid #e2e8f0;
                     background:#fff;color:#475569;font-size:14px;font-weight:500;cursor:pointer;">
            <?php _e('Hide All', 'bot-eraser'); ?>
          </button>
        </div>

      </div>
    </div>

    <script>
    (function($) {
        var nonce         = <?php echo wp_json_encode($nonce); ?>;
        var overlay       = $('#boteraser-upload-alert-overlay');
        var alertTimes    = <?php echo wp_json_encode($alert_times); ?>;
        var scannerUrl    = <?php echo wp_json_encode($scanner_url); ?>;
        var quarantineUrl = <?php echo wp_json_encode(admin_url('admin.php?page=bot-eraser-quarantine')); ?>;

        function navigateAfterDismiss(url) {
            $.post(ajaxurl, {
                action : 'boteraser_hide_all_popup_alerts',
                nonce  : nonce
            }).always(function() {
                overlay.fadeOut(150, function() {
                    overlay.remove();
                    window.location.href = url;
                });
            });
        }

        function refreshList() {
            var items = overlay.find('.boteraser-alert-item');
            if (items.length === 0) {
                overlay.fadeOut(200, function() { overlay.remove(); });
            }
        }

        // Hide single alert from popup (does NOT delete from Upload Alerts tab)
        overlay.on('click', '.boteraser-dismiss-one', function() {
            var btn  = $(this);
            var item = btn.closest('.boteraser-alert-item');
            var idx  = parseInt(btn.data('idx'), 10);
            var time = alertTimes[idx] || 0;

            $.post(ajaxurl, {
                action    : 'boteraser_hide_popup_alert',
                nonce     : nonce,
                idx       : idx,
                alert_time: time
            }).always(function() {
                item.fadeOut(150, function() {
                    $(this).remove();
                    overlay.find('.boteraser-alert-item').each(function(i) {
                        $(this).attr('data-idx', i);
                        $(this).find('[data-idx]').attr('data-idx', i);
                    });
                    refreshList();
                });
            });
        });

        // Open Scanner — dismiss popup then redirect
        $('#boteraser-go-scanner').on('click', function() {
            navigateAfterDismiss(scannerUrl);
        });

        // View Quarantine — dismiss popup then redirect
        $('#boteraser-go-quarantine').on('click', function() {
            navigateAfterDismiss(quarantineUrl);
        });

        // Hide all from popup (does NOT delete from Upload Alerts tab)
        $('#boteraser-dismiss-all-alerts').on('click', function() {
            $.post(ajaxurl, {
                action : 'boteraser_hide_all_popup_alerts',
                nonce  : nonce
            }).always(function() {
                overlay.fadeOut(200, function() { overlay.remove(); });
            });
        });
    })(jQuery);
    </script>
    <?php
}
add_action('admin_footer', 'boteraser_render_upload_alert_popup');
