<?php
if (!defined('ABSPATH')) {
    exit;
}

// ----------------------------------------------------------------------------
// Per-IP hit counter for the rate-limited / greylist enforcement. A flat file
// cannot survive high traffic (a write per request on a large array), so this
// uses a fixed-window counter with two backends chosen automatically:
//   1. Persistent object cache (Redis/Memcached) via wp_cache_incr — primary.
//   2. A dedicated indexed MySQL table (INSERT ... ON DUPLICATE KEY UPDATE) —
//      failover when no object cache exists, or when a cache op fails at runtime.
// Only IPs already on the grey/rate lists are ever counted, keeping the tracked
// set tiny relative to total traffic.
// ----------------------------------------------------------------------------

const BOT_ERASER_RATE_GROUP = 'boteraser_rl';

/**
 * Is a persistent (external) object cache active? Result cached per request.
 */
function bot_eraser_rate_use_cache(): bool {
    static $use = null;
    if ($use === null) {
        $use = function_exists('wp_using_ext_object_cache') && wp_using_ext_object_cache();
    }
    return $use;
}

/**
 * Fully-qualified name of the failover hits table.
 */
function bot_eraser_rate_table(): string {
    global $wpdb;
    return $wpdb->prefix . 'boteraser_hits';
}

/**
 * Create the failover table. Called on activation; idempotent.
 */
function bot_eraser_rate_create_table(): void {
    global $wpdb;
    $table   = bot_eraser_rate_table();
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table (
        ip VARCHAR(45) NOT NULL,
        window_start INT UNSIGNED NOT NULL,
        cnt INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (ip),
        KEY window_start (window_start)
    ) $charset;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

/**
 * Register one hit for $ip within a fixed window of $window seconds and return
 * the running count for the current window.
 */
function bot_eraser_rate_hit(string $ip, int $window): int {
    $window = max(1, $window);

    if (bot_eraser_rate_use_cache()) {
        $key   = md5($ip);
        $count = wp_cache_incr($key, 1, BOT_ERASER_RATE_GROUP);
        if ($count === false) {
            // First hit in this window: seed with TTL, then increment.
            wp_cache_add($key, 0, BOT_ERASER_RATE_GROUP, $window);
            $count = wp_cache_incr($key, 1, BOT_ERASER_RATE_GROUP);
        }
        if ($count !== false) {
            return (int) $count;
        }
        // Cache backend failed mid-request -> fall through to the DB.
    }

    return bot_eraser_rate_hit_db($ip, $window);
}

/**
 * MySQL failover counter. Atomic fixed-window upsert: reset when the stored
 * window has expired, otherwise increment.
 */
function bot_eraser_rate_hit_db(string $ip, int $window): int {
    global $wpdb;
    $table  = bot_eraser_rate_table();
    $now    = time();
    $cutoff = $now - $window;

    $wpdb->query($wpdb->prepare(
        "INSERT INTO $table (ip, window_start, cnt) VALUES (%s, %d, 1)
         ON DUPLICATE KEY UPDATE
            cnt = IF(window_start <= %d, 1, cnt + 1),
            window_start = IF(window_start <= %d, %d, window_start)",
        $ip, $now, $cutoff, $cutoff, $now
    ));

    return (int) $wpdb->get_var($wpdb->prepare(
        "SELECT cnt FROM $table WHERE ip = %s", $ip
    ));
}

/**
 * Prune stale rows from the failover table. Hooked on the 5-min cleanup cron.
 * Uses the widest configured window as the retention horizon.
 */
function bot_eraser_rate_cleanup(): void {
    if (bot_eraser_rate_use_cache()) {
        return; // object-cache entries expire on their own TTL.
    }
    global $wpdb;
    $table = bot_eraser_rate_table();
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) {
        return;
    }
    $max_window = 0;
    foreach (['rate_limited_bots', 'greylist'] as $name) {
        $cfg = function_exists('bot_eraser_list_cfg') ? bot_eraser_list_cfg($name) : [];
        $max_window = max($max_window, (int) ($cfg['window'] ?? 300));
    }
    $cutoff = time() - max(300, $max_window);
    $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE window_start < %d", $cutoff));
}
