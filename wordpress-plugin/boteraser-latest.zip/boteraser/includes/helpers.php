<?php
// Guard: dual-load (WP + prepend).
if (!defined('ABSPATH') && !defined('BOT_ERASER_PREPEND')) {
    exit;
}

define('BOT_ERASER_BLOCK_DURATION', 86400);
define('BOT_ERASER_LOG_MAX_ENTRIES', 10000);
define('BOT_ERASER_LOG_RETENTION_DAYS', 30);
define('BOT_ERASER_SCAN_TIMEOUT', 180);
define('BOT_ERASER_BF_MAX_ENTRIES', 1000);
define('BOT_ERASER_BF_TRIM_TO', 500);
define('BOT_ERASER_FP_RATE_LIMIT', 30);
define('BOT_ERASER_SERVER_MAX_IPS', 512);

/**
 * Pre-WP config snapshot (option mirror for prepend).
 */
function bot_eraser_prepend_config(): array {
    static $cfg = null;
    if ($cfg === null) {
        $root = defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : dirname(__DIR__, 3);
        $file = $root . '/uploads/boteraser/lists/prepend-config.php';
        $data = is_file($file) ? include $file : null;
        $cfg  = is_array($data) ? $data : [];
    }
    return $cfg;
}

function bot_eraser_get_visitor_ip() {
    static $ip = null;
    if ($ip !== null) return $ip;

    // REMOTE_ADDR: only non-spoofable IP.
    $remote = filter_var($_SERVER['REMOTE_ADDR'] ?? '', FILTER_VALIDATE_IP);
    if ($remote === false) {
        $ip = '0.0.0.0';
        return $ip;
    }

    // IP source: 'remote_addr' default; proxy/CDN header override.
    $source = function_exists('get_option')
        ? get_option('bot_eraser_ip_source', 'remote_addr')
        : (string) (bot_eraser_prepend_config()['ip_source'] ?? 'remote_addr');

    // Manual header selection; unknown falls back to REMOTE_ADDR.
    $manual = [
        'cloudflare'      => ['HTTP_CF_CONNECTING_IP'],
        'x_forwarded_for' => ['HTTP_X_FORWARDED_FOR'],
        'x_real_ip'       => ['HTTP_X_REAL_IP'],
    ];
    $ip = isset($manual[$source])
        ? (bot_eraser_first_ip_from_headers($manual[$source]) ?? $remote)
        : $remote;
    return $ip;
}

/**
 * First valid IP from $_SERVER headers (X-Forwarded-For list).
 */
function bot_eraser_first_ip_from_headers(array $keys) {
    foreach ($keys as $h) {
        if (empty($_SERVER[$h])) continue;
        foreach (explode(',', $_SERVER[$h]) as $part) {
            $candidate = filter_var(trim($part), FILTER_VALIDATE_IP);
            if ($candidate !== false) {
                return $candidate;
            }
        }
    }
    return null;
}

/**
 * Self-request check (avoid server self-blacklist).
 */
function bot_eraser_is_self_ip($ip) {
    if (!is_string($ip) || $ip === '' || $ip === '0.0.0.0') {
        return false;
    }

    // Loopback check.
    if (strpos($ip, '127.') === 0 || $ip === '::1') {
        return true;
    }

    // Server self-IP match.
    foreach (['SERVER_ADDR', 'LOCAL_ADDR'] as $k) {
        if (!empty($_SERVER[$k]) && $ip === $_SERVER[$k]) {
            return true;
        }
    }

    // Pre-WP: self IPs from snapshot (no DNS per request).
    if (!function_exists('get_transient')) {
        return in_array($ip, (array) (bot_eraser_prepend_config()['self_ips'] ?? []), true);
    }

    // Cache public self IPs for 6h.
    static $self_ips = null;
    if ($self_ips === null) {
        $self_ips = false;
        if (function_exists('get_transient')) {
            $cached = get_transient('bot_eraser_self_ips');
            if (is_array($cached)) {
                $self_ips = $cached;
            }
        }
        if ($self_ips === false) {
            $self_ips = [];
            $host = function_exists('home_url') ? (parse_url(home_url(), PHP_URL_HOST) ?: '') : '';
            if ($host === '' && !empty($_SERVER['HTTP_HOST'])) {
                $host = $_SERVER['HTTP_HOST'];
            }
            if ($host !== '' && !filter_var($host, FILTER_VALIDATE_IP)) {
                $recs = @dns_get_record($host, DNS_A + DNS_AAAA);
                if (is_array($recs)) {
                    foreach ($recs as $r) {
                        if (!empty($r['ip']))   $self_ips[] = $r['ip'];
                        if (!empty($r['ipv6'])) $self_ips[] = $r['ipv6'];
                    }
                }
            }
            if (function_exists('set_transient')) {
                set_transient('bot_eraser_self_ips', $self_ips, 6 * HOUR_IN_SECONDS);
            }
        }
    }

    return in_array($ip, $self_ips, true);
}

/**
 * Unique token correlating signal queue and JA4 capture. Format: ^/[a-z]/[a-f0-9]{16,64}$.
 */
function bot_eraser_gen_token(): string {
    $host = function_exists('home_url') ? (parse_url(home_url(), PHP_URL_HOST) ?: '') : '';
    if ($host === '' && !empty($_SERVER['HTTP_HOST'])) {
        $host = $_SERVER['HTTP_HOST'];
    }
    $site = substr(md5($host), 0, 8);
    return $site . bin2hex(random_bytes(16)) . dechex((int) round(microtime(true) * 1000000));
}

/**
 * Minimal signal for blocked re-entry token pair.
 */
function bot_eraser_send_min_signal($ip, $token, $reason = 'blocked_reentry') {
    $api_key = (string) get_option('bot_eraser_api_key', '');
    if ($api_key === '') return;
    $ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $uri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
    $met = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    // bot-detector.php is loaded after the immediate block check that can
    // reach this function — guard so a blocked IP's first visit never fatals.
    $ver = function_exists('bot_eraser_get_detection_config')
        ? (string) (bot_eraser_get_detection_config()['version'] ?? '')
        : '';
    $fields = [
        time(),  // 0: ts
        '',      // 1: domain
        $ver,    // 2: version
        $ip,     // 3: ip
        '',      // 4: ja4
        '',      // 5: ja4h
        '',      // 6: ja4t
        '',      // 7: ttl
        '',      // 8: connMin
        '',      // 9: timingMs
        '',      // 10: sni
        '',      // 11: srcPort
        '',      // 12: dstPort
        '',      // 13: ptr
        $ua,     // 14: ua
        '',      // 15: bot_name
        $uri,    // 16: uri
        '',      // 17: ref
        $met,    // 18: method
        '',      // 19: al
        '',      // 20: path
        0,       // 21: score
        '',      // 22: fams
        0,       // 23: strong
        0,       // 24: infra
        0,       // 25: has_inf
        '',      // 26: fp_id slot
        $reason, // 27: signals
        $token,  // 28: token
    ];
    $enc = [];
    foreach ($fields as $f) {
        $s = (string) $f;
        if (strpbrk($s, ",\"\n\r") !== false || strpos($s, ' ') !== false) {
            $enc[] = '"' . str_replace('"', '""', $s) . '"';
        } else {
            $enc[] = $s;
        }
    }
    wp_remote_post('https://data.boteraser.com/signal.php', [
        'body'     => implode(',', $enc) . "\n",
        'timeout'  => 1,
        'blocking' => false,
        'headers'  => ['Content-Type' => 'text/plain; charset=utf-8', 'X-Api-Key' => $api_key],
    ]);
}

/**
 * JA4 capture: 200 response with token baits; terminates request.
 */
function bot_eraser_emit_analyze_capture($token = '', $use_302 = false) {
    // Same token in signal queue and bait URL; random prefix busts cache.
    if ($token === '') {
        $token = bot_eraser_gen_token();
    }
    $url = 'https://data.boteraser.com/' . chr(random_int(97, 122)) . '/' . $token;
    if (!headers_sent()) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0', true);
        header('Pragma: no-cache', true);
        header('Refresh: 0; url=' . $url, true);
        if ($use_302) {
            header('Location: ' . $url, true, 302);
        }
    }
    $u = htmlspecialchars($url, ENT_QUOTES);
    $origin = '';
    $pu = parse_url($url);
    if (!empty($pu['scheme']) && !empty($pu['host'])) {
        $origin = $pu['scheme'] . '://' . $pu['host'];
    }
    $o = htmlspecialchars($origin, ENT_QUOTES);
    echo '<!DOCTYPE html><html><head><meta charset="utf-8">';
    echo '<meta http-equiv="refresh" content="0;url=' . $u . '">';
    // preconnect forces TLS handshake -> early JA4 capture.
    if ($origin !== '') {
        echo '<link rel="preconnect" href="' . $o . '" crossorigin>';
    }
    // CSS bait, carries token.
    echo '<link rel="stylesheet" href="' . $u . '">';
    echo '</head><body>';
    // Use screen-reader-text clip (a11y) instead of classic honeypot.
    $hidden = 'position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0';
    echo '<img src="' . $u . '" alt="" width="1" height="1" style="' . $hidden . '">';
    // Link bait for href-collecting crawlers.
    echo '<a href="' . $u . '" style="' . $hidden . ';white-space:nowrap">.</a>';
    // iframe bait for document-rendering clients, carries token.
    echo '<iframe src="' . $u . '" style="' . $hidden . '" aria-hidden="true" tabindex="-1"></iframe>';
    // fetch then location.replace (order matters: fetch first).
    echo '<script>try{fetch(' . json_encode($url) . ',{mode:"no-cors",cache:"no-store"})}catch(e){}location.replace(' . json_encode($url) . ')</script>';
    echo '</body></html>';
    exit;
}

/**
 * JA4-done marker file for pre-WP capture check.
 */
function bot_eraser_ja4_done_path(): string {
    return __DIR__ . '/sig-snap.php';
}

function bot_eraser_ja4_done(string $ip): bool {
    $file = bot_eraser_ja4_done_path();
    $data = is_file($file) ? include $file : null;
    return is_array($data) && isset($data[$ip]) && time() < $data[$ip];
}

/**
 * Write expiry marker; clean expired entries incidentally.
 */
function bot_eraser_ja4_mark_done(string $ip, int $expiry): void {
    $file = bot_eraser_ja4_done_path();
    $data = is_file($file) ? include $file : [];
    if (!is_array($data)) {
        $data = [];
    }
    $now  = time();
    $data = array_filter($data, function ($exp) use ($now) {
        return $exp > $now;
    });
    $data[$ip] = max($now + 60, $expiry);
    file_put_contents($file, '<?php return ' . var_export($data, true) . ';', LOCK_EX);
    bot_eraser_invalidate_opcache($file);
}

/**
 * Per-IP hit counter (403'd requests). APCu preferred, file fallback.
 */
function bot_eraser_hits_file(): string {
    return __DIR__ . '/hits.log';
}

function bot_eraser_hit_incr(string $ip): void {
    if ($ip === '' || $ip === '0.0.0.0') {
        return;
    }
    if (function_exists('apcu_inc')) {
        $ok = false;
        apcu_inc('be_hits_' . md5($ip), 1, $ok, 86400);
        return;
    }
    // File fallback: append per hit, cap size.
    $file = bot_eraser_hits_file();
    if (@filesize($file) > 1048576) {
        return;
    }
    @file_put_contents($file, $ip . "\n", FILE_APPEND);
}

/**
 * Fold hit deltas (APCu + file) into option store.
 */
function bot_eraser_hit_flush(): void {
    if (!function_exists('get_option')) {
        return;
    }
    $reasons = get_option('bot_eraser_block_reasons', []);
    if (!is_array($reasons)) {
        $reasons = [];
    }
    $changed = false;

    // APCu deltas for tracked IPs.
    if (function_exists('apcu_fetch') && function_exists('apcu_dec')) {
        foreach ($reasons as $ip => $r) {
            $ok    = false;
            $delta = apcu_fetch('be_hits_' . md5($ip), $ok);
            if ($ok && (int) $delta > 0) {
                $reasons[$ip]['count'] = max(1, (int) ($r['count'] ?? 1)) + (int) $delta;
                apcu_dec('be_hits_' . md5($ip), (int) $delta);
                $changed = true;
            }
        }
    }

    // File deltas: atomic claim, aggregate, drop.
    $file = bot_eraser_hits_file();
    if (is_file($file)) {
        $tmp = @tempnam(dirname($file), '.betmp');
        if (@rename($file, $tmp)) {
            $lines = @file($tmp, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
            @unlink($tmp);
            foreach (array_count_values($lines) as $ip => $delta) {
                if (isset($reasons[$ip])) {
                    $reasons[$ip]['count'] = max(1, (int) ($reasons[$ip]['count'] ?? 1)) + (int) $delta;
                    $changed = true;
                }
            }
        }
    }

    if ($changed) {
        update_option('bot_eraser_block_reasons', $reasons);
    }
}

function bot_eraser_invalidate_opcache($file) {
    static $scheduled = [];
    if (isset($scheduled[$file])) return;
    $scheduled[$file] = true;
    register_shutdown_function(function() use ($file) {
        if (function_exists('opcache_invalidate')) {
            opcache_invalidate($file, true);
        }
    });
}

/**
 * Atomic PHP cache write (temp + rename, lock-free reads).
 *
 * @param string $file Destination path.
 * @param array  $ips  Map of ip => expiry timestamp.
 * @return bool True on success.
 */
function bot_eraser_write_ip_cache($file, array $ips) {
    $php = '<?php return ' . var_export($ips, true) . ';';
    $tmp = @tempnam(dirname($file), '.betmp');
    if ($tmp === false) {
        // Locked in-place fallback.
        return @file_put_contents($file, $php, LOCK_EX) !== false;
    }
    if (@file_put_contents($tmp, $php, LOCK_EX) === false || !@rename($tmp, $file)) {
        @unlink($tmp);
        return false;
    }
    @chmod($file, 0644);
    if (function_exists('opcache_invalidate')) {
        opcache_invalidate($file, true);
    }
    return true;
}

function bot_eraser_debug_log($message) {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('Boteraser: ' . $message);
    }
}
