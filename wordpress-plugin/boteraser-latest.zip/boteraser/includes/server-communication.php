<?php
if (!defined('ABSPATH')) {
    exit;
}

function bot_eraser_send_data_to_server($type = 'cron') {
    // Block execution if privacy notice not accepted
    if (!get_option('bot_eraser_privacy_notice_dismissed')) {
        return [
            'status' => 'error',
            'message' => 'Privacy notice must be accepted before sending data',
            'sent_data' => [],
            'response' => ''
        ];
    }

    $result = [
        'status' => 'error',
        'message' => 'Initialization failed',
        'sent_data' => [],
        'response' => ''
    ];

    try {
        // Get and validate settings - use direct database queries to avoid caching issues
        global $wpdb;
        $api_key = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", 'bot_eraser_api_key'));
        $host_ip = get_option('bot_eraser_host_ip');
        $domain = get_option('bot_eraser_domain');
        
        
        if (empty($api_key) || empty($host_ip) || empty($domain)) {
            throw new Exception('Required settings are missing. API key: ' . (empty($api_key) ? 'EMPTY' : 'OK') . ', Host IP: ' . (empty($host_ip) ? 'EMPTY' : 'OK') . ', Domain: ' . (empty($domain) ? 'EMPTY' : 'OK'));
        }

        // Parse log data
        $log_data = bot_eraser_parse_log();
        if (empty($log_data['data'])) {
            $log_data['data'] = '';
            $log_data['srv_load'] = $log_data['srv_load'] ?? 0;
            $log_data['uptime'] = $log_data['uptime'] ?? 0;
        }

        // --- START: Add sorting logic here ---
        $unsorted_data_string = $log_data['data'];
        $lines = explode("\n", trim($unsorted_data_string));
        $lines = array_filter($lines); 
        
        $parsed_data = [];
        if (!empty($lines)) {
            foreach ($lines as $line) {
                // Match COUNT IP BOT_NAME (or just COUNT IP)
                if (preg_match('/^(\d+)\s+([0-9a-fA-F.:]+)(?:\s+(.*))?$/', trim($line), $matches)) {
                    $count = (int)$matches[1];
                    $ip = $matches[2];
                    $bot_name = isset($matches[3]) ? trim($matches[3]) : 'unknown'; // Handle missing bot name
                    
                    if (filter_var($ip, FILTER_VALIDATE_IP)) {
                        // Store IP as key to handle potential duplicates from parsing, though ideally shouldn't happen
                        $parsed_data[$ip] = ['count' => $count, 'bot' => $bot_name]; 
                    }
                }
            }

            // Sort the array by count descending
            uasort($parsed_data, function($a, $b) {
                return $b['count'] <=> $a['count']; // Sort by count descending
            });

            // Reformat back into the string
            $sorted_data_string = '';
            foreach ($parsed_data as $ip => $data) {
                $sorted_data_string .= $data['count'] . ' ' . $ip . ' ' . $data['bot'] . "\n";
            }
            $log_data['data'] = trim($sorted_data_string); // Update log_data with sorted string
        }
        // --- END: Add sorting logic here ---


        // Gather brute force stats
        $bf_data    = bot_eraser_bf_load_data();
        $bf_data    = bot_eraser_bf_cleanup($bf_data);
        $bf_max     = bot_eraser_bf_max_attempts();
        $bf_tracked = count($bf_data);
        $bf_blocked = count(array_filter($bf_data, function($e) use ($bf_max) {
            return $e['count'] >= $bf_max;
        }));

        // Prepare payload
        $payload = [
            'api_key'        => $api_key,
            'type'           => 'standard',
            'host_ip'        => $host_ip,
            'domain'         => $domain,
            'data'           => $log_data['data'],
            'srv_load'       => $log_data['srv_load'],
            'uptime'         => $log_data['uptime'],
            'bf_tracked'     => $bf_tracked,
            'bf_blocked'     => $bf_blocked,
        ];
        
        $result['sent_data'] = $payload;

        // Send to server
        $response = wp_remote_post(BOT_ERASER_SERVER_URL, [
            'body' => $payload,
            'timeout' => 10,
            'sslverify' => true
        ]);

        if (is_wp_error($response)) {
            $result['message'] = 'Server unreachable, local protection active';
            $result['status'] = 'warning';
            bot_eraser_debug_log('Server unreachable: ' . $response->get_error_message());
            return $result;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $result['response'] = $response_body;

        bot_eraser_debug_log('Server response code: ' . $response_code);
        bot_eraser_debug_log('Raw server response: ' . print_r($response_body, true));

        // Check for server errors (4xx and 5xx status codes)
        if ($response_code >= 400) {
            // Update API validation state to reflect server error
            $validation_state = array(
                'api_key_hash' => bot_eraser_simple_hash($api_key),
                'is_valid' => false,
                'message' => $response_body ?: 'Server returned error code: ' . $response_code,
                'timestamp' => time()
            );
            update_option('bot_eraser_api_validation_state', $validation_state);
            
            throw new Exception($response_body ?: 'Server returned error code: ' . $response_code);
        }

        if (!empty($response_body)) {
            $ips_to_block = array_filter(array_map('trim', explode("\n", $response_body)));
            $ips_to_block = array_slice($ips_to_block, 0, BOT_ERASER_SERVER_MAX_IPS);
            bot_eraser_debug_log('IPs to process: ' . print_r($ips_to_block, true));

            $blocked_count = 0;
            $invalid_count = 0;

            foreach ($ips_to_block as $ip_to_block) {
                if (!filter_var($ip_to_block, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    $invalid_count++;
                    bot_eraser_debug_log('Invalid IP format: ' . $ip_to_block);
                    continue;
                }

                if (!bot_eraser_is_ip_blocked($ip_to_block) && !bot_eraser_is_just_unblocked($ip_to_block)) {
                    $block_result = bot_eraser_block_ips([$ip_to_block]);
                    if ($block_result) {
                        $blocked_count++;
                        $reasons = get_option('bot_eraser_block_reasons', []);
                        if (!is_array($reasons)) $reasons = [];
                        $reasons[$ip_to_block] = [
                            'source'  => 'server',
                            'signals' => [],
                            'time'    => time(),
                            'ua'      => '',
                            'count'   => 1,
                        ];
                        update_option('bot_eraser_block_reasons', $reasons);
                    }
                }
            }

            // Set result message based on what happened
            if ($blocked_count > 0) {
                $result['message'] = sprintf('Data sent successfully. Blocked %d new IP(s).', $blocked_count);
                $result['status'] = 'success';
            } elseif ($invalid_count > 0) {
                $result['message'] = sprintf('Data sent successfully. Found %d invalid IP(s).', $invalid_count);
                $result['status'] = 'warning';
            } else {
                $result['message'] = 'Data sent successfully. No new IPs to block.';
                $result['status'] = 'success';
            }
            
            // Update API validation state to reflect successful communication
            $validation_state = array(
                'api_key_hash' => bot_eraser_simple_hash($api_key),
                'is_valid' => true,
                'message' => 'API key is valid',
                'timestamp' => time()
            );
            update_option('bot_eraser_api_validation_state', $validation_state);
        } else {
            $result['message'] = 'Data sent successfully. No IP addresses received.';
            $result['status'] = 'success';
            
            // Update API validation state to reflect successful communication
            $validation_state = array(
                'api_key_hash' => bot_eraser_simple_hash($api_key),
                'is_valid' => true,
                'message' => 'API key is valid',
                'timestamp' => time()
            );
            update_option('bot_eraser_api_validation_state', $validation_state);
        }

    } catch (Exception $e) {
        $result['message'] = $e->getMessage();
    }

    // Log the execution in history
    if (function_exists('bot_eraser_log_execution')) {
        bot_eraser_log_execution([
            'status' => $result['status'],
            'message' => $result['message'],
            'type' => $type
        ]);
    }

    return $result;
}

function bot_eraser_validate_api_key_with_server($api_key) {
    $result = [
        'valid' => false,
        'message' => 'Validation failed'
    ];

    try {
        
        if (empty($api_key)) {
            throw new Exception('API key is required');
        }
        
        // Get or set default values for required settings - use direct DB query for API key
        global $wpdb;
        $api_key_from_db = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", 'bot_eraser_api_key'));
        
        // Debug the API key retrieval in validation
        
        // Use the passed parameter, not the database value for validation
        if (empty($api_key)) {
            throw new Exception('API key parameter is required for validation');
        }
        
        $host_ip = get_option('bot_eraser_host_ip');
        $domain = get_option('bot_eraser_domain');
        
        // Set defaults if not configured
        if (empty($host_ip)) {
            $host_ip = $_SERVER['SERVER_ADDR'] ?? $_SERVER['LOCAL_ADDR'] ?? '127.0.0.1';
            update_option('bot_eraser_host_ip', $host_ip);
        }
        
        if (empty($domain)) {
            $domain = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';
            // Remove www. prefix if present
            $domain = preg_replace('/^www\./', '', $domain);
            update_option('bot_eraser_domain', $domain);
        }

        bot_eraser_debug_log('Using host_ip: ' . $host_ip . ', domain: ' . $domain);

        // Prepare minimal payload for validation
        $payload = [
            'api_key' => $api_key,
            'type' => 'standard',
            'host_ip' => $host_ip,
            'domain' => $domain,
            'data' => '', // Empty data for validation only
            'srv_load' => 0,
            'uptime' => 0,
            'validate_only' => true // Flag to indicate this is validation only
        ];

        $verify_url = 'https://user.boteraser.com/srv/api-verify.php';
        bot_eraser_debug_log('Sending validation request to: ' . $verify_url);

        // Send to server
        $response = wp_remote_post($verify_url, [
            'body' => $payload,
            'timeout' => 10,
            'sslverify' => true
        ]);

        if (is_wp_error($response)) {
            bot_eraser_debug_log('WP Error: ' . $response->get_error_message());
            throw new Exception($response->get_error_message());
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        bot_eraser_debug_log('Server response code: ' . $response_code);
        bot_eraser_debug_log('Server response body: ' . $response_body);
        
        // Check for server errors (500, etc.)
        if ($response_code >= 500) {
            throw new Exception($response_body);
        }
        
        if ($response_code >= 400) {
            throw new Exception($response_body);
        }

        // If we get a 200 response, consider the API key valid
        if ($response_code == 200) {
            $result['valid'] = true;
            $result['message'] = 'API key is valid';
            bot_eraser_debug_log('API key validation successful');
        } else {
            throw new Exception('Unexpected response code: ' . $response_code);
        }

        } catch (Exception $e) {
        bot_eraser_debug_log('Validation exception: ' . $e->getMessage());
        $result['valid'] = false;
        $result['message'] = $e->getMessage();
        }

    bot_eraser_debug_log('Final validation result: ' . print_r($result, true));
    return $result;
}
