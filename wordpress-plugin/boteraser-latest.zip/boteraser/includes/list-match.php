<?php
// Works in pre-WP prepend phase (BOT_ERASER_PREPEND, boteraser-prepend.php);
// No get_option/WP_CONTENT_DIR — falls back to snapshot config.
if (!defined('ABSPATH') && !defined('BOT_ERASER_PREPEND')) {
    exit;
}

// ----------------------------------------------------------------------------
// Request-time threat-list enforcement using compiled lists (list-sync.php).
// Matches IPs (exact, CIDR) and bot User-Agent substrings via O(1)/O(log n)
// lookups on every front-end request.
// ----------------------------------------------------------------------------

/**
 * Directory for compiled list caches. Mirrors uploads/boteraser/ layout.
 * Uses WP_CONTENT_DIR directly for pre-WP immediate check.
 */
function bot_eraser_list_dir(): string {
    $root = defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : dirname(__DIR__, 3);
    return $root . '/uploads/boteraser/lists/';
}

/**
 * Path to blocked-ips cache. Independent of BOT_ERASER_PLUGIN_DIR (not yet defined).
 */
function bot_eraser_list_blocked_path(): string {
    return __DIR__ . '/blocked-ips.php';
}

/**
 * Load a compiled list by name, cached per request.
 * Returns null if cache file is missing.
 * $reset drops the cache first, for readers running after a sync rewrote
 * the files in this same request.
 */
function bot_eraser_list_load(string $name, bool $reset = false) {
    static $cache = [];
    if ($reset) {
        $cache = [];
    }
    if (array_key_exists($name, $cache)) {
        return $cache[$name];
    }
    $file = bot_eraser_list_dir() . $name . '.php';
    $data = is_file($file) ? include $file : null;
    $cache[$name] = is_array($data) ? $data : null;
    return $cache[$name];
}

/**
 * Parse the raw server map.txt (CSV) into an assoc array keyed by list name.
 * '-' / '' cells are dropped so per-list defaults apply; block_ttl is hours->sec.
 */
function bot_eraser_list_parse_map(string $body): array {
    $map = [];
    foreach (preg_split('/\r\n|\r|\n/', $body) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') {
            continue;
        }
        $row = str_getcsv($line, ',', '"', '\\');
        $name = isset($row[0]) ? trim((string) $row[0]) : '';
        if ($name === '' || strcasecmp($name, 'list') === 0) {
            continue; // skip header
        }
        // Country: comparison-only, list not downloaded.
        if (strcasecmp($name, 'country') === 0) {
            $map['country'] = array_filter([
                'enabled'   => isset($row[1]) ? (int) $row[1] : 0,
                'count'     => isset($row[2]) && $row[2] !== '' && $row[2] !== '-' ? (int) $row[2] : 0,
                'block_ttl' => isset($row[4]) && $row[4] !== '' && $row[4] !== '-' ? (int) $row[4] * 3600 : 86400,
                'action'    => isset($row[5]) ? trim((string) $row[5]) : 'block',
            ], function ($v) {
                return $v !== '';
            });
            continue;
        }
        $map[$name] = array_filter([
            'enabled'   => isset($row[1]) ? (int) $row[1] : 1,
            'threshold' => isset($row[2]) && $row[2] !== '' && $row[2] !== '-' ? (int) $row[2] : '',
            'window'    => isset($row[3]) && $row[3] !== '' && $row[3] !== '-' ? (int) $row[3] : '',
            'block_ttl' => isset($row[4]) && $row[4] !== '' && $row[4] !== '-' ? (int) $row[4] * 3600 : '',
            'action'    => isset($row[5]) ? trim((string) $row[5]) : '',
        ], function ($v) {
            return $v !== '';
        });
    }
    return $map;
}

/**
 * Single source of truth for the list map: parsed from map.txt on disk,
 * cached per request. Works in the pre-WP prepend phase (no get_option).
 */
function bot_eraser_get_map(): array {
    static $map = null;
    if ($map !== null) {
        return $map;
    }
    $file = bot_eraser_list_dir() . 'map.txt';
    $map  = is_file($file) ? bot_eraser_list_parse_map((string) @file_get_contents($file)) : [];
    return $map;
}

/**
 * Parameter map (thresholds / windows / TTLs / actions) from map.txt.
 * Merged over per-list defaults for sane fallback behavior.
 */
function bot_eraser_list_cfg(string $name): array {
    $defaults = [
        'blacklist_ips'     => ['block_ttl' => 86400],
        'blacklist_bots'    => ['block_ttl' => 86400],
        'blacklist'         => ['block_ttl' => 86400],
        'rate_limited_bots' => ['threshold' => 50,  'window' => 300, 'block_ttl' => 3600],
        'greylist'          => ['threshold' => 100, 'window' => 300, 'block_ttl' => 1800],
    ];
    $base = $defaults[$name] ?? ['block_ttl' => 86400];
    $map  = bot_eraser_get_map();
    if (is_array($map) && isset($map[$name]) && is_array($map[$name])) {
        $base = array_merge($base, array_filter($map[$name], function ($v) {
            return $v !== '' && $v !== null;
        }));
    }
    return $base;
}

/**
 * Distinct effective block TTLs (seconds, ascending) across enabled map lists.
 * Falls back to the 24h default when the map holds no blocking list.
 */
function bot_eraser_map_block_ttls(): array {
    $ttls = [];
    foreach (bot_eraser_get_map() as $name => $cfg) {
        if (strcasecmp($name, 'whitelist') === 0 || empty($cfg['enabled'])) {
            continue;
        }
        $ttl = (int) (bot_eraser_list_cfg($name)['block_ttl'] ?? 0);
        if ($ttl > 0) {
            $ttls[$ttl] = $ttl;
        }
    }
    if (empty($ttls)) {
        $ttls[86400] = 86400;
    }
    sort($ttls);
    return $ttls;
}

/**
 * Check if $ip matches a compiled list.
 * IPv4 exact: hash; IPv4 CIDR: binary search; IPv6: linear compare.
 */
function bot_eraser_list_ip_match($compiled, string $ip): bool {
    if (empty($compiled) || $ip === '' || $ip === '0.0.0.0') {
        return false;
    }

    if (strpos($ip, ':') === false) {
        if (!empty($compiled['exact'][$ip])) {
            return true;
        }
        $ranges = $compiled['v4'] ?? [];
        if (empty($ranges)) {
            return false;
        }
        $x  = ip2long($ip);
        if ($x === false) {
            return false;
        }
        $x  = $x & 0xFFFFFFFF;
        $lo = 0;
        $hi = count($ranges) - 1;
        while ($lo <= $hi) {
            $mid = intdiv($lo + $hi, 2);
            $r   = $ranges[$mid];
            if ($x < $r[0]) {
                $hi = $mid - 1;
            } elseif ($x > $r[1]) {
                $lo = $mid + 1;
            } else {
                return true;
            }
        }
        return false;
    }

    $bin = @inet_pton($ip);
    if ($bin === false) {
        return false;
    }
    foreach (($compiled['v6'] ?? []) as $r) {
        if (strcmp($bin, $r[0]) >= 0 && strcmp($bin, $r[1]) <= 0) {
            return true;
        }
    }
    return false;
}

/**
 * Match User-Agent against bot patterns from a compiled list.
 * Pre-built regex chunks (list-sync.php) keep it to few preg_match calls.
 */
function bot_eraser_list_bot_match($compiled, string $ua): bool {
    if (empty($compiled['bots']) || $ua === '') {
        return false;
    }
    foreach ($compiled['bots'] as $chunk) {
        if (@preg_match($chunk, $ua)) {
            return true;
        }
    }
    return false;
}

/**
 * Write IP to blocked-ips cache with TTL and record block reason.
 * Standalone — runs before ip-blocker.php loads.
 */
function bot_eraser_list_block(string $ip, int $ttl, string $source, string $ua = '', int $count = 1): void {
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        return;
    }
    $file    = bot_eraser_list_blocked_path();
    $blocked = [];
    if (is_file($file)) {
        if (function_exists("opcache_invalidate")) {
            opcache_invalidate($file, true);
        }
        $blocked = include $file;
    }
    if (!is_array($blocked)) {
        $blocked = [];
    }
    $now = time();
    $blocked = array_filter($blocked, function ($expiry) use ($now) {
        return $expiry > $now;
    });
    $blocked[$ip] = $now + max(60, $ttl);
    bot_eraser_write_ip_cache($file, $blocked);

    if (function_exists('update_option')) {
        $reasons = get_option('bot_eraser_block_reasons', []);
        if (!is_array($reasons)) {
            $reasons = [];
        }
        $reasons[$ip] = [
            'source'  => $source,
            'signals' => [$source],
            'time'    => $now,
            'ua'      => $ua,
            'count'   => max(1, $count),
        ];
        update_option('bot_eraser_block_reasons', $reasons);
    }
}

/**
 * Emit 403 and end request. IP already persisted in blocked-ips.php;
 * next request hits normal block path via bot_eraser_check_ip().
 */
function bot_eraser_list_deny(): void {
    if (!headers_sent()) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0', true);
        header('Pragma: no-cache', true);
        header('HTTP/1.1 403 Forbidden', true, 403);
    }
    exit;
}

/**
 * Report multi-list match to report.php.
 * Only sends when WordPress HTTP API is available (plugin phase).
 */
function bot_eraser_send_list_report(string $ip, string $ua, array $matches): void {
    if (!function_exists('wp_remote_post')) return;

    $url = defined('BOT_ERASER_BLOCKLIST_URL')
        ? BOT_ERASER_BLOCKLIST_URL
        : 'https://user.boteraser.com/srv/report.php';

    $api_key = function_exists('get_option')
        ? (string) get_option('bot_eraser_api_key', '')
        : '';

    if ($api_key === '') return;

    $list_names = [];
    foreach ($matches as $name => $info) {
        $parts = $name;
        if (!empty($info['by_ip'])) $parts .= ':ip';
        if (!empty($info['by_ua'])) $parts .= ':ua';
        $list_names[] = $parts;
    }

    wp_remote_post($url, [
        'body'     => [
            'action' => 'multi_match',
            'ip'     => $ip,
            'ua'     => substr($ua, 0, 255),
            'lists'  => implode(',', $list_names),
            'ts'     => time(),
        ],
        'timeout'  => 1,
        'blocking' => false,
        'headers'  => ['X-Api-Key' => $api_key],
    ]);
}

/**
 * Core enforcement. Checks all lists (no short-circuit), reports multi-list
 * matches to report.php, and uses the longest TTL across matched blocklists.
 */
function bot_eraser_enforce_lists(string $ip, string $ua): void {
    if ($ip === '' || $ip === '0.0.0.0') {
        return;
    }

    // Whitelist bypasses all blocking.
    $wl = bot_eraser_list_load('whitelist');
    if ($wl && (bot_eraser_list_ip_match($wl, $ip) || bot_eraser_list_bot_match($wl, $ua))) {
        if (function_exists('get_option') && function_exists('update_option')) {
            $visits = get_option('bot_eraser_whitelist_visits', []);
            if (!is_array($visits)) $visits = [];
            $visits[] = ['ip' => $ip, 'ua' => substr($ua, 0, 255), 'uri' => $_SERVER['REQUEST_URI'] ?? '', 'ts' => time()];
            if (count($visits) > 2000) $visits = array_slice($visits, -1000);
            update_option('bot_eraser_whitelist_visits', $visits, false);
        }
        return;
    }

    $matches = [];

    // Hard blocklists — collect matches, no short-circuit.
    foreach (['blacklist_ips', 'blacklist_bots', 'blacklist'] as $name) {
        $c = bot_eraser_list_load($name);
        if (!$c) continue;
        $by_ip = bot_eraser_list_ip_match($c, $ip);
        $by_ua = bot_eraser_list_bot_match($c, $ua);
        if ($by_ip || $by_ua) {
            $matches[$name] = ['by_ip' => $by_ip, 'by_ua' => $by_ua, 'block' => true];
        }
    }

    // Rate-limited / greylist — collect matches; block only at threshold.
    $has_rate = function_exists('bot_eraser_rate_hit');
    foreach (['rate_limited_bots', 'greylist'] as $name) {
        $c = bot_eraser_list_load($name);
        if (!$c) continue;
        $by_ip = bot_eraser_list_ip_match($c, $ip);
        $by_ua = bot_eraser_list_bot_match($c, $ua);
        if (!$by_ip && !$by_ua) continue;
        $cfg  = bot_eraser_list_cfg($name);
        $over = false;
        if ($has_rate) {
            $count = bot_eraser_rate_hit($ip, (int) $cfg['window']);
            $over  = $count > (int) $cfg['threshold'];
        }
        $matches[$name] = ['by_ip' => $by_ip, 'by_ua' => $by_ua, 'block' => $over];
    }

    if (empty($matches)) return;

    // Report if matched in multiple lists.
    if (count($matches) > 1) {
        bot_eraser_send_list_report($ip, $ua, $matches);
    }

    // Determine max TTL and whether to block.
    // Manual lists (blacklist, greylist) override automated list TTLs.
    $should_block = false;
    $parts        = [];
    $manual_ttl   = 0;
    $auto_ttl     = 0;
    $has_manual   = false;
    foreach ($matches as $name => $info) {
        if (empty($info['block'])) continue;
        $cfg      = bot_eraser_list_cfg($name);
        $ttl      = (int) $cfg['block_ttl'];
        $is_manual = $name === 'blacklist' || $name === 'greylist';
        if ($is_manual) {
            $has_manual = true;
            if ($ttl > $manual_ttl) $manual_ttl = $ttl;
        } else {
            if ($ttl > $auto_ttl) $auto_ttl = $ttl;
        }
        $should_block = true;
        $parts[] = $name . (!empty($info['by_ip']) ? ':ip' : ':ua');
    }

    if (!$should_block) return;

    bot_eraser_list_block($ip, $has_manual ? $manual_ttl : $auto_ttl, implode('|', $parts), $ua, 1);
    bot_eraser_list_deny();
}
