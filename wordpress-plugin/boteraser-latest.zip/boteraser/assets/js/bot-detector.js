(function () {
    'use strict';

    // Frontend šalje SIROVE MERE (vrednosti), ne zaključke. Mapiranje
    // mere -> signal radi ISKLJUČIVO modul na serveru (detection.php).

    var pageLoadTime = Date.now();
    var mouseMoved = false;
    var scrolled = false;
    var mouseMoveBeforeFocus = false;
    var firstInputFocusHadMouse = false;
    var fieldFocusOrder = [];
    var fieldEdits = 0;

    document.addEventListener('mousemove', function () {
        mouseMoved = true;
        mouseMoveBeforeFocus = true;
    }, { once: true, passive: true });

    // Trajektorija miša (sirovi uzorci) za F5 mouse_trajectory. Zaključak (mehanički
    // pokret) računa modul; ovde samo skupljamo tačke, ograničeno.
    var mousePts = [];
    document.addEventListener('mousemove', function (e) {
        if (mousePts.length < 60) mousePts.push([e.clientX, e.clientY, Date.now()]);
    }, { passive: true });

    // True samo za STROGO mehanički pokret: dovoljno uzoraka + prava linija +
    // konstantna brzina. Odsustvo/kratak/ljudski pokret -> false (bez signal-šuma).
    function mouseLooksMechanical() {
        try {
            var p = mousePts;
            if (p.length < 12) return false;
            var dx = p[p.length - 1][0] - p[0][0], dy = p[p.length - 1][1] - p[0][1];
            var D = Math.sqrt(dx * dx + dy * dy);
            if (D < 50) return false;
            var path = 0, speeds = [];
            for (var i = 1; i < p.length; i++) {
                var sx = p[i][0] - p[i - 1][0], sy = p[i][1] - p[i - 1][1];
                var seg = Math.sqrt(sx * sx + sy * sy);
                path += seg;
                var dt = p[i][2] - p[i - 1][2];
                if (dt > 0) speeds.push(seg / dt);
            }
            if (path <= 0 || speeds.length < 8) return false;
            var straightness = D / path;
            var mean = 0, j; for (j = 0; j < speeds.length; j++) mean += speeds[j];
            mean /= speeds.length;
            if (mean <= 0) return false;
            var vv = 0, k; for (k = 0; k < speeds.length; k++) { var d = speeds[k] - mean; vv += d * d; }
            var cv = Math.sqrt(vv / speeds.length) / mean;
            return straightness > 0.99 && cv < 0.1;
        } catch (e) { return false; }
    }

    document.addEventListener('scroll', function () {
        scrolled = true;
    }, { once: true, passive: true });

    document.addEventListener('focusin', function (e) {
        if (e.target && /input|textarea|select/i.test(e.target.tagName)) {
            if (fieldFocusOrder.length === 0) {
                firstInputFocusHadMouse = mouseMoveBeforeFocus;
            }
            var name = e.target.name || e.target.id || e.target.type || 'field';
            fieldFocusOrder.push(name);
        }
    }, { passive: true });

    document.addEventListener('input', function () {
        fieldEdits++;
    }, { passive: true });

    // ---- Pojedinačni sirovi merači (svaki u try/catch; vrednost, ne presuda) ----

    function measureFonts() {
        try {
            var base = ['monospace', 'sans-serif', 'serif'];
            var test = ['Arial', 'Verdana', 'Times New Roman', 'Courier New', 'Georgia',
                        'Palatino', 'Garamond', 'Comic Sans MS', 'Trebuchet MS', 'Impact',
                        'Tahoma', 'Helvetica', 'Calibri', 'Cambria', 'Consolas'];
            var s = 'mmmmmmmmmmlli';
            var size = '72px';
            var span = document.createElement('span');
            span.style.cssText = 'position:absolute;left:-9999px;top:-9999px;font-size:' + size + ';';
            span.textContent = s;
            document.body.appendChild(span);
            var defaults = {};
            for (var i = 0; i < base.length; i++) {
                span.style.fontFamily = base[i];
                defaults[base[i]] = { w: span.offsetWidth, h: span.offsetHeight };
            }
            var detected = 0;
            for (var j = 0; j < test.length; j++) {
                var matched = false;
                for (var k = 0; k < base.length; k++) {
                    span.style.fontFamily = "'" + test[j] + "'," + base[k];
                    if (span.offsetWidth !== defaults[base[k]].w || span.offsetHeight !== defaults[base[k]].h) {
                        matched = true;
                        break;
                    }
                }
                if (matched) detected++;
            }
            document.body.removeChild(span);
            return detected;
        } catch (e) { return -1; }
    }

    function measureCanvas() {
        try {
            var c = document.createElement('canvas');
            c.width = 200; c.height = 50;
            var ctx = c.getContext('2d');
            if (!ctx) return '';
            ctx.textBaseline = 'top';
            ctx.font = '14px Arial';
            ctx.fillStyle = '#f60';
            ctx.fillRect(10, 10, 100, 30);
            ctx.fillStyle = '#069';
            ctx.fillText('BotEraser', 12, 14);
            var data = c.toDataURL();
            var h = 0;
            for (var i = 0; i < data.length; i++) {
                h = ((h << 5) - h + data.charCodeAt(i)) | 0;
            }
            return (h >>> 0).toString(16);
        } catch (e) { return ''; }
    }

    function measureWebGL() {
        try {
            var c = document.createElement('canvas');
            var gl = c.getContext('webgl') || c.getContext('experimental-webgl');
            if (!gl) return '';
            var ext = gl.getExtension('WEBGL_debug_renderer_info');
            if (!ext) return '';
            return String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '');
        } catch (e) { return ''; }
    }

    function measureAudio() {
        try {
            var AC = window.AudioContext || window.webkitAudioContext || window.OfflineAudioContext || window.webkitOfflineAudioContext;
            return AC ? 'ok' : '';
        } catch (e) { return ''; }
    }

    function detectPerfectOrder() {
        if (fieldFocusOrder.length < 2 || fieldEdits > 0) return false;
        for (var i = 1; i < fieldFocusOrder.length; i++) {
            if (fieldFocusOrder[i] === fieldFocusOrder[i - 1]) return false;
        }
        return true;
    }

    function collectMeasures() {
        var ua = navigator.userAgent || '';
        var isMobile = /Mobi|Android|iPhone|iPad|iPod/i.test(ua);
        var pageHeight = 0, viewHeight = 0;
        try {
            pageHeight = document.documentElement.scrollHeight || 0;
            viewHeight = window.innerHeight || 0;
        } catch (e) {}

        var honeypot = false;
        try {
            var hp = document.querySelector('input[data-be-honeypot]');
            honeypot = !!(hp && hp.value && hp.value.length > 0);
        } catch (e) {}

        return {
            // F1 — automation API (sirove zastavice)
            webdriver:          navigator.webdriver === true,
            phantom:            (typeof window.callPhantom !== 'undefined' || typeof window._phantom !== 'undefined'),
            nightmare:          (typeof window.__nightmare !== 'undefined'),
            dom_automation:     (typeof window.domAutomation !== 'undefined' || typeof window.domAutomationController !== 'undefined'),
            selenium:           (typeof window._selenium !== 'undefined' || typeof window.__webdriver_script_fn !== 'undefined'),
            fxdriver:           (typeof window.__webdriver_evaluate !== 'undefined' || typeof window.__fxdriver_evaluate !== 'undefined'),
            selenium_unwrapped: (typeof document.__selenium_unwrapped !== 'undefined'),
            awesomium:          (typeof window.awesomium !== 'undefined'),

            // F4 — fingerprint (sirove mere)
            is_mobile:          isMobile,
            plugins:            (navigator.plugins ? navigator.plugins.length : -1),
            languages:          (navigator.languages ? navigator.languages.length : -1),
            hardware:           (typeof navigator.hardwareConcurrency === 'number' ? navigator.hardwareConcurrency : -1),
            fonts:              measureFonts(),
            canvas:             measureCanvas(),
            webgl:              measureWebGL(),
            audio:              measureAudio(),
            has_chrome:         (typeof window.chrome !== 'undefined'),

            // F5 — bihevioralno (sirovo stanje u trenutku slanja)
            mouse_moved:        mouseMoved,
            scrolled:           scrolled,
            page_tall:          (pageHeight > viewHeight * 2),
            focus_had_mouse:    firstInputFocusHadMouse,
            perfect_order:      detectPerfectOrder(),
            mouse_linear:       mouseLooksMechanical(),
            load_to_submit_ms:  (Date.now() - pageLoadTime),

            // F3 — honeypot polje (skriveno; popunjeno samo od bota)
            honeypot_field:     honeypot
        };
    }

    function send() {
        if (!window.botEraserFP) return;
        var data = new FormData();
        data.append('action', 'bot_eraser_fingerprint');
        data.append('nonce', botEraserFP.nonce);
        data.append('measures', JSON.stringify(collectMeasures()));

        var xhr = new XMLHttpRequest();
        xhr.open('POST', botEraserFP.ajax_url, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    var r = JSON.parse(xhr.responseText);
                    if (r && r.redirect) window.location.replace(r.redirect);
                } catch (e) {}
            }
        };
        xhr.send(data);
    }

    function init() {
        var sent = false;
        function sendOnce() {
            if (sent) return;
            sent = true;
            send();
        }
        // Pošalji jednom: na submit, na napuštanje stranice, ili nakon kratkog
        // perioda (da svaki realan browser "obeleži JS viđen" i ne okine js_missing).
        document.addEventListener('submit', sendOnce, { passive: true });
        window.addEventListener('pagehide', sendOnce, { passive: true });
        setTimeout(sendOnce, 4000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
