(function () {
    'use strict';

    var signals = [];
    var pageLoadTime = Date.now();
    var mouseEventFired = false;
    var scrollEventFired = false;
    var mouseMoveBeforeFocus = false;
    var firstInputFocusHadMouse = false;
    var fieldFocusOrder = [];
    var fieldErrors = 0;

    // -------------------------------------------------------------------------
    // JS Definitive signals (IDs 2-9) — block immediately if any found
    // -------------------------------------------------------------------------

    function checkDefinitive() {

        // Signal 2: navigator.webdriver
        if (navigator.webdriver === true) {
            signals.push({ id: 2, group: 'js_definitive', label: 'webdriver' });
        }

        // Signal 3: PhantomJS
        if (typeof window.callPhantom !== 'undefined' || typeof window._phantom !== 'undefined') {
            signals.push({ id: 3, group: 'js_definitive', label: 'phantom' });
        }

        // Signal 4: Nightmare.js
        if (typeof window.__nightmare !== 'undefined') {
            signals.push({ id: 4, group: 'js_definitive', label: 'nightmare' });
        }

        // Signal 5: Chrome DevTools automation
        if (typeof window.domAutomation !== 'undefined' || typeof window.domAutomationController !== 'undefined') {
            signals.push({ id: 5, group: 'js_definitive', label: 'dom_automation' });
        }

        // Signal 6: Selenium variants
        if (typeof window._selenium !== 'undefined' || typeof window.__webdriver_script_fn !== 'undefined') {
            signals.push({ id: 6, group: 'js_definitive', label: 'selenium' });
        }

        // Signal 7: Firefox WebDriver
        if (typeof window.__webdriver_evaluate !== 'undefined' || typeof window.__fxdriver_evaluate !== 'undefined') {
            signals.push({ id: 7, group: 'js_definitive', label: 'fxdriver' });
        }

        // Signal 8: Selenium unwrapped
        if (typeof document.__selenium_unwrapped !== 'undefined') {
            signals.push({ id: 8, group: 'js_definitive', label: 'selenium_unwrapped' });
        }

        // Signal 9: Awesomium
        if (typeof window.awesomium !== 'undefined') {
            signals.push({ id: 9, group: 'js_definitive', label: 'awesomium' });
        }

        // NOTE: WebGL/headless_gpu signal removed — too many false positives
        // (remote desktop, Linux, disabled GPU acceleration)
    }

    // -------------------------------------------------------------------------
    // JS Behavioral (IDs 11-17) — scoring only, never block alone
    // -------------------------------------------------------------------------

    document.addEventListener('mousemove', function () {
        mouseEventFired = true;
        mouseMoveBeforeFocus = true;
    }, { once: true, passive: true });

    document.addEventListener('scroll', function () {
        scrollEventFired = true;
    }, { once: true, passive: true });

    document.addEventListener('focusin', function (e) {
        if (e.target && /input|textarea|select/i.test(e.target.tagName)) {
            firstInputFocusHadMouse = mouseMoveBeforeFocus;
        }
    }, { once: true, passive: true });

    document.addEventListener('focusin', function (e) {
        if (e.target && /input|textarea|select/i.test(e.target.tagName)) {
            var name = e.target.name || e.target.id || e.target.type || 'field';
            fieldFocusOrder.push(name);
        }
    }, { passive: true });

    document.addEventListener('input', function () {
        fieldErrors++;
    }, { passive: true });

    function checkBehavioral() {

        // Signal 11: No mouse event before submit
        if (!mouseEventFired) {
            signals.push({ id: 11, group: 'js_behavioral', label: 'no_mouse' });
        }

        // Signal 12: Pageload to send < 500ms
        if (Date.now() - pageLoadTime < 500) {
            signals.push({ id: 12, group: 'js_behavioral', label: 'fast_submit' });
        }

        // Signal 13: navigator.plugins empty on desktop UA
        var ua = navigator.userAgent || '';
        var isMobile = /Mobi|Android|iPhone|iPad/i.test(ua);
        if (!isMobile && navigator.plugins && navigator.plugins.length === 0) {
            signals.push({ id: 13, group: 'js_behavioral', label: 'no_plugins' });
        }

        // Signal 14: navigator.languages empty
        if (!navigator.languages || navigator.languages.length === 0) {
            signals.push({ id: 14, group: 'js_behavioral', label: 'no_languages' });
        }

        // Signal 15: No scroll on long page
        var pageHeight = document.documentElement.scrollHeight || 0;
        var viewHeight = window.innerHeight || 0;
        if (pageHeight > viewHeight * 2 && !scrollEventFired) {
            signals.push({ id: 15, group: 'js_behavioral', label: 'no_scroll' });
        }

        // Signal 16: Direct focus without mouse movement
        if (!firstInputFocusHadMouse && !mouseEventFired) {
            signals.push({ id: 16, group: 'js_behavioral', label: 'focus_no_mouse' });
        }

        // Signal 17: Perfect sequential field order, no corrections
        if (fieldFocusOrder.length >= 2 && fieldErrors === 0) {
            var isSequential = true;
            for (var i = 1; i < fieldFocusOrder.length; i++) {
                if (fieldFocusOrder[i] === fieldFocusOrder[i - 1]) {
                    isSequential = false;
                    break;
                }
            }
            if (isSequential) {
                signals.push({ id: 17, group: 'js_behavioral', label: 'perfect_order' });
            }
        }
    }

    // -------------------------------------------------------------------------
    // Send signals to server
    // -------------------------------------------------------------------------

    function sendSignals() {
        if (!window.botEraserFP || signals.length === 0) return;

        var data = new FormData();
        data.append('action', 'bot_eraser_fingerprint');
        data.append('nonce', botEraserFP.nonce);
        data.append('signals', JSON.stringify(signals));

        var xhr = new XMLHttpRequest();
        xhr.open('POST', botEraserFP.ajax_url, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.redirect) {
                        window.location.replace(response.redirect);
                    }
                } catch (e) {}
            }
        };
        xhr.send(data);
    }

    // -------------------------------------------------------------------------
    // Init
    // -------------------------------------------------------------------------

    function init() {
        checkDefinitive();

        // Definitive signal found — send immediately
        var hasDefinitive = signals.some(function (s) { return s.group === 'js_definitive'; });
        if (hasDefinitive) {
            sendSignals();
            return;
        }

        var sent = false;

        function sendOnce() {
            if (sent) return;
            sent = true;
            checkBehavioral();
            sendSignals();
        }

        // Send on form submit
        document.addEventListener('submit', sendOnce, { passive: true });

        // Send on page unload
        window.addEventListener('pagehide', sendOnce, { passive: true });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
