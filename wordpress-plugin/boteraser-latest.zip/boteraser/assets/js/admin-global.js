/**
 * Boteraser Global Admin JavaScript
 * Loaded on all admin pages and frontend when admin bar is visible.
 *
 * @package Boteraser
 * @version 1.0.0
 */

(function() {
    'use strict';

    // =========================================================================
    // 1. Admin Bar Mobile Toggle
    // =========================================================================
    function botEraserInitAdminBar() {
        var item    = document.getElementById('wp-admin-bar-boteraser');
        if (!item) return;
        var wrapper = item.querySelector('.ab-sub-wrapper');
        var link    = item.querySelector('a.ab-item');
        if (!wrapper || !link) return;

        var breakpoint = (typeof boteraser_global !== 'undefined' && boteraser_global.mobileBreakpoint)
            ? boteraser_global.mobileBreakpoint
            : 782;

        // Force wrapper visible when item has our open class
        wrapper.style.cssText = '';

        function open() {
            item.setAttribute('data-be-open', '1');
            wrapper.style.display = 'block';
        }
        function close() {
            item.removeAttribute('data-be-open');
            wrapper.style.display = '';
        }
        function isOpen() {
            return item.hasAttribute('data-be-open');
        }

        // Mobile: tap toggles
        link.addEventListener('click', function(e) {
            if (window.innerWidth > breakpoint) return;
            e.preventDefault();
            e.stopImmediatePropagation();
            isOpen() ? close() : open();
        }, true);

        // Close on tap outside
        document.addEventListener('click', function(e) {
            if (window.innerWidth > breakpoint) return;
            if (!item.contains(e.target)) close();
        }, true);

        // Desktop: hover
        item.addEventListener('mouseenter', function() {
            if (window.innerWidth <= breakpoint) return;
            open();
        });
        item.addEventListener('mouseleave', function() {
            if (window.innerWidth <= breakpoint) return;
            close();
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', botEraserInitAdminBar);
    } else {
        botEraserInitAdminBar();
    }

    // =========================================================================
    // 2. Privacy Notice Dismiss
    // =========================================================================
    function botEraserInitPrivacyNotice() {
        var notice = document.getElementById('bot-eraser-privacy-notice');
        if (!notice) return;

        // Use jQuery since it's available on all admin pages
        if (typeof jQuery === 'undefined') return;

        var $ = jQuery;
        var globalData = (typeof boteraser_global !== 'undefined') ? boteraser_global : {};

        $('#bot-eraser-dismiss-notice').on('click', function(e) {
            e.preventDefault();
            var button = $(this);
            button.prop('disabled', true).text(globalData.privacyProcessingText || 'Processing...');

            $.post(ajaxurl, {
                action: 'bot_eraser_dismiss_privacy_notice',
                nonce: globalData.privacyNonce || ''
            }, function() {
                $('#bot-eraser-privacy-notice').fadeOut(300, function() {
                    $(this).remove();
                });
            }).fail(function() {
                button.prop('disabled', false).text(globalData.privacyAcceptText || 'I Understand and Accept');
                alert(globalData.privacyErrorText || 'Error dismissing notice. Please try again.');
            });
        });

        // Handle native WordPress dismiss button
        $('#bot-eraser-privacy-notice').on('click', '.notice-dismiss', function() {
            $.post(ajaxurl, {
                action: 'bot_eraser_dismiss_privacy_notice',
                nonce: globalData.privacyNonce || ''
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', botEraserInitPrivacyNotice);
    } else {
        botEraserInitPrivacyNotice();
    }

})();
