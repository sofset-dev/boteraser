/**
 * Boteraser Admin JavaScript
 * Premium WordPress Plugin UI
 *
 * @package Boteraser
 * @version 1.0.0
 */

(function($) {
    'use strict';

    // Global namespace
    window.Boteraser = window.Boteraser || {};

    /**
     * Utility functions
     */
    Boteraser.Utils = {
        /**
         * Simple hash function for API key comparison
         */
        simpleHash: function(str) {
            var hash = 0;
            if (str.length === 0) return hash.toString(16);
            for (var i = 0; i < str.length; i++) {
                var char = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & 0xffffffff;
            }
            return Math.abs(hash).toString(16);
        },

        /**
         * Format number with commas
         */
        formatNumber: function(num) {
            return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },

        /**
         * Format bytes to human readable
         */
        formatBytes: function(bytes, decimals) {
            if (bytes === 0) return '0 Bytes';
            var k = 1024;
            var dm = decimals || 2;
            var sizes = ['Bytes', 'KB', 'MB', 'GB'];
            var i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
        },

        /**
         * Format uptime to human readable
         */
        formatUptime: function(seconds) {
            var days = Math.floor(seconds / 86400);
            var hours = Math.floor((seconds % 86400) / 3600);
            var minutes = Math.floor((seconds % 3600) / 60);
            var parts = [];
            if (days > 0) parts.push(days + 'd');
            if (hours > 0) parts.push(hours + 'h');
            if (minutes > 0) parts.push(minutes + 'm');
            return parts.length > 0 ? parts.join(' ') : '0m';
        },

        /**
         * Debounce function
         */
        debounce: function(func, wait) {
            var timeout;
            return function() {
                var context = this, args = arguments;
                clearTimeout(timeout);
                timeout = setTimeout(function() {
                    func.apply(context, args);
                }, wait);
            };
        }
    };

    /**
     * SVG Icons
     */
    Boteraser.Icons = {
        shield: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>',
        shieldCheck: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>',
        shieldX: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="9" y1="9" x2="15" y2="15"></line><line x1="15" y1="9" x2="9" y2="15"></line></svg>',
        key: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>',
        check: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>',
        checkCircle: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
        xCircle: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        alertCircle: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
        info: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
        loader: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>',
        activity: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>',
        server: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>',
        database: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path></svg>',
        cloud: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path></svg>',
        globe: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>',
        users: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        ban: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>',
        fileText: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>',
        settings: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>',
        externalLink: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>',
        refresh: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>',
        clock: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>',
        zap: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>',
        trendingUp: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>',
        trendingDown: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline><polyline points="17 18 23 18 23 12"></polyline></svg>',
        arrowRight: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
        play: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>',
        trash: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>'
    };

    /**
     * API Key Validation Module
     */
    Boteraser.ApiKey = {
        $input: null,
        $wrapper: null,
        $indicator: null,
        savedValidationState: null,
        serverApiKey: '',

        init: function(config) {
            this.$input = $('#boteraser-api-key');
            this.$wrapper = this.$input.closest('.boteraser-api-input-wrapper');
            this.$indicator = $('.boteraser-status-indicator');
            this.savedValidationState = config.validationState || null;
            this.serverApiKey = config.apiKey || '';

            this.bindEvents();
            this.checkInitialState();
        },

        bindEvents: function() {
            var self = this;

            // Input change handler with debounce
            this.$input.on('input', Boteraser.Utils.debounce(function() {
                self.checkApiKeyState();
            }, 300));

            // Focus effects
            this.$input.on('focus', function() {
                self.$wrapper.addClass('focused');
            }).on('blur', function() {
                self.$wrapper.removeClass('focused');
            });
        },

        checkInitialState: function() {
            var currentApiKey = this.$input.val().trim();

            if (currentApiKey === '') {
                this.showNotVerifiedState();
                return;
            }

            if (this.savedValidationState && this.savedValidationState.api_key_hash) {
                var currentKeyHash = Boteraser.Utils.simpleHash(currentApiKey);

                if (currentKeyHash === this.savedValidationState.api_key_hash) {
                    this.updateValidationUI(
                        this.savedValidationState.is_valid,
                        this.savedValidationState.message
                    );
                } else {
                    this.showNotVerifiedState();
                }
            } else {
                this.showNotVerifiedState();
            }
        },

        checkApiKeyState: function() {
            var currentApiKey = this.$input.val().trim();

            if (currentApiKey === '') {
                this.showNotVerifiedState();
                return;
            }

            if (this.savedValidationState && this.savedValidationState.api_key_hash) {
                var currentKeyHash = Boteraser.Utils.simpleHash(currentApiKey);

                if (currentKeyHash === this.savedValidationState.api_key_hash) {
                    this.updateValidationUI(
                        this.savedValidationState.is_valid,
                        this.savedValidationState.message
                    );
                } else {
                    this.showNotVerifiedState();
                }
            } else {
                this.showNotVerifiedState();
            }
        },

        showNotVerifiedState: function() {
            this.$input.removeClass('valid invalid validating');
            this.$indicator
                .removeClass('valid invalid validating visible')
                .find('.boteraser-status-icon-svg').html(Boteraser.Icons.shield);
            this.$indicator.find('.boteraser-status-text').text('Not Verified');
        },

        showValidatingState: function() {
            this.$input.removeClass('valid invalid').addClass('validating');
            this.$indicator
                .removeClass('valid invalid')
                .addClass('validating visible')
                .find('.boteraser-status-icon-svg').html(Boteraser.Icons.loader);
            this.$indicator.find('.boteraser-status-text').text('Validating...');
        },

        updateValidationUI: function(isValid, message) {
            this.$input.removeClass('validating valid invalid');
            this.$indicator.removeClass('validating valid invalid').addClass('visible');

            if (isValid === true) {
                this.$input.addClass('valid');
                this.$indicator.addClass('valid')
                    .find('.boteraser-status-icon-svg').html(Boteraser.Icons.shieldCheck);
                this.$indicator.find('.boteraser-status-text').text(message || 'API Key Valid');
            } else if (isValid === false) {
                this.$input.addClass('invalid');
                this.$indicator.addClass('invalid')
                    .find('.boteraser-status-icon-svg').html(Boteraser.Icons.shieldX);
                this.$indicator.find('.boteraser-status-text').text(message || 'Invalid API Key');
            }
        }
    };

    /**
     * Progress Bar Module
     */
    Boteraser.ProgressBar = {
        $bar: null,
        $fill: null,

        init: function() {
            this.$bar = $('.boteraser-progress-bar');
            this.$fill = this.$bar.find('.boteraser-progress-bar-fill');
        },

        show: function() {
            this.$bar.addClass('active');
        },

        hide: function() {
            this.$bar.removeClass('active');
        },

        setProgress: function(percent) {
            this.$fill.css('width', percent + '%');
        }
    };

    /**
     * Stats Animation Module
     */
    Boteraser.Stats = {
        init: function() {
            this.animateCounters();
        },

        animateCounters: function() {
            $('.boteraser-stat-value[data-count]').each(function() {
                var $this = $(this);
                var target = parseInt($this.data('count'), 10);
                var duration = 1000;
                var start = 0;
                var startTime = null;

                function animate(currentTime) {
                    if (!startTime) startTime = currentTime;
                    var progress = Math.min((currentTime - startTime) / duration, 1);
                    var value = Math.floor(progress * (target - start) + start);
                    $this.text(Boteraser.Utils.formatNumber(value));

                    if (progress < 1) {
                        requestAnimationFrame(animate);
                    }
                }

                requestAnimationFrame(animate);
            });
        }
    };

    /**
     * Execution Timeline Module
     */
    Boteraser.Timeline = {
        maxItems: 5,
        storageKey: 'boteraser_execution_timeline',

        init: function() {
            this.render();
        },

        addEntry: function(entry) {
            var timeline = this.getTimeline();
            timeline.unshift({
                timestamp: new Date().toISOString(),
                status: entry.status,
                message: entry.message
            });

            // Keep only the last maxItems
            if (timeline.length > this.maxItems) {
                timeline = timeline.slice(0, this.maxItems);
            }

            localStorage.setItem(this.storageKey, JSON.stringify(timeline));
            this.render();
        },

        getTimeline: function() {
            try {
                return JSON.parse(localStorage.getItem(this.storageKey)) || [];
            } catch (e) {
                return [];
            }
        },

        render: function() {
            var $container = $('.boteraser-timeline-list');
            if (!$container.length) return;

            var timeline = this.getTimeline();
            if (timeline.length === 0) {
                $container.html('<div class="boteraser-timeline-empty">No recent executions</div>');
                return;
            }

            var html = timeline.map(function(entry) {
                var date = new Date(entry.timestamp);
                var timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                var dateStr = date.toLocaleDateString([], { month: 'short', day: 'numeric' });

                return '<div class="boteraser-timeline-item">' +
                    '<div class="boteraser-timeline-dot ' + entry.status + '"></div>' +
                    '<div class="boteraser-timeline-time">' + dateStr + ' ' + timeStr + '</div>' +
                    '<div class="boteraser-timeline-message">' + entry.message + '</div>' +
                    '</div>';
            }).join('');

            $container.html(html);
        }
    };

    /**
     * Form Submission Handler
     */
    Boteraser.Forms = {
        init: function() {
            this.bindManualExecution();
        },

        bindManualExecution: function() {
            var $form = $('form[name="boteraser_manual_run"]');
            if (!$form.length) return;

            $form.on('submit', function() {
                Boteraser.ProgressBar.show();
                $(this).find('button[type="submit"]')
                    .prop('disabled', true)
                    .html(Boteraser.Icons.loader + ' Running...');
            });
        }
    };

    /**
     * Tooltips Module
     */
    Boteraser.Tooltips = {
        init: function() {
            $('[data-tooltip]').each(function() {
                var $el = $(this);
                var text = $el.data('tooltip');

                $el.on('mouseenter', function(e) {
                    var $tooltip = $('<div class="boteraser-tooltip">' + text + '</div>');
                    $('body').append($tooltip);

                    var offset = $el.offset();
                    $tooltip.css({
                        top: offset.top - $tooltip.outerHeight() - 8,
                        left: offset.left + ($el.outerWidth() / 2) - ($tooltip.outerWidth() / 2)
                    });
                }).on('mouseleave', function() {
                    $('.boteraser-tooltip').remove();
                });
            });
        }
    };

    /**
     * Smooth Scroll
     */
    Boteraser.SmoothScroll = {
        init: function() {
            $('a[href^="#"]').on('click', function(e) {
                var target = $($(this).attr('href'));
                if (target.length) {
                    e.preventDefault();
                    $('html, body').animate({
                        scrollTop: target.offset().top - 100
                    }, 500);
                }
            });
        }
    };

    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        // Only initialize on Boteraser admin pages
        if (!$('.boteraser-wrap').length) return;

        console.log('Boteraser: Initializing admin interface');

        // Initialize modules
        Boteraser.Stats.init();
        Boteraser.ProgressBar.init();
        Boteraser.Timeline.init();
        Boteraser.Forms.init();
        Boteraser.Tooltips.init();
        Boteraser.SmoothScroll.init();

        // API Key module is initialized from PHP with config
        if (typeof boteraser_config !== 'undefined') {
            Boteraser.ApiKey.init(boteraser_config);
        }

        console.log('Boteraser: Admin interface ready');
    });

})(jQuery);
