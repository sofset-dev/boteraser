/**
 * Boteraser Admin JavaScript
 * Premium WordPress Plugin UI
 *
 * @package Boteraser
 * @version 1.0.0
 */

(function($) {
    'use strict';

    // Global namespace
    window.Boteraser = window.Boteraser || {};

    /**
     * Utility functions
     */
    Boteraser.Utils = {
        /**
         * Simple hash function for API key comparison
         */
        simpleHash: function(str) {
            var hash = 0;
            if (str.length === 0) return hash.toString(16);
            for (var i = 0; i < str.length; i++) {
                var char = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & 0xffffffff;
            }
            return Math.abs(hash).toString(16);
        },

        /**
         * Format number with commas
         */
        formatNumber: function(num) {
            return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },

        /**
         * Format bytes to human readable
         */
        formatBytes: function(bytes, decimals) {
            if (bytes === 0) return '0 Bytes';
            var k = 1024;
            var dm = decimals || 2;
            var sizes = ['Bytes', 'KB', 'MB', 'GB'];
            var i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
        },

        /**
         * Format uptime to human readable
         */
        formatUptime: function(seconds) {
            var days = Math.floor(seconds / 86400);
            var hours = Math.floor((seconds % 86400) / 3600);
            var minutes = Math.floor((seconds % 3600) / 60);
            var parts = [];
            if (days > 0) parts.push(days + 'd');
            if (hours > 0) parts.push(hours + 'h');
            if (minutes > 0) parts.push(minutes + 'm');
            return parts.length > 0 ? parts.join(' ') : '0m';
        },

        /**
         * Debounce function
         */
        debounce: function(func, wait) {
            var timeout;
            return function() {
                var context = this, args = arguments;
                clearTimeout(timeout);
                timeout = setTimeout(function() {
                    func.apply(context, args);
                }, wait);
            };
        }
    };

    /**
     * SVG Icons
     */
    Boteraser.Icons = {
        shield: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>',
        shieldCheck: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>',
        shieldAlert: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
        shieldX: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="9" y1="9" x2="15" y2="15"></line><line x1="15" y1="9" x2="9" y2="15"></line></svg>',
        key: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>',
        check: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>',
        checkCircle: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
        xCircle: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        alertCircle: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
        info: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
        loader: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>',
        activity: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>',
        server: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>',
        database: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path></svg>',
        cloud: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path></svg>',
        globe: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>',
        users: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        ban: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>',
        fileText: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>',
        settings: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>',
        externalLink: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>',
        refresh: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>',
        clock: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>',
        zap: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>',
        trendingUp: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>',
        trendingDown: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline><polyline points="17 18 23 18 23 12"></polyline></svg>',
        arrowRight: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
        play: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>',
        pause: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>',
        shieldOff: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19.69 14a6.9 6.9 0 0 0 .31-2V5l-8-3-3.16 1.18"></path><path d="M4.73 4.73L4 5v7c0 6 8 10 8 10a20.29 20.29 0 0 0 5.62-4.38"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>',
        trash: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>'
    };

    /**
     * API Key Validation Module
     */
    Boteraser.ApiKey = {
        $input: null,
        $wrapper: null,
        $indicator: null,
        savedValidationState: null,
        serverApiKey: '',

        init: function(config) {
            this.$input = $('#boteraser-api-key');
            this.$wrapper = this.$input.closest('.boteraser-api-input-wrapper');
            this.$indicator = $('.boteraser-status-indicator');
            this.savedValidationState = config.validationState || null;
            this.serverApiKey = config.apiKey || '';

            this.bindEvents();
            this.checkInitialState();
        },

        bindEvents: function() {
            var self = this;

            // Input change handler with debounce
            this.$input.on('input', Boteraser.Utils.debounce(function() {
                self.checkApiKeyState();
            }, 300));

            // Focus effects
            this.$input.on('focus', function() {
                self.$wrapper.addClass('focused');
            }).on('blur', function() {
                self.$wrapper.removeClass('focused');
            });
        },

        checkInitialState: function() {
            var currentApiKey = this.$input.val().trim();

            if (currentApiKey === '') {
                this.showNotVerifiedState();
                return;
            }

            if (this.savedValidationState && this.savedValidationState.api_key_hash) {
                var currentKeyHash = Boteraser.Utils.simpleHash(currentApiKey);

                if (currentKeyHash === this.savedValidationState.api_key_hash) {
                    this.updateValidationUI(
                        this.savedValidationState.is_valid,
                        this.savedValidationState.message
                    );
                } else {
                    this.showNotVerifiedState();
                }
            } else {
                this.showNotVerifiedState();
            }
        },

        checkApiKeyState: function() {
            var currentApiKey = this.$input.val().trim();

            if (currentApiKey === '') {
                this.showNotVerifiedState();
                return;
            }

            if (this.savedValidationState && this.savedValidationState.api_key_hash) {
                var currentKeyHash = Boteraser.Utils.simpleHash(currentApiKey);

                if (currentKeyHash === this.savedValidationState.api_key_hash) {
                    this.updateValidationUI(
                        this.savedValidationState.is_valid,
                        this.savedValidationState.message
                    );
                } else {
                    this.showNotVerifiedState();
                }
            } else {
                this.showNotVerifiedState();
            }
        },

        showNotVerifiedState: function() {
            this.$input.removeClass('valid invalid validating');
            this.$indicator
                .removeClass('valid invalid validating visible')
                .find('.boteraser-status-icon-svg').html(Boteraser.Icons.shield);
            this.$indicator.find('.boteraser-status-text').text('Not Verified');
        },

        showValidatingState: function() {
            this.$input.removeClass('valid invalid').addClass('validating');
            this.$indicator
                .removeClass('valid invalid')
                .addClass('validating visible')
                .find('.boteraser-status-icon-svg').html(Boteraser.Icons.loader);
            this.$indicator.find('.boteraser-status-text').text('Validating...');
        },

        updateValidationUI: function(isValid, message) {
            this.$input.removeClass('validating valid invalid');
            this.$indicator.removeClass('validating valid invalid').addClass('visible');

            if (isValid === true) {
                this.$input.addClass('valid');
                this.$indicator.addClass('valid')
                    .find('.boteraser-status-icon-svg').html(Boteraser.Icons.shieldCheck);
                this.$indicator.find('.boteraser-status-text').text(message || 'API Key Valid');
            } else if (isValid === false) {
                this.$input.addClass('invalid');
                this.$indicator.addClass('invalid')
                    .find('.boteraser-status-icon-svg').html(Boteraser.Icons.shieldAlert);
                this.$indicator.find('.boteraser-status-text').text(message || 'Invalid API Key');
            }
        }
    };

    /**
     * Progress Bar Module
     */
    Boteraser.ProgressBar = {
        $bar: null,
        $fill: null,

        init: function() {
            this.$bar = $('.boteraser-progress-bar');
            this.$fill = this.$bar.find('.boteraser-progress-bar-fill');
        },

        show: function() {
            this.$bar.addClass('active');
        },

        hide: function() {
            this.$bar.removeClass('active');
        },

        setProgress: function(percent) {
            this.$fill.css('width', percent + '%');
        }
    };

    /**
     * Stats Animation Module — count-up with easeOutExpo easing + scale pop
     */
    Boteraser.Stats = {
        init: function() {
            this.animateCounters();
            this.animateHeroKpis();
        },

        /**
         * EaseOutExpo: fast start, gentle landing
         */
        easeOutExpo: function(t) {
            return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
        },

        /**
         * Animate a single element from 0 to its target numeric value.
         */
        animateValue: function($el, target, duration, formatFn) {
            var self = this;
            var startTime = null;
            var startVal = 0;
            formatFn = formatFn || Boteraser.Utils.formatNumber;

            function step(timestamp) {
                if (!startTime) startTime = timestamp;
                var elapsed = timestamp - startTime;
                var progress = Math.min(elapsed / duration, 1);
                var eased = self.easeOutExpo(progress);
                var current = Math.round(eased * (target - startVal) + startVal);
                $el.text(formatFn(current));

                if (progress < 1) {
                    requestAnimationFrame(step);
                } else {
                    // Final value with scale-pop micro-interaction
                    $el.text(formatFn(target));
                    $el.css({ transform: 'scale(1.08)', transition: 'transform 0.15s ease' });
                    requestAnimationFrame(function() {
                        $el.css({ transform: 'scale(1)', transition: 'transform 0.25s ease' });
                    });
                }
            }

            requestAnimationFrame(step);
        },

        animateCounters: function() {
            var self = this;
            // Animate all stat values that have data-count attributes
            $('.boteraser-stat-value[data-count]').each(function() {
                var $this = $(this);
                var target = parseInt($this.data('count'), 10);
                if (isNaN(target) || target <= 0) return;

                // Store original text for format detection
                var originalText = $this.text().trim();
                var isPercent = originalText.indexOf('%') !== -1;

                self.animateValue($this, target, 1200, function(val) {
                    return isPercent ? val + '%' : Boteraser.Utils.formatNumber(val);
                });
            });
        },

        animateHeroKpis: function() {
            var self = this;
            // Animate hero KPI values
            $('.boteraser-hero-kpi-value').each(function() {
                var $this = $(this);
                var text = $this.text().trim();
                // Extract numeric part
                var match = text.match(/^([\d,]+)/);
                if (!match) return;
                var target = parseInt(match[1].replace(/,/g, ''), 10);
                if (isNaN(target) || target <= 0) return;

                var suffix = text.replace(/^[\d,]+/, '');
                self.animateValue($this, target, 1000, function(val) {
                    return Boteraser.Utils.formatNumber(val) + suffix;
                });
            });
        }
    };


    /**
     * Form Submission Handler
     */
    Boteraser.Forms = {
        init: function() {
            this.bindManualExecution();
        },

        bindManualExecution: function() {
            var $form = $('form[name="boteraser_manual_run"]');
            if (!$form.length) return;

            $form.on('submit', function() {
                Boteraser.ProgressBar.show();
                $(this).find('button[type="submit"]')
                    .prop('disabled', true)
                    .html(Boteraser.Icons.loader + ' Running...');
            });
        }
    };

    /**
     * Tooltips Module
     */
    Boteraser.Tooltips = {
        init: function() {
            var self = this;
            $(document).on('mouseenter', '[data-tooltip]', function() {
                self.show($(this), $(this).data('tooltip'));
            }).on('mouseleave', '[data-tooltip]', function() {
                self.hide();
            });
        },

        show: function($el, text) {
            this.hide(); // Remove any existing tooltips

            var $tooltip = $('<div class="boteraser-tooltip">' + text + '</div>');
            $('body').append($tooltip);

            var offset = $el.offset();
            var elWidth = $el.outerWidth();
            var tooltipWidth = $tooltip.outerWidth();
            var tooltipHeight = $tooltip.outerHeight();

            // Calculate position
            var left = offset.left + (elWidth / 2) - (tooltipWidth / 2);
            var top = offset.top - tooltipHeight - 12;

            // Ensure tooltip stays within viewport
            if (left < 10) left = 10;
            if (left + tooltipWidth > $(window).width() - 10) {
                left = $(window).width() - tooltipWidth - 10;
            }

            $tooltip.css({
                top: top,
                left: left
            });
        },

        hide: function() {
            $('.boteraser-tooltip').remove();
        }
    };

    /**
     * Sparkline Charts Module — SVG-based with gradient fill
     */
    Boteraser.Sparklines = {
        init: function() {
            var self = this;
            var logStart = (typeof boteraser_config !== 'undefined' && boteraser_config.sparklineData && boteraser_config.sparklineData.logStart)
                ? boteraser_config.sparklineData.logStart
                : null;

            $('.boteraser-sparkline').each(function() {
                var $el = $(this);
                var metric = $el.data('metric');

                // Replace canvas with SVG container
                var $svg = self.draw($el, metric);
                $el.replaceWith($svg);

                // Wrap and add time range labels
                if (!$svg.parent().hasClass('boteraser-sparkline-wrapper')) {
                    $svg.wrap('<div class="boteraser-sparkline-wrapper"></div>');
                    var startLabel = logStart ? logStart : '—';
                    $svg.after(
                        '<div class="boteraser-sparkline-timerange">' +
                        '<span>' + startLabel + '</span>' +
                        '<span>now</span>' +
                        '</div>'
                    );
                }
            });
        },

        draw: function($el, metric) {
            var data = this.generateSampleData(metric);
            if (!data || data.length < 2) {
                data = [0, 0, 0, 0, 0, 0, 0, 0];
            }

            var W = 120;
            var H = 36;
            var pad = 2; // padding so the stroke doesn't clip at edges

            // Normalize data to SVG coordinates
            var min = Math.min.apply(null, data);
            var max = Math.max.apply(null, data);
            var range = max - min || 1;

            // Read accent color from the card's icon
            var iconEl = $el.closest('.boteraser-stat-card').find('.boteraser-stat-icon')[0];
            var iconColor = iconEl ? window.getComputedStyle(iconEl).color : 'rgb(37, 99, 235)';
            var rgbMatch = iconColor.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
            var r, g, b;
            if (rgbMatch) {
                r = rgbMatch[1]; g = rgbMatch[2]; b = rgbMatch[3];
            } else {
                r = 37; g = 99; b = 235;
            }

            var strokeColor = 'rgb(' + r + ',' + g + ',' + b + ')';
            var gradientId  = 'be-sparkline-grad-' + metric + '-' + Math.floor(Math.random() * 10000);

            // Build polyline points
            var points = [];
            for (var i = 0; i < data.length; i++) {
                var x = pad + ((i / (data.length - 1)) * (W - pad * 2));
                var y = pad + (H - pad * 2) - (((data[i] - min) / range) * (H - pad * 2));
                points.push(x.toFixed(1) + ',' + y.toFixed(1));
            }
            var polylinePoints = points.join(' ');

            // Build area polygon (add bottom corners for gradient fill)
            var areaPoints = points.slice();
            areaPoints.push((pad + W - pad * 2).toFixed(1) + ',' + (H - pad).toFixed(1));
            areaPoints.push(pad.toFixed(1) + ',' + (H - pad).toFixed(1));
            var polygonPoints = areaPoints.join(' ');

            // Detect trend direction for dot color
            var trend = 'neutral';
            if (data[data.length - 1] > data[0] * 1.1) trend = 'up';
            else if (data[data.length - 1] < data[0] * 0.9) trend = 'down';
            var dotColor = trend === 'up' ? 'rgb(16,185,129)' : (trend === 'down' ? 'rgb(239,68,68)' : strokeColor);

            var lastPoint = points[points.length - 1].split(',');
            var dotX = parseFloat(lastPoint[0]);
            var dotY = parseFloat(lastPoint[1]);

            var svg = '<svg class="boteraser-sparkline-svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '" preserveAspectRatio="none" aria-hidden="true">' +
                '<defs>' +
                    '<linearGradient id="' + gradientId + '" x1="0" y1="0" x2="0" y2="1">' +
                        '<stop offset="0%" stop-color="' + strokeColor + '" stop-opacity="0.25"/>' +
                        '<stop offset="100%" stop-color="' + strokeColor + '" stop-opacity="0.02"/>' +
                    '</linearGradient>' +
                '</defs>' +
                '<polygon points="' + polygonPoints + '" fill="url(#' + gradientId + ')" stroke="none"/>' +
                '<polyline points="' + polylinePoints + '" fill="none" stroke="' + strokeColor + '" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
                '<circle cx="' + dotX + '" cy="' + dotY + '" r="2.5" fill="' + dotColor + '" stroke="#fff" stroke-width="1.5"/>' +
            '</svg>';

            return $(svg);
        },

        generateSampleData: function(metric) {
            if (typeof boteraser_config !== 'undefined' && boteraser_config.sparklineData && boteraser_config.sparklineData[metric]) {
                return boteraser_config.sparklineData[metric];
            }
            return [0, 0, 0, 0, 0, 0, 0, 0];
        }
    };

    /**
     * Smooth Scroll
     */
    Boteraser.SmoothScroll = {
        init: function() {
            $('a[href^="#"]').on('click', function(e) {
                var target = $($(this).attr('href'));
                if (target.length) {
                    e.preventDefault();
                    $('html, body').animate({
                        scrollTop: target.offset().top - 100
                    }, 500);
                }
            });
        }
    };

    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        // Only initialize on Boteraser admin pages
        if (!$('.boteraser-wrap').length) return;

        console.log('Boteraser: Initializing admin interface');

        // Initialize modules
        Boteraser.Stats.init();
        Boteraser.ProgressBar.init();
        Boteraser.Forms.init();
        Boteraser.Tooltips.init();
        Boteraser.Sparklines.init();
        Boteraser.SmoothScroll.init();
        Boteraser.SnapshotTabs.init();
        Boteraser.LiveTraffic.init();
        Boteraser.VulnCheck.init();

        // Clickable stat cards
        $(document).on('click', '.boteraser-stat-card-link[data-href]', function(e) {
            if ($(e.target).closest('.boteraser-stat-help').length) return;
            window.location.href = $(this).data('href');
        });

        // Unblock IP via AJAX
        $(document).on('click', '.be-unblock-btn', function() {
            var $btn = $(this);
            var ip = $btn.data('ip');
            var nonce = $btn.data('nonce');
            var confirm_msg = $btn.data('confirm');

            if (!confirm(confirm_msg)) return;

            $btn.prop('disabled', true);

            $.post(ajaxurl, {
                action: 'bot_eraser_unblock_ip',
                ip: ip,
                nonce: nonce
            }, function(response) {
                if (response.success) {
                    var $row = $btn.closest('tr');
                    var rowSeconds = parseInt($row.data('seconds') || 0);

                    $row.fadeOut(300, function() {
                        $(this).remove();

                        var $total = $('#be-stat-total');
                        var newTotal = Math.max(0, parseInt($total.data('count')) - 1);
                        $total.data('count', newTotal).text(newTotal);

                        if (rowSeconds < 3600) {
                            var $expiring = $('#be-stat-expiring');
                            var newExpiring = Math.max(0, parseInt($expiring.data('count')) - 1);
                            $expiring.data('count', newExpiring).text(newExpiring);
                        }

                        if (newTotal === 0) {
                            $('#be-stat-status').text('Clear');
                        }
                    });
                } else {
                    $btn.prop('disabled', false);
                    alert('Error: ' + (response.data || 'Could not unblock IP'));
                }
            }).fail(function() {
                $btn.prop('disabled', false);
                alert('Request failed. Please try again.');
            });
        });

        // Manual run via AJAX
        $(document).on('click', '#be-manual-run-btn', function() {
            var $btn = $(this);
            var nonce = $btn.data('nonce');

            $btn.prop('disabled', true).find('svg').css('animation', 'spin 1s linear infinite');

            $.post(ajaxurl, {
                action: 'bot_eraser_manual_run',
                nonce: nonce
            }, function(response) {
                $btn.prop('disabled', false).find('svg').css('animation', '');

                if (response.success) {
                    var data = response.data;
                    var statusClass = data.status === 'success' ? 'success' : 'error';
                    var sentData = data.sent_data || {};
                    var now = new Date().toLocaleString();

                    var html = '<div class="boteraser-results ' + statusClass + '">';
                    html += '<div class="boteraser-results-header">';
                    html += '<h3>' + (statusClass === 'success' ? '✓' : '✗') + ' Execution Results</h3>';
                    html += '<span class="boteraser-results-time">' + now + '</span>';
                    html += '</div>';
                    html += '<div class="boteraser-results-grid">';

                    // Server Metrics
                    html += '<div class="boteraser-result-card">';
                    html += '<h4>Server Metrics</h4>';
                    html += '<div class="metrics-box">';
                    html += '<div class="metric"><label>Load</label><div class="value">' + (sentData.srv_load || 'N/A') + '</div></div>';
                    html += '<div class="metric"><label>Uptime</label><div class="value">' + (sentData.uptime ? Boteraser.Utils.formatUptime(sentData.uptime) : 'N/A') + '</div></div>';
                    html += '</div></div>';

                    // Data Payload
                    html += '<div class="boteraser-result-card">';
                    html += '<h4>Data Payload</h4>';
                    html += '<pre>' + (sentData.data ? sentData.data : 'No data generated') + '</pre>';
                    html += '</div>';

                    // Server Response
                    html += '<div class="boteraser-result-card">';
                    html += '<h4>Server Response</h4>';
                    html += '<pre>' + (data.response || 'No response received') + '</pre>';
                    html += '</div>';

                    html += '</div>'; // boteraser-results-grid

                    html += '<div class="boteraser-results-footer">';
                    html += '<span class="boteraser-status-badge ' + statusClass + '">' + statusClass.toUpperCase() + '</span>';
                    html += '<span class="boteraser-execution-message">' + (data.message || '') + '</span>';
                    html += '</div>';
                    html += '</div>';

                    var $results = $('.boteraser-results');
                    if ($results.length) {
                        $results.replaceWith(html);
                    } else {
                        $('#be-manual-run-btn').closest('.boteraser-card').append(html);
                    }

                    // Stretch left card to match right column height
                    setTimeout(function() {
                        var $leftCol = $('.boteraser-left-column');
                        var $rightCol = $('.boteraser-info-panel');
                        var $card = $('.boteraser-execution-section .boteraser-card');
                        $card.css('min-height', '');
                        var diff = $rightCol[0].getBoundingClientRect().bottom - $leftCol[0].getBoundingClientRect().bottom;
                        if (diff > 0) {
                            $card.css('min-height', ($card.outerHeight() + diff) + 'px');
                        }
                    }, 300);

                    // Update last run time
                    $('.boteraser-last-run-info span').text('Last run: just now');
                } else {
                    alert('Error: ' + (response.data || 'Could not run Boteraser'));
                }
            }).fail(function() {
                $btn.prop('disabled', false);
                alert('Request failed. Please try again.');
            });
        });

        // API Key module is initialized from PHP with config
        if (typeof boteraser_config !== 'undefined') {
            Boteraser.ApiKey.init(boteraser_config);

            // Check if we need to scroll to status indicator after page load
            // This happens when validation state was just updated (after form submission)
            if (boteraser_config.validationState && boteraser_config.validationState.message) {
                var timestamp = boteraser_config.validationState.timestamp || 0;
                var now = Math.floor(Date.now() / 1000);

                // If validation state was updated in the last 5 seconds, scroll to it
                if (now - timestamp < 5) {
                    setTimeout(function() {
                        var $indicator = $('.boteraser-status-indicator');
                        if ($indicator.length && $indicator.hasClass('visible')) {
                            $('html, body').animate({
                                scrollTop: $indicator.offset().top - 100
                            }, 500);
                        }
                    }, 100);
                }
            }
        }


        // Run alignment after images load (if any)
        $(window).on('load', function() {
            alignManualExecutionCard();
        });


        console.log('Boteraser: Admin interface ready');
        });
    
        // =========================================================================
        // Snapshot Tab Switcher (Dashboard)
        // =========================================================================
        Boteraser.SnapshotTabs = {
            init: function() {
                var snap = document.querySelector('[data-snapshot]');
                if (!snap) return;
                var tabs = snap.querySelectorAll('[data-snapshot-tab]');
                var panels = snap.querySelectorAll('[data-snapshot-panel]');
                tabs.forEach(function(tab) {
                    tab.addEventListener('click', function() {
                        var target = tab.getAttribute('data-snapshot-tab');
                        tabs.forEach(function(t) {
                            var active = t === tab;
                            t.classList.toggle('is-active', active);
                            t.setAttribute('aria-selected', active ? 'true' : 'false');
                        });
                        panels.forEach(function(p) {
                            var match = p.getAttribute('data-snapshot-panel') === target;
                            if (match) { p.classList.add('is-active'); p.removeAttribute('hidden'); }
                            else { p.classList.remove('is-active'); p.setAttribute('hidden', ''); }
                        });
                    });
                });
            }
        };
    
        // =========================================================================
        // Live Traffic Canvas (Dashboard)
        // =========================================================================
        Boteraser.LiveTraffic = {
            canvas: null,
            toggleBtn: null,
            statusEl: null,
            latestEl: null,
            ctx: null,
            W: 0,
            H: 0,
            bw: 0,
            running: false,
            data: null,
            hoverSlot: -1,
            bars: null,
            timer: null,
    
            init: function() {
                this.canvas = document.getElementById('be-live-canvas-dash');
                this.toggleBtn = document.getElementById('be-live-toggle-dash');
                this.statusEl = document.getElementById('be-live-status-dash');
                this.latestEl = document.getElementById('be-live-latest-dash');
                if (!this.canvas || !this.toggleBtn) return;
    
                this.ctx = this.canvas.getContext('2d');
                this.bars = new Array(60).fill(0);
                this.resize();
                window.addEventListener('resize', this.resize.bind(this));
    
                var self = this;
                this.toggleBtn.addEventListener('click', function() {
                    self.running = !self.running;
                    var ld = (typeof boteraser_live_dash !== 'undefined') ? boteraser_live_dash : {};
                    if (self.running) {
                        self.toggleBtn.innerHTML = (ld.iconPause || '') + ' ' + (ld.lblPause || 'Pause');
                        self.toggleBtn.classList.add('boteraser-btn-secondary');
                        self.toggleBtn.classList.remove('boteraser-btn-primary');
                        self.statusEl.className = 'be-live-status live';
                        self.statusEl.innerHTML = (ld.labelPrefix || '● ') + ' ' + (ld.lblLive || 'Live');
                        self.poll();
                    } else {
                        self.toggleBtn.innerHTML = (ld.iconPlay || '') + ' ' + (ld.lblGoLive || 'Go Live');
                        self.toggleBtn.classList.add('boteraser-btn-primary');
                        self.toggleBtn.classList.remove('boteraser-btn-secondary');
                        self.statusEl.className = 'be-live-status offline';
                        self.statusEl.innerHTML = (ld.labelPrefix || '● ') + ' ' + (ld.lblOffline || 'Offline');
                        clearTimeout(self.timer);
                    }
                });
    
                var canvas = this.canvas;
                canvas.addEventListener('mousemove', function(e) {
                    var mx = e.clientX - canvas.getBoundingClientRect().left;
                    self.hoverSlot = Math.min(59, Math.max(0, Math.floor(mx / self.bw)));
                    if (self.data) self.draw();
                });
                canvas.addEventListener('mouseleave', function() {
                    self.hoverSlot = -1;
                    if (self.data) self.draw();
                });
            },
    
            resize: function() {
                this.W = this.canvas.clientWidth;
                this.H = this.canvas.clientHeight;
                this.canvas.width = this.W;
                this.canvas.height = this.H;
                this.bw = this.W / 60;
                if (this.data) this.draw();
            },
    
            draw: function() {
                var x = this.ctx, W = this.W, H = this.H, d = this.data;
                if (!d) return;
                var b = d.buckets || [];
                x.clearRect(0, 0, W, H);
    
                var maxVal = 1;
                for (var i = 0; i < 60; i++) {
                    if (!b[i]) continue;
                    maxVal = Math.max(maxVal, b[i][0] + b[i][1] + b[i][2]);
                }
                var hm = H - 10;
    
                for (var i = 0; i < 60; i++) {
                    var total = 0, errs = 0;
                    if (b[i]) {
                        total = b[i][0] + b[i][1] + b[i][2];
                        errs = (b[i][3] || 0) + (b[i][4] || 0);
                    }
                    var target = total > 0 ? Math.max(3, (total / maxVal) * hm) : 0;
                    this.bars[i] += (target - this.bars[i]) * 0.3;
                    var xp = i * this.bw + 1;
                    var hv = Math.max(0, this.bars[i]);
                    var yp = H - hv - 2;
                    if (hv < 0.5) continue;
    
                    if (errs > 0 && errs >= total * 0.3) x.fillStyle = '#ef4444';
                    else if (total >= 1) x.fillStyle = '#10b981';
                    else x.fillStyle = '#d1d5db';
    
                    x.beginPath();
                    x.roundRect(xp, yp, this.bw - 1, hv, 2);
                    x.fill();
    
                    if (this.hoverSlot === i) {
                        x.fillStyle = 'rgba(0,0,0,0.08)';
                        x.beginPath();
                        x.roundRect(xp, yp, this.bw - 1, hv, 2);
                        x.fill();
                    }
                }
    
                // "now" marker
                x.strokeStyle = '#9ca3af';
                x.lineWidth = 1;
                x.setLineDash([3, 3]);
                x.beginPath();
                x.moveTo(W - 1, 2);
                x.lineTo(W - 1, H - 2);
                x.stroke();
                x.setLineDash([]);
                x.fillStyle = '#6b7280';
                x.font = '9px sans-serif';
                x.fillText('now', W - 24, H - 4);
    
                // Latest entries
                var l = this.latestEl;
                if (d.latest && d.latest.length) {
                    l.style.display = 'block';
                    l.innerHTML = d.latest.map(function(e) {
                        var c = e.code >= 500 ? '#ef4444' : e.code >= 400 ? '#f59e0b' : e.code >= 300 ? '#3b82f6' : '#10b981';
                        return '<span style="color:' + c + ';font-weight:600">' + e.code + '</span> <span style="color:#6b7280">' + e.ip + '</span> ' + e.path;
                    }).join(' &nbsp;|&nbsp; ');
                }
    
                // Hover tooltip
                if (this.hoverSlot >= 0 && this.hoverSlot < 60 && b[this.hoverSlot]) {
                    var bk = b[this.hoverSlot];
                    var sa = (60 - this.hoverSlot) * 5;
                    var txt = sa < 60 ? sa + 's ago' : Math.ceil(sa / 60) + 'm ago';
                    if (bk[5] && bk[5].length) {
                        txt += ' — ' + bk[5].slice(0, 5).join(', ');
                        if (bk[5].length > 5) txt += ' +' + (bk[5].length - 5);
                    }
                    x.font = '11px sans-serif';
                    var tw = x.measureText(txt).width + 20;
                    var tx = Math.min(W - tw / 2 - 6, Math.max(tw / 2 + 6, this.hoverSlot * this.bw + this.bw / 2));
                    x.fillStyle = 'rgba(0,0,0,0.82)';
                    x.beginPath();
                    x.roundRect(tx - tw / 2, 22, tw, 22, 4);
                    x.fill();
                    x.fillStyle = '#fff';
                    x.textAlign = 'center';
                    x.fillText(txt, tx, 37);
                    x.textAlign = 'start';
                }
            },
    
            poll: function() {
                if (!this.running) return;
                var self = this;
                var ld = (typeof boteraser_live_dash !== 'undefined') ? boteraser_live_dash : {};
                var fd = new FormData();
                fd.append('action', 'boteraser_live_traffic');
                fd.append('nonce', ld.nonce || '');
                fetch(ld.ajaxUrl || ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function(r) { return r.json(); })
                    .then(function(r) {
                        if (r.success) {
                            self.data = r.data;
                            self.draw();
                        }
                    });
                this.timer = setTimeout(function() { self.poll(); }, 2000);
            }
        };
    
        // =========================================================================
        // Vulnerability Check (Vulnerabilities page)
        // =========================================================================
        Boteraser.VulnCheck = {
            init: function() {
                var btn = document.getElementById('be-vuln-check-btn');
                var statusEl = document.getElementById('be-vuln-status');
                if (!btn || !statusEl) return;
    
                var vulnData = (typeof boteraser_vuln !== 'undefined') ? boteraser_vuln : {};
                var originalHtml = btn.innerHTML;
    
                btn.addEventListener('click', function() {
                    btn.disabled = true;
                    var saved = btn.innerHTML;
                    btn.innerHTML = (vulnData.iconLoader || '<svg width="16" height="16" class="animate-spin">…</svg>') + ' ' + (vulnData.lblChecking || 'Checking...');
                    statusEl.style.display = 'block';
    
                    var fd = new FormData();
                    fd.append('action', 'boteraser_vuln_check');
                    fd.append('nonce', vulnData.nonce || '');
    
                    fetch(vulnData.ajaxUrl || ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                        .then(function(r) { return r.json(); })
                        .then(function(r) {
                            statusEl.style.display = 'none';
                            if (r.success) {
                                location.reload();
                            } else {
                                alert((r.data && r.data.message) ? r.data.message : (vulnData.lblCheckFailed || 'Check failed.'));
                                btn.disabled = false;
                                btn.innerHTML = saved;
                            }
                        })
                        .catch(function() {
                            statusEl.style.display = 'none';
                            alert(vulnData.lblNetworkError || 'Network error.');
                            btn.disabled = false;
                            btn.innerHTML = saved;
                        });
                });
            }
        };
    
    })(jQuery);
    
    /* ==========================================================================
       Boteraser Security Scanner
       ========================================================================== */
(function($) {
    'use strict';

    var Scanner = {
        running: false,
        nonce: '',
        ajaxUrl: '',

        init: function() {
            // Dashboard widget
            if ($('#be-scan-start-btn').length) {
                this.nonce   = (window.boteraser_config && boteraser_config.scanNonce) || '';
                this.ajaxUrl = (window.boteraser_config && boteraser_config.ajaxUrl) || ajaxurl;
                this.bindDashboard();
            }

            // Scanner page
            if ($('#be-scanner-toggle').length) {
                this.nonce   = (window.boteraser_scanner && boteraser_scanner.nonce) || '';
                this.ajaxUrl = (window.boteraser_scanner && boteraser_scanner.ajaxUrl) || ajaxurl;
                this.bindScannerPage();
            }

            // Quarantine page
            if ($('.be-quarantine-table').length || $('.be-quarantine-empty').length) {
                this.nonce   = (window.boteraser_quarantine && boteraser_quarantine.nonce) || '';
                this.ajaxUrl = (window.boteraser_quarantine && boteraser_quarantine.ajaxUrl) || ajaxurl;
                this.bindQuarantinePage();
            }

            // Forward clicks from [data-be-trigger] elements to their target (e.g. Shield Core CTA -> scan toggle)
            $(document).on('click', '[data-be-trigger]', function() {
                var $el = $(this);
                var target = document.getElementById($el.data('be-trigger'));
                if (target) { target.click(); }
                var scrollSel = $el.data('be-scroll');
                if (scrollSel) {
                    var scrollEl = document.querySelector(scrollSel);
                    if (scrollEl && scrollEl.scrollIntoView) {
                        scrollEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                }
            });
        },

        // ---- Quarantine page ----
        bindQuarantinePage: function() {
            var self = this;

            $(document).on('click', '.be-q-restore', function() {
                var $btn = $(this);
                var stored = $btn.data('stored');
                var $row = $btn.closest('tr');
                var pathLabel = $row.find('.be-quarantine-path').text() || stored;
                self.confirm(
                    'Restore file',
                    'Restore <strong>' + self.escHtml(pathLabel) + '</strong> to its original location?',
                    function() { self.quarantineRestore(stored, $row); }
                );
            });

            $(document).on('click', '.be-q-delete', function() {
                var $btn = $(this);
                var stored = $btn.data('stored');
                var $row = $btn.closest('tr');
                var pathLabel = $row.find('.be-quarantine-path').text() || stored;
                self.confirm(
                    'Permanently delete from system',
                    'File <strong>' + self.escHtml(pathLabel) + '</strong> will be permanently removed from the system. This cannot be undone.',
                    function() { self.quarantineDeleteEntry(stored, $row); }
                );
            });

            $(document).on('click', '#be-modal-cancel', function() {
                $('#be-confirm-modal').hide().css('display', 'none');
            });
        },

        quarantineRestore: function(stored, $row) {
            var self = this;
            $.post(this.ajaxUrl, { action: 'boteraser_quarantine_restore', nonce: this.nonce, stored_name: stored })
                .done(function(resp) {
                    if (resp && resp.success) {
                        $row.fadeOut(300, function() {
                            $(this).remove();
                            self.updateQuarantineStats();
                        });
                    } else {
                        alert((resp && resp.data) || 'Restore failed.');
                    }
                })
                .fail(function(xhr) { alert('Restore request failed. Status: ' + xhr.status + ' | ' + xhr.responseText); });
        },

        quarantineDeleteEntry: function(stored, $row) {
            var self = this;
            $.post(this.ajaxUrl, { action: 'boteraser_quarantine_delete_entry', nonce: this.nonce, stored_name: stored })
                .done(function(resp) {
                    if (resp && resp.success) {
                        $row.fadeOut(300, function() {
                            $(this).remove();
                            self.updateQuarantineStats();
                        });
                    } else {
                        alert((resp && resp.data) || 'Delete failed.');
                    }
                })
                .fail(function() { alert('Delete request failed.'); });
        },

        updateQuarantineStats: function() {
            var $rows = $('.be-quarantine-table tbody tr');
            var count = $rows.length;
            var totalBytes = 0;
            $rows.each(function() {
                totalBytes += parseInt($(this).data('bytes') || 0, 10);
            });

            var sizeStr;
            if (totalBytes === 0) {
                sizeStr = '0 B';
            } else {
                var units = ['B', 'KB', 'MB', 'GB', 'TB'];
                var i = Math.min(Math.floor(Math.log(totalBytes) / Math.log(1024)), units.length - 1);
                sizeStr = parseFloat((totalBytes / Math.pow(1024, i)).toFixed(1)) + ' ' + units[i];
            }

            $('#be-q-kpi-items .boteraser-hero-kpi-value').text(count);
            $('#be-q-kpi-size .boteraser-hero-kpi-value').text(sizeStr);

            if (count === 0) {
                var qd = (typeof boteraser_quarantine !== 'undefined') ? boteraser_quarantine : {};
                $('.boteraser-table-wrapper').replaceWith(
                    '<div class="be-quarantine-empty">' +
                    Boteraser.Icons.shieldCheck +
                    '<h3>' + (qd.emptyTitle || 'No files in quarantine') + '</h3>' +
                    '<p>' + (qd.emptyMessage || '') + '</p>' +
                    '</div>'
                );
            }
        },

        // ---- Dashboard widget ----
        bindDashboard: function() {
            var self = this;

            $('#be-scan-start-btn').on('click', function() {
                if (self.running) {
                    self.cancelScan('dashboard');
                } else {
                    self.startScan('dashboard');
                }
            });

            $('#be-baseline-save-widget').on('click', function() {
                self.saveBaseline();
            });
        },

        // ---- Scanner page ----
        bindScannerPage: function() {
            var self = this;

            $('#be-scanner-toggle').on('click', function() {
                if (self.running) {
                    self.cancelScan('page');
                } else {
                    self.startScan('page');
                }
            });

            $('#be-baseline-save').on('click', function() {
                self.saveBaseline();
            });

            $('#be-auto-scan-enabled, #be-auto-scan-interval').on('change', function() {
                self.saveAutoScan($(this).is('#be-auto-scan-enabled') ? $(this) : null);
            });

            $('#be-notify-enabled').on('change', function() {
                self.saveNotify($(this));
            });

            $('#be-notify-email').on('blur', function() {
                self.saveNotify(null);
            });

            $('#be-auto-scan-files-themes-plugins').on('change', function() {
                self.saveAutoScanFilesThemesPlugins($(this));
            });

            $('#be-auto-quarantine').on('change', function() {
                self.saveAutoQuarantine($(this));
            });

            $('#be-waf-ruleset').on('change', function() {
                self.saveWafRuleset($(this));
            });

            $('#be-block-php-uploads, #be-block-dangerous-ext, #be-auto-quarantine-uploads, #be-scan-before-activation, #be-auto-deactivate-plugins, #be-rollback-on-update, #be-realtime-cloud-scan, #be-whitelist-safe-plugins').on('change', function() {
                self.saveUploadProtection($(this));
            });

            $('[name^="mod_"]').on('change', function() {
                self.saveScannerModules($(this));
            });

            // Filter buttons
            $(document).on('click', '.be-filter-btn', function() {
                $('.be-filter-btn').removeClass('active');
                $(this).addClass('active');
                var filter = $(this).data('filter');
                self.filterResults(filter);
            });

            // Quarantine button
            $(document).on('click', '.be-btn-quarantine', function() {
                var file = $(this).data('file');
                var $row = $(this).closest('tr');
                self.confirm(
                    'Quarantine file',
                    'File <strong>' + self.escHtml(file) + '</strong> will be moved outside the web root. You can restore it manually.',
                    function() { self.quarantineFile(file, $row); }
                );
            });

            // Delete button
            $(document).on('click', '.be-btn-delete', function() {
                var file = $(this).data('file');
                var $row = $(this).closest('tr');
                self.confirm(
                    'Permanently delete from system',
                    'File <strong>' + self.escHtml(file) + '</strong> will be permanently removed from the system. This cannot be undone.',
                    function() { self.deleteFile(file, $row); }
                );
            });

            // View Diff button
            $(document).on('click', '.be-btn-diff', function() {
                var file = $(this).data('file');
                self.openDiffModal(file);
            });

            // Diff modal close
            $(document).on('click', '#be-diff-modal-close, #be-diff-modal-overlay', function() {
                $('#be-diff-modal').hide();
            });

            // Restore from diff modal
            $(document).on('click', '#be-diff-restore-btn', function() {
                var file = $('#be-diff-modal').data('file');
                self.confirm(
                    'Restore original file',
                    'File <strong>' + self.escHtml(file) + '</strong> will be replaced with the original from WordPress.org. A backup will be saved automatically before replacing.',
                    function() { self.restoreFile(file); }
                );
            });

            // Whitelist button
            $(document).on('click', '.be-btn-whitelist', function() {
                var file = $(this).data('file');
                var $row = $(this).closest('tr');
                self.confirm(
                    'Add to whitelist',
                    'File <strong>' + self.escHtml(file) + '</strong> will be ignored in future scans.',
                    function() { self.whitelistFile(file, $row); }
                );
            });

            // Modal cancel
            $(document).on('click', '#be-modal-cancel', function() {
                $('#be-confirm-modal').hide().css('display', 'none');
            });
        },

        // ---- Elapsed timer ----
        startElapsedTimer: function() {
            var self = this;
            this.scanStartTime = Date.now();
            clearInterval(this._elapsedInterval);
            this._elapsedInterval = setInterval(function() {
                if (!self.running) { clearInterval(self._elapsedInterval); return; }
                var elapsed = Math.floor((Date.now() - self.scanStartTime) / 1000);
                var m = Math.floor(elapsed / 60);
                var s = elapsed % 60;
                var txt = m > 0 ? m + 'm ' + s + 's' : s + 's';
                $('#be-scanner-elapsed').text(txt);
            }, 1000);
        },

        stopElapsedTimer: function() {
            clearInterval(this._elapsedInterval);
            if (this.scanStartTime) {
                var elapsed = Math.floor((Date.now() - this.scanStartTime) / 1000);
                var m = Math.floor(elapsed / 60);
                var s = elapsed % 60;
                var txt = m > 0 ? m + 'm ' + s + 's' : s + 's';
                $('#be-scanner-elapsed').text(txt);
            }
        },

        // ---- Start scan ----
        startScan: function(context) {
            if (this.running) return;
            this.running = true;

            var modules = {};
            if (context === 'page') {
                $('[name^="mod_"]').each(function() {
                    modules[$(this).attr('name')] = $(this).is(':checked') ? '1' : '';
                });
            } else {
                // Dashboard: all modules
                modules = { mod_files:'1', mod_core:'1', mod_patterns:'1', mod_database:'1', mod_cron:'1', mod_permissions:'1' };
            }

            this.setRunningUI(context, true);
            this.consecutiveFailures = 0;
            if (context === 'page') this.startElapsedTimer();

            var self = this;
            $.post(this.ajaxUrl, $.extend({ action: 'boteraser_scan_start', nonce: this.nonce }, modules))
                .done(function(resp) {
                    if (resp.success) {
                        self.updateProgress(context, 0, 'Preparing...', '', {
                            phase: 'prepare',
                            scanned: 0,
                            total: resp.data.total_files || 0,
                            coreScanned: 0,
                            coreTotal: resp.data.core_total || 0,
                            pluginsScanned: 0,
                            pluginsTotal: 0,
                            themesScanned: 0,
                            themesTotal: 0
                        });
                        setTimeout(function() { self.processChunk(context); }, 300);
                    } else {
                        self.setRunningUI(context, false);
                        self.running = false;
                        if (context === 'page') self.stopElapsedTimer();
                    }
                })
                .fail(function() {
                    self.setRunningUI(context, false);
                    self.running = false;
                    if (context === 'page') self.stopElapsedTimer();
                });
        },

        saveScannerModules: function($changed) {
            var modules = {};
            // on change event the checkbox is already in the new state — revert to previous on failure
            var prevVal = $changed ? !$changed.is(':checked') : null;

            $('[name^="mod_"]').each(function() {
                modules[$(this).attr('name')] = $(this).is(':checked') ? '1' : '';
            });

            var self = this;
            $.post(this.ajaxUrl, $.extend({ action: 'boteraser_save_scanner_modules', nonce: this.nonce }, modules))
                .fail(function() {
                    if ($changed && prevVal !== null) {
                        $changed.prop('checked', prevVal);
                    }
                });
        },

        // ---- Process chunk ----
        processChunk: function(context) {
            if (!this.running) return;
            var self = this;
            // Plugin/theme ZIP downloads can take 60-90s on slow hosts.
            // 10 failures with exponential backoff gives ~17 minutes of
            // retry headroom before we give up — enough for any ZIP download.
            var MAX_FAILURES = 10;

            $.ajax({
                url:     this.ajaxUrl,
                type:    'POST',
                data:    { action: 'boteraser_scan_chunk', nonce: this.nonce },
                timeout: 150000  // 150s — longer than the PHP set_time_limit(120) budget
            })
                .done(function(resp) {
                    if (!resp || !resp.success) {
                        // Server responded but reported an error — don't retry indefinitely,
                        // but give it a couple of chances in case it was a transient DB error.
                        self.consecutiveFailures = (self.consecutiveFailures || 0) + 1;
                        if (self.consecutiveFailures >= MAX_FAILURES) {
                            self.running = false;
                            self.setRunningUI(context, false);
                            var msg = (resp && resp.data) ? resp.data : 'Scan stopped — server error.';
                            self.updateProgress(context, 0, msg, '');
                            return;
                        }
                        var delay = Math.min(8000, Math.pow(2, self.consecutiveFailures - 1) * 1000);
                        setTimeout(function() { self.processChunk(context); }, delay);
                        return;
                    }

                    self.consecutiveFailures = 0;
                    var data = resp.data;

                    if (data.status === 'running') {
                        self.updateProgress(context, data.progress, data.phase_label, data.current_file, {
                            phase: data.phase || '',
                            scanned: data.scanned || 0,
                            total: data.total || 0,
                            coreScanned: data.core_scanned || 0,
                            coreTotal: data.core_total || 0,
                            pluginsScanned: data.plugins_scanned || 0,
                            pluginsTotal: data.plugins_total || 0,
                            themesScanned: data.themes_scanned || 0,
                            themesTotal: data.themes_total || 0
                        });
                        if (self.running) {
                            setTimeout(function() { self.processChunk(context); }, 200);
                        }
                    } else if (data.status === 'complete') {
                        self.running = false;
                        self.setRunningUI(context, false);
                        self.updateProgress(context, 100, 'Scan complete!', '', {
                            phase: 'done',
                            scanned: data.summary && typeof data.summary.files_scanned !== 'undefined' ? data.summary.files_scanned : (data.scanned || 0),
                            total: data.total || 0
                        });
                        self.onComplete(context, data);
                    } else {
                        // Neočekivan status — tretira se kao greška i pokušava ponovo
                        self.consecutiveFailures = (self.consecutiveFailures || 0) + 1;
                        if (self.consecutiveFailures >= MAX_FAILURES) {
                            self.running = false;
                            self.setRunningUI(context, false);
                            var errMsg = (data && data.message) ? data.message : 'Scan stopped — unexpected server response.';
                            self.updateProgress(context, 0, errMsg, '');
                            return;
                        }
                        var delay = Math.min(8000, Math.pow(2, self.consecutiveFailures - 1) * 1000);
                        setTimeout(function() { self.processChunk(context); }, delay);
                    }
                })
                .fail(function(xhr, status) {
                    // Network error or timeout — retry with exponential backoff.
                    // A "timeout" here means the browser hit 150s waiting for PHP,
                    // which almost never happens (set_time_limit(120) fires first
                    // and PHP responds). If it does happen, we wait longer before retry.
                    self.consecutiveFailures = (self.consecutiveFailures || 0) + 1;
                    if (self.consecutiveFailures >= MAX_FAILURES) {
                        self.running = false;
                        self.setRunningUI(context, false);
                        self.updateProgress(context, 0, 'Scan stopped — server unreachable after ' + MAX_FAILURES + ' retries. Try again.', '');
                        return;
                    }
                    // Longer backoff for timeouts (the server is under load)
                    var base = (status === 'timeout') ? 5000 : 1000;
                    var delay = Math.min(30000, base * Math.pow(2, self.consecutiveFailures - 1));
                    self.updateProgress(context, null, 'Retrying... (attempt ' + self.consecutiveFailures + '/' + MAX_FAILURES + ')', '');
                    setTimeout(function() { self.processChunk(context); }, delay);
                });
        },

        // ---- Cancel scan ----
        cancelScan: function(context) {
            this.running = false;
            this.setRunningUI(context, false);
            if (context === 'page') this.stopElapsedTimer();
            $.post(this.ajaxUrl, { action: 'boteraser_scan_cancel', nonce: this.nonce });
        },

        // ---- UI helpers ----
        setRunningUI: function(context, isRunning) {
            if (context === 'dashboard') {
                var $btn = $('#be-scan-start-btn');
                if (isRunning) {
                    $btn.removeClass('boteraser-btn-primary').addClass('boteraser-btn-danger');
                    $('#be-scan-toggle-icon-play').addClass('be-hidden');
                    $('#be-scan-toggle-icon-stop').removeClass('be-hidden');
                    $('#be-scan-toggle-label').text('Stop Scan');
                } else {
                    $btn.removeClass('boteraser-btn-danger').addClass('boteraser-btn-primary');
                    $('#be-scan-toggle-icon-play').removeClass('be-hidden');
                    $('#be-scan-toggle-icon-stop').addClass('be-hidden');
                    $('#be-scan-toggle-label').text('Run Scan');
                }
                $('#be-scan-progress-wrap').toggleClass('be-hidden', !isRunning).toggle(isRunning);
            } else {
                var $btn = $('#be-scanner-toggle');
                if (isRunning) {
                    $btn.removeClass('boteraser-btn-primary').addClass('boteraser-btn-danger');
                    $('#be-scanner-toggle-icon-play').hide();
                    $('#be-scanner-toggle-icon-stop').show();
                    $('#be-scanner-toggle-label').text('Stop Scan');
                } else {
                    $btn.removeClass('boteraser-btn-danger').addClass('boteraser-btn-primary');
                    $('#be-scanner-toggle-icon-play').show();
                    $('#be-scanner-toggle-icon-stop').hide();
                    $('#be-scanner-toggle-label').text('Start Scan');
                }
                $('#be-scanner-progress-wrap').toggleClass('be-hidden', !isRunning).toggle(isRunning);
                if (isRunning) {
                    $('#be-scanner-empty-state-card').addClass('be-hidden').hide();
                }
            }
        },

        updateProgress: function(context, pct, label, file, counts) {
            if (context === 'dashboard') {
                $('#be-scan-progress-fill').css('width', pct + '%');
                $('#be-scan-status-text').text(label + (file ? ' — ' + file : ''));
            } else {
                counts = counts || {};
                var filesCountText = (function() {
                    switch (counts.phase) {
                        case 'files':
                            return (counts.scanned || 0) + ' / ' + (counts.total || 0) + ' files';
                        case 'core':
                            return (counts.coreScanned || 0) + ' / ' + (counts.coreTotal || 0) + ' core files';
                        case 'plugins':
                            return (counts.pluginsScanned || 0) + ' / ' + (counts.pluginsTotal || 0) + ' plugins';
                        case 'themes':
                            return (counts.themesScanned || 0) + ' / ' + (counts.themesTotal || 0) + ' themes';
                        case 'filenames':
                            return 'Filename checks active';
                        case 'uploads':
                            return 'Uploads inspection active';
                        case 'database':
                            return 'Database scan active';
                        case 'cron':
                            return 'Cron scan active';
                        case 'done':
                            return (counts.scanned || 0) + ' files scanned';
                        default:
                            return 'Preparing scan';
                    }
                }());
                if (pct !== null && pct !== undefined) {
                    $('#be-scanner-progress-fill').css('width', pct + '%');
                    $('#be-scanner-pct').text(pct + '%');
                }
                $('#be-scanner-phase-label').text(label);
                $('#be-scanner-files-count').text(filesCountText);
                $('#be-scanner-current-file').text(file);
            }
        },

        // ---- On complete ----
        onComplete: function(context, data) {
            if (context === 'dashboard') {
                this.updateHeroLastScan(data.summary);
                setTimeout(function() { window.location.reload(); }, 1200);
            } else {
                if (context === 'page') this.stopElapsedTimer();
                $('#be-scanner-progress-wrap').removeClass('be-hidden').show();
                this.renderFindings(data.findings);
                this.updateSummary(data.summary);
                this.updateHeroLastScan(data.summary);
                if (data.findings && data.findings.length) {
                    $('#be-scanner-results-card').removeClass('be-hidden').show();
                    $('#be-scanner-empty-state-card').addClass('be-hidden').hide();
                } else {
                    $('#be-scanner-results-card').addClass('be-hidden').hide();
                    $('#be-scanner-empty-state-card').removeClass('be-hidden').show();
                }
            }
        },

        updateHeroLastScan: function(summary) {
            if (!summary) return;

            var score = summary.score;
            var grade = summary.grade;
            var high  = summary.high || 0;

            // Score KPI
            var $scoreKpi = $('#be-hero-score');
            if ($scoreKpi.length) {
                var scoreTone = score >= 75 ? 'low' : (score >= 50 ? 'medium' : 'high');
                $scoreKpi.removeClass('boteraser-hero-kpi--low boteraser-hero-kpi--medium boteraser-hero-kpi--high boteraser-hero-kpi--neutral')
                    .addClass('boteraser-hero-kpi--' + scoreTone);
                $scoreKpi.find('.boteraser-hero-kpi-value').text(score + '/100');
                var $badge = $scoreKpi.find('.boteraser-hero-kpi-badge');
                if (!$badge.length) {
                    $badge = $('<span class="boteraser-hero-kpi-badge"></span>');
                    $scoreKpi.find('.boteraser-hero-kpi-value-row').append($badge);
                }
                $badge.text(grade);
                $scoreKpi.find('.boteraser-hero-kpi-context').text('Just completed');
            }

            // Dashboard hero KPI (other pages)
            var $kpi = $('#be-hero-last-scan');
            if ($kpi.length) {
                var tone = score >= 75 ? 'low' : (score >= 50 ? 'medium' : 'high');
                $kpi.removeClass('boteraser-hero-kpi--low boteraser-hero-kpi--medium boteraser-hero-kpi--high boteraser-hero-kpi--neutral')
                    .addClass('boteraser-hero-kpi--' + tone);
                $kpi.find('.boteraser-hero-kpi-value').text(score + '/100');
                var $kpiBadge = $kpi.find('.boteraser-hero-kpi-badge');
                if (!$kpiBadge.length) {
                    $kpiBadge = $('<span class="boteraser-hero-kpi-badge"></span>');
                    $kpi.find('.boteraser-hero-kpi-value-row').append($kpiBadge);
                }
                $kpiBadge.text(grade);
                $kpi.find('.boteraser-hero-kpi-context').text('Just completed');
            }

            // High findings KPI
            var $highKpi = $('#be-hero-high-findings');
            if ($highKpi.length) {
                var highTone = high > 0 ? 'high' : 'low';
                $highKpi.removeClass('boteraser-hero-kpi--low boteraser-hero-kpi--medium boteraser-hero-kpi--high boteraser-hero-kpi--neutral')
                    .addClass('boteraser-hero-kpi--' + highTone);
                $highKpi.find('.boteraser-hero-kpi-value').text(high);
            }

            // Aside status block
            var statusClass, statusLabel, statusMsg;
            if (high > 0) {
                statusClass = 'watch';
                statusLabel = 'Action Recommended';
                statusMsg   = 'High-severity findings are present. Review results before applying destructive actions.';
            } else {
                statusClass = 'safe';
                statusLabel = 'Scanner Healthy';
                statusMsg   = 'No critical findings in the latest scan. Keep the baseline current and rescan after updates.';
            }
            var $aside = $('.boteraser-hero-aside-scanner');
            if ($aside.length) {
                $aside.removeClass('boteraser-hero-aside-setup boteraser-hero-aside-watch boteraser-hero-aside-safe')
                    .addClass('boteraser-hero-aside-' + statusClass);
                $aside.find('.boteraser-hero-status-badge')
                    .removeClass('setup watch safe')
                    .addClass(statusClass)
                    .text(statusLabel);
                $aside.find('.boteraser-hero-status-text').text(statusMsg);
            }
        },

        // ---- Render findings table ----
        renderFindings: function(findings) {
            var self = this;
            var $tbody = $('#be-findings-tbody').empty();
            var whitelist = (window.boteraser_scanner && boteraser_scanner.whitelist) || [];

            if (!findings || findings.length === 0) {
                $('#be-scanner-results-card').addClass('be-hidden').hide();
                return;
            }

            $('#be-scanner-results-card').removeClass('be-hidden').show();

            $.each(findings, function(i, f) {
                if ($.inArray(f.file, whitelist) !== -1) return;
                var sev     = f.severity;
                var label   = f.findings[0] ? f.findings[0].label : '';
                var details = f.findings[0] ? f.findings[0].details : '';
                var isFile  = (f.ext !== 'db' && f.ext !== 'cron');

                var actionBtns = isFile
                    ? '<button type="button" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-btn-quarantine" data-file="' + self.escHtml(f.file) + '">Quarantine</button>'
                    + '<button type="button" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-btn-delete" data-file="' + self.escHtml(f.file) + '">Delete</button>'
                    : '';
                var isDiffable = isFile && self.isResolvableFile(f.file);
                if (isDiffable) {
                    actionBtns = '<button type="button" class="boteraser-btn boteraser-btn-primary boteraser-btn-sm be-btn-diff" data-file="' + self.escHtml(f.file) + '">View Diff</button>'
                        + actionBtns;
                }
                actionBtns += '<button type="button" class="boteraser-btn boteraser-btn-secondary boteraser-btn-sm be-btn-whitelist" data-file="' + self.escHtml(f.file) + '">Ignore</button>';

                var $tr = $('<tr data-severity="' + self.escHtml(sev) + '" data-file="' + self.escHtml(f.file) + '">'
                    + '<td><span class="be-severity-badge ' + sev.toLowerCase() + '">' + self.escHtml(sev) + '</span></td>'
                    + '<td><span class="be-file-path">' + self.escHtml(f.file) + '</span>'
                    + (details ? '<div class="be-finding-detail">' + self.escHtml(details.substring(0, 120)) + '</div>' : '')
                    + '</td>'
                    + '<td>' + self.escHtml(label) + '</td>'
                    + '<td><span class="be-score-pill ' + sev.toLowerCase() + '">' + f.score + '</span></td>'
                    + '<td class="be-action-btns">' + actionBtns + '</td>'
                    + '</tr>');
                $tbody.append($tr);
            });
        },

        updateSummary: function(summary) {
            if (!summary) return;
            var score = summary.score || 0;
            var tone  = score >= 75 ? 'good' : (score >= 50 ? 'warn' : 'bad');

            // Health Score gauge (180° ring): tone color + arc + value + grade
            $('.be-status-minimal')
                .removeClass('be-core-good be-core-warn be-core-bad be-core-neutral')
                .addClass('be-core-' + tone)
                .attr('aria-valuenow', score);

            var arc = Math.min(100, Math.max(0, score)) / 100;
            $('.be-sm-gauge').each(function() {
                this.style.setProperty('--sm-arc', arc);
                // Rebuild ring + hero so it also renders after the first scan (empty state has no SVG)
                $(this).html(
                    '<svg viewBox="0 0 200 200" preserveAspectRatio="xMidYMid meet" aria-hidden="true">' +
                        '<circle class="be-sm-gauge-track" cx="100" cy="100" r="84"></circle>' +
                        '<circle class="be-sm-gauge-fill" cx="100" cy="100" r="84" pathLength="100" transform="rotate(-90 100 100)"></circle>' +
                        '<circle class="be-sm-gauge-shine" cx="100" cy="100" r="84" pathLength="100" transform="rotate(-90 100 100)"></circle>' +
                    '</svg>' +
                    '<div class="be-sm-hero"><span class="be-sm-score">' + score + '</span><span class="be-sm-max">/100</span></div>'
                );
            });

            $('.be-sm-grade').text(summary.grade || (tone === 'good' ? 'GOOD' : (tone === 'warn' ? 'WARNING' : 'CRITICAL')));

            // Segment bar (10 segments lit by score/10)
            var lit  = Math.round(score / 10);
            var $bar = $('.be-sm-bar');
            if ($bar.length) {
                $bar.find('.be-sm-seg').each(function(i) {
                    $(this).toggleClass('be-sm-seg-on', i < lit);
                });
            } else {
                var segs = '';
                for (var s = 0; s < 10; s++) {
                    segs += '<span class="be-sm-seg' + (s < lit ? ' be-sm-seg-on' : '') + '"></span>';
                }
                $('<div class="be-sm-bar" aria-hidden="true">' + segs + '</div>').insertAfter('.be-sm-grade-row');
            }

            // HIGH / MEDIUM / LOW metric cards
            $('.be-metric-card.high .be-metric-value').text(summary.high);
            $('.be-metric-card.medium .be-metric-value').text(summary.medium);
            $('.be-metric-card.low .be-metric-value').text(summary.low);

            // Findings chips in results card header
            var total = (summary.high || 0) + (summary.medium || 0) + (summary.low || 0);
            $('.be-findings-chip.high').text(summary.high + ' HIGH');
            $('.be-findings-chip.medium').text(summary.medium + ' MEDIUM');
            $('.be-findings-chip.low').text(summary.low + ' LOW');
            $('.be-findings-summary-primary strong').text(total);
        },

        // ---- Filter ----
        filterResults: function(filter) {
            $('#be-findings-tbody tr').each(function() {
                var sev = $(this).data('severity');
                if (filter === 'all' || sev === filter) {
                    $(this).removeClass('be-row-hidden');
                } else {
                    $(this).addClass('be-row-hidden');
                }
            });
        },

        // ---- File actions ----
        quarantineFile: function(file, $row) {
            var self = this;
            var severity = $row && $row.data ? ($row.data('severity') || '') : '';
            $.post(this.ajaxUrl, {
                action: 'boteraser_quarantine_file',
                nonce: this.nonce,
                file: file,
                severity: severity
            })
                .done(function(resp) {
                    if (resp.success) {
                        $row.fadeOut(300, function() { $(this).remove(); });
                    } else {
                        alert(resp.data || 'Quarantine failed.');
                    }
                });
        },

        deleteFile: function(file, $row) {
            var self = this;
            $.post(this.ajaxUrl, { action: 'boteraser_delete_file', nonce: this.nonce, file: file })
                .done(function(resp) {
                    if (resp.success) {
                        $row.fadeOut(300, function() { $(this).remove(); });
                    } else {
                        alert(resp.data || 'Delete failed.');
                    }
                });
        },

        whitelistFile: function(file, $row) {
            var self = this;
            $.post(this.ajaxUrl, { action: 'boteraser_whitelist_add', nonce: this.nonce, file: file })
                .done(function(resp) {
                    if (resp.success) {
                        $row.fadeOut(300, function() { $(this).remove(); });
                    } else {
                        alert(resp.data || 'Whitelist failed.');
                    }
                });
        },

        // ---- Save baseline ----
        saveBaseline: function() {
            var $btn = $('#be-baseline-save').prop('disabled', true).text('Saving...');
            $.post(this.ajaxUrl, { action: 'boteraser_save_baseline', nonce: this.nonce })
                .done(function(resp) {
                    if (resp.success) {
                        $btn.text('Saved!');
                        setTimeout(function() { $btn.prop('disabled', false).html('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg> Sačuvaj Baseline'); }, 2000);
                    }
                })
                .fail(function() {
                    $btn.prop('disabled', false).text('Error');
                });
        },

        // ---- Save automatic scan settings ----
        saveAutoScan: function($changed) {
            var $status  = $('#be-auto-scan-status');
            var $heroKpi = $('#be-hero-next-scan');
            var enabled  = $('#be-auto-scan-enabled').is(':checked') ? '1' : '0';
            var interval = $('#be-auto-scan-interval').val();
            var prevVal  = $changed ? !$changed.is(':checked') : null;
            $status.text('Saving...');
            $.post(this.ajaxUrl, {
                action:   'boteraser_save_auto_scan',
                nonce:    this.nonce,
                enabled:  enabled,
                interval: interval
            })
                .done(function(resp) {
                    if (resp.success) {
                        if (resp.data && resp.data.next_run) {
                            var d = new Date(resp.data.next_run * 1000);
                            var pad = function(n) { return n < 10 ? '0' + n : n; };
                            var fmt = pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear()
                                    + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
                            $status.text('Next scan: ' + fmt);
                            if ($heroKpi.length) {
                                $heroKpi.removeClass('boteraser-hero-kpi--neutral boteraser-hero-kpi--medium boteraser-hero-kpi--high')
                                        .addClass('boteraser-hero-kpi--low');
                                $heroKpi.find('.boteraser-hero-kpi-value').text(fmt);
                                $heroKpi.find('.boteraser-hero-kpi-context').text('Next automatic scan run');
                            }
                        } else {
                            $status.text('Automatic scan disabled.');
                            if ($heroKpi.length) {
                                $heroKpi.removeClass('boteraser-hero-kpi--low boteraser-hero-kpi--medium boteraser-hero-kpi--high')
                                        .addClass('boteraser-hero-kpi--neutral');
                                $heroKpi.find('.boteraser-hero-kpi-value').text('Not scheduled');
                                $heroKpi.find('.boteraser-hero-kpi-context').text('Enable Automatic Scan to schedule');
                            }
                        }
                    } else {
                        $status.text('Error.');
                        if ($changed && prevVal !== null) {
                            $changed.prop('checked', prevVal);
                        }
                    }
                })
                .fail(function() {
                    $status.text('Error.');
                    if ($changed && prevVal !== null) {
                        $changed.prop('checked', prevVal);
                    }
                });
        },

        saveAutoScanFilesThemesPlugins: function($changed) {
            var enabled = $changed.is(':checked') ? '1' : '0';
            var prevVal = !$changed.is(':checked');
            $.post(this.ajaxUrl, {
                action:  'boteraser_save_auto_scan_files_themes_plugins',
                nonce:   this.nonce,
                enabled: enabled
            })
                .fail(function() {
                    $changed.prop('checked', prevVal);
                });
        },

        saveAutoQuarantine: function($changed) {
            var enabled = $changed.is(':checked') ? '1' : '0';
            var prevVal = !$changed.is(':checked');
            $.post(this.ajaxUrl, {
                action:  'boteraser_save_auto_quarantine',
                nonce:   this.nonce,
                enabled: enabled
            })
                .fail(function() {
                    $changed.prop('checked', prevVal);
                });
        },

        saveWafRuleset: function($changed) {
            var enabled = $changed.is(':checked') ? '1' : '0';
            var prevVal = !$changed.is(':checked');
            $.post(this.ajaxUrl, {
                action:  'boteraser_save_waf_ruleset',
                nonce:   this.nonce,
                enabled: enabled
            })
                .fail(function() {
                    $changed.prop('checked', prevVal);
                });
        },

        // ---- Save upload & plugin protection toggles ----
        saveUploadProtection: function($changed) {
            var field   = $changed.attr('name');
            var enabled = $changed.is(':checked') ? '1' : '0';
            var prevVal = !$changed.is(':checked');
            $.post(this.ajaxUrl, {
                action:  'boteraser_save_upload_protection',
                nonce:   this.nonce,
                field:   field,
                enabled: enabled
            })
                .fail(function() {
                    $changed.prop('checked', prevVal);
                });
        },

        // ---- Save notification setting ----
        saveNotify: function($changed) {
            var $status      = $('#be-notify-status');
            var $emailStatus = $('#be-notify-email-status');
            var enabled      = $('#be-notify-enabled').is(':checked') ? '1' : '0';
            var email        = $('#be-notify-email').val().trim();
            var prevVal      = $changed ? !$changed.is(':checked') : null;
            $status.text('Saving...');
            $.post(this.ajaxUrl, {
                action:  'boteraser_save_notify',
                nonce:   this.nonce,
                enabled: enabled,
                email:   email
            })
                .done(function(resp) {
                    if (resp.success) {
                        $status.text('Saved.');
                        if (resp.data.email) {
                            $emailStatus.text(resp.data.email);
                        }
                    } else {
                        $status.text('Error: ' + (resp.data || ''));
                        if ($changed && prevVal !== null) {
                            $changed.prop('checked', prevVal);
                        }
                    }
                    setTimeout(function() { $status.text(''); }, 2500);
                })
                .fail(function() {
                    $status.text('Error saving.');
                    if ($changed && prevVal !== null) {
                        $changed.prop('checked', prevVal);
                    }
                });
        },

        // ---- Diff modal ----
        openDiffModal: function(file) {
            var self = this;
            var $modal = $('#be-diff-modal');

            $modal.data('file', file);
            $modal.find('#be-diff-file-name').text(file);
            $modal.find('#be-diff-source-label').text('');
            $modal.find('#be-diff-original').empty();
            $modal.find('#be-diff-current').empty();
            $modal.find('#be-diff-loading').show();
            $modal.find('#be-diff-content').hide();
            $modal.find('#be-diff-clean').hide();
            $modal.find('#be-diff-restore-btn').show();
            $modal.find('#be-diff-error').hide().text('');
            $modal.css('display', 'flex');

            $.post(this.ajaxUrl, {
                action: 'boteraser_get_file_diff',
                nonce:  this.nonce,
                file:   file
            })
            .done(function(resp) {
                $modal.find('#be-diff-loading').hide();
                if (!resp.success) {
                    $modal.find('#be-diff-error').text(resp.data || 'Failed to load diff.').show();
                    return;
                }
                var d = resp.data;
                $modal.find('#be-diff-source-label').text(d.source_label);

                if (d.original === d.current) {
                    $modal.find('#be-diff-clean').show();
                    $modal.find('#be-diff-restore-btn').hide();
                } else {
                    $modal.find('#be-diff-clean').hide();
                    $modal.find('#be-diff-restore-btn').show();
                    $modal.find('#be-diff-content').show();
                    var diff = self.computeDiff(d.original, d.current);
                    self.renderDiffColumns($modal, diff);
                }
            })
            .fail(function() {
                $modal.find('#be-diff-loading').hide();
                $modal.find('#be-diff-error').text('Network error loading diff.').show();
            });
        },

        computeDiff: function(originalText, currentText) {
            var origLines = originalText.split('\n');
            var currLines = currentText.split('\n');
            var result    = [];

            // Simple LCS-based unified diff
            var m = origLines.length, n = currLines.length;
            // Build LCS length table (bounded to avoid O(m*n) on huge files)
            var maxLines = 2000;
            var truncated = false;
            if (m > maxLines || n > maxLines) {
                origLines = origLines.slice(0, maxLines);
                currLines = currLines.slice(0, maxLines);
                m = origLines.length;
                n = currLines.length;
                truncated = true;
            }

            var dp = [];
            for (var i = 0; i <= m; i++) {
                dp[i] = new Array(n + 1).fill(0);
            }
            for (var i = 1; i <= m; i++) {
                for (var j = 1; j <= n; j++) {
                    dp[i][j] = (origLines[i-1] === currLines[j-1])
                        ? dp[i-1][j-1] + 1
                        : Math.max(dp[i-1][j], dp[i][j-1]);
                }
            }

            // Backtrack
            var i = m, j = n;
            var ops = [];
            while (i > 0 || j > 0) {
                if (i > 0 && j > 0 && origLines[i-1] === currLines[j-1]) {
                    ops.push({ type: 'same', orig: origLines[i-1], curr: currLines[j-1] });
                    i--; j--;
                } else if (j > 0 && (i === 0 || dp[i][j-1] >= dp[i-1][j])) {
                    ops.push({ type: 'add', curr: currLines[j-1] });
                    j--;
                } else {
                    ops.push({ type: 'del', orig: origLines[i-1] });
                    i--;
                }
            }
            ops.reverse();

            if (truncated) {
                ops.push({ type: 'truncated' });
            }
            return ops;
        },

        renderDiffColumns: function($modal, diff) {
            var self    = this;
            var $orig   = $modal.find('#be-diff-original').empty();
            var $curr   = $modal.find('#be-diff-current').empty();
            var origNum = 1, currNum = 1;

            $.each(diff, function(idx, op) {
                if (op.type === 'truncated') {
                    $orig.append('<div class="be-diff-truncated">... (truncated at 2000 lines)</div>');
                    $curr.append('<div class="be-diff-truncated">... (truncated at 2000 lines)</div>');
                    return;
                }
                var origLine = '', currLine = '';
                if (op.type === 'same') {
                    origLine = '<div class="be-diff-line same"><span class="be-diff-num">' + origNum + '</span><span class="be-diff-code">' + self.escHtml(op.orig) + '</span></div>';
                    currLine = '<div class="be-diff-line same"><span class="be-diff-num">' + currNum + '</span><span class="be-diff-code">' + self.escHtml(op.curr) + '</span></div>';
                    origNum++; currNum++;
                } else if (op.type === 'del') {
                    origLine = '<div class="be-diff-line del"><span class="be-diff-num">' + origNum + '</span><span class="be-diff-code">' + self.escHtml(op.orig) + '</span></div>';
                    currLine = '<div class="be-diff-line empty"><span class="be-diff-num"></span><span class="be-diff-code"></span></div>';
                    origNum++;
                } else if (op.type === 'add') {
                    origLine = '<div class="be-diff-line empty"><span class="be-diff-num"></span><span class="be-diff-code"></span></div>';
                    currLine = '<div class="be-diff-line add"><span class="be-diff-num">' + currNum + '</span><span class="be-diff-code">' + self.escHtml(op.curr) + '</span></div>';
                    currNum++;
                }
                $orig.append(origLine);
                $curr.append(currLine);
            });
        },

        restoreFile: function(file) {
            var self = this;
            var $btn = $('#be-diff-restore-btn').prop('disabled', true).text('Restoring...');

            $.post(this.ajaxUrl, {
                action: 'boteraser_restore_file',
                nonce:  this.nonce,
                file:   file
            })
            .done(function(resp) {
                $btn.prop('disabled', false).text('Restore Original');
                if (resp.success) {
                    $('#be-diff-modal').hide();
                    // Remove the row from findings table
                    $('#be-findings-tbody tr[data-file="' + file + '"]').fadeOut(400, function() { $(this).remove(); });
                    // Show success notice
                    var $notice = $('<div class="notice notice-success is-dismissible"><p>'
                        + '<strong>File restored:</strong> ' + self.escHtml(file)
                        + '<br><small>Backup saved. Restored from: ' + self.escHtml(resp.data.restored_from) + '</small>'
                        + '</p></div>');
                    $('.wrap h1').first().after($notice);
                    setTimeout(function() { $notice.fadeOut(600, function() { $(this).remove(); }); }, 6000);
                } else {
                    alert('Restore failed: ' + (resp.data || 'Unknown error'));
                }
            })
            .fail(function() {
                $btn.prop('disabled', false).text('Restore Original');
                alert('Network error during restore.');
            });
        },

        // ---- Confirm modal ----
        confirm: function(title, body, callback) {
            $('#be-modal-title').text(title);
            $('#be-modal-body').html(body);
            $('#be-confirm-modal').removeClass('be-hidden').css('display', 'flex');
            $('#be-modal-confirm').off('click').on('click', function() {
                $('#be-confirm-modal').addClass('be-hidden').hide();
                callback();
            });
        },

        // Returns true if the file path can be resolved to a WordPress.org original
        // (core, plugin, or theme). Uploads and mu-plugins are excluded.
        isResolvableFile: function(filePath) {
            if (!filePath) return false;
            var p = filePath.replace(/\\/g, '/');
            return p.indexOf('wp-includes/') === 0
                || p.indexOf('wp-admin/') === 0
                || p.indexOf('wp-content/plugins/') === 0
                || p.indexOf('wp-content/themes/') === 0
                || /^wp-[a-z].*\.php$/.test(p); // root-level core files like wp-login.php
        },

        escHtml: function(str) {
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        }
    };

    // ===== Brute Force Dashboard Controls =====
    var BFSettings = {
        init: function() {
            var self = this;
            self.$card   = $('#be-bf-dash-card');
            if (!self.$card.length) return;

            self.$toggle      = $('#be-bf-toggle');
            self.$settings    = $('#be-bf-settings');
            self.$maxAttempts = $('#be-bf-max-attempts');
            self.$windowMin   = $('#be-bf-window-minutes');
            self.$blockMin    = $('#be-bf-block-minutes');
            self.$saveBtn     = $('#be-bf-save-settings');
            self.$saveStatus  = $('#be-bf-save-status');

            // Toggle enabled/disabled
            self.$toggle.on('change', function() {
                var enabled = $(this).is(':checked');
                self.$settings.toggle(enabled);
                self.$toggle.next('.boteraser-toggle-text').text(enabled ? 'Enabled' : 'Disabled');
                self.save();
            });

            // Save settings button
            self.$saveBtn.on('click', function() {
                self.save();
            });

            // Enter key in inputs triggers save
            self.$maxAttempts.add(self.$windowMin).on('keydown', function(e) {
                if (e.which === 13) self.save();
            });
        },

        save: function() {
            var self = this;
            var enabled      = self.$toggle.is(':checked') ? '1' : '0';
            var maxAttempts  = parseInt(self.$maxAttempts.val(), 10) || 5;
            var windowMin    = parseInt(self.$windowMin.val(), 10) || 15;
            var blockMin     = parseInt(self.$blockMin.val(), 10) || 15;

            // Clamp max attempts only (window is now a hardcoded select dropdown)
            maxAttempts = Math.max(1, Math.min(50, maxAttempts));
            self.$maxAttempts.val(maxAttempts);

            self.$saveStatus.text('Saving...').removeClass('success error');

            $.post(ajaxurl, {
                action:        'boteraser_save_bf_settings',
                nonce:         (window.boteraser_config && boteraser_config.nonce) || '',
                enabled:       enabled,
                max_attempts:  maxAttempts,
                window_minutes: windowMin,
                block_minutes: blockMin
            })
                .done(function(resp) {
                    if (resp.success) {
                        self.$saveStatus.text('Saved.').addClass('success');
                    } else {
                        self.$saveStatus.text('Error: ' + (resp.data || '')).addClass('error');
                    }
                    setTimeout(function() { self.$saveStatus.text('').removeClass('success error'); }, 2500);
                })
                .fail(function() {
                    self.$saveStatus.text('Network error.').addClass('error');
                    setTimeout(function() { self.$saveStatus.text('').removeClass('error'); }, 2500);
                });
        }
    };

    // =========================================================================
    // Scanner View Tabs (Scan Results / Upload Alerts)
    // =========================================================================
    var ScannerTabs = {
        init: function() {
            var container = document.querySelector('[data-be-scanner]');
            if (!container) return;
            var tabs   = container.querySelectorAll('[data-be-scanner-tab]');
            var panels = document.querySelectorAll('[data-be-scanner-panel]');
            tabs.forEach(function(tab) {
                tab.addEventListener('click', function() {
                    var target = tab.getAttribute('data-be-scanner-tab');
                    tabs.forEach(function(t) {
                        var active = t === tab;
                        t.classList.toggle('is-active', active);
                        t.setAttribute('aria-selected', active ? 'true' : 'false');
                    });
                    panels.forEach(function(p) {
                        if (p.getAttribute('data-be-scanner-panel') === target) {
                            p.removeAttribute('hidden');
                        } else {
                            p.setAttribute('hidden', '');
                        }
                    });
                });
            });
        }
    };

    // =========================================================================
    // Upload Alerts Dismiss (Scanner page)
    // =========================================================================
    var UploadAlerts = {
        init: function() {
            var $tbody = $('#be-ua-tbody');
            if (!$tbody.length) return;

            // Dismiss single row
            $tbody.on('click', '.be-ua-dismiss-one', function() {
                var $btn  = $(this);
                var $row  = $btn.closest('.be-ua-row');
                var idx   = parseInt($btn.data('idx'), 10);
                var nonce = $btn.data('nonce');

                $btn.prop('disabled', true).text('...');
                $.post(ajaxurl, {
                    action : 'boteraser_dismiss_upload_alert',
                    nonce  : nonce,
                    idx    : idx
                }).always(function(resp) {
                    $row.fadeOut(200, function() {
                        $row.remove();
                        UploadAlerts.reindex();
                        UploadAlerts.updateBadge(resp.success ? (resp.data.remaining || 0) : null);
                        UploadAlerts.checkEmpty();
                    });
                });
            });

            // Dismiss all
            $('#be-ua-dismiss-all').on('click', function() {
                var $btn  = $(this);
                var nonce = $btn.data('nonce');
                $btn.prop('disabled', true).text('...');
                $.post(ajaxurl, {
                    action : 'boteraser_dismiss_all_upload_alerts',
                    nonce  : nonce
                }).always(function() {
                    $('#be-ua-tbody .be-ua-row').fadeOut(200, function() {
                        $(this).remove();
                        UploadAlerts.updateBadge(0);
                        UploadAlerts.checkEmpty();
                        $('#be-ua-dismiss-all').hide();
                    });
                });
            });
        },

        reindex: function() {
            $('#be-ua-tbody .be-ua-row').each(function(i) {
                $(this).attr('data-idx', i);
                $(this).find('[data-idx]').attr('data-idx', i);
            });
        },

        updateBadge: function(count) {
            var $badges = $('.be-ua-tab-badge');
            if (count === null || count === undefined) return;
            if (count <= 0) {
                $badges.remove();
            } else {
                $badges.text(count);
            }
        },

        checkEmpty: function() {
            if ($('#be-ua-tbody .be-ua-row').length === 0) {
                var emptyHtml = '<tr><td colspan="6"><div class="boteraser-empty-state" style="padding:32px 0;">'
                    + '<p style="margin:0 0 4px;font-weight:600;">No upload alerts</p>'
                    + '<p style="margin:0;color:#94a3b8;">All uploads and installations have been clean so far.</p>'
                    + '</div></td></tr>';
                $('#be-ua-tbody').html(emptyHtml);
            }
        }
    };

    // ===== Visitor IP Source =====
    var IPSourceSettings = {
        init: function() {
            var self = this;
            self.$select   = $('#be-ipsrc-select');
            if (!self.$select.length) return;
            self.$status   = $('#be-ipsrc-status');
            self.$detected = $('#be-ipsrc-detected');

            self.$select.on('change', function() {
                self.save();
            });
        },

        save: function() {
            var self = this;
            self.$status.text('Saving...').removeClass('success error');
            $.post(ajaxurl, {
                action: 'boteraser_save_ip_source',
                nonce:  self.$select.data('nonce') || (window.boteraser_config && boteraser_config.nonce) || '',
                source: self.$select.val()
            })
                .done(function(resp) {
                    if (resp.success) {
                        self.$status.text('Saved.').addClass('success');
                        if (resp.data && resp.data.detected) {
                            self.$detected.text(resp.data.detected);
                        }
                    } else {
                        self.$status.text('Error: ' + (resp.data || '')).addClass('error');
                    }
                    setTimeout(function() { self.$status.text('').removeClass('success error'); }, 2500);
                })
                .fail(function() {
                    self.$status.text('Network error.').addClass('error');
                    setTimeout(function() { self.$status.text('').removeClass('error'); }, 2500);
                });
        }
    };

    $(document).ready(function() {
        Scanner.init();
        BFSettings.init();
        IPSourceSettings.init();
        ScannerTabs.init();
        UploadAlerts.init();

        // WAF ruleset manual sync button
        $('#be-waf-sync-btn').on('click', function() {
            var $btn = $(this);
            var $status = $('#be-waf-sync-status');
            $btn.prop('disabled', true);
            $status.text('Syncing...').removeClass('success error');
            $.post(ajaxurl, {
                action: 'boteraser_waf_sync',
                nonce: $btn.data('nonce')
            })
                .done(function(resp) {
                    if (resp.success && resp.data) {
                        $('#be-waf-count').text(resp.data.count);
                        $('#be-waf-synced').text(resp.data.synced_label);
                        $status.text('Synced.').addClass('success');
                    } else {
                        $status.text('Error: ' + (resp.data || '')).addClass('error');
                    }
                    setTimeout(function() { $status.text('').removeClass('success error'); }, 2500);
                })
                .fail(function() {
                    $status.text('Network error.').addClass('error');
                    setTimeout(function() { $status.text('').removeClass('error'); }, 2500);
                })
                .always(function() {
                    $btn.prop('disabled', false);
                });
        });

        // Threat Lists "Sync now" button
        $('#be-list-sync-btn').on('click', function() {
            var $btn = $(this);
            var $status = $('#be-list-sync-status');
            $btn.prop('disabled', true);
            $status.text('Syncing...').removeClass('success error');
            $.post(ajaxurl, {
                action: 'boteraser_list_sync',
                nonce: $btn.data('nonce')
            })
                .done(function(resp) {
                    if (resp.success && resp.data) {
                        $.each(resp.data.lists || {}, function(name, info) {
                            $('#be-list-count-' + name).text(info.count);
                            $('#be-list-when-' + name).text(info.when);
                        });
                        if (typeof resp.data.country !== 'undefined') {
                            $('#be-country-val').text(resp.data.country);
                        }
                        $status.text('Synced.').addClass('success');
                    } else {
                        $status.text('Error: ' + (resp.data || '')).addClass('error');
                    }
                    setTimeout(function() { $status.text('').removeClass('success error'); }, 2500);
                })
                .fail(function() {
                    $status.text('Network error.').addClass('error');
                    setTimeout(function() { $status.text('').removeClass('error'); }, 2500);
                })
                .always(function() {
                    $btn.prop('disabled', false);
                });
        });

        // System Software Refresh button
        $('#be-sys-refresh-btn').on('click', function() {
            var $btn = $(this);
            $btn.prop('disabled', true);
            $.post(boteraser_config.ajaxUrl, {
                action: 'boteraser_sys_detect',
                nonce: boteraser_config.sysDetectNonce
            }, function(res) {
                if (res.success && res.data) {
                    var d = res.data;
                    if (d.webserver) {
                        var wsParts = d.webserver.split('/');
                        var wsDisplay = wsParts[0].charAt(0).toUpperCase() + wsParts[0].slice(1) + (wsParts[1] ? ' ' + wsParts[1] : '');
                        $('#be-sys-web').text(wsDisplay);
                    }
                    $('#be-sys-php').text(d.php || '—');
                    $('#be-sys-openssh').text(d.openssh || '—');
                    $('#be-sys-linux').text(d.os || '—');
                }
            }).always(function() {
                $btn.prop('disabled', false);
            });
        });
    });

})(jQuery);
