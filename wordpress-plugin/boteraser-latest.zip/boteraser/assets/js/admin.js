/**
 * Boteraser Admin JavaScript
 * Premium WordPress Plugin UI
 *
 * @package Boteraser
 * @version 1.0.0
 */

(function($) {
    'use strict';

    // Global namespace
    window.Boteraser = window.Boteraser || {};

    /**
     * Utility functions
     */
    Boteraser.Utils = {
        /**
         * Simple hash function for API key comparison
         */
        simpleHash: function(str) {
            var hash = 0;
            if (str.length === 0) return hash.toString(16);
            for (var i = 0; i < str.length; i++) {
                var char = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & 0xffffffff;
            }
            return Math.abs(hash).toString(16);
        },

        /**
         * Format number with commas
         */
        formatNumber: function(num) {
            return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },

        /**
         * Format bytes to human readable
         */
        formatBytes: function(bytes, decimals) {
            if (bytes === 0) return '0 Bytes';
            var k = 1024;
            var dm = decimals || 2;
            var sizes = ['Bytes', 'KB', 'MB', 'GB'];
            var i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
        },

        /**
         * Format uptime to human readable
         */
        formatUptime: function(seconds) {
            var days = Math.floor(seconds / 86400);
            var hours = Math.floor((seconds % 86400) / 3600);
            var minutes = Math.floor((seconds % 3600) / 60);
            var parts = [];
            if (days > 0) parts.push(days + 'd');
            if (hours > 0) parts.push(hours + 'h');
            if (minutes > 0) parts.push(minutes + 'm');
            return parts.length > 0 ? parts.join(' ') : '0m';
        },

        /**
         * Debounce function
         */
        debounce: function(func, wait) {
            var timeout;
            return function() {
                var context = this, args = arguments;
                clearTimeout(timeout);
                timeout = setTimeout(function() {
                    func.apply(context, args);
                }, wait);
            };
        }
    };

    /**
     * SVG Icons
     */
    Boteraser.Icons = {
        shield: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>',
        shieldCheck: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><polyline points="9 12 11 14 15 10"></polyline></svg>',
        shieldAlert: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
        shieldX: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="9" y1="9" x2="15" y2="15"></line><line x1="15" y1="9" x2="9" y2="15"></line></svg>',
        key: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>',
        check: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>',
        checkCircle: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
        xCircle: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        alertCircle: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
        info: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
        loader: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>',
        activity: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>',
        server: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>',
        database: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path></svg>',
        cloud: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path></svg>',
        globe: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>',
        users: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        ban: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>',
        fileText: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>',
        settings: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>',
        externalLink: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>',
        refresh: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>',
        clock: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>',
        zap: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>',
        trendingUp: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>',
        trendingDown: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline><polyline points="17 18 23 18 23 12"></polyline></svg>',
        arrowRight: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
        play: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>',
        trash: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>'
    };

    /**
     * API Key Validation Module
     */
    Boteraser.ApiKey = {
        $input: null,
        $wrapper: null,
        $indicator: null,
        savedValidationState: null,
        serverApiKey: '',

        init: function(config) {
            this.$input = $('#boteraser-api-key');
            this.$wrapper = this.$input.closest('.boteraser-api-input-wrapper');
            this.$indicator = $('.boteraser-status-indicator');
            this.savedValidationState = config.validationState || null;
            this.serverApiKey = config.apiKey || '';

            this.bindEvents();
            this.checkInitialState();
        },

        bindEvents: function() {
            var self = this;

            // Input change handler with debounce
            this.$input.on('input', Boteraser.Utils.debounce(function() {
                self.checkApiKeyState();
            }, 300));

            // Focus effects
            this.$input.on('focus', function() {
                self.$wrapper.addClass('focused');
            }).on('blur', function() {
                self.$wrapper.removeClass('focused');
            });
        },

        checkInitialState: function() {
            var currentApiKey = this.$input.val().trim();

            if (currentApiKey === '') {
                this.showNotVerifiedState();
                return;
            }

            if (this.savedValidationState && this.savedValidationState.api_key_hash) {
                var currentKeyHash = Boteraser.Utils.simpleHash(currentApiKey);

                if (currentKeyHash === this.savedValidationState.api_key_hash) {
                    this.updateValidationUI(
                        this.savedValidationState.is_valid,
                        this.savedValidationState.message
                    );
                } else {
                    this.showNotVerifiedState();
                }
            } else {
                this.showNotVerifiedState();
            }
        },

        checkApiKeyState: function() {
            var currentApiKey = this.$input.val().trim();

            if (currentApiKey === '') {
                this.showNotVerifiedState();
                return;
            }

            if (this.savedValidationState && this.savedValidationState.api_key_hash) {
                var currentKeyHash = Boteraser.Utils.simpleHash(currentApiKey);

                if (currentKeyHash === this.savedValidationState.api_key_hash) {
                    this.updateValidationUI(
                        this.savedValidationState.is_valid,
                        this.savedValidationState.message
                    );
                } else {
                    this.showNotVerifiedState();
                }
            } else {
                this.showNotVerifiedState();
            }
        },

        showNotVerifiedState: function() {
            this.$input.removeClass('valid invalid validating');
            this.$indicator
                .removeClass('valid invalid validating visible')
                .find('.boteraser-status-icon-svg').html(Boteraser.Icons.shield);
            this.$indicator.find('.boteraser-status-text').text('Not Verified');
        },

        showValidatingState: function() {
            this.$input.removeClass('valid invalid').addClass('validating');
            this.$indicator
                .removeClass('valid invalid')
                .addClass('validating visible')
                .find('.boteraser-status-icon-svg').html(Boteraser.Icons.loader);
            this.$indicator.find('.boteraser-status-text').text('Validating...');
        },

        updateValidationUI: function(isValid, message) {
            this.$input.removeClass('validating valid invalid');
            this.$indicator.removeClass('validating valid invalid').addClass('visible');

            if (isValid === true) {
                this.$input.addClass('valid');
                this.$indicator.addClass('valid')
                    .find('.boteraser-status-icon-svg').html(Boteraser.Icons.shieldCheck);
                this.$indicator.find('.boteraser-status-text').text(message || 'API Key Valid');
            } else if (isValid === false) {
                this.$input.addClass('invalid');
                this.$indicator.addClass('invalid')
                    .find('.boteraser-status-icon-svg').html(Boteraser.Icons.shieldAlert);
                this.$indicator.find('.boteraser-status-text').text(message || 'Invalid API Key');
            }
        }
    };

    /**
     * Progress Bar Module
     */
    Boteraser.ProgressBar = {
        $bar: null,
        $fill: null,

        init: function() {
            this.$bar = $('.boteraser-progress-bar');
            this.$fill = this.$bar.find('.boteraser-progress-bar-fill');
        },

        show: function() {
            this.$bar.addClass('active');
        },

        hide: function() {
            this.$bar.removeClass('active');
        },

        setProgress: function(percent) {
            this.$fill.css('width', percent + '%');
        }
    };

    /**
     * Stats Animation Module
     */
    Boteraser.Stats = {
        init: function() {
            this.animateCounters();
        },

        animateCounters: function() {
            $('.boteraser-stat-value[data-count]').each(function() {
                var $this = $(this);
                var target = parseInt($this.data('count'), 10);
                var duration = 1000;
                var start = 0;
                var startTime = null;

                function animate(currentTime) {
                    if (!startTime) startTime = currentTime;
                    var progress = Math.min((currentTime - startTime) / duration, 1);
                    var value = Math.floor(progress * (target - start) + start);
                    $this.text(Boteraser.Utils.formatNumber(value));

                    if (progress < 1) {
                        requestAnimationFrame(animate);
                    }
                }

                requestAnimationFrame(animate);
            });
        }
    };


    /**
     * Form Submission Handler
     */
    Boteraser.Forms = {
        init: function() {
            this.bindManualExecution();
        },

        bindManualExecution: function() {
            var $form = $('form[name="boteraser_manual_run"]');
            if (!$form.length) return;

            $form.on('submit', function() {
                Boteraser.ProgressBar.show();
                $(this).find('button[type="submit"]')
                    .prop('disabled', true)
                    .html(Boteraser.Icons.loader + ' Running...');
            });
        }
    };

    /**
     * Tooltips Module
     */
    Boteraser.Tooltips = {
        init: function() {
            var self = this;
            $('[data-tooltip]').each(function() {
                var $el = $(this);
                var text = $el.data('tooltip');

                $el.on('mouseenter', function() {
                    self.show($el, text);
                }).on('mouseleave', function() {
                    self.hide();
                });
            });
        },

        show: function($el, text) {
            this.hide(); // Remove any existing tooltips

            var $tooltip = $('<div class="boteraser-tooltip">' + text + '</div>');
            $('body').append($tooltip);

            var offset = $el.offset();
            var elWidth = $el.outerWidth();
            var tooltipWidth = $tooltip.outerWidth();
            var tooltipHeight = $tooltip.outerHeight();

            // Calculate position
            var left = offset.left + (elWidth / 2) - (tooltipWidth / 2);
            var top = offset.top - tooltipHeight - 12;

            // Ensure tooltip stays within viewport
            if (left < 10) left = 10;
            if (left + tooltipWidth > $(window).width() - 10) {
                left = $(window).width() - tooltipWidth - 10;
            }

            $tooltip.css({
                top: top,
                left: left
            });
        },

        hide: function() {
            $('.boteraser-tooltip').remove();
        }
    };

    /**
     * Sparkline Charts Module
     */
    Boteraser.Sparklines = {
        init: function() {
            var self = this;
            $('.boteraser-sparkline').each(function() {
                var $canvas = $(this);
                var metric = $canvas.data('metric');
                self.draw($canvas[0], metric);
            });
        },

        draw: function(canvas, metric) {
            if (!canvas || !canvas.getContext) return;

            var ctx = canvas.getContext('2d');
            var width = canvas.width;
            var height = canvas.height;

            // Generate sample data (in production, this would come from server)
            var data = this.generateSampleData(metric);

            // Clear canvas
            ctx.clearRect(0, 0, width, height);

            // Find min and max for scaling
            var min = Math.min.apply(null, data);
            var max = Math.max.apply(null, data);
            var range = max - min || 1;

            // Color mapping for each metric
            var colors = {
                'total_requests': { stroke: 'rgba(139, 92, 246, 0.8)', fill: 'rgba(139, 92, 246, 0.1)' },  // Purple
                'unique_ips': { stroke: 'rgba(20, 184, 166, 0.8)', fill: 'rgba(20, 184, 166, 0.1)' },     // Teal
                'blocked_ips': { stroke: 'rgba(239, 68, 68, 0.8)', fill: 'rgba(239, 68, 68, 0.1)' },      // Red
                'recent_activity': { stroke: 'rgba(37, 99, 235, 0.8)', fill: 'rgba(37, 99, 235, 0.1)' }, // Blue (dynamic)
                'blocked_today': { stroke: 'rgba(16, 185, 129, 0.8)', fill: 'rgba(16, 185, 129, 0.1)' }  // Emerald
            };

            var color = colors[metric] || { stroke: 'rgba(37, 99, 235, 0.8)', fill: 'rgba(37, 99, 235, 0.1)' };

            // Draw line
            ctx.beginPath();
            ctx.strokeStyle = color.stroke;
            ctx.lineWidth = 2;
            ctx.lineJoin = 'round';
            ctx.lineCap = 'round';

            for (var i = 0; i < data.length; i++) {
                var x = (i / (data.length - 1)) * width;
                var y = height - ((data[i] - min) / range) * height;

                if (i === 0) {
                    ctx.moveTo(x, y);
                } else {
                    ctx.lineTo(x, y);
                }
            }

            ctx.stroke();

            // Draw area fill
            ctx.lineTo(width, height);
            ctx.lineTo(0, height);
            ctx.closePath();
            ctx.fillStyle = color.fill;
            ctx.fill();
        },

        generateSampleData: function(metric) {
            // Generate 7 days of sample data
            var data = [];
            var baseValue = 100;

            for (var i = 0; i < 7; i++) {
                var variation = Math.random() * 40 - 20;
                data.push(Math.max(0, baseValue + variation));
            }

            return data;
        }
    };

    /**
     * Smooth Scroll
     */
    Boteraser.SmoothScroll = {
        init: function() {
            $('a[href^="#"]').on('click', function(e) {
                var target = $($(this).attr('href'));
                if (target.length) {
                    e.preventDefault();
                    $('html, body').animate({
                        scrollTop: target.offset().top - 100
                    }, 500);
                }
            });
        }
    };

    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        // Only initialize on Boteraser admin pages
        if (!$('.boteraser-wrap').length) return;

        console.log('Boteraser: Initializing admin interface');

        // Initialize modules
        Boteraser.Stats.init();
        Boteraser.ProgressBar.init();
        Boteraser.Forms.init();
        Boteraser.Tooltips.init();
        Boteraser.Sparklines.init();
        Boteraser.SmoothScroll.init();

        // API Key module is initialized from PHP with config
        if (typeof boteraser_config !== 'undefined') {
            Boteraser.ApiKey.init(boteraser_config);

            // Check if we need to scroll to status indicator after page load
            // This happens when validation state was just updated (after form submission)
            if (boteraser_config.validationState && boteraser_config.validationState.message) {
                var timestamp = boteraser_config.validationState.timestamp || 0;
                var now = Math.floor(Date.now() / 1000);

                // If validation state was updated in the last 5 seconds, scroll to it
                if (now - timestamp < 5) {
                    setTimeout(function() {
                        var $indicator = $('.boteraser-status-indicator');
                        if ($indicator.length && $indicator.hasClass('visible')) {
                            $('html, body').animate({
                                scrollTop: $indicator.offset().top - 100
                            }, 500);
                        }
                    }, 100);
                }
            }
        }

        /**
         * Align Manual Execution card height with right column when results are shown
         */
        function alignManualExecutionCard() {
            var $wrapper = $('.boteraser-content-wrapper');

            // Only align if has-results class is present
            if ($wrapper.hasClass('has-results')) {
                var $leftColumn = $('.boteraser-left-column');
                var $rightColumn = $('.boteraser-info-panel');
                var $executionCard = $('.boteraser-execution-section .boteraser-card');
                var $apiCard = $('.boteraser-api-section');
                var $executionSection = $('.boteraser-execution-section');

                if ($leftColumn.length && $rightColumn.length && $executionCard.length && $apiCard.length && $executionSection.length) {
                    // Reset any previous height setting to get natural dimensions
                    $executionCard.css('min-height', '');

                    // Small delay to ensure DOM is fully rendered
                    setTimeout(function() {
                        // Get the total height of right column (without margins)
                        var rightColumnHeight = $rightColumn.outerHeight(false);

                        // Get API card height + its margin-bottom
                        var apiCardHeight = $apiCard.outerHeight(false);
                        var apiCardMarginBottom = parseFloat($apiCard.css('margin-bottom'));

                        // Get execution section margin-top
                        var executionSectionMarginTop = parseFloat($executionSection.css('margin-top'));

                        // Calculate the space that execution card should fill
                        // Total right column height minus (API card + its bottom margin + execution section top margin)
                        var requiredHeight = rightColumnHeight - apiCardHeight - apiCardMarginBottom - executionSectionMarginTop;

                        // Apply min-height to execution card
                        if (requiredHeight > 0) {
                            $executionCard.css('min-height', requiredHeight + 'px');
                        }
                    }, 100);
                }
            } else {
                // Remove min-height when results are not shown
                $('.boteraser-execution-section .boteraser-card').css('min-height', '');
            }
        }

        // Run alignment after page load
        alignManualExecutionCard();

        // Run alignment after window resize
        $(window).on('resize', function() {
            alignManualExecutionCard();
        });

        // Run alignment after images load (if any)
        $(window).on('load', function() {
            alignManualExecutionCard();
        });

        console.log('Boteraser: Admin interface ready');
    });

})(jQuery);
