=== Boteraser ===
Contributors: sofset
Tags: security, bot blocking, ddos protection, bot protection, firewall, ip blocking, api security, brute force protection, bot detection, wordpress security
Requires at least: 4.7
Tested up to: 6.8.1
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A powerful bot protection plugin that blocks malicious bots, secures your site from DDoS attacks, and ensures smooth, safe performance.

== Description ==

**Boteraser** is a powerful WordPress security plugin developed by [Sofset](https://sofset.com), a software development brand focused on creating innovative tools across tech fields. It protects your site from harmful bot traffic, brute-force attacks, and DDoS threats using continuously updated lists of known malicious IPs.

Boteraser connects to a centralized threat intelligence server managed by Sofset. The server aggregates and analyzes data from multiple trusted sources that provide up-to-date threat intelligence, including bot signature feeds, IP blocklists, and automated threat scanners. By leveraging all available intelligence and offloading heavy processing to the cloud, Boteraser delivers strong and efficient protection for your digital assets.

### Key Features:
- Bot blocking powered by continuously updated threat intelligence
- Lightweight and optimized for performance
- Comprehensive security analytics and reporting
- Easy WordPress integration with native admin interface
- Compatible with major caching and security plugins
- Subscription-based protection with Monthly, Semi-Annual, and Annual plans

This plugin is ideal for site owners who want professional, enterprise-grade bot protection with minimal configuration.

== Frequently Asked Questions ==

= Does Boteraser slow down my site? =

No, Boteraser is designed to be lightweight and optimized for performance. It operates efficiently in the background without affecting your site's loading speed or SEO performance.

= Is it compatible with caching plugins? =

Yes, Boteraser works well with popular WordPress caching plugins such as WP Super Cache, W3 Total Cache, and LiteSpeed Cache. It functions at a lower level in the request lifecycle, so it doesn’t interfere with cached content delivery.

= How does Boteraser detect bad bots? =

Boteraser connects to a centralized threat server operated by Sofset, which gathers up-to-date data from multiple trusted sources. This includes curated IP blocklists, bot signatures, and automated analysis tools. Using this intelligence, Boteraser detects and blocks malicious bots based on IP reputation, user-agent patterns, and behavior.

= Can I whitelist specific IPs or bots? =

Yes, Boteraser provides an interface for managing whitelists and blacklists. You can allow specific IPs, bot names, or user agents to bypass the protection filters.

= Will it block Googlebot or other good bots? =

No, Boteraser is built to distinguish between good bots (like Googlebot, Bingbot) and malicious or unknown bots. Legitimate search engine bots will not be blocked unless manually blacklisted.

= Does it protect my API endpoints? =

Yes, Boteraser includes optional features to protect custom API endpoints and block automated API abuse. This is especially useful for headless or custom integrations.

= Why don’t I see Uptime in the plugin dashboard? =

Boteraser attempts to display the server's uptime for monitoring purposes. However, if you don't see it, your hosting environment may be restricting access to system-level information. This is common on shared hosting, where such data is hidden for security reasons. On VPS or dedicated servers, uptime is typically available and visible.

= Can Boteraser stop DDoS attacks? =

Boteraser helps protect your website from bot-driven DDoS attacks by detecting and blocking malicious traffic early in the request phase. It reduces server load by filtering harmful requests before they reach your application, helping your site stay responsive and stable even during periods of increased automated attack traffic.

= Does it support IPv6? =

Yes, Boteraser fully supports both IPv4 and IPv6 addresses. You can manage and block IPs from both address families.

= Will this work on shared hosting? =

Yes, Boteraser is optimized for all hosting types, including shared hosting. It requires no special server configuration and is easy to install with a few clicks.

= How often is Boteraser updated? =

We update Boteraser regularly to ensure it stays effective against the latest threats. Updates may include new detection methods, threat intelligence, performance improvements, and compatibility enhancements.

== Screenshots ==

1. Dashboard overview
2. Blocked IP addresses
3. Logs overview
4. Data payload
5. API key management

== Changelog ==

= 1.0.0 - 2024-07-06 =

🚀 New Features  
- Advanced bot detection system using up-to-date threat intelligence  
- IP reputation checking based on regularly refreshed data  
- Automated threat response system powered by curated blocklists  
- Analytics dashboard with detailed reporting  
- API integration with automated installation script  
- Multi-tier protection plans (Monthly/Semi-Annual/Annual)  

🛡️ Security Improvements  
- End-to-end encryption for data transmission  
- Regular security audits implementation  
- 24/7 infrastructure monitoring  
- Encrypted backup procedures  
- GDPR and CCPA compliance measures  

⚙️ System Updates  
- Frequent updates to keep all threat data up-to-date  
- Continuous aggregation of data from trusted external sources  
- Ongoing infrastructure optimization routines 

🔧 Technical Implementations  
- WordPress plugin for seamless integration with WordPress-powered sites  
- Optional installation script (`be-install.sh`) for VPS and dedicated servers, including non-WordPress environments  
- Script can also be used on WordPress sites as an alternative to the plugin  
- Multi-source data aggregation for threat detection using various technologies    

💼 Business Features  
- Tiered support response times (12/24/48 hours)  
- PayPal integration for secure payments  
- Flexible subscription management  
- Professional technical support system  

📋 Notes  
- Initial stable release  
- Compatible with all major web servers  
- Requires PHP 7.4 or higher  

== Upgrade Notice ==

= 1.0.0 =
This version introduces the first release of our sophisticated bot protection plugin.

