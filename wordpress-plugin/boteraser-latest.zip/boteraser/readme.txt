=== Boteraser ===
Contributors: sofset
Tags: security, bot blocking, ddos protection, bot protection, firewall, ip blocking, api security, brute force protection, bot detection, wordpress security
Requires at least: 4.7
Tested up to: 6.9
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A powerful bot protection plugin that blocks unwanted bots, secures your site from DDoS attacks, and ensures smooth, safe performance.

== Description ==

**Boteraser** is a powerful WordPress security plugin developed by [Sofset](https://sofset.com), a software development brand focused on creating innovative tools across tech fields. It protects your site from harmful bot traffic, brute-force attacks, and DDoS threats using continuously updated lists of known blacklisted IPs.

Boteraser connects to a centralized threat intelligence server managed by Sofset. The server aggregates and analyzes data from multiple trusted sources that provide up-to-date threat intelligence, including bot signature feeds, IP blocklists, and automated threat scanners. By leveraging all available intelligence and offloading heavy processing to the cloud, Boteraser delivers strong and efficient protection for your digital assets.

### Key Features:
- Bot blocking powered by continuously updated threat intelligence
- Lightweight and optimized for performance
- Comprehensive security analytics and reporting
- Easy WordPress integration with native admin interface
- Compatible with major caching and security plugins
- Subscription-based protection with Monthly and Annual plan

This plugin is ideal for site owners who want professional, enterprise-grade bot protection with minimal configuration.

== Privacy & Data Collection ==

This plugin sends data to an external service for bot detection and protection.

**What data is sent:**
- Visitor IP addresses from your site traffic
- Bot identifiers (browser type derived from device information)
- Transmitted periodically to our threat analysis service

**External Service:**
- Service URL: https://user.boteraser.com
- Service operated by: Sofset
- Privacy Policy: https://boteraser.com/privacy-policy/
- Terms of Service: https://boteraser.com/terms-of-service/

**How it works:**
The plugin periodically sends visitor IP addresses and bot identifiers (browser type derived from device information) to our external service for security analysis. Blacklisted IPs are automatically blocked on your site.

**Data Processing:**
- IP addresses are personal data under GDPR
- Data is processed based on legitimate interest (GDPR Article 6(1)(f)) - protecting your website from security threats
- IP addresses are checked in real-time and not permanently stored on our servers beyond operational necessity
- Requires active paid subscription to function

**Site Owner Responsibilities:**
As a site owner using this plugin, you MUST disclose this data collection in your Privacy Policy. You should inform your visitors that:
- IP addresses are collected for security purposes
- IP addresses and bot identifiers (browser type derived from device information) are transmitted to user.boteraser.com for threat analysis
- Data is processed according to Boteraser's Privacy Policy and Terms of Service

**Additional Data Collected Locally:**
- Visitor IP addresses - retained for up to 30 days in local log files
- User-agent strings - browser and device information
- Access timestamps - date and time of each request
- Request URIs - visited page URLs and request methods
- HTTP status codes - response status for each request

For complete details, visit: https://boteraser.com/privacy-policy/

== Disclaimer ==

DISCLAIMER: This is powerful security software and should be used responsibly. It is provided "AS-IS" and "AS-AVAILABLE" without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, or non-infringement. Your use of the software is at your own risk. By downloading, installing or using this software, you agree to our [Terms of Service](https://boteraser.com/terms-of-service/) and [Privacy Policy](https://boteraser.com/privacy-policy/).

== Frequently Asked Questions ==

= Does Boteraser slow down my site? =

No, Boteraser is designed to be lightweight and optimized for performance. It operates efficiently in the background without affecting your site's loading speed or SEO performance.

= Is it compatible with caching plugins? =

Yes, Boteraser works well with popular WordPress caching plugins such as WP Super Cache, W3 Total Cache, and LiteSpeed Cache. It functions at a lower level in the request lifecycle, so it doesn’t interfere with cached content delivery.

= How does Boteraser detect bad bots? =

Boteraser connects to a centralized threat server operated by Sofset, which gathers up-to-date data from multiple trusted sources. This includes curated IP blocklists, bot signatures, and automated analysis tools. Using this intelligence, Boteraser detects and blocks unwanted bots based on IP reputation, user-agent patterns, and behavior.

= Can I whitelist specific IPs or bots? =

Yes, Boteraser provides an interface for managing whitelists and blacklists. You can allow specific IPs, bot names, or user agents to bypass the protection filters.

= Will it block Googlebot or other good bots? =

No, Boteraser is built to distinguish between good bots (like Googlebot, Bingbot) and unwanted or unknown bots. Legitimate search engine bots will not be blocked unless manually blacklisted.

= Does it protect my API endpoints? =

Yes, Boteraser includes optional features to protect custom API endpoints and block automated API abuse. This is especially useful for headless or custom integrations.

= Why don’t I see Uptime in the plugin dashboard? =

Boteraser attempts to display the server's uptime for monitoring purposes. However, if you don't see it, your hosting environment may be restricting access to system-level information. This is common on shared hosting, where such data is hidden for security reasons. On VPS or dedicated servers, uptime is typically available and visible.

= Can Boteraser stop DDoS attacks? =

Boteraser helps protect your website from bot-driven DDoS attacks by detecting and blocking unwanted traffic early in the request phase. It reduces server load by filtering harmful requests before they reach your application, helping your site stay responsive and stable even during periods of increased automated attack traffic.

= Does it support IPv6? =

Yes, Boteraser fully supports both IPv4 and IPv6 addresses. You can manage and block IPs from both address families.

= Will this work on shared hosting? =

Yes, Boteraser is optimized for all hosting types, including shared hosting. It requires no special server configuration and is easy to install with a few clicks.

= How often is Boteraser updated? =

We update Boteraser regularly to ensure it stays effective against the latest threats. Updates may include new detection methods, threat intelligence, performance improvements, and compatibility enhancements.

== Screenshots ==

1. Dashboard overview
2. Blocked IP addresses
3. Logs overview
4. Data payload
5. API key management

== Changelog ==

= 1.0.0 - 2024-07-06 =

🚀 New Features  
- Advanced bot detection system using up-to-date threat intelligence  
- IP reputation checking based on regularly refreshed data  
- Automated threat response system powered by curated blocklists  
- Analytics dashboard with detailed reporting  
- API integration with automated installation script  
- Multi-tier protection plans (Monthly/Annual)  

🛡️ Security Improvements  
- End-to-end encryption for data transmission  
- Regular security audits implementation  
- 24/7 infrastructure monitoring  
- Encrypted backup procedures  
- GDPR and CCPA compliance measures  

⚙️ System Updates  
- Frequent updates to keep all threat data up-to-date  
- Continuous aggregation of data from trusted external sources  
- Ongoing infrastructure optimization routines 

🔧 Technical Implementations  
- WordPress plugin for seamless integration with WordPress-powered sites  
- Optional installation script (`be-install.sh`) for VPS and dedicated servers, including non-WordPress environments  
- Script can also be used on WordPress sites as an alternative to the plugin  
- Multi-source data aggregation for threat detection using various technologies    

💼 Business Features  
- Tiered support response times (12/24/48 hours)  
- PayPal integration for secure payments  
- Flexible subscription management  
- Professional technical support system  

📋 Notes  
- Initial stable release  
- Compatible with all major web servers  
- Requires PHP 7.4 or higher  

== Upgrade Notice ==

= 1.0.0 =
This version introduces the first release of our sophisticated bot protection plugin.

