=== Boteraser ===
Contributors: sofset
Tags: security, bot blocking, ddos protection, bot protection, firewall, ip blocking, brute force protection, bot detection, wordpress security, malware scanner, vulnerability scanner, honeypot
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

All-in-one WordPress security plugin that helps block harmful bots, mitigate brute-force attacks, scan for malware, and defend against DDoS threats using cloud-powered threat intelligence.

== Description ==

**Protect your WordPress site from bots, malware, and attacks — all in one plugin.**

Boteraser is a comprehensive security solution developed by [Sofset](https://sofset.com) that combines multiple layers of protection to keep your WordPress site safe. Unlike other security plugins that focus on just one area, Boteraser provides comprehensive protection: bot blocking, malware scanning, brute force prevention, vulnerability detection, and real-time threat monitoring — all working together seamlessly.

### Why Choose Boteraser?

**Comprehensive Protection in One Plugin**
Stop juggling multiple security plugins. Boteraser combines bot detection, malware scanning, brute force protection, and vulnerability monitoring into a single, easy-to-use solution.

**Cloud-Powered Threat Intelligence**
Your site benefits from threat data collected across thousands of websites. When one site detects a new threat, all Boteraser users are protected within minutes.

**Zero Configuration Required**
Install, activate, and protection starts working automatically. Boteraser works out of the box with sensible defaults, but gives you full control when you need it.

**Performance First**
Security shouldn't slow down your site. Boteraser is engineered for speed — unwanted traffic is stopped at the earliest possible stage, minimizing delays for your visitors. With optional Extended Protection, blocked traffic is rejected before WordPress even loads, so attacks consume very little server resources.

### What Boteraser Protects Against

**Harmful Bots & Scrapers**
Automatically detects and blocks unwanted bots, scrapers, spam bots, and automated attack tools while allowing legitimate crawlers like Googlebot to access your site normally.

**Brute Force Attacks**
Protects your login page from password guessing attacks by tracking failed attempts and automatically blocking aggressive IPs.

**Web Application Attacks**
Helps block common hacking attempts such as SQL injection, cross-site scripting (XSS), and code execution, aiming to stop them before they reach your site.

**Malware & Backdoors**
Scans your entire WordPress installation for malicious code, suspicious files, and security vulnerabilities — then helps you clean them up.

**DDoS Attacks**
Reduces server load by filtering bot traffic early, helping your site stay online during automated attacks.

**Vulnerable Software**
Checks your server components (PHP, web server, OS) and alerts you when updates are available to patch security holes.

### Key Features

**Bot Detection & Blocking**
- Multi-layered bot detection that identifies automated and unwanted traffic with high accuracy
- Automatic blocking of known unwanted IPs from cloud threat intelligence
- Honeypot trap system that catches bots following hidden links
- Verified bot whitelist — legitimate crawlers (Googlebot, Bingbot, etc.) are recognized and allowed through
- Recognizes and safely allows verified AI agents and legitimate signed crawlers, helping prevent modern good bots from being mistakenly blocked
- Country blocking — restrict traffic from specific countries
- Manual control lists — whitelist, greylist, and blacklist IP addresses
- Intelligent classification of threats by type and severity
- 24-hour block duration

**Extended Protection (Pre-WordPress Firewall)**
- Optional firewall mode that runs before WordPress loads on every request (via PHP auto_prepend_file)
- Blocked IPs and blacklisted bots are rejected before WordPress, your theme, or other plugins consume any resources
- One-click setup from the admin — configures .user.ini (PHP-FPM/FastCGI) or .htaccess (mod_php/LiteSpeed) automatically
- Works on Apache, Nginx, and LiteSpeed — the mechanism is PHP-side, independent of the web server
- Coexists with other firewalls that use auto_prepend_file (existing entries are chained, not overwritten)
- Fail-safe by design: any error silently falls through to normal plugin protection

**Brute Force Protection**
- Login attempt tracking with configurable thresholds
- Automatic IP blocking after too many failed attempts
- Protection for wp-login.php and custom login pages
- Configurable time window and attempt limits
- Automatic cleanup of expired tracking data

**Web Application Firewall**
- Helps block common web attacks — SQL injection, cross-site scripting (XSS), remote and local file inclusion, and code execution attempts
- Stops vulnerability scanners and automated exploit tools
- Continuously updated protection rules from cloud threat intelligence
- Request-level filtering that works alongside your existing setup

**Upload & Plugin Protection**
- Helps prevent malicious files in your uploads folder from running
- Blocks dangerous file extensions from being uploaded
- Scans plugins for malware before they are activated
- Automatic rollback protection when an update introduces problems
- Automatic deactivation of plugins found to contain malicious code

**Malware Scanner**
- Comprehensive scanning of WordPress core files, plugins, and themes
- Integrity verification of core, plugins, and themes against their official releases
- Uploads directory monitoring for suspicious files
- Database scanning for malicious code injections
- Server configuration analysis for unauthorized modifications
- Scheduled-task inspection for malicious activity
- File permission auditing
- Smart detection that minimizes false positives from legitimate plugins
- Severity classification (High, Medium, Low) for prioritized action
- Change detection that flags unauthorized modifications to your files

**Quarantine System**
- Secure isolation of malicious files
- One-click restore to original location
- Permanent deletion option
- Download quarantined files for manual inspection
- Automatic plugin deactivation when malicious files are quarantined
- Complete audit trail of all quarantine actions

**Real-Time Upload Scanner**
- Automatic scanning of all uploaded files (media, plugins, themes)
- Instant alerts when malware is detected in uploads
- Admin popup warnings in WordPress dashboard
- Email notifications for immediate action

**Vulnerability Scanner**
- System component version checking (PHP, web server, OS)
- Outdated software detection
- Security patch recommendations
- Regular updates to vulnerability database

**Automated Protection**
- Scheduled malware scans (every 6 hours, twice daily, or daily)
- Automatic malware signature updates
- Email notifications with scan results
- Scan history tracking with visual trends

**Security Dashboard**
- Real-time threat level assessment (Low, Medium, High)
- Active blocked IPs count with trend indicators
- Recent activity metrics
- Protection rate calculation
- Malware health score (0-100)
- Visual sparkline charts showing 7-day trends
- Activity feed with recent blocks and findings

**Admin Bar Integration**
- Quick access to security status from any page
- Color-coded threat indicators
- Real-time metrics at a glance
- Direct links to relevant admin pages

**Blocked IPs Management**
- Paginated list with filtering and search
- Block reason display with detailed explanations
- Time remaining countdown for each block
- One-click unblock functionality
- Manual IP blocking option
- Grace period protection to prevent immediate re-blocking

**Traffic Monitoring**
- Real-time request tracking
- Visual traffic pattern analysis
- Request method breakdown (GET, POST, etc.)
- Error rate monitoring (4xx and 5xx responses)
- Latest request feed with IP, path, and status code

**Logs & Analytics**
- Comprehensive access logging
- 30-day retention with automatic cleanup
- Execution history for manual and scheduled scans
- Log size monitoring with warnings

**Email Notifications**
- Scan summary reports with severity breakdown
- Blocked IP statistics
- Health score and grade
- Customizable notification email address
- Professional HTML-formatted emails

### Premium vs. Free

**Free Features:**
- Bot detection and blocking
- Extended Protection (pre-WordPress blocking)
- Verified AI agent and signed crawler recognition
- Honeypot trap system
- Brute force protection
- Basic malware scanning with integrity verification
- Upload protection (block file execution and dangerous extensions)
- Scan plugins before activation
- Automatic rollback protection on updates
- Blocked IPs management
- Traffic logs and monitoring
- Security dashboard

**Premium Features:**
- Cloud-powered threat intelligence
- Web Application Firewall (SQL injection, XSS, and exploit protection)
- Country blocking and advanced manual lists (whitelist, greylist, blacklist)
- Advanced malware scanning with automatic signature updates
- Scheduled automatic scans
- Real-time upload scanner
- Automatic malware quarantine and plugin deactivation
- Vulnerability scanner
- Email notifications
- Priority support

[Upgrade to Premium](https://boteraser.com) for comprehensive protection.

### Compatibility

- Works with all major caching plugins (WP Super Cache, W3 Total Cache, LiteSpeed Cache)
- Compatible with CDN services (Cloudflare, Akamai, etc.)
- Supports reverse proxies and load balancers
- IPv4 and IPv6 support
- Multisite compatible
- Works on shared hosting, VPS, and dedicated servers
- No special server configuration required
- Extended Protection supports Apache (mod_php and PHP-FPM), Nginx + PHP-FPM, and LiteSpeed

### Easy to Use

Boteraser is designed for both beginners and advanced users:
- **Beginners:** Install and go — protection works automatically in the background
- **Advanced users:** Full control over all settings, manual blocking, detailed logs, and custom scan configurations

### Support & Documentation

- [Documentation & Guides](https://boteraser.com/faq/)
- [Contact Support](https://boteraser.com/contact/)
- [Privacy Policy](https://boteraser.com/privacy-policy/)
- [Terms of Service](https://boteraser.com/terms-of-service/)

== Privacy & Data Collection ==

This plugin sends data to external services for bot detection and security analysis.

**What data is sent:**
- Visitor IP addresses from your site traffic
- Bot identifiers (browser type and device information)
- Malware scan results (for signature updates)
- Server component versions (for vulnerability checking)

**External Service:**
- Service URL: https://user.boteraser.com
- Service operated by: Sofset
- Privacy Policy: https://boteraser.com/privacy-policy/
- Terms of Service: https://boteraser.com/terms-of-service/

**How it works:**
The plugin sends visitor IP addresses and bot identifiers to our threat intelligence service for security analysis. Unwanted IPs are automatically blocked on your site. Malware findings are shared to improve detection across all Boteraser users.

**Data Processing:**
- IP addresses are personal data under GDPR
- Data is processed based on legitimate interest (GDPR Article 6(1)(f)) - protecting your website from security threats
- IP addresses are not permanently stored on our servers beyond operational necessity
- Requires active subscription for premium features

**Site Owner Responsibilities:**
As a site owner using this plugin, you MUST disclose this data collection in your Privacy Policy. You should inform your visitors that:
- IP addresses are collected for security purposes
- IP addresses and bot identifiers are transmitted to user.boteraser.com for threat analysis
- Data is processed according to Boteraser's Privacy Policy and Terms of Service

**Additional Data Collected Locally:**
- Visitor IP addresses - retained for up to 30 days in local log files
- User-agent strings - browser and device information
- Access timestamps - date and time of each request
- Request URIs - visited page URLs
- HTTP status codes - response status for each request

For complete details, visit: https://boteraser.com/privacy-policy/

== Disclaimer ==

DISCLAIMER: This is powerful security software and should be used responsibly. It is provided "AS-IS" and "AS-AVAILABLE" without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, or non-infringement. Your use of the software is at your own risk. By downloading, installing or using this software, you agree to our [Terms of Service](https://boteraser.com/terms-of-service/) and [Privacy Policy](https://boteraser.com/privacy-policy/).

== Frequently Asked Questions ==

= Does Boteraser slow down my site? =

Boteraser is designed to be lightweight and fast. Unwanted traffic is stopped at the earliest possible stage, so the impact on page load times is minimal. Malware scanning runs in the background without noticeably affecting visitor experience.

= What is Extended Protection? =

Extended Protection loads Boteraser before WordPress on every PHP request, using the same auto_prepend_file mechanism as other leading firewalls. Blocked IPs and blacklisted bots receive a 403 response before WordPress, your theme, or any other plugin runs — so attack traffic consumes virtually no server resources. Enable it with one click from the Extended Protection card on the Boteraser dashboard. Without it, Boteraser still blocks the same threats, just slightly later (after WordPress core loads).

= How do I enable or disable Extended Protection? =

Use the Extended Protection card on the Boteraser dashboard — one button enables or disables it. On Apache with mod_php or LiteSpeed the change is immediate (.htaccess). On PHP-FPM/FastCGI (including Nginx) it takes up to ~5 minutes because PHP caches the .user.ini directive. On rare server setups where neither file can be used, the page shows a short snippet to add to php.ini manually.

= Does Extended Protection work with Nginx? =

Yes. The directive is read by PHP itself (via .user.ini), not by the web server, so it works the same on Nginx, Apache, and LiteSpeed.

= Is Extended Protection compatible with other firewall plugins? =

Yes. If another plugin already uses auto_prepend_file, Boteraser chains it after its own check instead of overwriting it, so both firewalls keep working.

= Does uninstalling remove everything? =

Yes — all options, transients, database tables, logs, cached lists, and firewall directives are removed. One small loader file (boteraser-waf.php in the site root) is intentionally left behind because PHP may cache the auto_prepend_file directive for a few minutes after removal; deleting the loader inside that window would take the site down. The file is a harmless no-op and can be deleted manually a few minutes after uninstalling.

= Is it compatible with caching plugins? =

Yes. Boteraser works seamlessly with popular caching plugins like WP Super Cache, W3 Total Cache, and LiteSpeed Cache. It's designed to protect your site without interfering with cached content.

= How does Boteraser detect bad bots? =

Boteraser uses a multi-layered detection engine combined with cloud-based threat intelligence to identify unwanted automated traffic and known bad IPs, while allowing legitimate crawlers like Googlebot to access your site normally.

= Will it block Googlebot or other good bots? =

Boteraser automatically verifies legitimate search engine crawlers, so Googlebot, Bingbot, YandexBot, and other legitimate crawlers are allowed through normally.

= Can I whitelist specific IPs? =

Yes. You can manually manage IP addresses through the Blocked IPs page. The plugin also automatically whitelists verified legitimate crawlers.

= Does Boteraser block SQL injection and XSS attacks? =

The built-in Web Application Firewall helps block common web attacks — including SQL injection, cross-site scripting (XSS), and code execution attempts — aiming to stop them before they reach your site. Its protection rules are kept up to date through cloud threat intelligence.

= Will Boteraser block AI crawlers like ChatGPT or other AI agents? =

Boteraser recognizes verified AI agents and legitimate signed crawlers and allows them through safely, helping prevent modern good bots from being mistakenly blocked. Unwanted or unverified automated traffic is still stopped.

= Can I block traffic from specific countries? =

Yes. Boteraser lets you block traffic originating from countries you choose, giving you an extra layer of control over who can access your site.

= How does the honeypot trap work? =

Boteraser places hidden links on your site that only bots can see. When a bot follows these links, it's identified as automated and blocked. The trap adapts continuously to stay effective against evolving bots.

= What happens when malware is detected? =

You'll receive immediate alerts in your WordPress dashboard. Premium users also get email notifications. You can quarantine malicious files with one click, and the plugin will automatically deactivate infected plugins.

= Can I restore quarantined files? =

Yes. The quarantine system tracks original file locations, so you can restore files with one click if they were flagged incorrectly. You can also permanently delete files or download them for manual inspection.

= Does it protect against brute force attacks? =

Yes. Boteraser tracks failed login attempts and automatically blocks IPs that exceed your configured threshold. You can customize the number of attempts and time window.

= Can I schedule automatic malware scans? =

Yes, premium users can schedule automatic scans every 6 hours, twice daily, or daily. Scans run automatically and you receive email notifications with results.

= How often should I run malware scans? =

For most sites, twice daily scanning provides good coverage. High-traffic sites or sites in high-risk industries may benefit from more frequent scanning. The upload scanner also checks files in real-time as they're uploaded.

= Can Boteraser stop DDoS attacks? =

Boteraser helps protect against bot-driven DDoS attacks by blocking unwanted traffic early and reducing server load. For large-scale DDoS attacks, we recommend combining Boteraser with a CDN service like Cloudflare.

= Does it support IPv6? =

Yes. Boteraser fully supports both IPv4 and IPv6 addresses.

= Will this work on shared hosting? =

Yes. Boteraser works on all hosting types including shared hosting, VPS, and dedicated servers. No special server configuration is required.

= How often is Boteraser updated? =

We update Boteraser regularly with new detection methods, threat intelligence, performance improvements, and security patches. Premium users receive automatic malware signature updates.

= Why don't I see Uptime in the dashboard? =

Some hosting environments restrict access to system-level information for security reasons. This is common on shared hosting. On VPS or dedicated servers, uptime is typically available.

= Does it protect my API endpoints? =

Yes. Boteraser protects all requests to your site, including REST API endpoints, AJAX calls, and custom API routes.

= What happens if the central server is unreachable? =

Boteraser continues to protect your site even when offline. Local blocking, bot detection, and brute force protection all work independently. Only cloud-based threat intelligence updates are delayed until the connection is restored.

= Can I manually block an IP address? =

Yes. You can manually block any IP address through the Blocked IPs page. Manual blocks last for 24 hours like automatic blocks.

= How long are IPs blocked? =

IP blocks last 24 hours, then expire automatically. Expired blocks are cleaned up automatically.

= Can I unblock an IP before it expires? =

Yes. You can unblock any IP with one click from the Blocked IPs page. Unblocked IPs have a short grace period to prevent immediate re-blocking.

= Do I need a premium subscription? =

Boteraser offers robust free protection including bot blocking, brute force prevention, and basic malware scanning. Premium unlocks advanced features like cloud threat intelligence, scheduled scans, upload scanner, vulnerability scanner, and email notifications.

== Screenshots ==

1. Security dashboard with threat level, metrics, and trend charts
2. Blocked IPs management with detailed information
3. Access logs with real-time traffic monitoring
4. Malware scanner with module selection
5. Scan results showing severity and file details
6. Quarantine management with restore options
7. Vulnerability scanner showing outdated components
8. Live traffic visualization
9. Admin bar integration with security overview
10. Upload malware alert popup
11. Email notification example

== Changelog ==

= 1.0.0 =

**Bot Protection**
- Advanced bot detection with multiple detection methods
- Cloud-powered threat intelligence with automatic updates
- Verified AI agent and signed crawler recognition
- Honeypot trap system with adaptive rotation
- Country blocking and manual lists (whitelist, greylist, blacklist)
- Verified bot whitelist for legitimate crawlers
- Automatic IP blocking with 24-hour expiration

**Extended Protection**
- Optional pre-WordPress firewall mode via auto_prepend_file
- Blocks bad IPs and bots before WordPress loads — near-zero resource cost per blocked request
- One-click setup (.user.ini or .htaccess, detected automatically)
- Apache, Nginx, and LiteSpeed support; chains existing auto_prepend_file firewalls
- Fail-safe: errors fall through silently to normal plugin protection

**Web Application Firewall** (Premium)
- Blocks SQL injection, XSS, code execution, and file inclusion attacks
- Stops vulnerability scanners and automated exploit tools
- Continuously updated protection rules from the cloud

**Brute Force Protection**
- Login attempt tracking and rate limiting
- Automatic IP blocking after failed attempts
- Configurable thresholds and time windows
- Protection for all login pages

**Malware Scanner**
- Comprehensive file scanning (core, plugins, themes, uploads)
- Integrity verification against official releases
- Database and server configuration analysis
- Scheduled-task and permission auditing
- Smart detection with minimal false positives
- Severity classification (High, Medium, Low)
- Change detection for unauthorized modifications

**Upload & Plugin Protection**
- Blocks file execution and dangerous extensions in uploads
- Scans plugins for malware before activation
- Automatic rollback protection on updates
- Automatic deactivation of infected plugins

**Quarantine System**
- Secure file isolation
- One-click restore and deletion
- Download option for manual inspection
- Automatic plugin deactivation
- Complete audit trail

**Upload Scanner** (Premium)
- Real-time scanning of all uploads
- Instant malware detection alerts
- Admin popup warnings
- Email notifications

**Vulnerability Scanner** (Premium)
- System component version checking
- Outdated software detection
- Security patch recommendations

**Automated Scanning** (Premium)
- Scheduled scans (6-hour, twice daily, daily)
- Automatic signature updates
- Email notifications with results
- Scan history with visual trends

**Dashboard & Monitoring**
- Real-time threat level assessment
- Blocked IPs count with trends
- Activity metrics and protection rate
- Malware health score (0-100)
- 7-day sparkline charts
- Activity feed
- Admin bar integration
- Live traffic monitoring
- Comprehensive access logs

**Management Tools**
- Blocked IPs management with pagination
- Block reason display with explanations
- One-click unblock functionality
- Manual IP blocking
- Grace period protection
- Execution history tracking

**Notifications** (Premium)
- Email scan reports
- Severity breakdown (high/medium/low)
- Blocked IP statistics
- Health score and grade
- Professional HTML emails

**Compatibility**
- Works with all major caching plugins
- CDN compatible (Cloudflare, Akamai, etc.)
- IPv4 and IPv6 support
- Multisite compatible
- Shared hosting friendly
- PHP 7.4+ and WordPress 5.0+ required

== Upgrade Notice ==

= 1.0.0 =
Initial release with comprehensive bot protection, malware scanning, brute force prevention, and cloud-powered threat intelligence.
