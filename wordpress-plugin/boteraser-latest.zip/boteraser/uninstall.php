<?php
/**
 * Boteraser Uninstall Script
 * 
 * This file runs when the plugin is uninstalled (deleted) from WordPress.
 * It cleans up ALL plugin data including options, transients, cron jobs, and files.
 * 
 * IMPORTANT: This ensures complete data removal - all settings will be lost!
 * Users will need to reconfigure the plugin completely if they reinstall it later.
 * 
 * Data that will be removed:
 * - All WordPress options (API key, host IP, domain, validation state)
 * - All transients (blocked IPs cache, temporary data)
 * - All cron jobs (scheduled tasks)
 * - All plugin files (logs, cached blocked IPs)
 * - All object cache entries
 */

// If uninstall not called from WordPress, then exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Ensure WordPress functions are available
if (!function_exists('delete_option') || !function_exists('get_option')) {
    error_log('Boteraser: WordPress functions not available during uninstall');
    exit;
}

// Define plugin constants needed for cleanup
if (!defined('BOT_ERASER_PLUGIN_DIR')) {
    define('BOT_ERASER_PLUGIN_DIR', dirname(__FILE__) . '/');
}
if (!defined('BOT_ERASER_LOG_PATH')) {
    define('BOT_ERASER_LOG_PATH', WP_CONTENT_DIR . '/uploads/boteraser/logs/access.log');
}

// Log the uninstall start
error_log('Boteraser: Starting complete uninstall and data cleanup...');

// Try to include the main plugin file to access cleanup function
$main_file = dirname(__FILE__) . '/boteraser.php';
if (file_exists($main_file)) {
    require_once $main_file;
}

// Execute the comprehensive cleanup function
if (function_exists('bot_eraser_cleanup_all_data')) {
    bot_eraser_cleanup_all_data();
    error_log('Boteraser: Complete cleanup executed via main function');
} else {
    error_log('Boteraser: ERROR - Main cleanup function not found, plugin may be corrupted');
}

// Final verification - check if any plugin data remains
if (function_exists('get_option')) {
    $remaining_options = [];
    $check_options = ['bot_eraser_api_key', 'bot_eraser_host_ip', 'bot_eraser_domain', 'bot_eraser_api_validation_state'];
    foreach ($check_options as $option) {
        if (get_option($option) !== false) {
            $remaining_options[] = $option;
        }
    }

    if (!empty($remaining_options)) {
        error_log('Boteraser: WARNING - Some options may still exist: ' . implode(', ', $remaining_options));
    } else {
        error_log('Boteraser: SUCCESS - All plugin data has been completely removed');
    }
}
