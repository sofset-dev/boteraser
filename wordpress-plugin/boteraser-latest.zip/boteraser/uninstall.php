<?php
/**
 * Boteraser Uninstall Script
 * 
 * This file runs when the plugin is uninstalled (deleted) from WordPress.
 * It cleans up ALL plugin data including options, transients, cron jobs, and files.
 * 
 * IMPORTANT: This ensures complete data removal - all settings will be lost!
 * Users will need to reconfigure the plugin completely if they reinstall it later.
 * 
 * Data that will be removed:
 * - All WordPress options (API key, host IP, domain, validation state)
 * - All transients (blocked IPs cache, temporary data)
 * - All cron jobs (scheduled tasks)
 * - All plugin files (logs, cached blocked IPs)
 * - All object cache entries
 */

// If uninstall not called from WordPress, then exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Ensure WordPress functions are available
if (!function_exists('delete_option') || !function_exists('get_option')) {
    error_log('Boteraser: WordPress functions not available during uninstall');
    exit;
}

// Define plugin constants needed for cleanup
if (!defined('BOT_ERASER_PLUGIN_DIR')) {
    define('BOT_ERASER_PLUGIN_DIR', dirname(__FILE__) . '/');
}
if (!defined('BOT_ERASER_LOG_PATH')) {
    define('BOT_ERASER_LOG_PATH', BOT_ERASER_PLUGIN_DIR . 'logs/access.log');
}

// Log the uninstall start
error_log('Boteraser: Starting complete uninstall and data cleanup...');

// Try to include the main plugin file to access cleanup function
$main_file = dirname(__FILE__) . '/boteraser.php';
if (file_exists($main_file)) {
    require_once $main_file;
}

// Execute the comprehensive cleanup function
if (function_exists('bot_eraser_cleanup_all_data')) {
    bot_eraser_cleanup_all_data();
    error_log('Boteraser: Complete cleanup executed via main function');
} else {
    // Comprehensive fallback cleanup if main function is not available
    error_log('Boteraser: Main cleanup function not found - performing comprehensive fallback cleanup');
    
    // Clean up ALL WordPress options
    $options_to_delete = [
        'bot_eraser_api_key',
        'bot_eraser_host_ip',
        'bot_eraser_domain',
        'bot_eraser_api_validation_state'
    ];
    
    foreach ($options_to_delete as $option) {
        delete_option($option);
        if (function_exists('delete_site_option')) {
            delete_site_option($option); // Also remove from multisite
        }
        
        // Clear from object cache
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete($option, 'options');
            wp_cache_delete($option, 'default');
        }
    }
    
    // Clean up ALL WordPress transients
    $transients_to_delete = [
        'bot_eraser_blocked_ips',
        'bot_eraser_api_key',
        'bot_eraser_process_data'
    ];
    
    foreach ($transients_to_delete as $transient) {
        if (function_exists('delete_transient')) {
            delete_transient($transient);
        }
        if (function_exists('delete_site_transient')) {
            delete_site_transient($transient); // Also remove from multisite
        }
    }
    
    // Clean up WordPress cron jobs completely
    if (function_exists('wp_clear_scheduled_hook')) {
        wp_clear_scheduled_hook('bot_eraser_cron_hook');
    }
    
    // Remove any remaining cron entries manually
    if (function_exists('get_option') && function_exists('update_option')) {
        $cron_array = get_option('cron');
        if (is_array($cron_array)) {
            foreach ($cron_array as $timestamp => $cron) {
                if (isset($cron['bot_eraser_cron_hook'])) {
                    unset($cron_array[$timestamp]['bot_eraser_cron_hook']);
                    if (empty($cron_array[$timestamp])) {
                        unset($cron_array[$timestamp]);
                    }
                }
            }
            update_option('cron', $cron_array);
        }
    }
    
    // Clean up plugin files
    $log_path = BOT_ERASER_LOG_PATH;
    if (file_exists($log_path)) {
        if (unlink($log_path)) {
            error_log('Boteraser: Removed log file: ' . $log_path);
        }
    }
    
    $blocked_ips_path = BOT_ERASER_PLUGIN_DIR . 'includes/blocked-ips.php';
    if (file_exists($blocked_ips_path)) {
        if (unlink($blocked_ips_path)) {
            error_log('Boteraser: Removed blocked IPs file: ' . $blocked_ips_path);
        }
    }
    
    // Remove logs directory if empty
    $logs_dir = BOT_ERASER_PLUGIN_DIR . 'logs/';
    if (is_dir($logs_dir)) {
        $files = scandir($logs_dir);
        // Check if directory is empty (only contains . and ..)
        if (count($files) <= 2) {
            if (rmdir($logs_dir)) {
                error_log('Boteraser: Removed empty logs directory');
            }
        }
    }
    
    // Clear all caches
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
    
    // Clear options cache specifically
    if (function_exists('wp_cache_delete')) {
        wp_cache_delete('alloptions', 'options');
    }
    
    error_log('Boteraser: Fallback cleanup completed');
}

// Final verification - check if any plugin data remains
if (function_exists('get_option')) {
    $remaining_options = [];
    $check_options = ['bot_eraser_api_key', 'bot_eraser_host_ip', 'bot_eraser_domain', 'bot_eraser_api_validation_state'];
    foreach ($check_options as $option) {
        if (get_option($option) !== false) {
            $remaining_options[] = $option;
        }
    }

    if (!empty($remaining_options)) {
        error_log('Boteraser: WARNING - Some options may still exist: ' . implode(', ', $remaining_options));
    } else {
        error_log('Boteraser: SUCCESS - All plugin data has been completely removed');
    }
}
