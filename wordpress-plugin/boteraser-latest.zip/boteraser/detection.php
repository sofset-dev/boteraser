<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('bot_eraser_detect')) {

function bot_eraser_detect(array $ctx, array $config): array {
    $triggered = bot_eraser_build_signals($ctx, $config);
    return bot_eraser_request_verdict($triggered, $ctx);
}

} // function_exists guard

return [
    'version'            => '2026-06-25.3',
    'rate_limit'         => 150,
    'rate_window'        => 300,
    'header_mismatch_min'=> 3,
    'js_grace_seconds'   => 60,
    'fast_submit_ms'     => 500,
    'min_fonts'          => 4,
    'min_hardware'       => 2,
    'bf' => [
        'max_attempts' => 5,
        'window'       => 900,
        'signal_min'   => 3,
    ],
    'patterns' => [
        'ua_claims_bot'  => '/Googlebot|Bingbot|YandexBot|AhrefsBot|GPTBot|ChatGPT-User|OAI-SearchBot|ClaudeBot|PerplexityBot|SemrushBot|MJ12bot|DotBot|PetalBot|Bytespider|SeznamBot|facebookexternalhit|meta-externalagent|DuckDuckBot|Applebot/i',
        'ua_fake'        => '/^(curl|Wget|python-requests|python-urllib|Go-http-client|libwww-perl|Scrapy|masscan|Nmap|sqlmap|Nikto|okhttp|Java\/)/i',
        'webgl_headless' => '/SwiftShader|llvmpipe|Offscreen|Mesa OffScreen/i',
    ],
    'waf' => [
        'scan_query'     => false,
        'crs_min'        => 2,
        'scanner'        => '/sqlmap|nikto|acunetix|nessus|wpscan|zgrab|nuclei|masscan|\bNmap\b|dirbuster|gobuster|WhatWeb/i',
        'path_traversal' => '#(\.\./|\.\.\\\\|%2e%2e/|%2e%2e%5c|\.\.%2f)#i',
        'lfi'            => '#(/etc/passwd|/proc/self/|php://|data://|expect://|file://|/windows/win\.ini)#i',
        'sqli'           => '/(\bunion\b\s+\bselect\b|\bselect\b.+\bfrom\b.+\binformation_schema\b|\bor\b\s+1\s*=\s*1|\'\s+or\s+\'1\'\s*=\s*\'1|sleep\s*\(\s*\d|benchmark\s*\(|\bload_file\s*\(|\binto\s+outfile\b)/i',
        'xss'            => '/(<script\b|<\/script>|javascript:\s*[^;]|onerror\s*=\s*["\']?\w|onload\s*=\s*["\']?\w|<img[^>]+onerror|<svg[^>]+onload)/i',
    ],
];
